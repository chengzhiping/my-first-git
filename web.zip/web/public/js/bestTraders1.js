$(document).ready(function() {
    var flag =1;//(1.周；2.季；3.年)
    //	//加载头部
    $("#wrapHeader").load("/header");
    //加载底部
    $("#indexFooter").load("/footer");
    //大赛排名
    $(".gameRankingList .gameRankingInfo").click(function() {
        $(this).addClass("gameRankingInfoActive").siblings(".gameRankingInfo").removeClass("gameRankingInfoActive")
    })
    //开户参赛和大赛规则的跳转
    $(".subscriptionsBox").click(function(){
    	window.location.href="/traderPcJion";
    });
    $(".anchorFindBox").click(function(){
    	window.location.href="/traderPcOrder";
    })
    //回到头部
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn();
        } else {
            $(".goTop").stop().fadeOut();
        }
    });
    $(".goTop").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 800)
    });
    // 大赛排行
    var yearPageIndex=1;
    var weekPageIndex=1;
    var seasonPageIndex=1;
    var startTime= 1502035200000;//(2017.08.7)1502380800000:8.11
    var endTime= 1502985600000;//(2018.08.03)
    // 进入页面时选择第几周弹框
    $(".select").click(function () {
        $(".selectWeek").stop().show();
        $(".selectSeason").stop().hide();
        $("#closeWeek").click(function () {
            $(".selectWeek").stop().hide();
        })
    })
    // 选择第几周弹框
    $(".weekTimeTrade").click(function () {
    	$(".bestTradersBtn").html("周赛收益");
        flag = 1;

        //填写当前周
        var today=new Date();
        var weekday=today.getDay();
        var monday=new Date(1000*60*60*24*(1-weekday) + today.getTime());//获得当前周一时间
        var friday=new Date(1000*60*60*24*(5-weekday) + today.getTime());//获得当前周五时间
        // console.log(friday);
        var mondayTime=monday.getTime();
        var fridayTime=friday.getTime();
        // console.log(fridayTime);//周五时间戳
        var weekN = (fridayTime - startTime)/ (7*86400000);
        var weekN1=parseInt(weekN)+1;//第N周
        var monday1=formats(new Date(monday.getTime()));
        var friday1=formats(new Date(friday.getTime()));
        $(".gameRankingTimeLogo").html("第 "+weekN1+" 周");
        $(".weekTimeNow").html(monday1 + " - " + friday1);
        $(".selectSeason").stop().hide();
        $(".select").stop().show();
        $(".incomeTabInfo ul").html("");
        getWeek(weekPageIndex,fridayStr);
        $(".select").click(function () {
            $(".selectWeek").stop().show();
            $(".selectSeason").stop().hide();
            $("#closeWeek").click(function () {
                $(".selectWeek").stop().hide();
            })
        })
    })
    // 选择第几季弹框
    $(".seasonTimeTrade").click(function () {
        flag = 2;
        $(".selectWeek").stop().hide();
        $(".select").stop().show();
        $(".incomeTabInfo ul").html("");
        $(".bestTradersBtn").html("季度收益");
        if(thisSeason==1){
            $(".gameRankingTime .gameRankingTimeLogo").html("第一季：");
            $(".gameRankingTime .weekTimeNow").html("2017.08.7 - 2017.11.03");
        }else if(thisSeason==2){
            $(".gameRankingTime .gameRankingTimeLogo").html("第二季：");
            $(".gameRankingTime .weekTimeNow").html("2017.11.06 - 2018.02.05");
        }else if(thisSeason==3){
            $(".gameRankingTime .gameRankingTimeLogo").html("第三季：");
            $(".gameRankingTime .weekTimeNow").html("2018.02.05 - 2018.05.04");
        }else if(thisSeason==4){
            $(".gameRankingTime .gameRankingTimeLogo").html("第四季：");
            $(".gameRankingTime .weekTimeNow").html("2018.05.07 - 2018.08.03");
        }
        getSeason(thisSeason,seasonPageIndex);
        $(".select").click(function () {
            $(".selectSeason").stop().show();
            $(".selectWeek").stop().hide();
            $("#closeSeason").click(function () {
                $(".selectSeason").stop().hide();
            })
            $("#enterSeason").click(function () {
                $(".selectSeason").stop().hide();
            })
        })
    })
    // 点击年赛，日期选择框去掉
    $(".yearTimeTrade").click(function () {
    	$(".bestTradersBtn").html("年度收益");
        $(".gameRankingTime .gameRankingTimeLogo").html("年赛：");
        $(".gameRankingTime .weekTimeNow").html("2017.08.7 - 2018.08.03");
        // console.log("haaaaaaaaa");
        flag = 3;
        $(".select").stop().hide();
        $(".selectWeek").stop().hide();
        $(".selectSeason").stop().hide();
        $(".incomeTabInfo ul").html("");
        getYear(yearPageIndex);
    })
    var today=new Date();
    var weekday=today.getDay();
    var monday=new Date(1000*60*60*24*(1-weekday) + today.getTime());//获得当前周一时间
    var friday=new Date(1000*60*60*24*(5-weekday) + today.getTime());//获得当前周五时间
    // console.log(friday);
    var mondayTime=monday.getTime();
    var fridayTime=friday.getTime();
    // console.log(fridayTime);//周五时间戳
    var weekN = (fridayTime - startTime)/ (7*86400000);
    var weekN1=parseInt(weekN)+1;//第N周
    var monday1=formats(new Date(monday.getTime()));
    var friday1=formats(new Date(friday.getTime()));
    $(".gameRankingTimeLogo").html("第"+weekN1+"周");
    $(".weekTimeNow").html(monday1 + " - " + friday1);
    var weekarr = friday1.split('.');
    var fridayStr=parseInt(weekarr[0]+weekarr[1]+weekarr[2]);//周五作为参数格式
    //填已经过去的周
    for(var i = 1;i<=weekN1;i++){
        var weekListInner = "<li><span>"+i+"</span></li>";
        $("#selectWhichWeek").append(weekListInner);
    }
    $("#selectWhichWeek li:last span").addClass("selected");
    $("#selectWhichWeek li:last span").css({"color":"#ffffff"});
    // 点击周获得周五参数
    $("#selectWhichWeek li span").click(function () {
        $("#selectWhichWeek li:last span").css({"color":"#2c2c2c"});
        $(this).css({"color":"#ffffff"});
        $(this).parent().siblings().children().css({"color":"#2c2c2c"});
        var weekNumber = parseInt($(this).html());
        // console.log(weekNumber);
        var timetime = 1502380800000 + (weekNumber-1)*604800000;
        // console.log(timetime);
        var fridayStr2 = formats(new Date(1502380800000 + (weekNumber-1)*604800000));//(第N周周五时间)
        // console.log(fridayStr2);
        var fridayStr3 = fridayStr2.split('.');
        var fridayStr4=parseInt(fridayStr3[0]+fridayStr3[1]+fridayStr3[2]);
        var MondayStr2 = formats(new Date(1502035200000 + (weekNumber-1)*604800000));//(第N周周一时间)
        // console.log(MondayStr2);
        fridayStr = fridayStr4;
        $(this).addClass("selected").parent().siblings().children().removeClass("selected");
        $(".gameRankingTimeLogo").html("第"+weekNumber+"周");
        $(".weekTimeNow").html(MondayStr2 + " - " + fridayStr2);
    })
    //周日期点击确认
    $("#enterWeek").click(function () {
        $(".selectWeek").stop().hide();
        $(".incomeTabInfo ul").html("");
        weekPageIndex=1;
        getWeek(weekPageIndex,fridayStr);
    })
    getWeek(1,fridayStr);
    //周排行接口
    function getWeek(weekPageIndex,fridayStr) {
        $.ajax({
            dataType: "json",
            type: "post",
            async: true,
            url: "/api/v3/fo/getProfitRankByType.do",
            data: {
                "type": 1,
                "date": fridayStr,
                "pageIndex": weekPageIndex,
                "pageSize": 15,
            },
            success: function (res) {
                // console.log(fridayStr);
                // console.log(weekPageIndex);
                // console.log(res);
                var startTime= 1502035200000;
                var fridayTime=friday.getTime();
                var weekN = (fridayTime - startTime)/ (7*86400000);
                var weekN1=parseInt(weekN)+1;//第N周
                //console.log(weekN1);
                if(weekPageIndex==1 && res.data.length==0){
                    $(".gameRankingCenter").stop().hide();
                    $(".queshengRanking").stop().show();
                }
                var length=res.data.length;
                $(res.data).each(function(i,k){
                    var profitRate=k.profitRate;
                    var headImgUrl;
                    if(k.userInfo.headImgUrl == "" || k.userInfo.headImgUrl == undefined ){
                        headImgUrl = "../images/anchorHeadAnchor.png";
                    }else{
                        headImgUrl = k.userInfo.headImgUrl;
                    }
                    var nickName=k.userInfo.nickName;
                   /* var field = k.userInfo.field;
                    if(field == "" || field == undefined){
                        field = "暂无持仓...";
                    }*/
                    var uid = k.userInfo.uid;
                    // var grade = i+1;
                    var grade = (weekPageIndex-1)*15 + i + 1;
                    if(weekPageIndex==1){
                        if(i==0){//第一名
                            $(".gameRankingCenterL .firstTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterL .firstTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterL .firstTraderName").html(nickName);
                            $(".gameRankingCenterL .firstTraderProfitRate").html(profitRate+"%");
                        }else if(i==1){//第二名
                            $(".gameRankingCenterR .twoTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterR .twoTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterR .twoTraderHeaderName").html(nickName);
                            $(".gameRankingCenterR .twoTraderProfitRate").html(profitRate+"%");
                        }else if(i==2){//第三名
                            $(".gameRankingCenterR .threeTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterR .threeTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterR .threeTraderHeaderName").html(nickName);
                            $(".gameRankingCenterR .threeTraderProfitRate").html(profitRate+"%");
                        }else{
                            var incomeTabInfoInner = "<li>"+
                                                    "<span class='grade'>"+grade+"</span>"+
                                                    "<img class='gameRankingImg' src='"+headImgUrl+"' alt='' />"+
                                                    "<span class='gameNickName'>"+nickName+"</span>"+
                                                    "<span class='weekIncome'>"+profitRate+"%</span>"+
                                                    // "<span class='lastestIncome'>"+field+"</span>"+
                                                    "<span class='incomeBtn' uid="+uid+">看交易</span>"+
                                                    "</li>";
                            $(".incomeTabInfo ul").append(incomeTabInfoInner);
                        }
                        $(".gameRankingCenterL .firstTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=1&dateDetail="+weekN1;
                        })
                        $(".gameRankingCenterR .twoTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=1&dateDetail="+weekN1;
                        })
                        $(".gameRankingCenterR .threeTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=1&dateDetail="+weekN1;
                        })
                    }else{
                        var incomeTabInfoInner = "<li>"+
                            "<span class='grade'>"+grade+"</span>"+
                            "<img class='gameRankingImg' src='"+headImgUrl+"' alt='' />"+
                            "<span class='gameNickName'>"+nickName+"</span>"+
                            "<span class='weekIncome'>"+profitRate+"%</span>"+
                            // "<span class='lastestIncome'>"+field+"</span>"+
                            "<span class='incomeBtn' uid="+uid+">看交易</span>"+
                            "</li>";
                        $(".incomeTabInfo ul").append(incomeTabInfoInner);
                    }
                    $(".incomeBtn").each(function(){
                        var uid=$(this).attr("uid");
                        $(this).click(function () {
                            window.location.href="userProfile?uid="+uid+"&tab=4&dateType=1&dateDetail="+weekN1;
                        })
                    })
                })
            }
        })
    }

    //获取季排行
    var thisSeason = 3;
    /*if(today <= new Date(2017,11,03).getTime()){
        thisSeason=1;
    }else if(new Date(2017,11,06).getTime() <= today <= new Date(2018,02,05).getTime()){
        thisSeason=2;
    }else if(new Date(2018,02,05).getTime() <= today <= new Date(2018,05,04).getTime()){
        thisSeason=3;
    }else if(new Date(2018,05,07).getTime() <= today <= new Date(2018,08,03).getTime()){
        thisSeason=4;
    };*/
    //填已经过去的季
    for(var i = 1;i<=thisSeason;i++){
        var seasonListInner = "<li><span>"+i+"</span></li>";
        $("#selectWhichSeason").append(seasonListInner);
    }
    $("#selectWhichSeason li:last span").addClass("selected");
    $("#selectWhichSeason li:last span").css({"color":"#ffffff"});
    // 点击季获得参数
    $("#selectWhichSeason li span").click(function () {
        $(this).addClass("selected").parent().siblings().children().removeClass("selected");
        $("#selectWhichSeason li:last span").css({"color":"#2c2c2c"});
        $(this).css({"color":"#ffffff"});
        $(this).parent().siblings().children().css({"color":"#2c2c2c"});
        thisSeason =parseInt($(this).html());
    })
    $("#enterSeason").click(function () {
        // console.log(thisSeason);
        if(thisSeason==1){
            $(".gameRankingTime .gameRankingTimeLogo").html("第一季：");
            $(".gameRankingTime .weekTimeNow").html("2017.08.7 - 2017.11.03");
        }else if(thisSeason==2){
            $(".gameRankingTime .gameRankingTimeLogo").html("第二季：");
            $(".gameRankingTime .weekTimeNow").html("2017.11.06 - 2018.02.05");
        }else if(thisSeason==3){
            $(".gameRankingTime .gameRankingTimeLogo").html("第三季：");
            $(".gameRankingTime .weekTimeNow").html("2018.02.05 - 2018.05.04");
        }else if(thisSeason==4){
            $(".gameRankingTime .gameRankingTimeLogo").html("第四季：");
            $(".gameRankingTime .weekTimeNow").html("2018.05.07 - 2018.08.03");
        }
        $(".selectSeason").stop().hide();
        $(".incomeTabInfo ul").html("");
        seasonPageIndex = 1;
        getSeason(thisSeason,seasonPageIndex);
    })

    function getSeason(thisSeason,seasonPageIndex) {
        $.ajax({
            dataType: "json",
            type: "post",
            async: true,
            url: "/api/v3/fo/getProfitRankByType.do",
            data: {
                "type": 2,
                "season": thisSeason,
                "pageIndex": seasonPageIndex,
                "pageSize": 15,
            },
            success: function (res) {
                // console.log(res);
                // console.log(thisSeason);
                if(seasonPageIndex==1 && res.data.length==0){
                    $("#seasonNoData").stop().show();
                }
                $(res.data).each(function(i,k){
                    var profitRate=k.profitRate;
                    var headImgUrl;
                    if(k.userInfo.headImgUrl == "" || k.userInfo.headImgUrl ==undefined){
                        headImgUrl = "../images/anchorHeadAnchor.png";
                    }else{
                        headImgUrl=k.userInfo.headImgUrl;
                    }
                    var nickName=k.userInfo.nickName;
                    var uid=k.userInfo.uid;
                    /*var field = k.userInfo.field;
                    if(field == "" || field == undefined){
                        field = "暂无持仓...";
                    }
                    var uid = k.userInfo.uid;*/
                    var grade = (seasonPageIndex-1)*15 + i + 1;
                    if(seasonPageIndex==1){
                        if(i==0){//第一名
                            $(".gameRankingCenterL .firstTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterL .firstTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterL .firstTraderName").html(nickName);
                            $(".gameRankingCenterL .firstTraderProfitRate").html(profitRate+"%");
                        }else if(i==1){//第二名
                            $(".gameRankingCenterR .twoTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterR .twoTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterR .twoTraderHeaderName").html(nickName);
                            $(".gameRankingCenterR .twoTraderProfitRate").html(profitRate+"%");
                        }else if(i==2){
                            $(".gameRankingCenterR .threeTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterR .threeTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterR .threeTraderHeaderName").html(nickName);
                            $(".gameRankingCenterR .threeTraderProfitRate").html(profitRate+"%");
                        }else{
                            var incomeTabInfoInner = "<li>"+
                                "<span class='grade'>"+grade+"</span>"+
                                "<img class='gameRankingImg' src='"+headImgUrl+"' alt='' />"+
                                "<span class='gameNickName'>"+nickName+"</span>"+
                                "<span class='weekIncome'>"+profitRate+"%</span>"+
                                // "<span class='lastestIncome'>"+field+"</span>"+
                                "<span class='incomeBtn' uid="+uid+">看交易</span>"+
                                "</li>";
                            $(".incomeTabInfo ul").append(incomeTabInfoInner);
                        }
                        $(".gameRankingCenterL .firstTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=2&dateDetail="+thisSeason;
                        })
                        $(".gameRankingCenterR .twoTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=2&dateDetail="+thisSeason;
                        })
                        $(".gameRankingCenterR .threeTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=2&dateDetail="+thisSeason;
                        })
                    }else{
                        var incomeTabInfoInner = "<li>"+
                            "<span class='grade'>"+grade+"</span>"+
                            "<img class='gameRankingImg' src='"+headImgUrl+"' alt='' />"+
                            "<span class='gameNickName'>"+nickName+"</span>"+
                            "<span class='weekIncome'>"+profitRate+"%</span>"+
                            // "<span class='lastestIncome'>"+field+"</span>"+
                            "<span class='incomeBtn' uid="+uid+">看交易</span>"+
                            "</li>";
                        $(".incomeTabInfo ul").append(incomeTabInfoInner);
                    }
                    $(".incomeBtn").each(function(){
                        var uid=$(this).attr("uid");
                        $(this).click(function () {
                            window.location.href="userProfile?uid="+uid+"&tab=4&dateType=2&dateDetail="+thisSeason;
                        })
                    })
                })
            }
        })
    }
    function getYear(yearPageIndex) {
        $.ajax({
            dataType: "json",
            type: "post",
            async: true,
            url: "/api/v3/fo/getProfitRankByType.do",
            data: {
                "type": 3,
                "pageIndex": yearPageIndex,
                "pageSize": 15,
            },
            success: function (res) {
                // console.log(res);
                var length=res.data.length;
                if(yearPageIndex==1 && res.data.length==0){
                    $("#seasonNoData").stop().show();
                }
                $(res.data).each(function(i,k){
                    var profitRate=k.profitRate;
                    var headImgUrl;
                    if(k.userInfo.headImgUrl == "" || k.userInfo.headImgUrl ==undefined){
                        headImgUrl = "../images/anchorHeadAnchor.png";
                    }else{
                        headImgUrl=k.userInfo.headImgUrl;
                    }
                    var nickName=k.userInfo.nickName;
                    var uid=k.userInfo.uid;
                    /*$.ajax({
                        dataType: "json",
                        type: "get",
                        async: true,
                        url: "/api/v2/fo/getPositionsByUid.do",
                        data: {
                            "uid": uid,
                            "pageIndex": 1,
                            "pageSize": 1
                        },
                        success: function (res) {
                            console.log(uid);
                            console.log(res);
                            if(res.code == 0){

                            }
                        }
                    })*/
                    var grade = (yearPageIndex-1)*15 + i + 1;
                    if(seasonPageIndex==1){
                        if(i==0){//第一名
                            $(".gameRankingCenterL .firstTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterL .firstTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterL .firstTraderName").html(nickName);
                            $(".gameRankingCenterL .firstTraderProfitRate").html(profitRate+"%");
                        }else if(i==1){//第二名
                            $(".gameRankingCenterR .twoTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterR .twoTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterR .twoTraderHeaderName").html(nickName);
                            $(".gameRankingCenterR .twoTraderProfitRate").html(profitRate+"%");
                        }else if(i==2){
                            $(".gameRankingCenterR .threeTraderHeaderUrl").attr("src",headImgUrl);
                            $(".gameRankingCenterR .threeTraderHeaderUrl").attr("uid",uid);
                            $(".gameRankingCenterR .threeTraderHeaderName").html(nickName);
                            $(".gameRankingCenterR .threeTraderProfitRate").html(profitRate+"%");
                        }else{
                            var incomeTabInfoInner = "<li>"+
                                "<span class='grade'>"+grade+"</span>"+
                                "<img class='gameRankingImg' src='"+headImgUrl+"' alt='' />"+
                                "<span class='gameNickName'>"+nickName+"</span>"+
                                "<span class='weekIncome'>"+profitRate+"%</span>"+
                                // "<span class='lastestIncome'></span>"+
                                "<span class='incomeBtn' uid="+uid+">看交易</span>"+
                                "</li>";
                            $(".incomeTabInfo ul").append(incomeTabInfoInner);
                        }
                        $(".gameRankingCenterL .firstTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=3";
                        })
                        $(".gameRankingCenterR .twoTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=3";
                        })
                        $(".gameRankingCenterR .threeTraderHeaderUrl").click(function () {
                            var uid = $(this).attr("uid");
                            window.location.href = "userProfile?uid="+uid+"&tab=4&dateType=3";
                        })
                    }else{
                        var incomeTabInfoInner = "<li>"+
                            "<span class='grade'>"+grade+"</span>"+
                            "<img class='gameRankingImg' src='"+headImgUrl+"' alt='' />"+
                            "<span class='gameNickName'>"+nickName+"</span>"+
                            "<span class='weekIncome'>"+profitRate+"%</span>"+
                            // "<span class='lastestIncome'>"+field+"</span>"+
                            "<span class='incomeBtn' uid="+uid+">看交易</span>"+
                            "</li>";
                        $(".incomeTabInfo ul").append(incomeTabInfoInner);
                    }
                    $(".incomeBtn").each(function(){
                        var uid=$(this).attr("uid");
                        $(this).click(function () {
                            window.location.href="userProfile?uid="+uid+"&tab=4&dateType=3";
                        })
                    })
                })
            }
        })
    }

    //排行加载更多
    $("#scrollBar1").mCustomScrollbar({
        callbacks:{
            onScrollStart:function(){},
            onScroll:function(){},
            onTotalScroll:function(){
                if(flag == 1){//周
                    weekPageIndex++;
                    getWeek(weekPageIndex,fridayStr);
                }else if(flag == 2){//季
                    seasonPageIndex++;
                    getSeason(thisSeason,seasonPageIndex);
                }else if(flag == 3){//年
                    yearPageIndex++;
                    getYear(yearPageIndex);
                }
            },
            onTotalScrollBack:function(){},
            onTotalScrollOffset:80,
            whileScrolling:false,
            whileScrollingInterval:0
        },
        scrollInertia:300
    });
    // 开户参赛
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v1/banner/selectByType.do",
        data: {
            "type": 24
        },
        success: function (res) {
            // console.log(res);
            if (res.code == 0) {

            }
        }
    })
    // 获奖历史
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v1/banner/selectByType.do",
        data: {
            "type": 33,
            "pageIndex": 1,
            "pageSize": 3
        },
        success: function (res) {
            if (res.code == 0) {
                // console.log(res);
                $(res.data).each(function (i, k){
                    var anchorRecommendList = "<a href="+k.id+"><li><img class='gameWinImg' src='"+k.imgUrl+"' alt=''/></li></a>";
                    $(".anchorRecommend ul").append(anchorRecommendList);
                })
            }
        }
    })
    //大赛直播
    $.ajax({
        type: "get",
        async: true,
        dataType: "json",
        url: "/api/v3/live/getContestRoom.do",
        success: function (res) {
            if (res.code == 0) {
                // console.log(res);
                var roomId = res.data.roomId;
                var uid = res.data.liverInfo.uid;
                var status = res.data.status;
                if(status == 1){//直播中
                }else{
                    $(".isLiving").stop().hide();
                }
                $(".latestHotSpotImg").attr("src",res.data.coverUrl);
                $(".latestHotSpotImg").attr("uid",uid);
                $(".latestHotSpotImg").attr("roomid",roomId);
                $(".latestHotSpotTitle").html(res.data.topic);
                $(".latestHotSpotContent").html(res.data.latest.content);
                $(".latestHotSpotBoxRB nickname").html(res.data.liverInfo.nickName+"的直播间");
                $(".partakesNum").html(res.data.partakes);
                $(".subscribersNum").html(res.data.subscribers +"人订阅");
                $(".latestHotSpotBoxRB .time").html(format(new Date(res.data.latest.time))+" 更新");
                $(".latestHotSpotImg").click(function () {
                    var uid = $(this).attr("uid");
                    var roomid = $(this).attr("roomid");
                    window.location.href ="liveNew?uid="+uid+"&roomid="+roomid;
                })
                // console.log(roomId);
                //获取回放列表
                $.ajax({
                    type: "get",
                    async: true,
                    dataType: "json",
                    url: "/api/v3/live/getVideoLivePlaybackList.do",
                    data: {
                        "roomId": roomId,
                        "pageIndex": 1,
                        "pageSize": 3
                    },
                    success: function (res) {
                        // console.log(res);
                        if (res.code == 0) {
                            $(res.data).each(function (i, k){
                                var gamePlaybackList = "<li uid="+k.liverInfo.uid+" roomid="+k.roomId+" playbackId="+k.id+">"+
                                    "<img src='"+k.coverUrl+"' alt='' />"+
                                    "<p class='topicName'>"+k.topic+"</p>"+
                                    "<span class='watchNum'>"+k.watchCount+"人观看</span>"+
                                    "</li>";
                                $(".gamePlayback ul").append(gamePlaybackList);
                            })
                            $(".gamePlayback ul li").click(function () {
                                var uid = $(this).attr("uid");
                                var roomid = $(this).attr("roomid");
                                var playbackId = $(this).attr("playbackId");
                                window.location.href = "liveLookBack?id="+playbackId+"&uid="+uid+"&roomid="+roomid;
                            })
                        }
                    }
                })
            }
        }
    })
    // 大赛活动
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v1/banner/selectByType.do",
        data: {
            "type": 34,
            "pageIndex": 1,
            "pageSize": 3
        },
        success: function (res) {
            if (res.code == 0) {
                // console.log(res);
                $(res.data).each(function (i, k){
                    var bannerType = k.bannerType;//1文章，2短评，3视频，4直播，5静态网页，6主播个人页,7不跳转，8操盘手个人页，9个人实盘页，10话题，11专栏详情页，12=直播间，13=音频,14=回放，15=文字链，16=专题
                    if(bannerType == 1){
                        var topicInnerLIst = "<a href=/article?id=" + k.id + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 2){
                        var topicInnerLIst = "<a href=/shortView?id=" + k.id + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 3){
                        var topicInnerLIst = "<a href=/video?id=" + k.id + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 4 || bannerType == 12){
                        var topicInnerLIst = "<a href=/liveNew?uid=" + k.uid + "&roomid=" + k.roomId + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 5){
                        var topicInnerLIst = "<a href="+k.id+"><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 6 || bannerType == 8 || bannerType == 9){
                        var topicInnerLIst = "<a href=/userProfile?uid=" + k.uid + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 7){
                        var topicInnerLIst = "<li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 10 || bannerType == 15){

                    }else if(bannerType == 11){
                        var topicInnerLIst = "<a href=/columnDetail?id=" + k.id + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 13){
                        var topicInnerLIst = "<a href=/audio?id=" + k.id + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 14){
                        var topicInnerLIst = "<a href=/liveLookBack?id=" + k.id + "uid=" + k.uid + "&roomid=" + k.roomId + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }else if(bannerType == 16){
                        var topicInnerLIst = "<a href=/dissertation?id=" + k.id + "><li>"+
                            "<img src='"+k.imgUrl+"' alt='' />"+
                            "<p class='topicName'>"+k.remarks+"</p>"+
                            "</li></a>";
                        $(".gameActivity ul").append(topicInnerLIst);
                    }
                })
            }
        }
    })
    var eventPageIndex = 1;
    getEventDynamicsList(1);
    // 赛事动态
    function getEventDynamicsList(eventPageIndex) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v3/homePage/eventDynamics.do",
            data: {
                "pageIndex": eventPageIndex,
                "pageSize": 10
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    $(res.data).each(function (i, M){
                        getEventDynamics(M);
                    })
                }
            }
        })
    }
    //赛事动态列表
    function getEventDynamics(M) {
        var type=M.type;
        if(type==0){//最头条
            // console.log(M);
        }else if(type==1){//专栏类目
            //console.log(M);
        }else if(type==2){//话题
            // console.log(M);
        }else if(type==3){//直播
            var liveWrap = "<a href=/liveNew?uid=" +  M.information.liverInfo.uid + "&roomid=" +  M.information.roomId + " >" +
                "<div class='liveWrap' uid=" +  M.information.liverInfo.uid + ">" +
                "<div class='liveL fl'>" +
                "<img class='liveCover' src=" +  M.information.coverUrl + '!220X164' + ">" +
                "<img class='liveSystem' src='images/indexlive.png' />" +
                "</div>" +
                "<div class='videoR fl'>" +
                "<div class='videoRPosition'>" +
                "<p class='videoTitle'>" +  M.information.topic + "</p>" +
                "<p class='videoRBottom'>" +
                "<img class='videoImgAnchorHead fl' src=" +  M.information.liverInfo.headImgUrl + ">" +
                "<span class='videoImgAnchorNickName fl'>" +  M.information.liverInfo.nickName + "</span>" +
                "<span class='videoImgTime fl'>" + format(new Date( M.information.createTime)) + "</span>" +
                "</p></div></div></div></a>";
            $(".gameTrends").append(liveWrap);
            $(".liveCover").one("error", function(e) {
                $(this).attr("src", "images/vedioCoverUrl.jpg")
            });
        }else if(type==4){//回看
            var liveLookWrap = "<a href=/liveLookBack?id=" + M.information.id + "&roomid=" + M.information.roomId + "&uid=" + M.information.liverInfo.uid + ">" +
                "<div class='liveLookWrap' id=" + M.information.id + ">" +
                "<div class='liveL fl'>" +
                "<img class='liveCover' src=" + M.information.coverUrl + '!220X164' + ">" +
                "<img class='liveLookSystem' src='images/playback.png' />" +
                "<img class='videoSystem' src='images/indexvideo.png' />" +
                "</div>" +
                "<div class='videoR fl'>" +
                "<div class='videoRPosition'>" +
                "<p class='videoTitle'>" + M.information.topic + "</p>" +
                "<p class='videoRBottom'>" +
                "<img class='videoImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">" +
                "<span class='videoImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
                "<span class='videoImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
                "</p></div></div></div></a>";
            $(".gameTrends").append(liveLookWrap);
            $(".liveCover").one("error", function(e) {
                $(this).attr("src", "images/vedioCoverUrl.jpg")
            });
        }else if(type==5){//视频
            var videoWrap = "<a href=/video?id=" + M.information.id + ">" +
                "<div class='videoWrap' videoId=" + M.information.id + ">" +
                "<div class='liveL fl'>" +
                "<img class='liveCover' src=" + M.information.coverUrl + '!220X164' + ">" +
                "<img class='videoSystem' src='images/indexvideo.png' />" +
                "<span class='videoTime'>" + durationFun(M.information.duration) + "</span>" +
                "</div>" +
                "<div class='videoR fl'>" +
                "<div class='videoRPosition'>" +
                "<p class='videoTitle'>" + M.information.topic + "</p>" +
                "<p class='videoRBottom'>" +
                "<img class='videoImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">" +
                "<span class='videoImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
                "<span class='videoImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
                "</p></div></div></div></a>";
            $(".gameTrends").append(videoWrap);
        }else if(type==6){//音频
            var indexAudioBox=
                "<a href=/audio?id=" + M.information.id + ">" +
                "<div class='ImgArticleWrap'>"+
                "<p class='ImgArticleImgTitle'>"+M.information.topic+"</p>"+
                "<div class='indexAudioBox'>"+
                "<div class='indexAudioBoxL fl'>"+
                "<img src="+ M.information.liverInfo.headImgUrl +">"+
                "<img src='../images/indexvideo.png'/>"+
                "</div>"+
                "<p class='fl'>"+M.information.topic+"</p>"+
                "<p class='fl audioTime'>" + durationFun(M.information.duration) + "</p>"+
                '</div>'+
                "<p>"+
                "<img class='ImgArticleImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">"+
                "<span class='ImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>"+
                "<span class='mgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>"+
                "</p></div></a>";
            $(".gameTrends").append(indexAudioBox);
        }else if(type==7){//文章
            var content = htmlEncode(M.information.content);
            var imgReg = /<img.*?(?:>|\/>)/gi;
            //匹配src属性
            var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
            var imgArr = content.match(imgReg);
            if(imgArr == null) {
                var ImgArticleWrap = "<a href=/article?id="+ M.information.id + ">" +
                    "<div class='ImgArticleWrap'>" +
                    "<p class='ImgArticleImgTitle'>" + M.information.title + "</p>" +
                    "<p class='ImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
                    "<p>" +
                    "<img class='ImgArticleImgAnchorHead fl' src="+ M.information.liverInfo.headImgUrl + ">" +
                    "<span class='ImgArticleImgAnchorNickName fl'>"  + M.information.liverInfo.nickName + "</span>" +
                    "<span class='mgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
                    "</p></div></a>";
                $(".gameTrends").append(ImgArticleWrap);
                //文章无图，显示内容一行半
                $(".ImgArticleImgInner").each(function() {
                    var shortReviewText = $(this).text().substring(0, 80) + "...";
                    if($(this).text().length > 80) {
                        $(this).text(shortReviewText);
                    }
                });
                $(".ImgArticleImgAnchorHead").one("error", function(e) {
                    $(this).attr("src", "images/anchorHead.png");
                });
            }else{
                src = imgArr[0].match(srcReg);
                if(src[1]){
                    var content = htmlEncode( M.information.content);
                    var oneImgArticleWrap = "<a href=/article?id=" + M.information.id + ">" +
                        "<div class='oneImgArticleWrap' id=" + M.information.id + ">" +
                        "<div class='oneImgArticleL fl'>" +
                        "<img class='fl oneImgArticleImg' src=" + src[1] +  ">" +
                        "</div>" +
                        "<div class='oneImgArticleImgR'>" +
                        "<p class='oneImgArticleImgTitle'>" + M.information.title + "</p>" +
                        "<p class='oneImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
                        "<p>" +
                        "<img class='oneImgArticleImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">" +
                        "<span class='oneImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>"+
                    "<span class='oneImgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
                    "</p></div></div></a>";
                    $(".gameTrends").append(oneImgArticleWrap);
                    //文章无图，显示内容一行半
                    $(".oneImgArticleImgInner").each(function() {
                        var shortReviewText = $(this).text().substring(0, 60) + "...";
                        if($(this).text().length > 60) {
                            $(this).text(shortReviewText);
                        }
                    });
                    $(".oneImgArticleImgAnchorHead").one("error", function(e) {
                        $(this).attr("src", "images/anchorHead.png");
                    });
                }
            }
        }else if(type==10){//大图文章
            var content = htmlEncode( M.information.content);
            var oneImgArticleWrap = "<a href=/article?id=" + M.information.id + ">" +
                "<div class='oneImgArticleWrap' id=" + M.information.id + ">" +
                "<div class='oneImgArticleL fl'>" +
                "<img class='fl oneImgArticleImg' src=" + M.information.coverUrl + '!220X164' + ">" +
                "</div>" +
                "<div class='oneImgArticleImgR'>" +
                "<p class='oneImgArticleImgTitle'>" + M.information.title + "</p>" +
                "<p class='oneImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
                "<p>" +
                "<img class='oneImgArticleImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">" +
                "<span class='oneImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>"+
            "<span class='oneImgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
            "</p></div></div></a>";
            $(".gameTrends").append(oneImgArticleWrap);
            //文章无图，显示内容一行半
            $(".oneImgArticleImgInner").each(function() {
                var shortReviewText = $(this).text().substring(0, 60) + "...";
                if($(this).text().length > 60) {
                    $(this).text(shortReviewText);
                }
            });
            $(".oneImgArticleImgAnchorHead").one("error", function(e) {
                $(this).attr("src", "images/anchorHead.png");
            });
        }else if(type==11){//,11-话题回答
            // console.log(M);
        }else if(type==12){//,12-专题
            var subjectBottomId=M.information.subject.id+"subjectBottomId";
            var subjectHrefId=M.information.subject.id+"subjectHrefId";
            var subjectBoxId=M.information.subject.id+"subjectBoxId";
            var indexThematicBox=
                '<div class="indexThematicBox" id='+subjectBoxId+'>'+
                '<div class="indexThematicBoxT">'+
                '<span>专题</span>'+
                '<span>'+M.information.subject.name+'</span>'+
                '<span class="fr" id='+subjectHrefId+' objectId='+M.information.subject.id+'>更多>></span>'+
                '</div>'+
                '<div class="indexThematicBoxC" id='+subjectBottomId+'>'+
                '</div></div>';
            $(".gameTrends").append(indexThematicBox);
            //专题详情
            $("#"+subjectHrefId).click(function(){
                var dissertationId=$(this).attr("objectId");
                window.location.href="/dissertation?id="+dissertationId;
            })
            var subjectLen=M.information.content.length;
            if(subjectLen==0){
                $("#"+subjectBoxId).stop().hide();
            }else{
                $(M.information.content).each(function(q,S){//内容类型（0-短评 1-文章 2-视频 3-音频 4-回放 5-直播 6-banner 7-PDF）
                    //console.log(S);
                    var id=S.object.id;
                    var imgCoverid=S.object.id+"img";
                    if(S.objectType==2){//视频
                        var contentBotton=
                            "<a href=/video?id=" + S.object.id + ">" +
                            '<li class="indexThematicBoxCInfo fl">'+
                            '<div class="indexThematicBoxCInfoT">'+
                            '<img id='+imgCoverid+' src="'+S.object.coverUrl+'"/>'+
                            '<div class="indexThematicBoxCInfoTCover"></div>'+
                            '</div>'+
                            '<p>'+S.object.topic+'</p>'+
                            '</li></a>';
                        $("#"+subjectBottomId).append(contentBotton);
                    }else if(S.objectType==1){//文章
                        var contentBotton=
                            "<a href=/article?id=" +S.object.id+ ">" +
                            '<li class="indexThematicBoxCInfo fl">'+
                            '<div class="indexThematicBoxCInfoT">'+
                            '<img id='+imgCoverid+' src="'+S.object.coverUrl+'"/>'+
                            '<div class="indexThematicBoxCInfoTCover"></div>'+
                            '</div>'+
                            '<p>'+S.object.title+'</p>'+
                            '</li></a>';
                        $("#"+subjectBottomId).append(contentBotton);
                    }else if(S.objectType==3){//音频
                        var contentBotton=
                            "<a href=/audio?id=" +S.object.id+ ">" +
                            '<li class="indexThematicBoxCInfo fl">'+
                            '<div class="indexThematicBoxCInfoT">'+
                            '<img id='+imgCoverid+' src="'+S.object.coverUrl+'"/>'+
                            '<div class="indexThematicBoxCInfoTCover"></div>'+
                            '</div>'+
                            '<p>'+S.object.topic+'</p>'+
                            '</li></a>';
                        $("#"+subjectBottomId).append(contentBotton);
                    }
                    $("#"+imgCoverid).one("error", function(e) {
                        $(this).attr("src", "images/vedioCoverUrl.jpg");
                    });
                })
            }
        }else if(type==13){//,13-直播间
//		  console.log(M);
            var liveCarouselBoxOlnyid="liveCarouselBoxOlnyid"+M.information.roomId;
            var onlyLiveRoomId="onlyLiveRoomId"+M.information.roomId;
            var liveBoxOnlyId="liveBoxOnlyId111"+M.information.roomId;
            var liveCarouselBox=
                '<div class="liveCarouselBox liveCarouselBoxOlny" id='+onlyLiveRoomId+' roomid='+M.information.roomId+' uid='+M.information.liverInfo.uid+' >'+
                '<p class="anchorRecommendTop anchorRecommendTopOnly">'+M.information.description+'<span class="fr">'+M.information.subscribers.count+'人参与</span></p>'+
                '<div class="liveCarouselInfo liveCarouselInfoOnly">'+
                '<img class="fl" src="'+M.information.liverInfo.headImgUrl+'" />'+
                '<div class="liveCarouselInfoR fl">'+
                '<p><span>'+M.information.liverInfo.nickName+'</span><span>'+format(new Date(M.information.createTime))+'</span></p>'+
                '<div id='+liveBoxOnlyId+' class="liveBoxOnly">'+
                '<div class="JQ-content-box">'+
                '<div class="liveCarouselInfoBox JQ-slide-content liveCarouselInfoBoxOnly" id='+liveCarouselBoxOlnyid+'>'+
                '</div></div></div></div></div></div>';
            $(".gameTrends").append(liveCarouselBox);
            $(M.information.newest).each(function(Q,E){
                var newestBox=
                    "<p>"+E.content+"</p>";
                $("#"+liveCarouselBoxOlnyid).append(newestBox);
            });
            $("#"+liveBoxOnlyId).Slide({
                effect: "scroolY",
                speed: "slow",
                autoPlay: true,
                steps: 1,
                timer: 3000
            });
            $(document).on("click", "#"+onlyLiveRoomId, function(e) {
                var roomid = $(this).attr("roomid");
                var uid = $(this).attr("uid");
                window.location.href="/liveNew?uid="+uid+"&roomid="+roomid;
            })
        }else if(type==14){//,14-活动
        }else if(type==16){//,16-实盘
            // console.log(M);
        }else if(type==15){//,15-直播间轮播
        }
    }
    // 滚动到底部加载更多
    $(window).scroll(function() {
        var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop());
        if($(document).height() <= totalheight) {
            eventPageIndex++;
            getEventDynamicsList(eventPageIndex);
        }
    });

    // 轮播
    $(".commentTopBoxLCarousel").load("/liveCarousel1");



})