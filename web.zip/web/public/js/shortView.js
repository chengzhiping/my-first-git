$(document).ready(function () {
    var articleid = GetQueryString("id");
    var userId;
    var usertoken;
    var articleUserUid;
    var pageIndex1=1;
    var pageIndex2=1;
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");
    // 检查用户是否登录
    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function (res) {
            // console.log(res);
            if (res.code == -2) { //未登录
                getArticle1();
                getCommentList1(1);//未登录评论列表
                //评论点击加载更多
                $(".moreComment").on("click", function () {
                    pageIndex1++;
                    console.log(pageIndex1);
                    getCommentList1(pageIndex1);
                })
                $(".publish").on("click", function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
                $("#articleZan").on("click", function () {//文章点赞
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
                $("#articleCollect").on("click", function () {//文章收藏
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
            } else if (res.code == 0) {//已登录
                //console.log(res);
                userId = res.data.userInfo.uid;
                usertoken = res.data.token;
                getArticle2();
                getCommentList2(1);
                //评论点击加载更多
                $(".moreComment").on("click", function () {
                    pageIndex2++;
                    getCommentList2(pageIndex2);
                })
                $(".weChatErrorEnter").click(function () {
                    payFun(userId, usertoken);
                })
            }
        }
    })
    //充值弹框
    $(".money_listinfo").click(function() {
        $(this).addClass("click_effect").siblings().removeClass("click_effect");
    });
    /*关闭框*/
    $(".alertClose").click(function() {
        $("#n_money").stop().hide();
        $("#exceptWrap").stop().hide();
        clearInterval(intervalTime)
    });
    $(".weChatClose").click(function() {
        $(".weChatCodeWrap").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatSuccessClose").click(function() {
        $(".weChatPaySuccess").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatOweWrapClose").click(function() {
        $(".weChatOweWrap").css("display", "none");
        $("#exceptWrap").stop().hide();
    });
    $(".wechat_pay").click(function() {
        $(".wechatI").show();
        $(".alipayI").hide()
    });
    $(".alipay").click(function() {
        $(".wechatI").hide();
        $(".alipayI").show()
    });
    $(".columnImg").click(function () {
        var kid = $(this).attr("kid");
        window.location.href = "/columnDetail?id="+kid;
    })
    $(".closePay").click(function () {
        $(".payMoney").stop().hide();
        history.go(-1);
    })
    $(".payMoneyBoxT img").click(function () {
        $(".payMoneyBoxWrap").stop().hide();
        history.go(-1);
    })
    // 获取文章详情(未登录)
    function getArticle1() {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v1/article/getArticle1.do",
            data: {
                "id": articleid,
            },
            success: function (res) {
                if (res.code == 0) {
                    console.log(res);
                    articleUserUid = res.data.liverInfo.uid;
                    var content = res.data.content;
                    var lead = res.data.lead;
                    if(lead != ""){
                        $(".abstract .abstractInner").html(lead);
                    }else{
                        $(".abstract").stop().hide();
                    }
                    var headImgUrl = res.data.liverInfo.headImgUrl;
                    var uid = res.data.liverInfo.uid;
                    if (headImgUrl != "") {
                        $(".introduce img").attr("src", headImgUrl);
                        $(".introduce img").attr("uid", uid);
                    }
                    $(".dumpLink li").attr("uid", uid);
                    var nickName = res.data.liverInfo.nickName;
                    var roleType=res.data.liverInfo.roleType;//主播角色类型{0=普通用户，1=主播，2=主播且操盘手}
                    if(roleType==0 ||　roleType==1){
                        $("#shipan").stop().hide();
                    }
                    var uid = res.data.liverInfo.uid;
                    var signature = res.data.liverInfo.signature;
                    var title = res.data.title;
                    var click = res.data.click;
                    var time = res.data.createTime;
                    var isCollection = res.data.isCollection;
                    var isAgree = res.data.isAgree;
                    var agreeCount = res.data.agreeCount;
                     var resume = res.data.liverInfo.resume;
                    if(resume == "" || resume == undefined||resume == null){
                        $(".authorDetail").html("暂无简介...");
                    }else{
                        $(".authorDetail").html(resume);
                    }
                    $("#keywordsId").attr("content",nickName+"，金融资盘，缩量横盘，私有化退市，今日股评，股市大家谈，上证红利指数，短线黑马，分级基金套利");
                    $(".articleTitle").html(title);
                    $(".introduce .people").html("主播：" + nickName);
                    $(".introduce .time").html(format(new Date(time)));
                    $(".anchor .name").html(nickName);
                    $(".anchor .introduce").html(signature);
                    $(".articleContent").html(htmlEncode(content));
                    var shortid = res.data.id;
                    var media = res.data.media;
                    if(media == "" || media == undefined){
                        $(".shortViewImgBox").stop().hide();
                    }else{
                        var shortViewImg = (media.split(','));
                        // console.log(shortViewImg);
                    }
                    //获取短评图片显示
                    getImgList(shortViewImg,shortid);
                    var content1=$(".articleContent").text().substring(0,100);
                    //console.log(content1);
                    $("#descriptionId").attr("content",content1);
                    if (agreeCount != 0) {
                        $(".shareLeft .num").html(agreeCount);
                    }
                    var isCollection = res.data.isCollection;
                    $(".articleContent p").each(function () {
                        var articleContentP = $(this).html();
                        //console.log(articleContentP);
                        var articleContentP2=$.trim(articleContentP);
                        $(this).html(articleContentP2);
                        $(this).css("text-indent","0");
                    })
                    var url = window.location.href;
                    var description= $(".articleContent").text().substr(0, 60);
                    shareFun(url, title, description, headImgUrl);
                }
            }
        });
    }
    //第三方分享
    function shareFun(url, title, description, pic) {
        mobShare.config({
            debug: true, // 开启调试，将在浏览器的控制台输出调试信息
            appkey: '1d102ac0241c0', // appkey
            params: {
                url: url, // 分享链接
                title: title, // 分享标题
                description: description, // 分享内容
                pic: pic, // 分享图片，使用逗号,隔开
                reason: '', //自定义评论内容，只应用与QQ,QZone与朋友网
            },
            callback: function(plat, params) {
                // console.log("分享成功了");
            }
        });
    }
    function getImgList(shortViewImg,shortid) {
        if(shortViewImg){
            var imgLength = shortViewImg.length;
            if(imgLength == 1){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }else if(imgLength == 2){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>' +
                    '<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }else if(imgLength == 3){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>' +
                    '<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }else if(imgLength ==4){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>' +
                    '<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }else if(imgLength == 5){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>' +
                    '<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }else if(imgLength ==6){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>' +
                    '<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }else if(imgLength == 7){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>' +
                    '<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }else if(imgLength ==8){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>' +
                    '<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[7] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[7] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }else if(imgLength ==9){
                var shortViewImg = '<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
                    '</a>' +
                    '<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[7] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[7] + '">' +
                    '</a>'+
                    '<a class="shortViewImgWrap" href="' + shortViewImg[8] + '" data-lightbox="' + shortid + '">' +
                    '<img class="shortViewImg" src="' + shortViewImg[8] + '">' +
                    '</a>';
                $(".shortViewImgBox").append(shortViewImg);
            }
        }
    }
    //电脑跳转手机
    function browserRedirect() {
        var sUserAgent = navigator.userAgent.toLowerCase();
        var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
        var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
        var bIsMidp = sUserAgent.match(/midp/i) == "midp";
        var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
        var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
        var bIsAndroid = sUserAgent.match(/android/i) == "android";
        var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
        var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
        if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
            window.location.href = "https://www.fntv8.com/m/v5.0/shortDetail?id=" + articleid + "";
        }
    }
    browserRedirect();
    // 获取文章详情(已登录)
    function getArticle2() {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v1/article/getArticle2.do",
            data: {
                "id": articleid,
                "uid": userId,
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    console.log(res);
                    articleUserUid = res.data.liverInfo.uid;
                    var content=res.data.content;
                    var lead = res.data.lead;
                    if(lead != ""){
                        $(".abstract .abstractInner").html(lead);
                    }else{
                        $(".abstract").stop().hide();
                    }
                    var headImgUrl=res.data.liverInfo.headImgUrl;
                    var uid=res.data.liverInfo.uid;
                    if (headImgUrl != "") {
                        $(".introduce img").attr("src", headImgUrl);
                        $(".introduce img").attr("uid", uid);
                    }
                    $(".dumpLink li").attr("uid",uid);
                    var nickName=res.data.liverInfo.nickName;
                    var uid=res.data.liverInfo.uid;
                    var signature=res.data.liverInfo.signature;
                    var title=res.data.title;
                    var click=res.data.click;
                    var time=res.data.createTime;
                    var isCollection=res.data.isCollection;
                    var isAgree=res.data.isAgree;
                    var agreeCount=res.data.agreeCount;
                    var resume = res.data.liverInfo.resume;
                    if(resume == "" || resume == undefined){
                        $(".authorDetail").html("暂无简介...");
                    }else{
                        $(".authorDetail").html(resume);
                    }
                    var roleType=res.data.liverInfo.roleType;//主播角色类型{0=普通用户，1=主播，2=主播且操盘手}
                    if(roleType==0 ||　roleType==1){
                        $("#shipan").stop().hide();
                    }
                    $(".articleTitle").html(title);
                    $(".introduce .people").html("主播："+nickName);
                    $(".introduce .time").html(format(new Date(time)));
                    $(".anchor .name").html(nickName);
                    $(".anchor .introduce").html(signature);
                    $(".articleContent").html(htmlEncode(content));
                    $(".articleContent p").each(function () {
                        var articleContentP = $(this).html();
                        //console.log(articleContentP);
                        var articleContentP2=$.trim(articleContentP);
                        $(this).html(articleContentP2);
                        $(this).css("text-indent","0");
                    })
                    var shortid = res.data.id;
                    var media = res.data.media;
                    if(media == "" || media == undefined){
                        $(".shortViewImgBox").stop().hide();
                    }else{
                        var shortViewImg = (media.split(','));
                        // console.log(shortViewImg);
                    }
                    //获取短评图片显示
                    getImgList(shortViewImg,shortid);
                    if(agreeCount!=0){
                        $(".shareLeft .num").html(agreeCount);
                    }
                    var url=window.location.href;
                    var description= $(".articleContent").text().substr(0, 60);
                    shareFun(url, title,description, headImgUrl);
                    //检查是否点赞
                    if(isAgree==true){
                        $(".shareLeft .zanImg").attr("src", "../images/rewardP.png");
                        $(".shareLeft .num").css("color", "#fe4502");
                    }
                    checkZan(articleid);
                    var isCollection=res.data.isCollection;
                    if(isCollection==true){//已收藏
                        $("#articleCollect").attr("src","../images/collectingP.png");
                        $("#collect").html("已收藏");
                        $("#collect").css("color","#fe4502");
                    }
                    checkCollect(articleid);
                }
            }
        })
    }
    //检查文章是否点赞
    function checkZan(articleid) {
        //判断是否点赞
        $("#articleZan").on("click",function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v2/agree/selectAgreeCount.do",
                data: {
                    "objectId": articleid,
                    "uid": userId,
                    "agreeType": 1,
                },
                success: function (res) {
                    if (res.code == 0) {
                        console.log(res);
                        var isAgree = res.data.isAgree;
                        // var agreeCount=res.data.agreeCount;
                        if (isAgree == true) {//已点赞
                            //取消点赞
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/deleteAgree.do",
                                data: {
                                    "objectId": articleid,
                                    "uid": userId,
                                    "token": usertoken,
                                    "agreeType": 1,
                                },
                                success: function (res) {
                                    //console.log(res);
                                    if (res.code == 0) {
                                        $(".shareLeft .zanImg").attr("src", "../images/rewardIcon.png");
                                        $(".shareLeft .num").css("color", "#A9A9A9");
                                        var praiseCount1 = $(".shareLeft .num").html();
                                        var praiseCount2 = Number(praiseCount1) - 1;
                                        $(".shareLeft .num").html(praiseCount2);
                                    }
                                }
                            })
                        } else {//未点赞
                            //点赞接口
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/insertAgree.do",
                                data: {
                                    "objectId": articleid,
                                    "uid": userId,
                                    "token": usertoken,
                                    "type": 1,
                                    "agreeType": 1,
                                },
                                success: function (res) {
                                    // console.log(res);
                                    if (res.code == 0) {
                                        $("#articleZan").attr("src", "../images/rewardP.png");
                                        $(".shareLeft .num").css("color", "#fe4502");
                                        var praiseCount1 = $(".shareLeft .num").html();
                                        var praiseCount2 = Number(praiseCount1) + 1;
                                        $(".shareLeft .num").html(praiseCount2);
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }
    //检查文章是否收藏
    function checkCollect(articleid) {
        //判断是否收藏
        $("#articleCollect").on("click",function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v2/agree/selectAgreeCount.do",
                data: {
                    "objectId": articleid,
                    "uid": userId,
                    "agreeType": 2,
                },
                success: function (res) {
                    if (res.code == 0) {
                        // console.log(res);
                        var isAgree = res.data.isAgree;
                        if (isAgree == true) {//已收藏
                            //取消收藏
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/deleteAgree.do",
                                data: {
                                    "objectId": articleid,
                                    "uid": userId,
                                    "token": usertoken,
                                    "agreeType": 2,
                                },
                                success: function (res) {
                                    //console.log(res);
                                    if (res.code == 0) {
                                        $("#articleCollect").attr("src","../images/collecting.png");
                                        $("#collect").html("收藏");
                                        $("#collect").css("color","#a9a9a9");
                                    }
                                }
                            })
                        } else {//未收藏
                            //收藏接口
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/insertAgree.do",
                                data: {
                                    "objectId": articleid,
                                    "uid": userId,
                                    "token": usertoken,
                                    "type": 1,
                                    "agreeType": 2,
                                },
                                success: function (res) {
                                    // console.log(res);
                                    if (res.code == 0) {
                                        $("#articleCollect").attr("src","../images/collectingP.png");
                                        $("#collect").html("已收藏");
                                        $("#collect").css("color","#fe4502");
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }
    //查询评论数量接口
    $.ajax({
        type: "POST",
        async: true,
        dataType: "json",
        url: "/api/v1/comment/countComment.do",
        data: {
            "objectId": articleid,
        },
        success: function (res) {
            // console.log(res);
            if (res.code == 0) {
                $("#commentNumber").html(res.data+"条评论");
            }
        }
    })
    //获取最近打赏信息
    getRewardMsg();
    function getRewardMsg() {
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v2/journal/selectLatelyByTarget.do",
            data: {
                "target": articleid,
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    var rewardNumber = res.data.count;
                    if(rewardNumber == 0){//无人打赏
                        $(".rewordNumber").stop().hide();
                        $(".rewordHead").stop().hide();
                    }else{
                        $(".rewordNumber").stop().show();
                        $(".rewordHead").stop().show();
                        $(".rewordNumber").html(rewardNumber+"人已打赏");
                        var imgLength = res.data.imgUrl.length;
                        // console.log(imgLength);
                        if(rewardNumber == imgLength){
                            for(var i = 0;i<imgLength;i++){
                                if(res.data.imgUrl[i]==""){
                                    res.data.imgUrl[i] = "../images/anchorHeadAnchor.png";
                                }
                                var imgListInner = "<img src='"+res.data.imgUrl[i]+"' alt='' />";
                                $(".rewordHead").append(imgListInner);
                            }
                        }
                    }
                }
            }
        })
    }
    //发表评论
    $(".publish").on("click",function(){
        var comment=$("textarea").val();
        if(comment==""){
            // alert("评论内容不能为空！");
            $(".noContent").fadeIn(100).delay(4000).fadeOut(100);
            return false;
        }
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v2/comment/insert.do",
            data: {
                "uid":userId ,
                "token":usertoken,
                "comment":comment,
                "objectId":articleid,
            },
            success: function (res) {
                if (res.code == 0) {
                    $('.comment ul li').remove();
                    getCommentList2(pageIndex2);
                    $(".articleLeft .comment textarea").val("");
                }
            }
        })
    })
    //获取评论接口（未登录）
    function getCommentList1(pageIndex1) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v3/comment/getCommentByObjId1.do",
            data: {
                "objectId": articleid,
                "pageIndex": pageIndex1,
                "pageSize": 10
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    if(res.data.length<10 && pageIndex1==1){
                        $(".moreComment").stop().hide();
                    }
                    if(res.data.length<10 && pageIndex1!=1){
                        $(".moreComment").stop().hide();
                        $(".noMoreComment").html("没有更多了");
                    }
                    $(res.data).each(function (i, k) {
                        var headImg = k.commentatorInfo.headImgUrl;
                        var nickName = k.commentatorInfo.nickName;
                        var replayNickName = "回复"+nickName+"...";
                        var comment = k.comment;
                        var time = k.time;
                        var id = k.id;
                        var commentId = "comment"+k.id;
                        var isAgree = k.isAgree;
                        var agreeCount = k.agreeCount;
                        var uid=k.commentatorInfo.uid;
                        var commentType = k.commentType;
                        if(commentType == 1){//1=一级评论；
                            var commentListInner = "<li>" +
                                "<div class='commentLeft'>" +
                                "<img uid="+uid+" src='" + headImg + "' alt=''>" +
                                "</div>" +
                                "<div class='commentRight'>" +
                                "<p class='name'>" + nickName + "<span class='time'>" + format(new Date(time)) + "</span></p>" +
                                "<p class='content'>" + comment + "</p>" +
                                "<div class='zan'>" +
                                "<img class='zanImg1' src='./images/answer.png' alt='' />"+
                                "<span class='playback'>回复</span>"+
                                "<img class='zanImg' id=" + id + " src='./images/rewardIcon.png' alt='' />" +
                                "<span class='zanNum'>" + agreeCount + "</span></div>" +
                                "<div class='applyabox'>"+
                                "<textarea placeholder="+replayNickName+"></textarea>"+
                                "<span class='sendApply' id="+commentId+" commentatorId="+k.commentatorId+">发送</span>"+
                                "<span class='cancalApply'>取消</span>"+
                                "</div></div></li>";
                            $(".comment ul").append(commentListInner);
                        }else if(commentType == 2){//2=二级评论
                            var parentName = k.parentCommentatorInfo.nickName;
                            var commentListInner = "<li>" +
                                "<div class='commentLeft'>" +
                                "<img uid="+uid+" src='" + headImg + "' alt=''>" +
                                "</div>" +
                                "<div class='commentRight'>" +
                                "<p class='name'>" + k.commentatorInfo.nickName + " <span style='color: #A9A9A9'>回复了 </span>"+k.parentCommentatorInfo.nickName+" <span class='time'>" + format(new Date(time)) + "</span></p>" +
                                "<p class='content'>" + comment + "</p>" +
                                "<div class='zan'>" +
                                "<img class='zanImg1' src='./images/answer.png' alt='' />"+
                                "<span class='playback'>回复</span>"+
                                "<img class='zanImg' id=" + id + " src='./images/rewardIcon.png' alt='' />" +
                                "<span class='zanNum'>" + agreeCount + "</span></div>" +
                                "<div class='applyabox'>"+
                                "<textarea placeholder="+replayNickName+"></textarea>"+
                                "<span class='sendApply'>发送</span>"+
                                "<span class='cancalApply'>取消</span>"+
                                "</div></div></li>";
                            $(".comment ul").append(commentListInner);
                        }
                    })
                    $(".commentLeft img").one("error", function(e) {
                        $(this).attr("src", "images/anchorHead.png");
                    })
                    $(".zan .zanImg").on("click",function(){//评论点赞
                        $("#loginAlert").stop().show();
                        $("#loginAlert").load("/login");
                    })
                    $(".commentLeft img").click(function () {
                        var uid=$(this).attr("uid");
                        window.location.href ="userProfile?uid="+uid;
                    })
                    $(".zanImg1").click(function () {
                        $("#loginAlert").stop().show();
                        $("#loginAlert").load("/login");
                    })
                }
            }
        })
    }
    //获取评论接口（已登录）
    function getCommentList2(pageIndex2) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v3/comment/getCommentByObjId2.do",
            data: {
                "objectId": articleid,
                "pageIndex": pageIndex2,
                "uid": userId,
                "pageSize": 10
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    if(res.data.length<10 && pageIndex2==1){
                        $(".moreComment").stop().hide();
                    }
                    if(res.data.length<10 && pageIndex2!=1){
                        $(".moreComment").stop().hide();
                        $(".noMoreComment").html("没有更多了");
                    }
                    $(res.data).each(function (i, k) {
                        var headImg = k.commentatorInfo.headImgUrl;
                        var nickName = k.commentatorInfo.nickName;
                        var replayNickName = "回复"+nickName+"...";
                        var comment = k.comment;
                        var time = k.time;
                        var id = k.id;
                        var isAgree = k.isAgree;
                        var agreeCount = k.agreeCount;
                        var uid=k.commentatorInfo.uid;
                        var commentType = k.commentType;
                        if(commentType == 1){//1=一级评论；
                            var commentListInner = "<li>" +
                                "<div class='commentLeft'>" +
                                "<img uid="+uid+" src='" + headImg + "' alt=''>" +
                                "</div>" +
                                "<div class='commentRight'>" +
                                "<p class='name'>" + nickName + "<span class='time'>" + format(new Date(time)) + "</span></p>" +
                                "<p class='content'>" + comment + "</p>" +
                                "<div class='zan'>" +
                                "<img class='zanImg1' src='./images/answer.png' alt='' />"+
                                "<span class='playback'>回复</span>"+
                                "<img class='zanImg' isAgree="+isAgree+"  id=" + id + "  src='./images/rewardIcon.png' alt=''/>" +
                                "<span class='zanNum'>" + agreeCount + "</span></div>" +
                                "<div class='applyabox'>"+
                                "<textarea placeholder="+replayNickName+"></textarea>"+
                                "<span class='sendApply' kid="+k.id+" commentatorId="+k.commentatorInfo.uid+">发送</span>"+
                                "<span class='cancalApply'>取消</span>"+
                                "</div></div></li>";
                            $(".comment ul").append(commentListInner);
                        }else if(commentType == 2){//二级评论
                            var commentListInner = "<li>" +
                                "<div class='commentLeft'>" +
                                "<img uid="+uid+" src='" + headImg + "' alt=''>" +
                                "</div>" +
                                "<div class='commentRight'>" +
                                "<p class='name'>" + k.commentatorInfo.nickName + " <span style='color: #A9A9A9'>回复了 </span>"+k.parentCommentatorInfo.nickName+" <span class='time'>" + format(new Date(time)) + "</span></p>" +
                                "<p class='content'>" + comment + "</p>" +
                                "<div class='zan'>" +
                                "<img class='zanImg1' src='./images/answer.png' alt='' />"+
                                "<span class='playback'>回复</span>"+
                                "<img class='zanImg' isAgree="+isAgree+"  id=" + id + "  src='./images/rewardIcon.png' alt=''/>" +
                                "<span class='zanNum'>" + agreeCount + "</span></div>" +
                                "<div class='applyabox'>"+
                                "<textarea placeholder="+replayNickName+"></textarea>"+
                                "<span class='sendApply' kid="+k.id+" commentatorId="+k.commentatorInfo.uid+">发送</span>"+
                                "<span class='cancalApply'>取消</span>"+
                                "</div></div></li>";
                            $(".comment ul").append(commentListInner);
                        }
                    })
                    $(".commentLeft img").one("error", function(e) {
                        $(this).attr("src", "images/anchorHead.png");
                    })
                    $(".commentLeft img").click(function () {
                        var uid=$(this).attr("uid");
                        window.location.href ="userProfile?uid="+uid;
                    })
                    $(".zan .zanImg").each(function () {
                        isAgree=$(this).attr("isAgree");
                        var id=$(this).attr("id");
                        var agreeCount=res.data.agreeCount;
                        var agreeCount=parseInt($(this).next().attr("agreeCount"));
                        // console.log(agreeCount);
                        if(isAgree=="true") {//已点赞
                            $(this).attr("src", "../images/rewardP.png");
                            $(this).next().css("color", "#fe4502");
                        }
                        checkZan2(id,agreeCount);
                    })
                    $(".zanImg1").click(function () {
                        $(this).parent().next(".applyabox").stop().show();
                    })
                    $(".cancalApply").click(function () {
                        $(this).parent(".applyabox").stop().hide();
                    })
                    $(".sendApply").click(function () {
                        var replayComment = $(this).prev("textarea").val();
                        var commentatorId = $(this).attr("commentatorId");
                        var authorId = commentatorId;
                        var parentId = $(this).attr("kid");
                        // 回复评论接口
                        $.ajax({
                            type: "post",
                            async: true,
                            dataType: "json",
                            url: "/api/v3/comment/insert.do",
                            data: {
                                "uid": userId,
                                "token": usertoken,
                                "comment": replayComment,
                                "objectId": articleid,
                                "parentId": parentId,
                                "type": 3,
                                "commentType": 2,
                                "authorId": commentatorId
                            },
                            success: function (res) {
                                if (res.code == 0) {
                                    // console.log(res);
                                    $('.comment ul li').remove();
                                    getCommentList2(pageIndex2);
                                    $(".applyabox textarea").val("");
                                }
                            }
                        })
                    })
                }
            }
        })
    }
    // 检查评论点赞
    function checkZan2(id,agreeCount) {
        //判断是否点赞
        $("#"+id).on("click",function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v2/agree/selectAgreeCount.do",
                data: {
                    "objectId": id,
                    "uid": userId,
                    "agreeType":1,
                },
                success: function (res) {
                    if (res.code == 0) {
                        // console.log(res);
                        var isAgree=res.data.isAgree;
                        // var agreeCount=res.data.agreeCount;
                        if(isAgree==true){//已点赞
                            //取消点赞
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/deleteAgree.do",
                                data: {
                                    "objectId": id,
                                    "uid": userId,
                                    "token": usertoken,
                                    "agreeType":1,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        // console.log(res);
                                        $("#"+id).attr("src","../images/rewardIcon.png");
                                        $("#"+id).next().css("color","#a9a9a9");
                                        var praiseCount1 = $("#"+id).next().html();
                                        var praiseCount2 = Number(praiseCount1) - 1;
                                        $("#"+id).next().html(praiseCount2);
                                    }
                                }
                            })
                        }else{
                            //点赞接口
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/insertAgree.do",
                                data: {
                                    "objectId": id,
                                    "uid": userId,
                                    "token": usertoken,
                                    "type":4,
                                    "agreeType":1,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        // console.log(res);
                                        $("#"+id).attr("src","../images/rewardP.png");
                                        var praiseCount1 = $("#"+id).next().html();
                                        var praiseCount2 = Number(praiseCount1) + 1;
                                        $("#"+id).next().html(praiseCount2);
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }
    // 头像跳转
    $(".introduce img").click(function () {
        var uid=$(this).attr("uid");
        window.location.href ="/userProfile?uid="+uid;
    })
    $(".dumpLink li").click(function () {
        var uid=$(this).attr("uid");
        var tab=$(this).attr("tab");
        window.location.href ="/userProfile?uid="+uid+"&tab="+tab;
    })
    //打赏
    var gift = [
        {niubi:1,text:'厉害了我的主播！',img:'images/giftzan.png'},
        {niubi:10,text:'来两颗金豆压压惊！',img:'images/giftjindou.png'},
        {niubi:188,text:'这是一个神奇的宝箱！',img:'images/giftbaoxiang.png'},
        {niubi:999,text:'让你的每只股都涨停！',img:'images/giftzhangtingban.png'},
        {niubi:1888,text:'让你财源滚滚来！',img:'images/giftcaishenye.png'},
        {niubi:8888,text:'让你牛气冲天，一牛再牛！',img:'images/giftjinniu.png'}
    ];

    $(".giftImg img").each(function(i){
        $(this).mouseover(function () {
            $(".giftImgHover").fadeIn(10);
            $(".giftValue").text(gift[i].niubi);
            $(".giftText").text(gift[i].text);
            $(".hoverImg").attr('src',gift[i].img);
            var aa = 192+75*i;
            $(".giftImgHover").css("left",aa+"px");
        });
        $(this).mouseleave(function () {
            $(".giftImgHover").fadeOut(10);
        });
    });

    function award(uid,uidIn,target,coinType,monetary,awardToken,channel,token) {
        $.ajax({
            type: "post",
            url: "/api/v1/account/award.do",
            data:{
                uid:uid,
                uidIn:uidIn,
                target:target,
                coinType:coinType,
                monetary:monetary,
                awardToken:awardToken,
                channel:channel,
                token:token
            },
            success: function (res) {
                console.log(res);
                if(res.code == 0){
                    $('.praiseSuccess').fadeIn(200);
                    setTimeout(function () {
                        $('.praiseSuccess').fadeOut(200);
                    },2000);
                    $(".reward .rewordPeople").stop().show();
                    $(".rewordHead img").remove();
                    getRewardMsg();
                }else if(res.code == -706){
                    $("#exceptWrap").stop().show();
                    $(".weChatOweWrap").stop().show();
                    $(".weChatErrorEnter").click(function() {
                        $(".weChatOweWrap").stop().hide();
                        $("#n_money").stop().show()
                    })
                }else if(res.code == -9998){
                    layer.msg('打赏失败！');
                }
            }
        })
    };

    $("body,html").click(function () {
        $(".giftImg").fadeOut(200);
    });

    $(".rewordBtn").click(function () {
        $.ajax({
            type: "get",
            url: "/userInfos",
            success: function (res) {
                if(res.code == 0){
                    $(".giftImg").fadeIn(200);
                    var token = res.data.token;
                    var uid = res.data.userInfo.uid;
                    //查询用户账户
                    $.ajax({
                        type: "post",
                        url: "/api/v1/account/selectByWhere.do",
                        data:{
                            uid:uid,
                            coinType:'RECHARGE_COIN',
                            token:token
                        },
                        success: function (res) {
                            if (res.code == 0) {
                                console.log(res);
                                $(".balanceVal").text(res.data[0].coinNumber);
                                $("#havaMoney").html(res.data[0].coinNumber+"牛币");
                            }
                        }
                    });
                }else {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                }
            }
        })
    });
    $(".giftImgInner").on("click",function () {
        var niubi=$(this).attr("niubi");
        var niubishu=Number(niubi);
        $.ajax({
            type: "post",
            url: "/api/v1/account/getToken.do",
            data:{uid:userId,token:usertoken},
            success: function (result) {
                if (result.code == 0) {
                    award(userId,articleUserUid,articleid,'RECHARGE_COIN',niubishu,result.data,'WEB',usertoken);
                }
            }
        });
    })
    //充值函数
    function payFun(userId, token) {
        /*充值接口*/
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v1/account/selectByWhere.do",
            data: {
                "uid": userId,
                "coinType": "RECHARGE_COIN",
                "token": token,
            },
            success: function(res) {
                // console.log(res);
                if(res.code == 0) {
                    $(".coinNiBi").html(res.data[0].coinNumber);
                    $("#balanceCoin").html(res.data[0].coinNumber + "牛币")
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus);
            }
        });
        //点击重置按钮
        $(".payMoneyBtn").click(function() {
            $("#exceptWrap").stop().show();
            $("#n_money").stop().show();
        })
        $(".qitaMoney").focus(function() {
            $(this).removeAttr("placeholder");
            $(".moneyAlert").stop().show()
        });
        $(".qitaMoney").blur(function() {
            $(this).attr("placeholder", "其他金额");
            $(".moneyAlert").stop().hide()
        });
        $(".payBtn").click(function() {
            var totalFee = "";
            if($(".qitaMoney").val() != "") {
                totalFee = parseInt($(".qitaMoney").val());
                //console.log(totalFee)
            } else {
                totalFee = parseInt($(".money_list").find(".click_effect").children().text())
            }
            $(".weChatPayNum").html(totalFee);
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v1/order/wxUnifiedOrder.do",
                data: {
                    "uid": userId,
                    "totalFee": totalFee,
                    "tradeType": "NATIVE",
                    "token": token,
                },
                success: function(res) {
                    if(res.code == 0) {
                        $("#n_money").fadeOut(1);
                        $(".weChatCodeWrap").fadeIn(1);
                        var codeUrl = res.data.codeUrl;
                        var outTradeNo = res.data.outTradeNo;
                        //console.log(outTradeNo);
                        jQuery("#weChatPayCode").qrcode({
                            render: "canvas",
                            foreground: "#000",
                            background: "#FFF",
                            width: 180,
                            height: 180,
                            text: codeUrl,
                            correctLevel: 2
                        });
                        intervalTime = setInterval(function() {
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/order/wxFrontNotify.do",
                                data: {
                                    "uid": userId,
                                    "outTradeNo": outTradeNo,
                                    "token": token,
                                },
                                success: function(res) {
                                    //	console.log(res);
                                    if(res.code == 0) {
                                        $(".weChatCodeWrap").stop().hide();
                                        $(".weChatPaySuccess").stop().show()
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus)
                                }
                            })
                        }, 3000)
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    console.log(XMLHttpRequest.status);
                    console.log(XMLHttpRequest.readyState);
                    console.log(textStatus);
                }
            })
        })
    }
    /*固定条*/
    var IndexpageIndex =1;
    $(".fixed_nav .reload").click(function() {
        $("body,html").animate({
            scrollTop: 1200
        }, 800)
        IndexpageIndex++;
        insertHot(IndexpageIndex, 10, "top");
        $(".insertTopWrap").stop().show(0).delay(4000).hide(0);
        $("#hotTopLoading").show().delay(1000).hide(0);
        $(".insertTop").delay(1000).slideDown(0).delay(3000).slideUp(0);

    })
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn()
        } else {
            $(".goTop").stop().fadeOut()
        }
    });
    $(".goTop").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 800)
    });
    
    //固定条
    $(window).scroll(function() {
		var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop()+140);
		if($(document).height() <= totalheight) {
			$(".share").css({
				"bottom":"355px"
			})
		}else{
			$(".share").css({
				"bottom":"0"
			})
		}
	});
})