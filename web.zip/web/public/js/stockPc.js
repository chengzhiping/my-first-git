$(document).ready(function() {
	getTzsColumn(1, 10);
	var IndexpageIndex=1;

	function getTzsColumn(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/column/getTzsColumn.do",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					//console.log(res.data.length);
					if(pageIndex == 1 && res.data.length == 0) {
						$("#freeLookBoxColumn").stop().hide();
					} else {
						var res = res.data;
						handleDataFun(res);
						$(".columnNrLoading").stop().hide();
						$(".columnNrNoMore").stop().show();
					}
					if(res!=undefined||res!=null||res!=""){
						if(res.length>6) {
							$(window).scroll(function() {
								var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop() + 200);
								if($(document).height() <= totalheight) {
									IndexpageIndex++;
									getTzsColumn(IndexpageIndex, 10);
								}
							});
						};
						
					}
					
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
	}

	function handleDataFun(res) {
		//console.log(res);
		$(res).each(function(i, k) {
			var herfId = k.information.id + "herfId";
			var objectId = k.information.id;
			var headImgId = k.information.id + "headImgId";
			if(k.type == 1) { //内容类型（1-视频/音频，2-文章）
				//console.log(k)
				if(k.information.type == 1 || k.information.type == 2) { //2.录制视频 3、音频
					var videoIdCover = k.information.id + "videoIdCover";
					var videoWrap =
						'<div class="videoWrap" id=' + herfId + ' objectId=' + objectId + '>' +
						'<div class="videoL fl">' +
						'<img class="videoCover" id=' + videoIdCover + ' src="' + k.information.coverUrl + '!220X164">' +
						'<img class="videoSystem" src="images/select.png" />' +
						'<span class="videoTime">' + durationFun(new Date(k.information.duration)) + '</span>' +
						'</div>' +
						'<div class="videoR fl">' +
						'<p class="videoTitle">' + k.information.topic + '</p>' +
						' <p class="columnArticleBigBoxRB columnArticleBigBoxRBSame fl">' + k.information.liverInfo.nickName + '</p>' +
						'</div> ' +
						'</div>';
					$(".columnMiddleTabBoxTab1").append(videoWrap);
					$("#" + videoIdCover).one("error", function(e) {
						$(this).attr("src", "images/vedioCoverUrl.jpg");
					});
					$(document).on("click", "#" + herfId, function(e) {
						var id = $(this).attr("objectId");
						window.location.href = "/video?id=" + id;
					});
				} else if(k.information.type == 3) { //音频
					var ImgArticleWrap =
						'<div class="ImgArticleWrap" id=' + herfId + ' objectId=' + objectId + '>' +
						'<p class="ImgArticleImgTitle">' + k.information.topic + '</p>' +
						'<div class="indexAudioBox">' +
						'<div class="indexAudioBoxL fl">' +
						'<img id=' + headImgId + ' src="' + k.information.liverInfo.headImgUrl + '!60X60"/>' +
						'<img src="../images/indexvideo.png"/>' +
						'</div>' +
						'<p class="fl">' + k.information.topic + '</p>' +
						'<p class="fl audioTime">' + durationFun(new Date(k.information.duration)) + '</p>' +
						'</div>' +
						'<p class="columnArticleBigBoxRB columnArticleBigBoxRBSame fl stockBottom">' + k.information.liverInfo.nickName + '</p>' +
						'</div>';
					$(".columnMiddleTabBoxTab1").append(ImgArticleWrap);
					$("#" + videoIdCover).one("error", function(e) {
						$(this).attr("src", "images/vedioCoverUrl.jpg");
					});
					$("#" + headImgId).one("error", function(e) {
						$(this).attr("src", "images/anchorHead.png");
					});
					$(document).on("click", "#" + herfId, function(e) {
						var id = $(this).attr("objectId");
						window.location.href = "/audio?id=" + id;
					});
				}
			} else if(k.type == 2) {
			//	console.log(k);
				var articleContent = k.information.content;
				var content = htmlEncode(articleContent);
				if(k.information.coverUrl) { //运营设计
					var chooseIdArticleHaveImg = k.information.id + "chooseIdArticleHaveImg";
					var columnArticleBigBox =
						'<div class="columnArticleBigBox" id=' + herfId + ' objectId=' + objectId + '>' +
						'<img class="columnArticleBigImg fl" id=' + chooseIdArticleImg + ' src="' + k.information.coverUrl + '!220X164"/>' +
						'<div class="columnArticleBigBoxR fl">' +
						'<h2>' + k.information.title + '</h2>' +
						'<p class="columnArticleBigImgIntro">' + removeHTMLTag(content) + '</p>' +
						' <p class="columnArticleBigBoxRB fl">' + k.information.liverInfo.nickName + '</p>' +

						'</div>' +
						'</div>';
					$("#" + chooseIdArticleImg).one("error", function(e) {
						$(this).attr("src", "images/vedioCoverUrl.jpg");
					});
					$(".columnMiddleTabBoxTab1").append(columnArticleBigBox);
					$(document).on("click", "#" + herfId, function(e) {
						var id = $(this).attr("objectId");
						window.location.href = "/article?id=" + id;
					});
				} else if(k.information.userCoverUrl) {
					var chooseIdArticleHaveImg = k.information.id + "chooseIdArticleHaveImg";
					var columnArticleBigBox =
						'<div class="columnArticleBigBox" id=' + herfId + ' objectId=' + objectId + '>' +
						'<img class="columnArticleBigImg fl" id=' + chooseIdArticleImg + ' src="' + k.information.userCoverUrl + '!220X164"/>' +
						'<div class="columnArticleBigBoxR fl">' +
						'<h2>' + k.information.title + '</h2>' +
						'<p class="columnArticleBigImgIntro">' + removeHTMLTag(content) + '</p>' +
						' <p class="columnArticleBigBoxRB fl">' + k.information.liverInfo.nickName + '</p>' +
						'</div>' +
						'</div>';
					$(".columnMiddleTabBoxTab1").append(columnArticleBigBox);
					$("#" + chooseIdArticleImg).one("error", function(e) {
						$(this).attr("src", "images/vedioCoverUrl.jpg");
					});
					$(document).on("click", "#" + herfId, function(e) {
						var id = $(this).attr("objectId");
						window.location.href = "/article?id=" + id;
					});
				} else {
					var imgReg = /<img.*?(?:>|\/>)/gi;
					//匹配src属性
					var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
					var imgArr = content.match(imgReg); //'所有已成功匹配图片的数组
					if(imgArr == null) {
						var columnArticleBigBoxNull =
							'<div class="columnArticleBigBox columnArticleBigBoxNull" id=' + herfId + ' objectId=' + objectId + '>' +
							'<div class="columnArticleBigBoxR fl columnArticleNullBigBox">' +
							'<h2>' + k.information.title + '</h2>' +
							'<p class="columnArticleBigImgIntro">' + removeHTMLTag(content) + '</p>' +
							'<p class="columnArticleBigBoxRB columnArticleBigBoxRBSame stockBottom fl">' + k.information.liverInfo.nickName + '</p>' +
							'</div>' +
							"</div>";
						$(".columnMiddleTabBoxTab1").append(columnArticleBigBoxNull);
						$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/article?id=" + id;
						});
					} else {
						src = imgArr[0].match(srcReg);
						var chooseIdArticleImg = k.information.id + "chooseIdArticleImg";
						if(src[1]) {
							var columnArticleBigBox =
								'<div class="columnArticleBigBox" id=' + herfId + ' objectId=' + objectId + '>' +
								'<img class="columnArticleBigImg fl" id=' + chooseIdArticleImg + ' src="' + src[1] + '"/>' +
								'<div class="columnArticleBigBoxR fl">' +
								'<h2>' + k.information.title + '</h2>' +
								'<p class="columnArticleBigImgIntro">' + removeHTMLTag(content) + '</p>' +
								' <p class="columnArticleBigBoxRB fl">' + k.information.liverInfo.nickName + '</p>' +
								'</div>' +
								'</div>';
							$("#" + chooseIdArticleImg).one("error", function(e) {
								$(this).attr("src", "images/vedioCoverUrl.jpg");
							});
							$(".columnMiddleTabBoxTab1").append(columnArticleBigBox);
							$(document).on("click", "#" + herfId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/article?id=" + id;
							});
						}
					}
				}
			}

		})
	}
	/*回到顶部*/
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
	
	//页面跳转
	function browserRedirect() {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		var bIsMidp = sUserAgent.match(/midp/i) == "midp";
		var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		var bIsAndroid = sUserAgent.match(/android/i) == "android";
		var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
		if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
			window.location.href = "https://www.fntv8.com/m/v5.0/stock"
          //  window.location.href = "http://192.168.8.13:8445/m/v5.0/invite"
		}
	}
	browserRedirect();

})