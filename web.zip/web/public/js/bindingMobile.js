$(document).ready(function () {
    var phoneReg = /^[1][34578]\d{9}$/;//手机号码正则
    var passwordReg = /^[0-9a-zA-Z]+$/  //密码正则
    var numReg = new RegExp(/^\d{4}$/); //图形验证码
    var verifyReg = new RegExp(/^\d{6}$/); //短信验证码

    //关闭图形验证码弹框
    $(".bingingBG .graphCloseBtn").click(function () {
        $(".bingingBG .numCodeBG").fadeOut(100);
        $(".bingingBG .graphInput").val('');
    });
    //关闭绑定手机号弹框
    $(".bingingBG .graphCloseBtn").click(function () {
        $(".bingingBG .numCodeBG").fadeOut(100);
        $(".bingingBG .graphInput").val('');
    });
    //关闭绑定手机号弹框
    $(".bindingClose").click(function () {
        $("#loginAlert").fadeOut(100);
    });

    //获取图形验证码
    function refreshCodeFun() {
        $.ajax({
            type: "GET",
            url: "/refreshGraphCode",
            success: function(res){
                $(".bingingBG .graphCode").attr("src","/refreshGraphCode");
            }
        });
    };
    //刷新图形验证码
    $(".bingingBG .graphCode").click(function () {
        refreshCodeFun();
    });

    //手机号输入框
    $(".bindMobile").change(function(){
        var bindMobile = $(this).val();
        if (!phoneReg.test(bindMobile)){
            layer.msg('手机号码有误，请重新输入！');
        }
    });
    //密码输入框
    $(".bindPassword").change(function(){
        var bindPassword = $(this).val();
        if (!passwordReg.test(bindPassword)){
            layer.msg('密码有误！');
        }
    });

    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function (res) {
            if(res.code==0){
                var headImg = res.data.userInfo.headImgUrl;
                if(!headImg){
                    headImg = "images/anchorHead.png"
                }
                $(".bindingCom .headerImg").css('background-image','url('+headImg+')');
                $(".bindingCom h2").text(res.data.userInfo.nickName);
                //获取验证码按钮
                $(".smsVerify").click(function () {
                    var bindMobile = $(".bindMobile").val();
                    if (!phoneReg.test(bindMobile)){
                        layer.msg('手机号码有误，请重新输入!');
                    }else{
                        $.ajax({
                            type: "post",
                            url: "/api/v1/user/getIsRegister.do",
                            data: {'mobile': bindMobile},
                            success: function (result) {
                                // console.log(result);
                                if(result.code == -101){
                                    layer.msg('手机号已被绑定');
                                }else if(result.code == 0){
                                    refreshCodeFun();
                                    $(".bingingBG .numCodeBG").fadeIn(200);
                                    //图形验证码确认按钮
                                    $(".bingingBG .graphBtn").click(function(){
                                        var graphInput = $(".bingingBG .graphInput").val();
                                        if (!numReg.test(graphInput)){
                                            graphInput = '';
                                            layer.msg('验证码有误');
                                        }else {
                                            $.ajax({//校验图形验证码
                                                type: "post",
                                                url: "/checkGraphCode",
                                                data:{'verifiCode':graphInput},
                                                success: function(resp){
                                                    graphInput = '';
                                                    if(resp.code == 0){//图形验证码正确
                                                        $(".bingingBG .numCodeBG").fadeOut(100);
                                                        $.ajax({//发送短信验证码
                                                            type: "post",
                                                            url: "/api/v2/user/sendSms.do",
                                                            data:{'type':2,'mobile':bindMobile},
                                                            success: function(response){
                                                                // console.log(res);
                                                                if(response.code == 0){
                                                                    layer.msg('验证码发送成功');
                                                                }else if(response.code == -14){
                                                                    layer.msg('该手机号发送短信次数过于频繁');
                                                                }else if(response.code == -20){
                                                                    layer.msg('系统繁忙，请稍后再试');
                                                                }else if(response.code == -101){
                                                                    layer.msg('手机号已被注册');
                                                                }else{
                                                                    layer.msg('发送失败');
                                                                }
                                                            }
                                                        });
                                                    }else if(resp.code == -1){
                                                        layer.msg('图形验证码有误');
                                                    }
                                                }
                                            });
                                        }
                                    });
                                }
                            }
                        })
                    };
                });
                //提交----绑定手机号按钮
                $(".bindBtn").click(function () {
                    var bindMobile = $(".bindMobile").val();
                    var bindPassword = $(".bindPassword").val();
                    var bindVerify = $(".bindVerify").val();
                    var bindData = {
                        mobile:bindMobile,
                        uid:res.data.userInfo.uid,
                        token:res.data.token,
                        password:bindPassword,
                        authCode:bindVerify
                    };
                    if(!phoneReg.test(bindMobile)){
                        layer.msg('手机号码有误，请重新输入!');
                    }else if (!passwordReg.test(bindPassword)){
                        layer.msg('密码有误！');
                    }else if (!verifyReg.test(bindVerify)){
                        layer.msg('验证码有误！');
                    }else{
                        $.ajax({
                            type: "post",
                            url: "/api/v1/user/bindingMobile.do",
                            data: bindData,
                            success: function (result) {
                                // console.log(result);
                                if(result.code==0){
                                    layer.msg('绑定成功!');
                                    setTimeout(function () {
                                        window.location.reload(true);
                                    },1300);
                                }else if(result.code==-6){
                                    layer.msg('手机验证码无效!');
                                }else if(result.code == -14){
                                    layer.msg('该手机号发送短信次数过于频繁');
                                }else if(result.code == -20){
                                    layer.msg('系统繁忙，请稍后再试');
                                }else if(result.code == -101){
                                    layer.msg('手机号已被注册');
                                }else{
                                    layer.msg('发送失败');
                                }
                            }
                        })
                    }
                })
            }
        }
    });




});

