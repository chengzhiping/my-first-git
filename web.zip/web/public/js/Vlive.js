$(document).ready(function () {
    var userId;
    var usertoken;
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");

    //随机数
    function RandomNumBoth(Min,Max){
        var Range = Max - Min;
        var Rand = Math.random();
        var num = Min + Math.round(Rand * Range);
        return num;
    };

    // banner
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url:"/api/v1/banner/selectByType.do",
        data: {
            "pageIndex": 1,
            "pageSize": 10,
            "type":13,
        },
        success: function (res) {
            if (res.code == 0) {
                //console.log(res);
                $(res.data).each(function(i,k) {
                    var imgUrl=k.imgUrl;
                    var bannerType=k.bannerType;
                    var id=k.id;
                    var uid=k.uid;
                    //console.log(bannerType);
                    var imgInner="<li objectId="+id+" objectType="+bannerType+" uid="+uid+" ><img src='"+imgUrl+"' alt=''/></li>";
                    $(".img").append(imgInner);
                })
                var size = $(".img li").length;
                //console.log("size="+size);
                for (var i = 1; i <= size; i++) {	//创建图片个数相对应的底部数字个数
                    var li = "<li>" + i + "</li>";	//创建li标签，并插入到页面中
                    $(".num").append(li);
                };
                var activeIndex = RandomNumBoth(0,res.data.length-1);
                // console.log(activeIndex)
                //手动控制图片轮播
                $(".img li").eq(activeIndex).show();	//显示第一张图片
                $(".num li").eq(activeIndex).addClass("active");	//第一张图片底部相对应的数字列表添加active类
                $(".num li").mouseover(function () {
                    $(this).addClass("active").siblings().removeClass("active");  //鼠标在哪个数字上那个数字添加class为active
                    var index = $(this).index();  //定义底部数字索引值
                    i = index;  //底部数字索引值等于图片索引值
                    $(".img li").eq(index).stop().fadeIn(500).siblings().stop().fadeOut(500);	//鼠标移动到的数字上显示对应的图片
                });

                //自动控制图片轮播
                var i = 0;  //初始i=0
                var t = setInterval(move, 5000);  //设置定时器，1.5秒切换下一站轮播图
                //向左切换函数
                function moveL() {
                    i--;
                    if (i == -1) {
                        i = size - 1;  //如果这是第一张图片再按向左的按钮则切换到最后一张图
                    }
                    $(".num li").eq(i).addClass("active").siblings().removeClass("active");  //对应底部数字添加背景
                    $(".img li").eq(i).fadeIn(500).siblings().fadeOut(500);  //对应图片切换
                };

                //向右切换函数
                function move() {
                    i++;
                    if (i == size) {
                        i = 0;  //如果这是最后一张图片再按向右的按钮则切换到第一张图
                    }
                    $(".num li").eq(i).addClass("active").siblings().removeClass("active");  //对应底部数字添加背景
                    $(".img li").eq(i).fadeIn(500).siblings().fadeOut(500);  //对应图片切换
                };

                //左按钮点击事件
                $(".carouselLeft .left").click(function () {
                    moveL();	//点击左键调用向左切换函数
                });
                //右按钮点击事件
                $(".carouselLeft .right").click(function () {
                    move();    //点击右键调用向右切换函数
                });
                //定时器开始与结束
                $(".carouselLeft").hover(function () {
                    clearInterval(t);	//鼠标放在轮播区域上时，清除定时器
                }, function () {
                    t = setInterval(move, 5000);  //鼠标移开时定时器继续
                })
            }
            bannerDump(".carouselLeft ul li");
        }
    })

    // 直播使用指引
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v1/banner/selectByType.do",
        data: {
            "type": 26,
        },
        success: function (res) {
            if (res.code == 0) {
                //console.log(res);
                var imgUrl=res.data[0].imgUrl;
                var id=res.data[0].id;
                //console.log(id);
                if(imgUrl!=""){
                    $(".carouselRight .carouselTop").attr("src",imgUrl);
                    $(".carouselRight .carouselTop").attr("objectId",id);
                }
                if(id!=undefined && id!="") {
                    $(".carouselRight .carouselTop").click(function () {
                        var id = $(this).attr("objectId");
                        window.location.href = id;
                    })
                }
            }
        }
    })
    // 主播活动
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v1/banner/selectByType.do",
        data: {
            "type": 27,
        },
        success: function (res) {
            if (res.code == 0) {
                //console.log(res);
                var imgUrl=res.data[0].imgUrl;
                var id=res.data[0].id;
                //console.log(id);
                if(imgUrl!=""){
                    $(".carouselRight .carouselBottom").attr("src",imgUrl);
                    $(".carouselRight .carouselBottom").attr("objectId",id);
                }
                if(id!=undefined && id!=""){
                    $(".carouselRight .carouselBottom").click(function () {
                        var id=$(this).attr("objectId");
                        window.location.href =id;
                    })
                }
            }

        }
    })
    // 直播广告
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v1/banner/selectByType.do",
        data: {
            "type": 28,
        },
        success: function (res) {
            if (res.code == 0) {
               // console.log(res);
                var id1=res.data[0].id;
                var id2=res.data[1].id;
                $(".ads .ads1").attr("src",res.data[0].imgUrl);
                $(".ads .ads1").attr("objectId",id1);
                $(".ads .ads2").attr("src",res.data[1].imgUrl);
                $(".ads .ads2").attr("objectId",id2);
            }
            $(".ads .ads1").click(function () {
                var id=$(this).attr("objectId");
                window.location.href =id;
            })
            $(".ads .ads2").click(function () {
                var id=$(this).attr("objectId");
                window.location.href =id;
            })
        }
    })

    // 大V推荐
    $.ajax({
        type: "get",
        async: true,
        dataType: "json",
        url:"/api/v2/live/getRecLiverList.do",
        data: {
            "pageIndex": 1,
            "pageSize": 4,
        },
        success: function (res) {
            if (res.code == 0) {
               //console.log(res);
                $(res.data).each(function (i, k) {
                    var uid=k.uid;
                    //console.log(uid);
                    var nickName=k.nickName;
                    var headImgUrl=k.headImgUrl;
                    var resume=k.resume;
                    var VliveMemberInner="<li uid="+uid+" class='member' uid="+uid+">"+
                                        "<img src='"+headImgUrl+"' alt=''>"+
                                        "<p class='name'>"+nickName+"</p>"+
                                        "<p class='resume'>"+resume+"</p>"+
                                        "<p class='focus' id="+uid+">关注</p>"+
                                        "</li>";
                    $(".VliveMember").append(VliveMemberInner);
                    if(resume==""||resume == null||resume == undefined){
                        $(".member .resume").html("暂无签名...");
                    }
                    $(".member img").one("error", function(e) {
                        $(this).attr("src", "images/anchorHead.png");
                    })
                })
                //遍历
                $(".focus").each(function () {
                    var thisUid=$(this).attr("id");
                    // 检查用户是否登录
                    $.ajax({
                        type: "get",
                        url: "/userInfos",
                        success: function (res) {
                            //console.log(res);
                            if (res.code == -2) { //未登录
                                $("#"+thisUid).on("click",function(){
                                    $("#loginAlert").stop().show();
                                    $("#loginAlert").load("/login");
                                })
                            } else if (res.code == 0) {//已登录
                                userId = res.data.userInfo.uid;
                                usertoken = res.data.token;
                                // 检查是否关注
                                $.ajax({
                                    type: "POST",
                                    async: true,
                                    dataType: "json",
                                    url: "/api/v1/user/checkFollowing.do",
                                    data: {
                                        "receptorId": thisUid,
                                        "uid": userId,
                                        "token": usertoken,
                                    },
                                    success: function (res) {
                                        //console.log(res);
                                        if (res.code == 0) {
                                            var isFocus = res.data;
                                            if (isFocus == 1) {//已关注
                                                $("#" + thisUid).html("已关注");
                                                $("#" + thisUid).css("color", "#a9a9a9");
                                            }
                                        }
                                    }
                                })
                                //检查关注
                                checkFocus(thisUid);
                            }
                        }
                    })
                })
            }
        }
    })
    //检查关注
    function checkFocus(thisUid) {
        $("#"+thisUid).on("click",function(){
            // 检查是否关注
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v1/user/checkFollowing.do",
                data: {
                    "receptorId": thisUid,
                    "uid": userId,
                    "token": usertoken,
                },
                success: function (res) {
                    //console.log(res);
                    if (res.code == 0) {
                        var isFocus=res.data;
                        if(isFocus==1){//已关注
                            $("#"+thisUid).html("已关注");
                            $("#"+thisUid).css("color","#a9a9a9");
                            //取消关注
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/user/deleteFollow.do",
                                data: {
                                    "receptorId": thisUid,
                                    "uid": userId,
                                    "token": usertoken,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        //console.log(res);
                                        $("#"+thisUid).html("关注");
                                        $("#"+thisUid).css("color","#FE4502");
                                    }
                                }
                            })
                        }else {
                            //关注
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/user/following.do",
                                data: {
                                    "receptorId": thisUid,
                                    "uid": userId,
                                    "token": usertoken,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        //console.log(res);
                                        $("#" + thisUid).html("已关注");
                                        $("#" + thisUid).css("color", "#a9a9a9");
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }
    // 最头条
    $.ajax({
        type: "get",
        async: true,
        dataType: "json",
        url:"/api/v2/homePage/kind.do",
        data: {
            "type": 0,
        },
        success: function (res) {
            if(res.code == 0) {
                //console.log(res);
                var headlineListLen = res.data.length;
                if(res.data==""){
                    $(".headlineWrap").stop().hide();
                }
                if(headlineListLen > 5) {
                    headlineListLen = 5;
                };
                if(headlineListLen == 1 || headlineListLen == 2 || headlineListLen == 3 || headlineListLen == 4 || headlineListLen == 5) {
                    for(var k = 0; k < headlineListLen; k++) {
                        var remarks = res.data[k].remarks;
                        var bannerType = res.data[k].bannerType;
                        var createTime = res.data[k].createTime;
                        var objectId=res.data[k].id;
                        if(k == 0) {
                            var headlineList = "<li class='headlineList'  objectId=" + objectId + " bannerType=" + bannerType + " id=a" + createTime + ">" +
                                "<img class='fl' src='images/index1Num1.png'/>" +
                                "<p class='fl'>" + remarks + "</p>" +
                                "</li>";
                            $(".headlineListWrap").append(headlineList);
                        } else if(k == 1) {
                            var headlineList = "<li class='headlineList'  objectId=" + objectId + " bannerType=" + bannerType + " id=a" + createTime + ">" +
                                "<img class='fl' src='images/index1Num2.png'/>" +
                                "<p class='fl'>" + remarks + "</p>" +
                                "</li>";
                            $(".headlineListWrap").append(headlineList);
                        } else if(k == 2) {
                            var headlineList = "<li class='headlineList'  objectId=" + objectId + " bannerType=" + bannerType + " id=a" + createTime + ">" +
                                "<img class='fl' src='images/index1Num3.png'/>" +
                                "<p class='fl'>" + remarks + "</p>" +
                                "</li>";
                            $(".headlineListWrap").append(headlineList);
                        } else if(k == 3) {
                            var headlineList = "<li class='headlineList'  objectId=" + objectId + " bannerType=" + bannerType + " id=a" + createTime + ">" +
                                "<img class='fl' src='images/index1Num4.png'/>" +
                                "<p class='fl'>" + remarks + "</p>" +
                                "</li>";
                            $(".headlineListWrap").append(headlineList);
                        } else if(k == 4) {
                            var headlineList = "<li class='headlineList'  objectId=" + objectId + " bannerType=" + bannerType + " id=a" + createTime + ">" +
                                "<img class='fl' src='images/index1Num5.png'/>" +
                                "<p class='fl'>" + remarks + "</p>" +
                                "</li>";
                            $(".headlineListWrap").append(headlineList);
                        };
                    }


                };
                //根据bannerType判断链接跳转	横幅类型（1文章，2短评，3视频，4直播或视频回放，5静态网页，6主播个人页,7不跳转，8操盘手个人页，9个人实盘页，10话题详情页，11专栏详情页）
                $(".headlineList").click(function() {
                    var bannerType = $(this).attr("bannerType");
                    //console.log(bannerType);
                    if(bannerType == 1) {//文章
                        var objectId=$(this).attr("objectId");
                        window.open("/article?id=" + objectId); //文章
                    }
                    if(bannerType == 2) {//短评
                        var uid=$(this).attr("uid");
                        window.open("/userProfile?uid=" + uid); //短评
                    }
                    if(bannerType == 3){//视频
                        var objectId=$(this).attr("objectId");
                        window.open("/video?id=" + objectId); //视频
                    }
                    if(bannerType == 5){//5静态网页
                        var objectId=$(this).attr("objectId");
                        window.open(objectId); //静态网页
                    }
                    if(bannerType == 6) {//6主播个人页
                        var uid=$(this).attr("uid");
                        window.open("/userProfile?uid=" + uid); //短评
                    }
                    if(bannerType == 9) {//6主播个人页
                        var uid=$(this).attr("uid");
                        window.open("/userProfile?uid=" + uid); //短评
                    }
                    if(bannerType == 10){//11专栏详情
                        var objectId=$(this).attr("objectId");
                        window.open("/topicDetails?id=" + objectId); //专栏详情
                    }
                    if(bannerType == 11){//11专栏详情
                        var objectId=$(this).attr("objectId");
                        window.open("/columnDetail?id=" + objectId); //专栏详情
                    }
                })
            }
        }
    })

    // 全部直播
    function allLive(pageindex,ulid) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url:"/api/v3/live/getVideoLiveRoomList.do",
            data: {
                "pageIndex": pageindex,
                "pageSize":8,
            },
            success: function (res) {
                if(res.code==0){
                   // console.log(res);
                    var length=res.data.length;
                    if(length<8 && res.data!=""){
                        $(".loading").stop().hide();
                        $(".loadEnd").stop().show();
                    }
                    $(res.data).each(function(i,k) {
                        var coverUrl=k.coverUrl;
                        var headImgUrl=k.liverInfo.headImgUrl;
                        var type=k.type;
                        var topic=k.topic;
                        var nickName=k.liverInfo.nickName;
                        var watchCount=k.watchCount;
                        var id=k.id;
                        var status = k.status;
                        var openness=k.openness;
                        var uid=k.liverInfo.uid;
                        if(status==0){//视频
                            var allLive1Inner = "<li id="+id+" openness="+openness+" uid="+uid+" kid='0' class='allLiveInner'>" +
                                "<img class='liveImg' src='"+coverUrl+"' alt=''>" +
                                "<img class='play' src='./images/select.png' alt=''>" +
                                "<div class='livePerson'>" +
                                "<img class='headImg' src='"+headImgUrl+"' alt=''>" +
                                "<p class='title'>"+topic+"</p>" +
                                "<p class='name'>"+nickName+"</p>" +
                                "<span class='watch'>"+watchCount+"人已看</span>" +
                                "</div>" +
                                "</li>"
                            $(ulid).append(allLive1Inner);
                        }else if(status==1){//直播
                            var allLive1Inner = "<li id="+id+" openness="+openness+" uid="+uid+" kid='1' class='allLiveInner'>" +
                                "<img class='liveImg' src='"+coverUrl+"' alt=''>" +
                                "<img class='play' src='./images/select.png' alt=''>" +
                                "<img class='living' src='./images/live.png' alt=''>" +
                                "<div class='livePerson'>" +
                                "<img src='"+headImgUrl+"' alt=''>" +
                                "<p class='title'>"+topic+"</p>" +
                                "<p class='name'>"+nickName+"</p>" +
                                "<span class='watch'>"+watchCount+"人已看</span>" +
                                "</div>" +
                                "</li>"
                            $(ulid).append(allLive1Inner);
                        }
                        $(".allLiveInner .liveImg").one("error", function(e) {
                            $(this).attr("src", "images/vedioCoverUrl.jpg");
                        })
                        $(".allLiveInner .livePerson img").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        })
                    })
                }
            }
        })
    }
    allLive(1,"#allLive1");
    allLive(2,"#allLive2");

    // 全部直播下拉加载更多
    var pageIndex=2;
    $(window).on('scroll', function () {
        if($(document).scrollTop() + $(window).height() >= $(document).height()){
            pageIndex++;
            allLive(pageIndex,"#allLive2");
        }
    });
})

function bannerDump(obj) {
    $(obj).on("click",function () {
        var type=$(this).attr("objectType");
        var id=$(this).attr("objectId");
        var uid=$(this).attr("uid");
        if(type==1){//文章
            window.location.href ="";
        }else if(type==2){//短评
            //window.location.href ="";
        }else if(type==3){//视频或回放
            window.location.href ="/video?id="+id;
        }else if(type==4){//直播
            window.location.href ="/live?uid="+uid;
        }else if(type==5){//静态页面
            window.location.href =id;
        }else if(type==6){//个人主播页
            window.location.href ="/userProfile?uid="+uid;
        }else if(type==7){//不跳转
            //window.location.href ="http://www.baidu.com";
        }else if(type==8){//操盘手个人页
            // window.location.href ="/userProfile?uid="+uid;
        }else if(type==9){//个人实盘页
            window.location.href ="/userProfile?uid="+uid;
        }else if(type==10){//话题
            window.location.href ="/topicDetails?id="+id;
        }else if(type==11){//专栏详情页
            window.location.href ="/columnDetail?id="+id;
        }
    })
}


//大V推荐跳转
$(document).on("click", ".member img", function(e) {
    var uid = $(this).parent().attr("uid");
    // console.log(uid);
    window.location.href ="/userProfile?uid="+uid;
})

//全部直播跳转
$(document).on("click", ".allLive ul li .play", function(e) {
    var uid = $(this).parent().attr("uid");
    var id = $(this).parent().attr("id");
    var kid = $(this).parent().attr("kid");
    if(kid=="0"){//视频
        window.location.href ="/video?id="+id;
    }else if(kid=="1"){//直播
        window.location.href ="/live?uid="+uid;
    }
})

/*固定条*/
var IndexpageIndex =1;
$(".fixed_nav .reload").click(function() {
    $("body,html").animate({
        scrollTop: 1200
    }, 800)
    IndexpageIndex++;
    insertHot(IndexpageIndex, 10, "top");
    $(".insertTopWrap").stop().show(0).delay(4000).hide(0);
    $("#hotTopLoading").show().delay(1000).hide(0);
    $(".insertTop").delay(1000).slideDown(0).delay(3000).slideUp(0);

})
$(window).scroll(function() {
    var t = $(this).scrollTop();
    if(t > 200) {
        $(".goTop").stop().fadeIn()
    } else {
        $(".goTop").stop().fadeOut()
    }
});
$(".goTop").click(function() {
    $("body,html").animate({
        scrollTop: 0
    }, 800)
});



