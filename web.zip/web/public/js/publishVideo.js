$(document).ready(function(){
	//根据屏幕的高度，写发布视频的弹框高度
	 var coverUrl;
	if(window.screen.availHeight>=1000){
	  $(".publishVideoWrap").css({
	  	"margin-top":"100px"
	  })
	}else{
	  $(".publishVideoWrap").css({
	  	"margin-top":"25px"
	  })	
	};
	//视频字数限制30个
	$("#videoTitle").on("keyup", function() {
		/*字数倒计数*/
		var num = 30 - ($(this).val().length);
		$(".titleFontNum").html(num);
	});
	//加密不加密
	$("#videoPsdBox").click(function(){
		var pawStatu=$("#videoPsdBox").val();
		if(pawStatu==="1"){
			$(".setPawBox").stop().show();
			$("#pawNum").stop().show();
		}else{
			$(".setPawBox").stop().hide();
			$("#pawNum").stop().hide();
		}
	})
	//判断主播是否登录
	$.ajax({
		type: "get",
		url: "/userInfos",
		success: function(res) {
			// console.log(res);
			if(res.code == -2) { //未登录
				//登录
				$("#publishViewBtn").click(function() {
					$("#loginAlert").load("/login");
				});
				
			};
			if(res.code == 0) {
				// console.log(res);
				var uid=roleType=res.data.userInfo.uid;
				var token=res.data.token;
				//发布成功跳转到主播个人页
				$(".gotoUserProfile").click(function(){
		            window.location.href="/userProfile?uid=" + uid+"&tab=2";
		            $("#publishVideoBox").stop().hide();
		            $("#loginAlert").stop().hide();
	            });
	             //专栏
                getColumnByUid(uid);
	            
	            //上传视频
                videoUpload(uid,token);
                //上传封面
//              console.log($("#uploadVideoInfo").innerHTML);
//              if($("#uploadVideoInfo").innerHTML=="上传成功！"){
	            uplodVideoEdit(uid,token);
//	            }
               
               
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus);
		},
	});
	//专栏
	function getColumnByUid(uid){
		$.ajax({
				type: "get", //请求方式
				async: true, //是否异步
				dataType: "json",
				url:"/api/v2/column/getColumnByUid.do",
				data:{
					"uid": uid,
				},
				success:function(res){
					//console.log(res);
					var dataLen=res.data.length;
					if(dataLen>=1){
						$(res.data).each(function(i,k){
						   var videozl="<option id="+k.id+">"+k.name+"</option>";
						   $("#contentSortVideo").append(videozl);
						});
					}else{
						 var videozl="<option>您还没有专栏哦</option>";
						 $("#contentSortVideo").append(videozl);
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				},
		})
	}
	//上传视频
	var videouploder;
	function videoUpload(uid,token){
		var updownHref="https://video.fengniutv.com/";
		//var updownHref="http://video.91qiniu.com/";
		$.ajax({
				type: "get", //请求方式
				async: true, //是否异步
				dataType: "json",
				url:"/api/v1/video/upload/token.do",
				data:{
					"uid": uid,
					"token": token,
					"duration":"",
				},
				success:function(res){
					console.log(res);
					var videotoken = res.data.uploadToken;
					var videofilekey=res.data.id;
					videouploder = Qiniu.uploader({
	                    runtimes: 'html5,flash,html4',    //上传模式,依次退化
	                    browse_button: 'videoUploadButton',       //上传选择的点选按钮，**必需**
	                    uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
	                    uptoken : videotoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
	                    uptoken_func: function(file) {
	                 		
	                    },
	                    unique_names: false, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
	                    save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
	                  //  domain: 'http://video.fengniutv.com/',//bucket域名，下载资源时用到，**必需**外网
	                    domain: updownHref,//bucket域名，下载资源时用到，**必需*内网
	                    get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
	                    container: 'videoUploadProcessBox',           //上传区域DOM ID，默认是browser_button的父元素，
	                    max_file_size: '1024mb',           //最大文件体积限制   
	                    flash_swf_url: 'js/Moxie.swf',  //引入flash,相对路径
	                    max_retries: 3,                   //上传失败最大重试次数
	                    dragdrop: true,                   //开启可拖曳上传
	                    drop_element: 'videoUploadProcessBox',   //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
	                    chunk_size: '4mb',                //分块上传时，每片的体积
	                    auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                        filters : {
                            max_file_size : '1024mb',
                            prevent_duplicates: true,
                            //Specify what files to browse for
                            mime_types: [
                               {title : "Video files", extensions : "flv,mpg,mpeg,avi,wmv,mov,asf,rm,rmvb,mkv,m4v,mp4"} //限定video后缀上传格式上传
                            ]
                        },
	                    init: {
	                        'FilesAdded': function(up, files) {
	                            plupload.each(files, function(file) {
	                                // 文件添加进队列后,处理相关的事情
	                            });
	                        },
	                        'BeforeUpload': function(up, file) {
	                               // 每个文件上传前,处理相关的事情
	                        },
	                        'UploadProgress': function(up, file) {
	                               // 每个文件上传时,处理相关的事情
	                              //进度条
	                               $("#videoUploadProcessBox").show();
	                               //文件名
	                                //百分比
	                               var pro=file.percent;
	                               var fileName=file.name;
	                               $(".videoUploadTitle").html(fileName);
	                               //文件大小	
	                               var fileSize=((file.size/1024)/1024).toFixed(2);
	                               $(".videoSize").html(fileSize);
	                               //上传速度
	                               var speed=(file.speed/1024).toFixed(2);
	                               $(".videoSpeed").html(speed);
	                               //已上传
	                               var uploadedFile=((fileSize*pro)/100).toFixed(2);
	                               $(".videouploaded1").html(uploadedFile);
	                               //剩余时间
	                              	var lastTime=(((fileSize/speed)*(100-pro))*10).toFixed(2);
	                              	$(".videoLastTime").html(lastTime);
						            //文字提示
						            $("#uploadVideoInfo").text(pro+"%");
						            if(pro == 100){
						            	$("#uploadVideoInfo").text("99%");
						            }
						            //动态改变div的宽度占比
						            $(".videoUploadProcessInner").width(pro+"%");
	                        },
	                        'FileUploaded': function(up, file, info) {
//	                        	console.log(info);
//	                        	var info=JSON.stringify(info);
//	                        	if(info.code==0){//上传成功
//	                        		$("#uploadVideoInfo").text("上传成功！");
//	                        	}
								//console.log(file);
								var headerInfo=JSON.parse(info);
								console.log(headerInfo);
								if(headerInfo.code==0){//上传成功
	                        	   $("#uploadVideoInfo").text("上传成功！");
	                        	}else{
	                        		$("#uploadVideoInfo").text("上传失败！请重新上传");
	                        	}
								var videoUrl=updownHref+videofilekey;
								console.log(videoUrl);
								var videoinfo = videoUrl+"?avinfo";
								//console.log(videoinfo);
							//	var videoinfo1 = videoinfo.replace("http","https");//外网
								//获取视频第一帧图片作为视频封面
								coverUrl=videoUrl+"?vframe/jpg/offset/0";
							 //   console.log(coverUrl);
								//$(".videoCoverUrl").attr("src",coverUrl);
								//调用接口获得视频时长
								$.ajax({
									url: videoinfo,
									async: true,
									type: 'get',
									dataType: "json",
									success: function (res) {
										//console.log(res);
										var duration = parseInt(res.format.duration);//时长
										//上传视频接口
										$("#videoConfirm").on("click",function(){
                                            // console.log(duration);
											var topic=$("#videoTitle").val();
											var columnId=$("#contentSortVideo option:selected").attr("id");
											publishVideoFun(uid,token,videofilekey,coverUrl,topic,'window',2,columnId,duration);
										})
									}
								})
	                        },
	                        'Error': function(up, err, errTip) {
	                        	console.log(up);
                            	console.log(err);
                                console.log(errTip);
                                if(errTip.code!=0){
                                	$("#uploadVideoInfo").text("上传失败！请重新上传");
                                }
	                               //上传出错时,处理相关的事情
	                        },
	                        'UploadComplete': function() {
	                               //队列文件处理完毕后,处理相关的事情
	                        },
	                        'Key': function(up, file) {
	                            var key =videofilekey;
	                            return key;
//                              var key = "";
//                              return key
	                        }
	                    }
	           		});
			}
		});
	    $('.quxiaoUpload').on('click', function(){
	        videouploder.stop();
	    });
	};
	//X
	closeVideoBox(".successClose");
    closeVideoBox(".closeShortPage");
    closeVideoBox(".cancelVideoBtn");
	function closeVideoBox(obj){
		$(obj).click(function(){
			$("#publishVideoBox").stop().hide();
			$("#loginAlert").stop().hide();
			 videouploder.stop();
		});
	}
	//编辑视频封面图片
    function uplodVideoEdit(uid,token){
    	// var updownimgHref="http://picture.91qiniu.com/";//内网
		var updownimgHref="https://picture.fengniutv.com/";
        $.ajax({
            type: "get", //请求方式
            async: true, //是否异步
            dataType: "json",
            url: "/api/v1/picture/batchUpload/token.do",
            data:{
                "uid": uid,
                "token": token,
            },
            success:function(res){
                if(res.code==0)
                {
                	//console.log(res);
                    var videoEditImgtoken = res.data.uploadToken;
                    //七牛上传图片
                    var uploader6 = Qiniu.uploader({
                        runtimes: 'html5,flash,html4',    //上传模式,依次退化
                        browse_button: 'upLoadVideoCover',       //上传选择的点选按钮，**必需**
                        uptoken_url: updownimgHref, //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                        uptoken : videoEditImgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                        uptoken_func: function(file) {

                        },
                        unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                        save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                        domain: updownimgHref,//bucket域名，下载资源时用到，**必需**
                        get_new_uptoken: true,  //设置上传文件的时候是否每次都重新获取新的token
                        container: 'upDpwnWrapImgBox',           //上传区域DOM ID，默认是browser_button的父元素，
                        max_file_size: '100mb',           //最大文件体积限制
                        flash_swf_url: 'js/Moxie.swf',  //引入flash,相对路径
                        max_retries: 3,                   //上传失败最大重试次数
                        dragdrop: true,                   //开启可拖曳上传
                        drop_element: 'upDpwnWrapImgBox',   //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                        chunk_size: '4mb',                //分块上传时，每片的体积
                        auto_start: true,                //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                        init: {
                            'FilesAdded': function(up, files) {
                                plupload.each(files, function(file) {
                                    // 文件添加进队列后,处理相关的事情
                                });
                            },
                            'BeforeUpload': function(up, file) {
                                //console.log(file);
                                // 每个文件上传前,处理相关的事情
                            },
                            'UploadProgress': function(up, file) {
                                // 每个文件上传时,处理相关的事情
                            },
                            'FileUploaded': function(up, file, info) {
                            	// console.log(info);
                                var imgInfoVideoEditinfo=JSON.parse(info);
                                coverUrl=updownimgHref+imgInfoVideoEditinfo.key;
                                $(".videoCoverUrl").attr("src",coverUrl);
                            },
                            'Error': function(up, err, errTip) {
                            	console.log(up);
                            	console.log(err);
                                console.log(errTip);
                                //上传出错时,处理相关的事情
                            },
                            'UploadComplete': function() {
                                //队列文件处理完毕后,处理相关的事情
                            }
                        }

                    });
                }
            },
        });
    }
    
    function publishVideoFun(uid,token,id,coverUrl,topic,device,type,columnId,duration){
    	$.ajax({
	        url:"/api/v3/video/publish.do",
	        async:true,
	        type:'post',
	        dataType:"json",
	        data:{
	            "uid":uid,
				"token":token,
				"id":id,
				"coverUrl":coverUrl,
				"topic": topic,
				"device": device,
				"type":type,
				"columnId":columnId,
				"duration":duration
	        },
	        success:function(res){
	           // console.log(res);
	            if(res.data==0){
	               $(".publishVideoWrap").stop().hide();
	               $(".sendSccessBoxWrap").stop().show();
	            }
	        }
	    })
    }
	
})
