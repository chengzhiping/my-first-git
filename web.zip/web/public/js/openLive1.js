$(document).ready(function () {
    var uid = GetQueryString("uid");
    var roomId = GetQueryString("roomid");
    var userId;
    var token;
    var userNickName;
    var userNickHeadurl;
    // 判断登录
    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function (res) {
            if (res.code == -2) { //未登录（用户视角）
            }else if(res.code == 0) {//已登录
                // console.log(res);
                userId = res.data.userInfo.uid;
                token = res.data.token;
                userNickName = res.data.userInfo.nickName;
                userNickHeadurl = res.data.userInfo.headImgUrl;
                uploadVideoImg(uid,token);
            }
        }
    })
    //关闭FMS及串流码弹框
    $("#closeStreaCodeFMS").click(function () {
        $(".streaCodeFMS").stop().hide();
    })
    //关闭创建视频直播弹框
    $("#closeCreateVideo").click(function () {
        $(".createVideo").stop().hide();
    })
    //取消创建视频直播弹框
    $("#cancalVideo").click(function () {
        $(".createVideo").stop().hide();
    })
    //重置串流码
    $("#reputCode").click(function () {
        $(".streaCodeFMS").stop().hide();
        $(".createVideo").stop().show();
    })
    //关闭填写参数流程弹框
    $(".closeWriteSteps").click(function () {
        $(".writeSteps").stop().hide();
    })
    //点击如何填入参数
    $(".drmpNext").click(function () {
        $(".noticeDownload").stop().hide();
        $(".writeSteps").stop().show();
    })
    //关闭提示下载弹框
    $(".closeNoticeDownload").click(function () {
        $(".noticeDownload").stop().hide();
    })
    // 点击
    $("#startOBS").click(function () {
        $(".streaCodeFMS").stop().hide();
        $(".noticeDownload").stop().show();
    })
    //点击视频直播
    $("#publishVideo").click(function () {
        $(".createVideo").stop().show();
        $("html,body").animate({scrollTop:0},200);
    })
    // 点击添加链接
    $("#addLinkUrl").click(function () {
        $(".addLinkUrl").stop().show();
        $("html,body").animate({scrollTop:0},200);
    })
    // 点击取消添加链接
    $("#cancalAddLinkUrl").click(function () {
        $(".addLinkUrl").stop().hide();
    })
    // 点击关闭直播回放框
    $(".closeVideoPlay").click(function () {
        $(".videoPlay").stop().hide();
    })
    // 点击发布图文
    $("#publishImgBtn").click(function () {
        $(".publishImgBox").stop().show();
        $("html,body").animate({scrollTop:0},200);
    })
    //关闭发布图文弹框
    $(".closeShortPage").click(function(){
        $(".publishImgBox").stop().hide();
    });
    $(".shortViewContent").on("keyup", function() {
        /*字数倒计数*/
        var num = 300 - ($(this).val().length);
        /*console.log(num);*/
        if(num > 0&&num<300) {
            $(".shortViewContentNum").html(num);
            $("#publishViewBtn").css({
                "background":"#fe4502"
            });
            $('#publishViewBtn').removeAttr("disabled");

        } else if(num<=0){
            $(".shortViewContentNum").html(0);
        };
        if(num==300){
            $(".shortViewContentNum").html(300);
            $("#publishViewBtn").css({
                "background":"#d8d8d8"
            });
            $('#publishViewBtn').attr("disabled","disabled");
        }
        $(".shortViewContentNum").css(
            'color', "#FE4502"
        );
    });
    // uploadVideoImg(uid,token);
    //上传直播封面图片
    function uploadVideoImg(uid,token){
        // var updownimgHref="http://picture.91qiniu.com/";//内网
        var updownimgHref="http://picture.fengniutv.com/";
        $.ajax({
            type: "get", //请求方式
            async: true, //是否异步
            dataType: "json",
            url: "/api/v1/picture/batchUpload/token.do",
            data:{
                "uid": uid,
                "token": token,
            },
            success:function(res){
                if(res.code==0)
                {
                    // console.log(res);
                    var videoEditImgtoken = res.data.uploadToken;
                    //七牛上传图片
                    var uploader = Qiniu.uploader({
                        runtimes: 'html5,flash,html4',    //上传模式,依次退化
                        browse_button: 'add1Img',       //上传选择的点选按钮，**必需**
                        uptoken_url: updownimgHref, //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                        uptoken : videoEditImgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                        uptoken_func: function(file) {

                        },
                        unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                        save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                        domain: updownimgHref,//bucket域名，下载资源时用到，**必需**
                        get_new_uptoken: true,  //设置上传文件的时候是否每次都重新获取新的token
                        container: 'uploadInnerImg',           //上传区域DOM ID，默认是browser_button的父元素，
                        max_file_size: '100mb',           //最大文件体积限制
                        flash_swf_url: 'js/Moxie.swf',  //引入flash,相对路径
                        max_retries: 3,                   //上传失败最大重试次数
                        dragdrop: true,                   //开启可拖曳上传
                        drop_element: 'uploadInnerImg',   //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                        chunk_size: '4mb',                //分块上传时，每片的体积
                        auto_start: true,                //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                        init: {
                            'FilesAdded': function(up, files) {
                                plupload.each(files, function(file) {
                                    // 文件添加进队列后,处理相关的事情
                                });
                            },
                            'BeforeUpload': function(up, file) {
                                //console.log(file);
                                // 每个文件上传前,处理相关的事情
                            },
                            'UploadProgress': function(up, file) {
                                // 每个文件上传时,处理相关的事情
                            },
                            'FileUploaded': function(up, file, info) {
                                // console.log(info);
                                var imgInfoVideoEditinfo=JSON.parse(info);
                                coverUrl=updownimgHref+imgInfoVideoEditinfo.key;
                                $("#uploadInnerImg").attr("src",coverUrl);
                                $(".addTips").html("修改封面");
                                $(".addTips").css("color","#ffffff");
                            },
                            'Error': function(up, err, errTip) {
                                // console.log(up);
                                // console.log(err);
                                // console.log(errTip);
                                //上传出错时,处理相关的事情
                            },
                            'UploadComplete': function() {
                                //队列文件处理完毕后,处理相关的事情
                            }
                        }
                    });
                }
            },
        });
    }
    getLiveMessage(roomId);
    //获取直播间基本信息
     function getLiveMessage(roomId) {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v3/live/getLiveRoomInfo.do",
            data: {
                "roomId": roomId,
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    var encryption = res.data.encryption;
                    // console.log(encryption);
                    if(encryption == 0){//不允许加密
                        $("#isVideoPwd1").stop().hide();
                        $("#isVideoPwd2").stop().hide();
                        // 开启视频直播
                        $("#getCode").click(function () {
                            var topic = $("#videoTitle").val();
                            var coverUrl = $("#uploadInnerImg").attr("src");
                            // console.log(topic);
                            // console.log(coverUrl);
                            if(topic == ""){
                                $(".mustImg").stop().show();
                                $(".mustTips").stop().show();
                                return false;
                            }
                            if(coverUrl == "" || coverUrl == undefined){
                                alert("请上传封面图片");
                                return false;
                            }
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/live/createLive.do",
                                data: {
                                    "roomId": roomId,
                                    "uid":uid,
                                    "token":token,
                                    "topic":topic,
                                    "coverUrl":coverUrl,
                                    "device": "Windows"
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        // console.log(res);
                                        var videoTopic = res.data.topic;
                                        var str = res.data.pushUrl;
                                        //截取直播流
                                        function find(str,cha,num){
                                            var x=str.indexOf(cha);
                                            for(var i=0;i<num;i++){
                                                x=str.indexOf(cha,x+1);
                                            }
                                            return x;
                                        }
                                        var indexNum=find(str,'/',3);
                                        /*获得fms*/
                                        var fmsUrl=str.substring(0,indexNum);
                                        var tuiliuUrl=str.substring(indexNum+1,str.length);
                                        // console.log(fmsUrl);
                                        // console.log(tuiliuUrl);
                                        $("#liveTitle").val(videoTopic);
                                        $("#getVideoImg2").attr("src",coverUrl);
                                        $("#FMSURL2").val(fmsUrl);
                                        $("#maskLayerCode2").val(tuiliuUrl);
                                        $("#FMSURL3").val(fmsUrl);
                                        $("#maskLayerCode3").val(tuiliuUrl);
                                        //点击生成串流码
                                        $(".createVideo").stop().hide();
                                        $(".streaCodeFMS").stop().show();
                                    }
                                }
                            })
                        })
                    }else if(encryption == 1){//允许加密
                        // 开启视频直播
                        $("#getCode").click(function () {
                            var topic = $("#videoTitle").val();
                            var pwd = $("#videoPwd").val();
                            var coverUrl = $("#uploadInnerImg").attr("src");
                            // console.log(topic);
                            // console.log(coverUrl);
                            if(topic == ""){
                                $(".mustImg").stop().show();
                                $(".mustTips").stop().show();
                                return false;
                            }
                            if(coverUrl == "" || coverUrl == undefined){
                                alert("上传封面图片");
                                return false;
                            }
                            // 密码为6位数字
                            var pwdstr = $("#videoPwd").val().trim();
                            if(pwdstr.length!=6 && $("#videoPwd").val()!=""){
                                reg=/^\d{6}$/;
                                if(!reg.test(pwdstr)){
                                    $(".pwdTips").stop().show();
                                    setTimeout('$(".pwdTips").fadeOut()', 2000);
                                    return false;
                                }
                            }
                            if($("#videoPwd").val() == ""){
                                $.ajax({
                                    type: "post",
                                    async: true,
                                    dataType: "json",
                                    url: "/api/v3/live/createLive.do",
                                    data: {
                                        "roomId": roomId,
                                        "uid":uid,
                                        "token":token,
                                        "topic":topic,
                                        "coverUrl":coverUrl,
                                        "device": "Windows"
                                    },
                                    success: function (res) {
                                        // console.log(res);
                                        if (res.code == 0) {
                                            var videoTopic = res.data.topic;
                                            var str = res.data.pushUrl;
                                            //截取直播流
                                            function find(str,cha,num){
                                                var x=str.indexOf(cha);
                                                for(var i=0;i<num;i++){
                                                    x=str.indexOf(cha,x+1);
                                                }
                                                return x;
                                            }
                                            var indexNum=find(str,'/',3);
                                            /*获得fms*/
                                            var fmsUrl=str.substring(0,indexNum);
                                            var tuiliuUrl=str.substring(indexNum+1,str.length);
                                            // console.log(fmsUrl);
                                            // console.log(tuiliuUrl);
                                            $("#liveTitle").val(videoTopic);
                                            $("#getVideoImg2").attr("src",coverUrl);
                                            $("#FMSURL2").val(fmsUrl);
                                            $("#maskLayerCode2").val(tuiliuUrl);
                                            $("#FMSURL3").val(fmsUrl);
                                            $("#maskLayerCode3").val(tuiliuUrl);
                                            //点击生成串流码
                                            $(".createVideo").stop().hide();
                                            $(".streaCodeFMS").stop().show();
                                        }
                                    }
                                })
                            }else{
                                $.ajax({
                                    type: "post",
                                    async: true,
                                    dataType: "json",
                                    url: "/api/v3/live/createLive2.do",
                                    data: {
                                        "roomId": roomId,
                                        "uid":uid,
                                        "token":token,
                                        "topic":topic,
                                        "coverUrl":coverUrl,
                                        "device": "Windows",
                                        "openness": 1,
                                        "authCode": pwd
                                    },
                                    success: function (res) {
                                        // console.log(res);
                                        if (res.code == 0) {
                                            var videoTopic = res.data.topic;
                                            var str = res.data.pushUrl;
                                            //截取直播流
                                            function find(str,cha,num){
                                                var x=str.indexOf(cha);
                                                for(var i=0;i<num;i++){
                                                    x=str.indexOf(cha,x+1);
                                                }
                                                return x;
                                            }
                                            var indexNum=find(str,'/',3);
                                            /*获得fms*/
                                            var fmsUrl=str.substring(0,indexNum);
                                            var tuiliuUrl=str.substring(indexNum+1,str.length);
                                            // console.log(fmsUrl);
                                            // console.log(tuiliuUrl);
                                            $("#liveTitle").val(videoTopic);
                                            $("#getVideoImg2").attr("src",coverUrl);
                                            $("#livePwd").val(pwd);
                                            $("#FMSURL2").val(fmsUrl);
                                            $("#maskLayerCode2").val(tuiliuUrl);
                                            $("#FMSURL3").val(fmsUrl);
                                            $("#maskLayerCode3").val(tuiliuUrl);
                                            //点击生成串流码
                                            $(".createVideo").stop().hide();
                                            $(".streaCodeFMS").stop().show();
                                        }
                                    }
                                })
                            }
                        })
                    }
                }
            }
        })
    }
    //复制
    $("#copyFMSURL").click(function () {
        copyUrl("#FMSURL3",'#copyFMSURL');
    })
    $("#copyMaskLayerCode").click(function () {
        copyUrl("#maskLayerCode3",'#copyMaskLayerCode');
    })
    //复制
    $("#copyFMSURL1").click(function () {
        copyUrl1("#FMSURL2",'#copyFMSURL1');
    })
    $("#copyMaskLayerCode1").click(function () {
        copyUrl1("#maskLayerCode2",'#copyMaskLayerCode1');
    })
    function copyUrl(copyContent,copyBtn) {
        var g_url =$(copyContent).val();
        // console.log(g_url);
        var clipboard = new Clipboard(copyBtn, {
            text: function() {
                return g_url;//返回本页的地址
            }
        });
        clipboard.on('success', function(e) {
            //复制成功的弹框显示，2s后消失
            $("#copySuccess").stop().show();
            setTimeout('$("#copySuccess").fadeOut()', 2000);
            // console.log(e);
        });
        clipboard.on('error', function(e) {
            //复制失败的弹框显示，2s后消失
            $("#copyFaired").stop().show();
            setTimeout('$("#copyFaired").fadeOut()', 2000);
            // console.log(e);
        });
    }
    function copyUrl1(copyContent,copyBtn) {
        var g_url =$(copyContent).val();
        // console.log(g_url);
        var clipboard = new Clipboard(copyBtn, {
            text: function() {
                return g_url;//返回本页的地址
            }
        });
        clipboard.on('success', function(e) {
            //复制成功的弹框显示，2s后消失
            $("#copySuccess2").stop().show();
            setTimeout('$("#copySuccess2").fadeOut()', 2000);
            // console.log(e);
        });
        clipboard.on('error', function(e) {
            //复制失败的弹框显示，2s后消失
            $("#copyFaired1").stop().show();
            setTimeout('$("#copyFaired1").fadeOut()', 2000);
            // console.log(e);
        });
    }
})