//(function($) {
//	$.extend(true, $.trumbowyg, {
//		langs: {
//			en: {
//				base64: "Image as base64",
//				file: "File",
//				errFileReaderNotSupported: "FileReader is not supported by your browser."
//			},
//			fr: {
//				base64: "Image en base64",
//				file: "Fichier"
//			},
//			zh_cn: {
//				base64: "本地上传",
//				file: "文件"
//			}
//		},
//		opts: {
//			btnsDef: {
//				base64: {
//					isSupported: function() {
//						if(typeof FileReader === "undefined") {
//							console.err("[Trumbowyg - Plugin base64] FileReader is not supported by your browser.");
//							return false
//						}
//						return true
//					},
//					func: function(params, tbw) {
//						var file, $modal = tbw.openModalInsert(tbw.lang["base64"], {
//							file: {
//								type: "file",
//								required: true
//							},
//							alt: {
//								label: "description"
//							}
//						}, function(values, fields) {
//							var data = new FormData(),
//								fReader = new FileReader();
//							fReader.onloadend = function() {
//								tbw.execCommand("insertImage", fReader.result);
//								$(['img[src="', fReader.result, '"]:not([alt])'].join(""), tbw.$box).attr("alt", values["alt"]);
//								tbw.closeModal()
//							};
//							fReader.readAsDataURL(file)
//						});
//						$("input[type=file]").on("change", function(e) {
//							file = e.target.files[0]
//						})
//					}
//				}
//			}
//		}
//	})
//})(jQuery);