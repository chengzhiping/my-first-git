$(document).ready(function () {
	//倒计时
    function GetRTime(){
        var EndTime= new Date('2017/12/10 09:00:00');
        var NowTime = new Date();
        var t =EndTime.getTime() - NowTime.getTime();
        var d=0;
        var h=0;
        var m=0;
        var s=0;
        if(t>=0){
            d=Math.floor(t/1000/60/60/24);
            h=Math.floor(t/1000/60/60%24)+d*24;
            m=Math.floor(t/1000/60%60);
            s=Math.floor(t/1000%60);
            if(h<10){
                h="0"+h;
            }
            if(m<10){
                m="0"+m;
            }
            if(s<10){
                s="0"+s;
            }
        }
        document.getElementById("t_h").innerHTML = h + ":";
        document.getElementById("t_m").innerHTML = m + ":";
        document.getElementById("t_s").innerHTML = s;

        if(t<=0) {
            clearInterval(startTime);
			$(".timing").stop().hide();
			$(".daojishi").stop().hide();
			$(".daojishiOver").stop().show();
        }
    }
    var startTime=setInterval(GetRTime,0);
    //获取直播封面图
    $.ajax({
        dataType: "json",
        type: "post", //请求方式
        async: true, //是否异步
        url: "/api/v1/banner/selectByType.do",
        data: {
            "type": 11,
            "pageIndex": 1,
            "pageSize": 3
        },
        success: function (res) {
            if (res.code == 0) {
                console.log(res);
                $(".img1").attr("src",res.data[0].imgUrl);
                $(".img2").attr("src",res.data[1].imgUrl);
                $(".img3").attr("src",res.data[2].imgUrl);
            }
        }
    })
	//跳转
    $(".liveList").click(function(){
    	var roomid = $(this).attr("roomid");
    	var uid = $(this).attr("uid");
    	window.location.href = "/vipLive?uid="+uid+"&roomid="+roomid;
    })
    //电脑手机跳转
    function browserRedirect() {
        var sUserAgent = navigator.userAgent.toLowerCase();
        var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
        var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
        var bIsMidp = sUserAgent.match(/midp/i) == "midp";
        var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
        var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
        var bIsAndroid = sUserAgent.match(/android/i) == "android";
        var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
        var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
        if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
            window.location.href = "https://www.fntv8.com/m/v5.0/payLive";
            // window.location.href = "https://dev.fntv8.com/m/v5.0/payLive";
        }
    }
    browserRedirect();
})