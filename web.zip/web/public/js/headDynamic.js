$(document).ready(function() {
	$("#wrapHeader").load("/header");
	$("#indexFooter").load("/footer");
	//TAB切换
	$(".dynamicTab").click(function() {
		$(".dynamicTabLBoxWrap .dynamicTabLBox").eq($(this).index()).css("display", "block").siblings(".dynamicTabLBox").css("display", "none");
		$(this).addClass("dynamicTabActive").siblings(".dynamicTab").removeClass("dynamicTabActive");
	});

	//切换
	var tab = GetQueryString("tab");
	if(tab != "" && tab != undefined && tab != null) {
		//console.log(tab);
		tabFun(tab);
	} else {
		$(".dynamicTab").eq(0).addClass("dynamicTabActive").siblings().remove("dynamicTabActive");
		$(".dynamicTabLBoxWrap .dynamicTabLBox").eq(0).css("display", "block").siblings(".dynamicTabLBox").css("display", "none");
	}

	function tabFun(tab) {
		$(".dynamicTab").eq(tab - 1).addClass("dynamicTabActive").siblings().remove("dynamicTabActive");
		$(".dynamicTabLBoxWrap .dynamicTabLBox").eq(tab - 1).css("display", "block").siblings(".dynamicTabLBox").css("display", "none");
		if(tab == 3) {
			$("#anchorFindBox").html("");
			getTagList("", "", 1, 20);
		}

	}
	/*轮播*/
	//回到头部
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
	//热门动态
	loginFun();
	//判断是否已经登录-已登录看看是否关注，点赞
	function loginFun() {
		$.ajax({
			type: "get",
			url: "/userInfos",
			success: function(res) {
				//console.log(res);
				if(res.code == -2) { //未登录
					selectDynamicHotPaging("", "", 1, 10, "HotPaging");
					$(".nologinAlert").stop().show();
					$(".getDynamicListLoading").stop().hide();
					$(".loginBtn").click(function() {
						$("#loginAlert").stop().show();
						$("#loginAlert").load("/login");
					});
					//主播发现
					$(".userFindBox").click(function() {
						$("#anchorFindBox").html("");
						getTagList("", "", 1, 20);
					})
				} else if(res.code == 0) { //已登录
					//console.log(res);
					var userId = res.data.userInfo.uid;
					var userToken = res.data.token;
					selectDynamicHotPaging(userId, userToken, 1, 10, "HotPaging");
					$(".usergetDynamicList").click(function() {
						getDynamicListFun(userId, userToken, 1, 10, "getDynamicList");
					})
					selectReceptorV2(userId, 1, 5);
					//主播发现
					$(".userFindBox").click(function() {
						$("#anchorFindBox").html("");
						getTagList(userId, userToken, 1, 20);
					})
				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		})
	}
	//点击登录按钮，进行登录

	//DynamicHotType=HotPaging热门动态  getDynamicList//获得关注的动态
	function selectDynamicHotPaging(uid, token, pageIndex, pageSize, DynamicHotType) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v2/dynamicHot/selectDynamicHotPaging.do",
			data: {
				"uid": uid,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					introDynamicSame(uid, token, res, DynamicHotType,token);
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
	};

	function getDynamicListFun(uid, token, pageIndex, pageSize, DynamicHotType) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/dynamic/getDynamicList.do",
			data: {
				"uid": uid,
				"token": token,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					introDynamicSame(uid, token, res, DynamicHotType,token);
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
	}

	//解析动态
	var AllPageIndex = 1;
	var getDynamicListIndex = 1;
	

	function introDynamicSame(uid, token, res, DynamicHotType,userToken) {
		var bottomH = 150; //距离底部多少像素开始加载
		if(res.data.length =10) {
			$(window).scroll(function() {
				var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop() + bottomH);
				if($(document).height() <= totalheight) {
					if(DynamicHotType == "HotPaging") {
						AllPageIndex++;
						selectDynamicHotPaging(uid, token, AllPageIndex, 10, "HotPaging");
					} else if(DynamicHotType == "getDynamicList") {
						getDynamicListIndex++;
						getDynamicListFun(uid, token, getDynamicListIndex, 10, "getDynamicList");
					}
				}
			});
		}
//		if(res.data.length > 0) {
//			if(DynamicHotType == "HotPaging") {
//				AllPageIndex++;
//				selectDynamicHotPaging(uid, token, AllPageIndex, 10, "HotPaging");
//			} else if(DynamicHotType == "getDynamicList") {
//				getDynamicListIndex++;
//				getDynamicListFun(uid, token, getDynamicListIndex, 10, "getDynamicList");
//			}
//		};
		if(res.data.length < 10) {
			if(DynamicHotType == "HotPaging") {
				$(".selectDynamicHotPagingLoading").stop().hide();
				$(".selectDynamicHotPagingNoMore").stop().show();
			} else if(DynamicHotType == "getDynamicList") {
				$(".getDynamicListLoading").stop().hide();
				$(".getDynamicListnoMore").stop().show();
			}
		}
		$(res.data).each(function(i, k) {
			var objectType = k.objectType; //动态类型
			var isAgree = k.object.isAgree;
			var isAgreeLogo = k.object.isAgree + k.object.id + DynamicHotType;
			var categoryName = k.object.liverInfo.uid + k.object.id + DynamicHotType;
			var columnName = k.object.columnName;
			var locationHrefId = k.object.publishTime + k.object.id + DynamicHotType;
			var locationHrefLiveId = k.publishTime + k.object.id + DynamicHotType;
			var objectId = k.object.id;
			var headerImgHeadId = k.object.isAgree + k.object.id + DynamicHotType+"headerImg";
			var commentCountLiveBackLogo= k.object.isAgree + k.object.id + DynamicHotType+"commentCountLiveBackLogo";
			//console.log(columnName);
			//console.log(categoryName);
			//  console.log(isAgreeLogo);
			//console.log(DynamicHotType);
			if(objectType == 1) { //文章或短评
				var type = k.object.type;
				//console.log(k);
				if(type == 1) { //短评
					var media = k.object.media;
					if(media == "") { //无图短评
						//	console.log(k);
						var shortViewNullImg =
							'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
							'<div class="BoxWrapT">' +
							'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
							'<div class="liveBoxWrapTR fl">' +
							'<p>' + k.object.liverInfo.nickName + '</p>' +
							'<p>' + format(new Date(k.publishTime)) + '</p>' +
							'</div>' +
							'</div>' +
							'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
							'<ul class="sameBottom borderSameBottom">' +
							'<li class="fr sameBottomList">分享</li>' +
							'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
							'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
							'</ul>' +
							'</div>';
						if(DynamicHotType == "HotPaging") {
							$(".selectDynamicHotPagingLoading").before(shortViewNullImg);
						} else if(DynamicHotType == "getDynamicList") {
							$(".getDynamicListLoading").before(shortViewNullImg);
						}
						$(document).on("click", "#" + locationHrefId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/shortView?id=" + id;
						});

					} else {
						var shortViewImg = (media.split(','));
						var len = shortViewImg.length;
						var shortid = k.object.id + DynamicHotType;
						if(len == 1) { //1张图
							var shortViewOneImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<a href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImgOne" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewOneImg);
							} else if(DynamicHotType == "getDynamicList") {
								$(".getDynamicListLoading").before(shortViewOneImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});
						} else if(len == 2) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" ilikeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewTwoImg);
							} else if(DynamicHotType == "getDynamicList") {
								//console.log(k);
								$(".getDynamicListLoading").before(shortViewTwoImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 3) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewTwoImg);
							} else if(DynamicHotType == "getDynamicList") {
								//console.log(k);
								$(".getDynamicListLoading").before(shortViewTwoImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 4) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewTwoImg);
							} else if(DynamicHotType == "getDynamicList") {
								//console.log(k);
								$(".getDynamicListLoading").before(shortViewTwoImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 5) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewTwoImg);
							} else if(DynamicHotType == "getDynamicList") {
								//console.log(k);
								$(".getDynamicListLoading").before(shortViewTwoImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 6) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewTwoImg);
							} else if(DynamicHotType == "getDynamicList") {
								//console.log(k);
								$(".getDynamicListLoading").before(shortViewTwoImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 7) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewTwoImg);
							} else if(DynamicHotType == "getDynamicList") {
								//console.log(k);
								$(".getDynamicListLoading").before(shortViewTwoImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 8) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[7] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[7] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewTwoImg);
							} else if(DynamicHotType == "getDynamicList") {
								//console.log(k);
								$(".getDynamicListLoading").before(shortViewTwoImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 9) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[7] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[7] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[8] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[8] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(shortViewTwoImg);
							} else if(DynamicHotType == "getDynamicList") {
								$(".getDynamicListLoading").before(shortViewTwoImg);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						}
					}
				} else if(type == 2) { //长文章
					var coverUrl = k.object.userCoverUrl;
					var articleid = k.object.id;
					var article_content = htmlEncode(k.object.content);
					if(coverUrl == "") { //无图文章——//判断文章里面是否有图片，如果有显示第一张
						var articleContent = k.object.content;
						var content = htmlEncode(articleContent);
						var imgReg = /<img.*?(?:>|\/>)/gi;
						//匹配src属性
						var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
						var imgArr = content.match(imgReg); //'所有已成功匹配图片的数组
						// console.log(imgArr);
						if(imgArr == null) {
							var nullImgArticleBox =
								'<div class="NullartileBoxWrap" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'</div>' +
								'<h2> ' + k.object.title + ' </h2>' +
								'<p class="articleContent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "HotPaging") {
								$(".selectDynamicHotPagingLoading").before(nullImgArticleBox);
							} else if(DynamicHotType == "getDynamicList") {
								$(".getDynamicListLoading").before(nullImgArticleBox);
							};
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/article?id=" + id;
							});
						} else {
							src = imgArr[0].match(srcReg);
							//获取图片地址
							if(src[1]) {
								// console.log(src[1]);
								var ImgArticleBox =
									' <div class="imgArticleBoxWrap" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
									'<div class="BoxWrapT">' +
									'<img id='+headerImgHeadId+' class="fl" src="' + k.object.liverInfo.headImgUrl + '">' +
									'<div class="liveBoxWrapTR fl">' +
									'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
									'<p>' + format(new Date(k.publishTime)) + '</p>' +
									'</div>' +
									'</div>' +
									'<div class="liveBoxWrapBL fl">' +
									'<img src="' + src[1] + '">' +
									'</div>' +
									'<div class="imgArticleBoxWrapBR fr">' +
									'<div class="imgArticleBoxWrapBRT">' +
									'<h3>' + k.object.title + '</h3>' +
									'<p class="imgArticleBoxWrapBCentent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
									'</div>' +
									'<div class="imgArticleBoxWrapBRB sameBottom">' +
									'<li class="fr sameBottomList">分享</li>' +
									'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
									'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
									'</div>' +
									'</div>' +
									'</div>'
								if(DynamicHotType == "HotPaging") {
									$(".selectDynamicHotPagingLoading").before(ImgArticleBox);
								} else if(DynamicHotType == "getDynamicList") {
									$(".getDynamicListLoading").before(ImgArticleBox);
								};

								$(document).on("click", "#" + locationHrefId, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/article?id=" + id;
								});
							}
						}

					} else { //有图文章
						var ImgArticleBox =
							' <div class="imgArticleBoxWrap" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
							'<div class="BoxWrapT">' +
							'<img class="fl" id='+headerImgHeadId+' src="' + k.object.liverInfo.headImgUrl + '">' +
							'<div class="liveBoxWrapTR fl">' +
							'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
							'<p>' + format(new Date(k.publishTime)) + '</p>' +
							'</div>' +
							'</div>' +
							'<div class="liveBoxWrapBL fl">' +
							'<img src="' + k.object.userCoverUrl + '!220X164' + '">' +
							'</div>' +
							'<div class="imgArticleBoxWrapBR fr">' +
							'<div class="imgArticleBoxWrapBRT">' +
							'<h3>' + k.object.title + '</h3>' +
							'<p class="imgArticleBoxWrapBCentent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
							'</div>' +
							'<div class="imgArticleBoxWrapBRB sameBottom">' +
							'<li class="fr sameBottomList">分享</li>' +
							'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
							'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
							'</div>' +
							'</div>' +
							'</div>'
						if(DynamicHotType == "HotPaging") {
							$(".selectDynamicHotPagingLoading").before(ImgArticleBox);
						} else if(DynamicHotType == "getDynamicList") {
							$(".getDynamicListLoading").before(ImgArticleBox);
						};

						$(document).on("click", "#" + locationHrefId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/article?id=" + id;
						});
					}
					// console.log(k);	
				}
			} else if(objectType == 2) { //视频
				//console.log(k);
				var videoNewsWrapBox =
					'<div class="videoNewsWrap" class="videoNewsWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
					'<div class="BoxWrapT">' +
					'<img class="fl" id='+headerImgHeadId+' src="' + k.object.liverInfo.headImgUrl + '">' +
					'<div class="liveBoxWrapTR fl">' +
					'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
					'<p>' + format(new Date(k.publishTime)) + '</p>' +
					'</div>' +
					'</div>' +
					'<div class="videoNewsBoxB">' +
					'<div class="videoNewsBoxBL fl">' +
					'<img src="images/livevideo.png" />' +
					'<img class="vedioCoverUrl" src="' + k.object.coverUrl + '">' +
					'<span>' + durationFun(new Date(k.object.duration)) + '</span>' +
					'</div>' +
					'<div class="videoNewsBoxBR fl">' +
					'<p></p>' +
					'<p>' + k.object.topic + '</p>' +
					'<p>' + k.object.watchCount + '人观看</p>' +
					'<ul class="sameBottom borderSameBottom">' +
					'<li class="fr sameBottomList">分享</li>' +
					'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
					'<li class="fr sameBottomList likeWatchLogin" likeType="2" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
					'</ul>' +
					'</div>' +
					'</div>' +
					'</div>';
				if(DynamicHotType == "HotPaging") {
					$(".selectDynamicHotPagingLoading").before(videoNewsWrapBox);
				} else if(DynamicHotType == "getDynamicList") {
					$(".getDynamicListLoading").before(videoNewsWrapBox);
				};
				$(document).on("click", "#" + locationHrefId, function(e) {
					var id = $(this).attr("objectId");
					window.location.href = "/video?id=" + id;
				});
			} else if(objectType == 3) { //直播
				var liveType = k.object.type;
				if(liveType == 0) {
					//console.log(k);
					//console.log(locationHrefLiveId);
					var liveBoxWrap =
						'<div class="videoNewsWrap" class="videoNewsWrapBox" id=' + locationHrefLiveId + ' roomid=' + k.object.roomId + ' uid=' + k.object.liverInfo.uid + '>' +
						'<div class="BoxWrapT">' +
						'<img class="fl" id='+headerImgHeadId+' src="' + k.object.liverInfo.headImgUrl + '" />' +
						'<div class="liveBoxWrapTR fl">' +
						'<p>' + k.object.liverInfo.nickName + '<span class="playStyleLive">正在公开直播</span></p>' +
						'<p>' + format(new Date(k.publishTime)) + '</p>' +
						'</div>' +
						'</div>' +
						'<div class="videoNewsBoxB">' +
						'<div class="videoNewsBoxBL fl">' +
						'<img src="images/livevideo.png" style="display: none;" />' +
						'<img class="vedioCoverUrl" src="' + k.object.coverUrl + '!220X164' + '">' +
						'<img src="images/live.png" />' +
						'</div>' +
						'<div class="videoNewsBoxBR fl">' +
						'<p></p>' +
						'<p>' + k.object.topic + '</p>' +
						'<p>' + k.object.watchCount + '人观看</p>' +
						'</div>' +
						'</div>' +
						'</div>';
					if(DynamicHotType == "HotPaging") {
						$(".selectDynamicHotPagingLoading").before(liveBoxWrap);
					} else if(DynamicHotType == "getDynamicList") {
						$(".getDynamicListLoading").before(liveBoxWrap);
					};
					if(k.object.roomType == 1) {
						$(".playStyleLive").html("正在VIP直播：");
						$(document).on("click", "#" + locationHrefLiveId, function(e) {
							var roomid = $(this).attr("roomid");
							var uid = $(this).attr("uid");
							window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
						});
					} else if(k.object.roomType == 0) {
						$(".playStyleLive").html("正在公开直播：");
						$(document).on("click", "#" + locationHrefLiveId, function(e) {
							var roomid = $(this).attr("roomid");
							var uid = $(this).attr("uid");
							window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
						});
					}
				} else if(liveType == 1) { //回放
					var liveBoxWrap =
						'<div class="videoNewsWrap" class="videoNewsWrapBox" id=' + locationHrefLiveId + ' roomid=' + k.object.roomId + ' uid=' + k.object.liverInfo.uid + ' objectId=' +  k.object.id + '>' +
						'<div class="BoxWrapT">' +
						'<img class="fl" id='+headerImgHeadId+' src="' + k.object.liverInfo.headImgUrl + '" />' +
						'<div class="liveBoxWrapTR fl">' +
						'<p>' + k.object.liverInfo.nickName + '</p>' +
						'<p>' + format(new Date(k.publishTime)) + '</p>' +
						'</div>' +
						'</div>' +
						'<div class="videoNewsBoxB">' +
						'<div class="videoNewsBoxBL fl">' +
						'<img src="images/livevideo.png" style="display: none;" />' +
						'<img class="vedioCoverUrl" src="' + k.object.coverUrl + '!220X164' + '">' +
						'<img src="images/playback.png" />' +
						'</div>' +
						'<div class="videoNewsBoxBR fl">' +
						'<p></p>' +
						'<p>' + k.object.topic + '</p>' +
						'<p>' + k.object.watchCount + '人观看</p>' +
						'<ul class="sameBottom borderSameBottom">' +
						'<li class="fr sameBottomList">分享</li>' +
						'<li class="fr sameBottomList" id='+commentCountLiveBackLogo+'>' + k.commentCount + '条评论</li>' +
//						'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + '>' + k.likeCount + '</li>' +
						'</ul>' +
						'</div>' +
						'</div>' +
						'</div>';
					if(DynamicHotType == "HotPaging") {
						$(".selectDynamicHotPagingLoading").before(liveBoxWrap);
					} else if(DynamicHotType == "getDynamicList") {
						$(".getDynamicListLoading").before(liveBoxWrap);
					};
					$("#"+commentCountLiveBackLogo).stop().hide();
					$(document).on("click", "#" + locationHrefLiveId, function(e) {
						var roomid = $(this).attr("roomid");
						var id = $(this).attr("objectId");
						var uid = $(this).attr("uid");
						window.location.href = "/liveLookBack?id=" + id + "&roomid=" + roomid+ "&uid=" + uid;
					});
				}
			} else if(objectType == 4) { //回答
//				//console.log(k);
//				var answerBox =
//					'<div class="topicBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
//					'<div class="BoxWrapT">' +
//					'<img class="fl" id='+headerImgHeadId+' src="' + k.object.liverInfo.headImgUrl + '">' +
//					'<div class="liveBoxWrapTR fl">' +
//					'<p>' + k.object.liverInfo.nickName + '</p>' +
//					'<p>' + format(new Date(k.publishTime)) + '</p>' +
//					'</div>' +
//					'</div>' +
//					'<p class="topicTitle">回答了<span>#话题#</span>' + k.object.discuss.discussTitle + '</p>' +
//					'<div class="topicBoxBottom">' +
//					'<img class="fl" src="images/livehuati.png" />' +
//					'<div class="topicBoxBottomR">' +
//					'<p>' + removeHTMLTag(htmlEncode(k.object.answerContent)) + ' </p>' +
//					'<p><span> ' + k.object.discuss.discussWatchCount + '人看过</span><span>' + k.object.discuss.discussAnswerCount + ' 人回答</span></p>' +
//					'</div>' +
//					'</div>' +
//					'<ul class="sameBottom borderSameBottom">' +
//					'<li class="fr sameBottomList">分享</li>' +
//					'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
//					'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + '>' + k.likeCount + '</li>' +
//					'</ul>' +
//					"</div>";
//				if(DynamicHotType == "HotPaging") {
//					$(".selectDynamicHotPagingLoading").before(answerBox);
//				} else if(DynamicHotType == "getDynamicList") {
//					$(".getDynamicListLoading").before(answerBox);
//				};
//				$(document).on("click", "#" + locationHrefId, function(e) {
//					var id = $(this).attr("objectId");
//					window.location.href = "/topicDetails?id=" + id;
//				});
			} else if(objectType == 5) { //实盘
				var delegateType = k.object.delegateType;
				if(delegateType == 1) { //买入
					var firmBugWrap = "<div class='firmBugWrap'>" +
						"<div class='BoxWrapT'>" +
						"<img class='fl' id="+headerImgHeadId+" src=" + k.object.liverInfo.headImgUrl + ">" +
						"<div class='liveBoxWrapTR fl'>" +
						"<p>" + k.object.liverInfo.nickName + "</p>" +
						"<p>" + format(new Date(k.publishTime)) + "</p>" +
						"</div>" +
						"</div>" +
						"<p class='firmBugBox'>" +
						"我的<span>#实盘#</span>有最新的买入操作记录" +
						"</p>" +
						"<div class='firmBugBoxB'>" +
						"<div class='firmBugBoxBL fl'>买</div>" +
						"<div class='firmBugBoxBCL fl'>" +
						"<p>" + k.object.stockName + "</p>" +
						"<p>" + k.object.stockCode + "</p>" +
						"</div>" +
						"<div class='firmBugBoxBCR fl'>" +
						"<p><span>" + k.object.beforePositionRate + "%</span>-><span>" + k.object.changePositionRate + "%</span></p>" +
						"<p><span> 成交价：￥</span>" + k.object.price + "</p>" +
						"</div>" +
						"<div class='firmBugBoxBR fl'>看交易</div>" +
						"</div>" +
						"<ul class='sameBottom'>" +
						"<li class='fr sameBottomList'>分享</li>" +
						"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
						'<li class="fr sameBottomList likeWatchLogin" likeType="5" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
						"</ul>" +
						"</div>"
					if(DynamicHotType == "HotPaging") {
						$(".selectDynamicHotPagingLoading").before(firmSellWrap);
					} else if(DynamicHotType == "getDynamicList") {
						$(".getDynamicListLoading").before(firmSellWrap);
					};
				} else if(delegateType == -1) { //卖出
					//  console.log(k);
					var firmSellWrap = "<div class='firmBugWrap'>" +
						"<div class='BoxWrapT'>" +
						"<img class='fl' id="+headerImgHeadId+" src=" + k.object.liverInfo.headImgUrl + ">" +
						"<div class='liveBoxWrapTR fl'>" +
						"<p>" + k.object.liverInfo.nickName + "</p>" +
						"<p>" + format(new Date(k.publishTime)) + "</p>" +
						"</div>" +
						"</div>" +
						"<p class='firmBugBox'>" +
						"我的<span>#实盘#</span>有最新的卖出操作记录" +
						"</p>" +
						"<div class='firmBugBoxB'>" +
						"<div class='firmBugBoxBLSell fl'>卖</div>" +
						"<div class='firmBugBoxBCL fl'>" +
						"<p>" + k.object.stockName + "</p>" +
						"<p>" + k.object.stockCode + "</p>" +
						"</div>" +
						"<div class='firmBugBoxBCR fl'>" +
						"<p><span>" + k.object.beforePositionRate + "%</span>-><span>" + k.object.changePositionRate + "%</span></p>" +
						"<p>成交价：￥" + k.object.price + "</p>" +
						"</div>" +
						"<div class='firmBugBoxBR fl'>看交易</div>" +
						"</div>" +
						"<ul class='sameBottom'>" +
						"<li class='fr sameBottomList'>分享</li>" +
						"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
						'<li class="fr sameBottomList likeWatchLogin" likeType="5" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
						"</ul>" +
						"</div>"
					if(DynamicHotType == "HotPaging") {
						$(".selectDynamicHotPagingLoading").before(firmSellWrap);
					} else if(DynamicHotType == "getDynamicList") {
						$(".getDynamicListLoading").before(firmSellWrap);
					};
				}
			} else if(objectType == 6) { //音频
				var audioBox =
					'<div class="NullartileBoxWrap" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
					'<div class="BoxWrapT">' +
					'<img class="fl" id='+headerImgHeadId+' src="' + k.object.liverInfo.headImgUrl + '">' +
					'<div class="liveBoxWrapTR fl">' +
					'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
					'<p>' + format(new Date(k.publishTime)) + '</p>' +
					'</div>' +
					'</div>' +
					'<div class="audioBox">' +
					'<div class="audioBoxL fl">' +
					'<img src="images/audioLogo.png"/>' +
					'<img src="images/anchorHead.png"/>' +
					'</div>' +
					'<p class="fl">' + k.object.topic + '</p>' +
					' <span class="fr">' + durationFun(new Date(k.object.duration)) + '</span>' +
					'</div>' +
					'<ul class="sameBottom borderSameBottom">' +
					'<li class="fr sameBottomList">分享</li>' +
					'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
					'<li class="fr sameBottomList likeWatchLogin" likeType="2" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
					'</ul>' +
					"</div>";
				if(DynamicHotType == "HotPaging") {
					$(".selectDynamicHotPagingLoading").before(audioBox);
				} else if(DynamicHotType == "getDynamicList") {
					$(".getDynamicListLoading").before(audioBox);
				};
				$(document).on("click", "#" + locationHrefId, function(e) {
					var id = $(this).attr("objectId");
					window.location.href = "/audio?id=" + id;
				});
			}
			/*点赞*/

           $("#" + isAgreeLogo).click(function(event){
		    	 event.stopPropagation(); 
		    	 var objectId = $(this).attr("objectId");
		    	 var likeType = $(this).attr("likeType");
		    	 //判断是否点赞
		    	 $.ajax({
		                type: "POST",
		                async: true,
		                dataType: "json",
		                url: "/api/v2/agree/selectAgreeCount.do",
		                data: {
		                    "objectId": objectId,
		                    "uid": uid,
		                    "agreeType": 1,
		                },
		                success: function (res) {
		                	console.log(res);
		                    if (res.code == 0) {
		                        var isAgree = res.data.isAgree;
		                        // var agreeCount=res.data.agreeCount;
		                        if (isAgree == true) {//已点赞
		                        	//取消点赞
		                        	deleteAgreeFun(uid,objectId,1,userToken,isAgreeLogo,isAgree);
		                        }else{
		                        	//点赞
		                        	insertAgreeFun(uid,objectId,likeType,1,userToken,isAgreeLogo,isAgree);
		                        }
		                    }
		                }
		            })
		    	 
		    })
			//console.log(userToken);
			if(userToken) { //登录状态——点赞取消赞
				if(isAgree == true) {//已经点赞取消点赞
					$("#" + isAgreeLogo).css({
						"background": "url(../images/rewardP.png) no-repeat left center"
					});
				}
                
			} else { //未登录——登录——点赞取消赞
				$("#" + isAgreeLogo).click(function(event){
				   event.stopPropagation(); 
                   $("#loginAlert").stop().show();
                   $("#loginAlert").load("/login");
                })
			}

//			if(isAgree == true) {
//				$("#" + isAgreeLogo).css({
//					"background": "url(../images/rewardP.png) no-repeat left center"
//				});
//			}
//			if(uid) { //登录状态——点赞取消赞
//             
//			} else { //未登录——登录——点赞取消赞
////             $("#" + isAgreeLogo).click(function(event){
////             	   returnfalse; 
////             	   event.stopPropagation(); 
////             	   $("#loginAlert").stop().show();
////				   $("#loginAlert").load("/login");
////             })
//			}
			if(columnName) {
				$("#" + categoryName).next().html("《" + columnName + "》");
			} else {
				$("#" + categoryName).stop().hide();
				$("#" + categoryName).next().hide();
			}
			$("#" + headerImgHeadId).one("error", function(e) {
				$(this).attr("src", "images/anchorHead.png");
			});
			
			
		})
	}
	//点赞函数
	function insertAgreeFun(uid,objectId,likeType,agreeType,token,isAgreeLogo){
	    	$.ajax({
				type: "post",
				url: "/api/v2/agree/insertAgree.do",
				async: true,
				data: {
					"uid": uid,
					"objectId": objectId,
					"type": likeType,
					"agreeType":agreeType,
					"token": token,
				},
				success: function(res) {
					//console.log(res);
					if(res.code == 0) {
						$("#" + isAgreeLogo).css({
							"background": "url(../images/rewardP.png) no-repeat left center"
						});
						var likeCountBefore=Number($("#" + isAgreeLogo).html());
						$("#" + isAgreeLogo).html(likeCountBefore+1);
					} 
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				},
			})
	    }
	//取消赞函数
	function deleteAgreeFun(uid,objectId,agreeType,token,isAgreeLogo){
	    	$.ajax({
				type: "post",
				url: "/api/v2/agree/deleteAgree.do",
				async: true,
				data: {
					"uid": uid,
					"objectId": objectId,
					"agreeType":agreeType,
					"token": token,
				},
				success: function(res) {
					//console.log(res);
					if(res.code == 0) {
						$("#" + isAgreeLogo).css({
							"background": "url(../images/livereward.png) no-repeat left center"
						});
						var likeCountBefore=Number($("#" + isAgreeLogo).html());
						$("#" + isAgreeLogo).html(likeCountBefore-1);
					
					}else if(res.code==-21){
						
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				},
			})
	    }

	//我关注的人
	function selectReceptorV2(uid, pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v2/user/selectReceptor.do",
			data: {
				"uid": uid,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					var receptorCount = res.data.receptorCount;
					if(receptorCount == 0) {
						//无关注的人
						$(".noReceptorCount").stop().show();
						$(".getDynamicListLoading").stop().hide();
					} else {
						var selectReceptorLen = res.data.receptorList.length;
						$(res.data.receptorList).each(function(i, k) {
							var imgId = k.uid;
							var signatureId = k.uid + "signature";
							var selectReceptor =
								'<li class="anchorRecommendList" uid=' + k.uid + '>' +
								'<img class="fl" id="' + imgId + '" src="' + k.headImgUrl + '" alt="" />' +
								'<div class="anchorRecommendListR fl">' +
								'<p><span>' + k.nickName + '</span><span>粉丝：' + k.fansCount + '</span></p>' +
								'<p id="' + signatureId + '" class="signatureId fl">' + k.signature + '</p>' +
								'</div>' +
								"</li>";
							$(".dynamicComentBoxR").append(selectReceptor);
							$("#" + imgId).one("error", function(e) {
								$(this).attr("src", "images/anchorHead.png");
							});
							if(k.signature == " " || k.signature == "" || k.signature == undefined || k.signature == null) {
								$("#" + signatureId).html("暂无签名");
							}
						});
						$(document).on("click", ".anchorRecommendList", function(e) {
							var uid = $(this).attr("uid");
							window.location.href = "/userProfile?uid=" + uid;
						});
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
	};

	//主播发现
	function getTagList(userId, userToken, pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/tag/getTagList.do",
			data: {
				"tagId": "",
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(res.data).each(function(i, k) {
						var getTagListId = k.id;
						var lunboId = k.id + "lunbo";
						var getTagListName = k.name;
						var prevId = k.id + "prev";
						var nextId = k.id + "next";
						//console.log(getTagListId);
						var slideBox =
							'<div class="slide-box">' +
							'<div class="slide-content" id="' + lunboId + '">' +
							'<div class="JQ-slide-nav">' +
							'<p class="fl">' + getTagListName + '</p>' +
							'<img class="prev fl" id="' + prevId + '" src="images/leftBefore.png"/>' +
							'<img class="next fl" id="' + nextId + '" src="images/rightBefore.png"/>' +
							'</div>' +
							'<div class="wrap">' +
							'<ul class="JQ-slide-content" id="' + getTagListId + '">' +

							'</ul>' +
							'</div>' +

							'</div>' +
							'</div>';
						$("#anchorFindBox").append(slideBox);
						getTagContent(userId, userToken, getTagListId, 1, 20, lunboId);
						$("#"+nextId).hover(function(){
							$(this).attr("src","../images/rightHover.png");
						},function(){
							$(this).attr("src","../images/rightBefore.png");
						});
						$("#"+prevId).hover(function(){
							$(this).attr("src","../images/leftHover.png");
						},function(){
							$(this).attr("src","../images/leftBefore.png");
						})

					});

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
	};

	//根据标签获取牛人大咖
	var getTagContentIndex = 1;

	function getTagContent(userId, userToken, tagId, pageIndex, pageSize, lunboId) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/tag/getTagContent.do",
			data: {
				"uid": userId,
				"tagId": tagId,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				if(res.code == 0) {
					if(res.data.userArray == undefined || res.data.userArray == null || res.data.userArray == "") {
						$("#" + lunboId).parent().remove();
					} else {
						$(res.data.userArray).each(function(i, M) {
							var isFollowId = M.liverInfo.uid + tagId + M.isFollow;
							var isFollowIdClick = M.liverInfo.uid + tagId;
							var resumeId=M.liverInfo.uid + tagId+"resume";
							var getTagContent =
								' <li>' +
								'<img src="' + M.liverInfo.headImgUrl + '!60X60" alt="" id=' + isFollowIdClick + ' uid=' + M.liverInfo.uid + ' />' +
								'<h3>' + M.liverInfo.nickName + '</h3>' +
								'<p class="anchorRZ" id=' + resumeId + '>' + M.liverInfo.resume + '</p>' +
								'<p class="anchorFocus">粉丝:' + M.funsCount + '</p>' +
								'<p class="addLike" id=' + isFollowId + ' uid=' + M.liverInfo.uid + '>关注</p>' +
								'</li>';
							$("#" + tagId).append(getTagContent);
							if(!M.liverInfo.resume){
								$("#"+resumeId).html("暂无简介");
							}
							$(document).on("click", "#" + isFollowIdClick, function(e) {
								var uid = $(this).attr("uid");
								window.location.href = "/userProfile?uid=" + uid;
							});
                            /*头像缺省*/
                            $("#" + isFollowIdClick).one("error", function(e) {
								$(this).attr("src", "images/anchorHead.png");
							});
							if(userId) { //已登录
								if(M.isFollow == 1) { //已经关注
									$("#" + isFollowId).text("已关注");
									$("#" + isFollowId).css({
										"color": "#a9a9a9",
										"borderColor": "#c6c6c6"
									});
									$("#" + isFollowId).click(function() {
										var uid = $(this).attr("uid");
										cancelConcern(uid, userId, userToken, isFollowId);
									})
								} else if(M.isFollow == 0) {
									$("#" + isFollowId).text("关注");
									$("#" + isFollowId).click(function() {
										var uid = $(this).attr("uid");
										addConcern(uid, userId, userToken, isFollowId);
									})
								}
							} else { //未登录
								$(".addLike").click(function() {
									$("#loginAlert").stop().show();
									$("#loginAlert").load("/login");
								});
							}

						})

						$("#" + lunboId).Slide({
							//						effect: "scroolLoop",
							effect: "scroolY",
							autoPlay: false,
							speed: "normal",
							timer: 3000,
							steps: 4
						});
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
	};
	//取消关注
	function cancelConcern(uid, userId, usertoken, isFollowId) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/deleteFollow.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$("#" + isFollowId).text("关注");
					$("#" + isFollowId).css({
						"color": "#ff5038",
						"borderColor": "#ff5038"
					});
				} else if(res.code == -2) { //未登录
					$("#loginAlert").stop().show();
					$("#loginAlert").load("/login");
				}else if(res.code==-1){
					addConcern(uid, userId, usertoken,isFollowId);
				}

			}
		})
	}
	//关注
	function addConcern(uid, userId, usertoken, isFollowId) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/following.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$("#" + isFollowId).text("已关注");
					$("#" + isFollowId).css({
						"color": "#a9a9a9",
						"borderColor": "#c6c6c6"
					});
				} else if(res.code == -1) {
					cancelConcern(uid, userId, usertoken, isFollowId);
				} else if(res.code == -2) { //未登录
					$("#loginAlert").stop().show();
					$("#loginAlert").load("/login");
				}

			}
		})
	}

})