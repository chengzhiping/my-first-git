$(document).ready(function() {
	$(".shortViewContent").on("keyup", function() {
		/*字数倒计数*/
		var num = 300 - ($(this).val().length);
		/*console.log(num);*/
		if(num > 0&&num<300) {
			$(".shortViewContentNum").html(num);
			$("#publishViewBtn").css({
        		"background":"#fe4502"
           });
           $('#publishViewBtn').removeAttr("disabled"); 
        
		} else if(num<=0){
			$(".shortViewContentNum").html(0);
		};
		if(num==300){
			$(".shortViewContentNum").html(300);
			$("#publishViewBtn").css({
        		"background":"#d8d8d8"
           });
            $('#publishViewBtn').attr("disabled","disabled"); 
		}
		$(".shortViewContentNum").css(
			'color', "#FE4502"
		);
	});
	//判断主播是否登录
	$.ajax({
		type: "get",
		url: "/userInfos",
		success: function(res) {
			// console.log(res);
			if(res.code == -2) { //未登录
				//登录
				$("#publishViewBtn").click(function() {
					$("#loginAlert").load("/login");
				});
				
			};
			if(res.code == 0) {
				// console.log(res);
				var uid=roleType=res.data.userInfo.uid;
				var token=res.data.token;
				//发布成功跳转到主播个人页
				$(".gotoUserProfile").click(function(){
		            window.location.href="/userProfile?uid=" + uid+"&tab=2";
		            $("#publishViewBox").stop().hide();
		            $("#loginAlert").stop().hide();
	            });
	            //添加图片
                addMoreImg(uid,token);
                //发布
                 publishShortViewFun(uid,token);
               
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus);
		},
	});
	//七牛云上传多张短评图片
	var media=[];
    var imgCount=0;
	function addMoreImg(uid,token){
    	$.ajax({
			type: "get", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v1/picture/batchUpload/shortViewToken.do",
			data:{
				"uid":uid,
				"token":token,
			},
			success:function(res){
				// console.log(res);
				if(res.code==0)
				{	
					var sortimgtoken = res.data.uploadToken;
			 		//七牛上传图片
					var uploader6 = Qiniu.uploader({
				        runtimes: 'html5,flash,html4',    //上传模式,依次退化
				        browse_button: 'addMoreImage',       //上传选择的点选按钮，**必需**
				        uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
				        uptoken : sortimgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
				        uptoken_func: function(file) {
				     		
				        },
				        unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
				        save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
				        domain: 'upload.qbox.me',//bucket域名，下载资源时用到，**必需**
				        get_new_uptoken: true,  //设置上传文件的时候是否每次都重新获取新的token
				        container: 'shortViewImgBox',           //上传区域DOM ID，默认是browser_button的父元素，
				        max_file_size: '100mb',           //最大文件体积限制   
				        flash_swf_url: 'js/Moxie.swf',  //引入flash,相对路径
				        max_retries: 3,                   //上传失败最大重试次数
				        dragdrop: true,                   //开启可拖曳上传
				        drop_element: 'shortViewImgBox',   //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
				        chunk_size: '4mb',                //分块上传时，每片的体积
				        auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
				        init: {
				            'FilesAdded': function(up, files) {
                                // plupload.each(files, function(file) {
				                 //    // 文件添加进队列后,处理相关的事情
								// });
                                var maxfiles = 9;
                                if(up.files.length > maxfiles ) {
                                    $("#imgLenTen").stop().show();
                                    $(".imgLenTenClose").click(function(){
                                    	$("#imgLenTen").stop().hide();
                                    	$(".floatImg").remove();
                                    	window.location.reload();
                                    })
                                   // $("#imgLenTen").fadeIn(100).delay(4000).fadeOut(100);
                                   }
//                              if (up.files.length === maxfiles) {
//                                  $('.upload_out').hide("slow"); // provided there is only one #uploader_browse on page
//                              }
				            },
				            'BeforeUpload': function(up, file) {
				            	 	//console.log(file);
				                   // 每个文件上传前,处理相关的事情
				            },
				            'UploadProgress': function(up, file) {
				                   // 每个文件上传时,处理相关的事情
				            },
				            'FileUploaded': function(up, file, info) { 
				            		var sortimgInfo=JSON.parse(info);
				            		//console.log(info);
				            		var sortimgUrl="https://picture.fengniutv.com/"+sortimgInfo.key;//外网
				            		//var sortimgUrl="http://picture.91qiniu.com/"+sortimgInfo.key;//内网
							        var addMoreImageInner="<p class='floatImg' id='floatImg"+imgCount+"'><img src='"+sortimgUrl+"' /><img src='images/shortView5.png' class='perCloseBtn'/></p>"
							        $(".upload_out").before(addMoreImageInner);
			            			media.push(sortimgUrl);
				            		imgCount++;
				            		//console.log(imgCount);
				            		//console.log(media);
				            		            		
				            		//鼠标进入图片关闭按钮时变红色
				            		$(".perCloseBtn").hover(function(){
									    $(this).attr("src","images/shortView5P.png");
									},function(){
									    $(this).attr("src","images/shortView5.png");
									});
				            },
				            'Error': function(up, err, errTip) {
				            	console.log(errTip);
				                   //上传出错时,处理相关的事情
				            },
				            'UploadComplete': function() {
				                   //队列文件处理完毕后,处理相关的事情
				                   //删除media对应的图片URL
				                  $(".perCloseBtn").on("click",function(){
				            			var thisUrl=$(this).prev().attr("src");
				            			// console.log(thisUrl);
				            			media.splice($.inArray(thisUrl,media),1);
				            			// console.log(media);
				            			$(this).parent().remove();
								  })
				            }
				        }

				    });					
				 }
			},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
    }
	
	//发布短评按钮
	//publishShortViewFun(uid,token)
	//publishShortViewFun();
	function publishShortViewFun(uid,token){
        $("#publishViewBtn").click(function(){
        	var content=$(".shortViewContent").val();
        	if(content!=""&&content!=null&&content!=undefined){
        		var media1=media.join(",")+",";
			    // console.log(media1);
				//发布短评接口
				$.ajax({
					type: "post",
					async: true,
					dataType: "json",
					url: "/api/v1/article/saveOrUpdate.do",
					data: {
						"uid": uid,
						"token": token,
						"type": 1,						
						"content":content,
						"media":media1,
					},
					success: function(res) {
						if(res.code==0){
    						$("#publishViewBox").stop().hide();
							$(".sendSccessBoxWrap").stop().show().delay(60000).hide(30);
							$("#loginAlert").delay(60000).hide(30);
						}
					},
				})
        	}
        })
	}
	
	
	
	
	//关闭页面
	$(".closeShortPage").click(function(){
		$("#publishViewBox").stop().hide();
		$("#loginAlert").stop().hide();
	});


	$(".successClose").click(function(){
		$("#publishViewBox").stop().hide();
		$("#loginAlert").stop().hide();
	});
	
	//
	$(".imgLenTenClose").click(function(){
		$("#imgLenTen").stop().hide();
	})
   
})