var uid;
var uidLogin="";
var tokenLogin;
var roomid;
$(document).ready(function() {
	$(".headerWrap").load("/header");
	$("#footerBox").load("/footer");
	//TAB切换
	$(".anchorListNewsInfo").click(function() {
		$(".commentWrapBoxLBox .commentWrapBoxLInner").eq($(this).index()).css("display", "block").siblings(".commentWrapBoxLInner").css("display", "none");
		$(this).addClass("anchorListNewsActive").siblings(".anchorListNewsInfo").removeClass("anchorListNewsActive");
	});
	uid = GetQueryString("uid");
	roomid = GetQueryString("roomid");
	if(roomid) {
		$(".editLiveListBox").stop().hide();
		$(".editVipRoomWrapBox").stop().show();
		//获得直播间详情信息
		getLiveRoomInfoVIP(roomid); //添加编辑
		getRoomAnnouncementList(roomid, 1, 5);
	}
	getReceptorCount(uid);
	var tabPageIndex = 1;
	//获取用户直播间
	getUserLiveRoomList("", uid, "", 1, 5, 0, 1);
	getUserLiveRoomList("", uid, 1, 1, 5, 0, 5); //VIP服务的VIP直播间
	//动态tab切换
	tabFun(".DynamicListBoxUserInfoList", "DynamicListBoxUserInfoListActive", ".hotNewsC");
	$.ajax({
		type: "get",
		url: "/userInfos",
		success: function(res) {
			//console.log(res);
			if(res.code == -2) { //未登录
				uid = GetQueryString("uid");
				getUserLiveRoomList('', uid, 0, 1, 5, 0, 4); //主直播间
				getUserLiveRoomList('', uid, 1, 1, 5, 0, 4); //VIP直播间列表
				getColumnByUidV3(uid, 2, 1, 10, "tab5", 0, ""); //编辑专栏
				var columnAddMore = 1
				$(".columnAddMore").click(function() {
					columnAddMore++;
					getColumnByUidV3(uid, 2, columnAddMore, 10, "tab5", 0, ""); //编辑专栏
				});
				//主播动态
				anchorNewsFun(uid, 10, 1, "anchorOwnhotNews", "", "");
				anchorNewsFun(uid, 5, 1, "anchorOwnTab1", "", "");
				//文章
				$(".articleDynamicListBoxBtn").click(function(){
					$(".articleDynamicListBox").html("");
					getDynamicByTypeV3(uid, 10, 1, "articleDynamicListBox", "", "",1);
				})
				//音视频
				$(".videoAudioDynamicListBoxBtn").click(function(){
				   $(".videoAudioDynamicListBox").html("");
				   getDynamicByTypeV3(uid, 10, 1, "videoAudioDynamicListBox", "", "",2);
				})
				//回放
				$(".liveBackDynamicListBoxBtn").click(function(){
					$(".liveBackDynamicListBox").html("");
				    getDynamicByTypeV3(uid, 10, 1, "liveBackDynamicListBox", "", "",3);
				});
				getPositionsByUid(uid,"",1,10,"");////当前持仓
				getTransferRecords(uid,"", 1, 10,"");//交易动态
				$(".takeFirmBtn").click(function(){//订阅按钮
					$("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
				})
			};
			if(res.code == 0) {
				uidLogin = res.data.userInfo.uid;
				tokenLoginStute = res.data.token;
				uid = GetQueryString("uid");
				getPositionsByUid(uid,uidLogin,1,10,tokenLoginStute);//当前持仓
				getTransferRecords(uid,uidLogin, 1, 10,tokenLoginStute);//交易动态
				followFun(uid, tokenLogin, uidLogin);
				$(".takeFirmBtn").click(function(){
				   getSubscribeCharge(uidLogin,uid,3,tokenLoginStute);
				})
				if(res.data.userInfo.roleType == 1 || res.data.userInfo.roleType == 2) {
					//console.log(uid);
					//console.log(res);
					uidLogin = res.data.userInfo.uid;

					if(uid == uidLogin) {
						$(".userAnchorFollowBtn").stop().hide();
						$(".userAnchorEditBtn").click(function() {
							window.location.href = "/me";
						});
						tokenLogin = res.data.token;
						//window.location.href = "/userProfile?uid=" + uidLogin;
						getUserLiveRoomList('', uidLogin, 0, 1, 5, 1, 4); //主直播间—1主播显示删除，开启直播按钮
						getUserLiveRoomList('', uidLogin, 1, 1, 5, 1, 4); //VIP直播间列表
						getColumnByUidV3(uid, 2, 1, 10, "tab5", 1, tokenLogin); //专栏主播可编辑
						//getColumnByUidV3(uid, 2, 1, 10, "tab5", 1, ""); //编辑专栏
						var columnAddMoreuid = 1
						$(".columnAddMore").click(function() {
							columnAddMoreuid++;
							getColumnByUidV3(uid, 2, columnAddMoreuid, 10, "tab5", 1, tokenLogin); //专栏主播可编辑
						});
						$(".editLiveListTop").stop().show();
						//创建VIP直播间
						$(".createVipRoomBtn").click(function() {
							$(".editLiveListBox").stop().hide();
							$(".creatVipRoomWrapBox").stop().show();
						});
						//创建专栏
						$(".createColumnRoomBtn").click(function() {
							$(".columnAddMoreBox").stop().hide();
							$(".createColumnBox").stop().show();
						});
						descriptionImgUrlVip(uidLogin, tokenLogin, "descriptionImgUrlBtn", "liveRoomIntroductionInfoVip", ".descriptionImgUrlVip") //上传VIP特权的图片
						descriptionImgUrlVip(uidLogin, tokenLogin, "liveCoverVipBtn", "setVipLiveCover", ".liveVipRoomCover") //上传VIP封面
						descriptionImgUrlVip(uidLogin, tokenLogin, "editDescriptionImgUrlBtn", "liveRoomIntroductionInfoVip", ".editDescriptionImgUrlVip") //编辑VIP特权封面
						descriptionImgUrlVip(uidLogin, tokenLogin, "editLiveCoverVipBtn", "editSetVipLiveCover", ".editLiveVipRoomCover") //编辑封面
						descriptionImgUrlVip(uidLogin, tokenLogin, "columnDescriptionImgUrlBtn", "columnIntroductionInfoVip", ".descriptionImgUrlColumn") //创建专栏-专栏介绍
						descriptionImgUrlVip(uidLogin, tokenLogin, "columnCoverVipBtn", "columnLiveCover", ".columnRoomCover") //创建专栏-专栏封面
						descriptionImgUrlVip(uidLogin, tokenLogin, "add2Img", "editLiveGoBackBtn", "#editLiveBackMe") //编辑回放封面
						$(".stratVipLiveBoxBtn").click(function() {
							createVipRoom(tokenLogin, uidLogin);
						});
						$(".startcreateColumnBtn").click(function() {
							createColumn("", tokenLogin, uidLogin, "createColumn");
						});
						/*创建专栏*/
						$(document).on("click", ".moneySelete", function(e) {
							var moneySeleteType = $(".moneySelete").find("option:selected").text();
							if(moneySeleteType == "周期收费") {
								$(".createColumnMoneyCycle").stop().show();
							} else {
								$(".createColumnMoneyCycle").stop().hide();
							}
							if(moneySeleteType == "全期收费") {
								$(".createColumnMoneyALL").stop().show();
							} else {
								$(".createColumnMoneyALL").stop().hide();
							}
						});
						anchorNewsFun(uid, 10, 1, "anchorOwnhotNews", uidLogin, tokenLogin);

						anchorNewsFun(uid, 5, 1, "anchorOwnTab1", uidLogin, tokenLogin);
						//文章
						$(".articleDynamicListBoxBtn").click(function(){
							$(".articleDynamicListBox").html("");
							getDynamicByTypeV3(uid, 10, 1, "articleDynamicListBox", uidLogin, tokenLogin,1);
						})
						//音视频
						$(".videoAudioDynamicListBoxBtn").click(function(){
						   $(".videoAudioDynamicListBox").html("");
						   getDynamicByTypeV3(uid, 10, 1, "videoAudioDynamicListBox", uidLogin, tokenLogin,2);
						})
						//回放
						$(".liveBackDynamicListBoxBtn").click(function(){
							$(".liveBackDynamicListBox").html("");
						    getDynamicByTypeV3(uid, 10, 1, "liveBackDynamicListBox", uidLogin, tokenLogin,3);
						})

					} else {
						uid = GetQueryString("uid");
						tokenLoginStute = res.data.token;
						getUserLiveRoomList('', uid, 0, 1, 5, 0, 4); //主直播间
						getUserLiveRoomList('', uid, 1, 1, 5, 0, 4); //VIP直播间列表

						var columnAddMore2 = 1;
						getColumnByUidV3(uid, 2, 1, 10, "tab5", 0, ""); //编辑专栏
						$(".columnAddMore").click(function() {
							columnAddMore2++;
							getColumnByUidV3(uid, 2, columnAddMore2, 10, "tab5", 0, ""); //编辑专栏
						});
						anchorNewsFun(uid, 10, 1, "anchorOwnhotNews", uidLogin, tokenLoginStute);

						anchorNewsFun(uid, 5, 1, "anchorOwnTab1", uidLogin, tokenLoginStute);
						
						//文章
						$(".articleDynamicListBoxBtn").click(function(){
							$(".articleDynamicListBox").html("");
							getDynamicByTypeV3(uid, 10, 1, "articleDynamicListBox", uidLogin, tokenLoginStute,1);
						})
						//音视频
						$(".videoAudioDynamicListBoxBtn").click(function(){
						   $(".videoAudioDynamicListBox").html("");
						   getDynamicByTypeV3(uid, 10, 1, "videoAudioDynamicListBox", uidLogin,tokenLoginStute,2);
						})
						//回放
						$(".liveBackDynamicListBoxBtn").click(function(){
							$(".liveBackDynamicListBox").html("");
						    getDynamicByTypeV3(uid, 10, 1, "liveBackDynamicListBox", uidLogin, tokenLoginStute,3);
						})
					}

				} else {
					uid = GetQueryString("uid");
					getUserLiveRoomList('', uid, 0, 1, 5, 0, 4); //主直播间
					getUserLiveRoomList('', uid, 1, 1, 5, 0, 4); //VIP直播间列表
					//					$(".deleteBoxWrap").stop().hide();
					//					$(".startLiveBtn").stop().hide();
					var columnAddMore1 = 1;
					getColumnByUidV3(uid, 2, 1, 10, "tab5", 0, ""); //编辑专栏
					$(".columnAddMore").click(function() {
						columnAddMore1++;
						getColumnByUidV3(uid, 2, columnAddMore1, 10, "tab5", 0, ""); //编辑专栏
					});
					anchorNewsFun(uid, 10, 1, "anchorOwnhotNews", uidLogin, tokenLoginStute);
					var anchorpageIndex = 1;
					anchorNewsFun(uid, 5, 1, "anchorOwnTab1", uidLogin, tokenLoginStute);
					//文章
					$(".articleDynamicListBoxBtn").click(function(){
						$(".articleDynamicListBox").html("");
						getDynamicByTypeV3(uid, 10, 1, "articleDynamicListBox", uidLogin, tokenLoginStute,1);
					})
					//音视频
					$(".videoAudioDynamicListBoxBtn").click(function(){
					   $(".videoAudioDynamicListBox").html("");
					   getDynamicByTypeV3(uid, 10, 1, "videoAudioDynamicListBox", uidLogin, tokenLoginStute,2);
					})
					//回放
					$(".liveBackDynamicListBoxBtn").click(function(){
						$(".liveBackDynamicListBox").html("");
					    getDynamicByTypeV3(uid, 10, 1, "liveBackDynamicListBox", uidLogin, tokenLoginStute,3);
					})
				}
			}

		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus);
		},
	});
	var tab = GetQueryString("tab");
	if(tab != "" && tab != undefined && tab != null) {
		//console.log(tab);
		tabFun1(tab);
	} else {
		$(".anchorListNewsInfo").eq(0).addClass("anchorListNewsActive").siblings().remove("anchorListNewsActive");
		$(".commentWrapBoxLBox .commentWrapBoxLInner").eq(0).css("display", "block").siblings(".commentWrapBoxLInner").css("display", "none");
	}

	function tabFun1(tab) {
		$(".anchorListNewsInfo").eq(tab - 1).addClass("anchorListNewsActive").siblings().remove("anchorListNewsActive");
		$(".commentWrapBoxLBox .commentWrapBoxLInner").eq(tab - 1).css("display", "block").siblings(".commentWrapBoxLInner").css("display", "none");
	}
	var usertoken;
	var userId;
	var userUrl = window.location.href;
	$(".bannerBoxTopL").html(userUrl);
	//判断是否登录
	//loginFun();
	//获得主播详情
	anchorInfoFun(uid);

	//动态总条数
	anchorNewsNum(uid);
	//获得公告接口
	getAnnouncement(uid);
	//获得动态，直播，实盘总条数
	liveSumNum(uid, 3); //{1 = 文章；2 = 视频；3 = 直播 4是话题回答，5才是实盘}
	liveSumNum(uid, 5);
	//获得专栏的总条数
	getColumnListNum(uid);
	//获得直播列表
	var livePageIndex = 1;
	liveListFun(uid, 1);
	$(".liveAddMore").click(function() {
		livePageIndex++;
		liveListFun(uid, livePageIndex);
	});

	//获得专栏-类型 （type 0=免费，1=VIP，2=全部）
	//roleType=0普通用户和游客，roleType=1直播
	getColumnByUidV3(uid, 2, 1, 5, "tab1", 0, ""); //主页
	getColumnByUidV3(uid, 1, 1, 10, "tab6", 0, ""); //VIP服务
	function getColumnByUidV3(uid, columnType, pageIndex, pageSize, locationPlace, roleType, userToken) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/column/getColumnByUid.do",
			data: {
				"uid": uid,
				"type": columnType,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				if(res.code == 0) {
					if(locationPlace == "tab6") { //columnType=1(VIP服务)columnType=2(主页)columnType=3（专栏tab）
						//console.log(res);
						if(pageIndex == 1 && res.data.length == 0) {
							$(".ColumnBoxWrapLiveTab6").stop().hide();
						} else {
							//console.log(res);
							$(".vipTabFiveBoxNull").stop().hide();
							$(res.data).each(function(i, k) {
								var subscribeType = k.subscribeType; //订阅类型（0=免费，1=周期收费，2=永久收费）
								//console.log(subscribeType);
								var subscribeTypeId = k.id + "subscribeType";
								var subscribeTypeLogoId = k.id + "subscribeTypeLogo";
								var subscribeTypeIdHref = k.id + "subscribeTypeHref";
								var vipColumnBoxLive =
									'<li class="liveListBoxIndexRoomInfo fl" objectId=' + k.id + ' id=' + subscribeTypeIdHref + '>' +
									'<div class="liveListBoxIndexRoomInfoT">' +
									'<img src="' + k.coverUrl + '!120X160" />' +
									'<img id=' + subscribeTypeLogoId + ' src="images/charge.png" />' +
									'</div>' +
									'<div class="liveListBoxIndexRoomInfoB">' +
									'<p>' + k.name + '</p>' +
									'<p><span>' + k.subscribePay + '牛币</span>/<span class="subscribeCycleLogo" id=' + subscribeTypeId + '>' + k.subscribeCycle + '天</span></p>' +
									'</div>' +
									'</li>';
								$(".vipColumnBoxLive").append(vipColumnBoxLive);
								if(subscribeType == 2) {
									$("#" + subscribeTypeId).html("全期");
								};
								if(subscribeType == 0) {
									$("#" + subscribeTypeLogoId).stop().hide();
									$("#" + subscribeTypeId).parent().remove();
								};

								$(document).on("click", "#" + subscribeTypeIdHref, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/columnDetail?id=" + id;
								});

							});

						}
					} else if(locationPlace == "tab1") {
						if(pageIndex == 1 && res.data.length == 0) {
							$(".ColumnBoxWrapLiveTab1").stop().hide();
						} else {
							//console.log(res);
							$(res.data).each(function(i, k) {
								var subscribeType = k.subscribeType; //订阅类型（0=免费，1=周期收费，2=永久收费）
								//console.log(subscribeType);
								var subscribeTypeId = k.id + "subscribeType1";
								var subscribeTypeLogoId = k.id + "subscribeTypeLogo1";
								var subscribeTypeCoverId= k.id + "subscribeTypeCoverId1";
								var subscribeTypeIdHref = k.id + "subscribeTypeHref1";
								var vipColumnBoxLive =
									'<li class="liveListBoxIndexRoomInfo fl" objectId=' + k.id + ' id=' + subscribeTypeIdHref + '>' +
									'<div class="liveListBoxIndexRoomInfoT">' +
									'<img id=' + subscribeTypeCoverId + ' src="' + k.coverUrl + '!120X160" />' +
									'<img id=' + subscribeTypeLogoId + ' src="images/charge.png" />' +
									'</div>' +
									'<div class="liveListBoxIndexRoomInfoB">' +
									'<p>' + k.name + '</p>' +
									'<p><span>' + k.subscribePay + '牛币</span>/<span class="subscribeCycleLogo" id=' + subscribeTypeId + '>' + k.subscribeCycle + '天</span></p>' +
									'</div>' +
									'</li>';
								$(".ColumnBoxLiveTab1").append(vipColumnBoxLive);
								if(subscribeType == 2) {
									$("#" + subscribeTypeId).html("全期");
								};
								if(subscribeType == 0) {
									$("#" + subscribeTypeLogoId).stop().hide();
									$("#" + subscribeTypeId).parent().remove();
								};
								$(document).on("click", "#" + subscribeTypeIdHref, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/columnDetail?id=" + id;
								});
								$("#" + subscribeTypeCoverId).one("error", function(e) {
									$(this).attr("src", "images/vedioCoverUrl.jpg");
								});
								
							})
						}
					} else if(locationPlace == "tab5") {
						if(res.data.length == 0 && pageIndex != 1) {
							$(".columnAddMore").stop().hide();
							$(".ColumnEnd").stop().show();
						}
						if(pageIndex == 1 && res.data.length == 0) {
							$(".columnAddMore").stop().hide();
							$(".ColumnEnd").stop().hide();
						} else {
							console.log(res);
							$(res.data).each(function(i, k) {
								var subscribeType = k.subscribeType; //订阅类型（0=免费，1=周期收费，2=永久收费）
								//console.log(k);
								var subscribeTypeId = k.id + "subscribeTypeTab5";
								var subscribeType1Id = k.id + "subscribeTypeTab51";
								var subscribeType1Id1 = k.id + "subscribeTypeTab511";
								var subscribeTypeMoneryId = k.id + "subscribeTypeMoneryTab5";
								var subscribeTypeLogoId = k.id + "subscribeTypeLogoTab5";
								var subscribeTypeCoverId = k.id + "subscribeTypeCoverId5";
								var subscribeTypeIdHref = k.id + "subscribeTypeHrefTab5";
								var subscribeTypeIdUpDate = k.id + "subscribeTypeHrefTab5UpDate";
								var delColumnBtnId = k.id + "delColumnBtnId";
								var editColumnBtnId = k.id + "editColumnBtnId";
								var delColumnBtnIdBox = k.id + "delColumnBtnIdBox";
								var subscribePayId=k.id + "subscribePayColumnBtnIdBox";
								var vipColumnBoxLiveTab5 =
									'<div class="columnWrap" id=' + subscribeTypeIdHref + ' objectId=' + k.id + '>' +
									'<div class="columnWrapL fl">' +
									'<img id=' + subscribeTypeCoverId + ' src="' + k.coverUrl + '!120X160" />' +
									'<img id=' + subscribeTypeLogoId + ' src="images/charge.png" alt="" />' +
									'</div>' +
									'<div class="columnWrapR fl">' +
									'<p class="fl columnWrapRTitle">' + k.name + '</p>' +
									'<span class="fl columnWrapRFree" id=' + subscribeTypeId + '>' + k.contentCount + '期内容</span>' +
									'<span class="fl columnWrapOwnNum" id=' + subscribeType1Id + '>' + k.subscribeCount + '人订阅</span>' +
									'<p class="fl columnWrapRMoney" id=' + subscribeTypeMoneryId + '><span id='+subscribePayId+'>' + k.subscribePay + '牛币/'+k.subscribeCycle+'天</span><span>|</span><span id=' + subscribeType1Id1 + '>' + k.subscribeCount + '人订阅</span></p>' +
									'<div class="fr deleteBtn">' +
									'<img src="images/gengduo_56.png" />' +
									'<div class="deleteInfoWrap">' +
									'<p id=' + editColumnBtnId + ' objectId=' + k.id + '>编辑</p>' +
									'<p id=' + delColumnBtnId + ' objectId=' + k.id + '>删除</p>' +
									'</div>' +
									'</div>' +
									'<p class="columnTitle">' + k.introduction + '</p>' +
									'<p class="columnUpdate"><span>更新：</span><span id=' + subscribeTypeIdUpDate + '>' + k.description + '</span></p>' +
									'</div>' +
									'</div>	';
								$(".columnAddMore").before(vipColumnBoxLiveTab5);
								$("#" + subscribeTypeCoverId).one("error", function(e) {
									$(this).attr("src", "images/vedioCoverUrl.jpg");
								});
								if(subscribeType == 0) { //订阅类型（0=免费，1=周期收费，2=永久收费）
									$("#" + subscribeTypeId).stop().show();
									$("#" + subscribeTypeMoneryId).stop().hide();
									$("#" + subscribeType1Id).stop().show();
									$("#" + subscribeTypeLogoId).stop().hide();
								} else {
									$("#" + subscribeTypeId).stop().hide();
									$("#" + subscribeType1Id).stop().hide();
									$("#" + subscribeTypeMoneryId).stop().show();
									if(subscribeType == 2){
										$("#"+subscribePayId).html(k.subscribePay + "牛币/全期");
									}
								}
								//专栏里面没内容可以删除，否则提示不能删除
								if(k.description == "" || k.description == null || k.description == undefined) {
									$("#" + subscribeTypeIdUpDate).html("暂无更新内容");
									if(k.subscribeCount == 0) {
										$(document).on("click", "#" + delColumnBtnId, function(event) {
											event.stopPropagation();
											var id = $(this).attr("objectId");
											$("#" + delColumnBtnIdBox).stop().hide();
											deleteColumnFun(id, uid, userToken);
										});
									} else {
										$(document).on("click", "#" + delColumnBtnId, function(event) {
											event.stopPropagation();
											layer.msg('已有人订阅该专栏，不能删除');
										});
									}
									//删除专栏
								} else {
									//不能删除专栏的提示
									$(document).on("click", "#" + delColumnBtnId, function(event) {
										event.stopPropagation();
										layer.msg('删除专栏，需将专栏内容清空！');
									});

								};
								//主播角色才可以开启直播和编辑
								if(roleType == 1) {
									$(".deleteBtn").stop().show();
								}
								$(document).on("click", "#" + subscribeTypeIdHref, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/columnDetail?id=" + id;

								});
								//编辑专栏按钮
								$(document).on("click", "#" + editColumnBtnId, function(event) {
									event.stopPropagation();
									var id = $(this).attr("objectId");
									$(".columnAddMoreBox").stop().hide();
									$(".createColumnBox").stop().show();
									$(".createColumnBoxInfo1").html("编辑专栏");
									$(".startcreateColumnBtn").stop().hide();
									$(".editColumnBtn").stop().show();
									//获得专栏详情
									getColumnDetail(id, userToken, uid);
								});
							})
						}
					}

				}

			}
		})

	}
	//获得专栏详情
	function getColumnDetail(columnId, token, uid) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v2/column/getColumnDetail.do",
			data: {
				"columnId": columnId,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".ColumnName").val(res.data.name);
					$(".ColumnIntro").val(res.data.introduction);
					$(".ColumnIntrodescription").val(res.data.subscribeSummary);
					$(".descriptionImgUrlColumn").attr("src", res.data.summaryUrl);
					$(".columnRoomCover").attr("src", res.data.coverUrl);
					if(res.data.subscribeType == 1) { //0-免费，1-周期性，2-一次性
						$(".createColumnMoneyCycle").stop().show();
						$(".moneySelete").find("option:selected").text("周期收费");
						$(".niubiBoxColumn").val(res.data.subscribePay);
						$(".dayBoxColumn").val(res.data.subscribeCycle);
					} else if(res.data.subscribeType == 2) {
						$(".createColumnMoneyALL").stop().show();
						$(".moneySelete").find("option:selected").text("全期收费");
						$(".dayBoxColumnAll").val(res.data.subscribePay);
					};
					$(".editColumnBtn").click(function() {
						//编辑专栏
						createColumn(columnId, token, uid, "editColumn");
					})

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})
		//
	}
	//删除专栏
	function deleteColumnFun(id, uid, token) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/column/delete.do",
			data: {
				"id": id,
				"uid": uid,
				"token": token,
			},
			success: function(res) {
				if(res.code == 0) {
					layer.msg('删除专栏成功！');
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})
	}

	//专栏列表
	//getColumnByUid(uid, 1, 10);
	//收益信息
	getProfitInfoByUid(uid);
	function liveSumNum(uid, objectType) {
		$.ajax({
			type: "get",
			async: true,
			url: "/api/v2/dynamic/selectCountByTypeLiveVideo.do",
			data: {
				"uid": uid,
				"objectType": objectType,
			},
			success: function(res) {
				if(objectType == 3) {
					var liveWholeNumber = res.data;
					$(".anchorLiveNum").html(liveWholeNumber);
					if(liveWholeNumber == 0) {
						$(".liveNewsStatus").show();
						$(".liveAddMore").hide();
						$(".liveNewBEnd").stop().hide();
					} else {
						$(".liveNewsStatus").hide();
						$(".liveAddMore").show();
					}
				} else if(objectType == 5) {
					//console.log(res);
					var tradeWholeNumber = res.data; //实盘交易总条数
					tradeWholeNumberFun(tradeWholeNumber);
					if(tradeWholeNumber == 0) {
						//交易动态缺省
						$(".transactionBoxWrap").stop().hide();
						$(".PaginationVedio").stop().hide();
						$(".tradeStatuNull").stop().show();
					} else {
						$(".tradeWholeNumber").html(tradeWholeNumber);
					}
				}

			}
		});
	}
	var anchorpageIndex = 1;

	function anchorNewsFun(uid, pageSize, pageIndex, DynamicHotType, roleTypeStype, userToken) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"uid": uid,
				"pageSize": pageSize,
				"pageIndex": pageIndex,
				"userId": roleTypeStype,
			},
			url: "/api/v3/dynamic/getLiverDynamicListByAuthorV3.do",
			success: function(res) {
			//	console.log(res);
				if(res.code == 0) {
					//console.log(res);
					var resDataLen = res.data.length;
					if(resDataLen > 0) {
						$(".sameAddMoreAllDynamicList").click(function() {
							anchorpageIndex++;
							anchorNewsFun(uid, pageSize, anchorpageIndex, "anchorOwnhotNews", roleTypeStype, userToken);
						})
					} else {
						$(".sameAddMoreAllDynamicList").stop().hide();
						$(".sameAddEndDynamicList").stop().show();
					}
					dynamicFun(uid, pageSize, pageIndex, DynamicHotType, roleTypeStype, userToken, res);
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});

	}

    //根据类型获取动态
    var articleDynamicListBoxIndex=1;
    var videoAudioDynamicListBoxIndex=1;
    var liveBackDynamicListBoxIndex=1;
    //dynamicType动态类型{1=文章；2=音视频；3=直播回放}
    function getDynamicByTypeV3(uid, pageSize, pageIndex, DynamicHotType, roleTypeStype, userToken,dynamicType){
    	$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"uid": uid,
				"pageSize": pageSize,
				"pageIndex": pageIndex,
				"userId": roleTypeStype,
				"dynamicType": dynamicType,
			},
			url: "/api/v3/dynamic/getDynamicByTypeV3.do",
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					//console.log(res);
					if(DynamicHotType=="articleDynamicListBox"){
						var resDataLen = res.data.length;
						if(resDataLen>0){
							$(".articleDynamicListBoxSameAddMore").click(function(){
							   articleDynamicListBoxIndex++;
							   getDynamicByTypeV3(uid, pageSize, articleDynamicListBoxIndex, DynamicHotType, roleTypeStype, userToken,dynamicType);
						    })
						}else{
							$(".articleDynamicListBoxSameAddMore").stop().hide();
							$(".articleDynamicListBoxSameAddEnd").stop().show();
						}
						
						dynamicFun(uid, pageSize, pageIndex, "articleDynamicListBox", roleTypeStype, userToken, res)
					}else if(DynamicHotType=="videoAudioDynamicListBox"){
						var resDataLen = res.data.length;
						if(resDataLen>0){
						   $(".videoAudioDynamicListBoxSameAddMore").click(function(){
							  videoAudioDynamicListBoxIndex++;
							  getDynamicByTypeV3(uid, pageSize, videoAudioDynamicListBoxIndex, DynamicHotType, roleTypeStype, userToken,dynamicType);
						   })
						}else {
							$(".videoAudioDynamicListBoxSameAddMore").stop().hide();
							$(".videoAudioDynamicListBoxSameAddEnd").stop().show();
						}
						dynamicFun(uid, pageSize, pageIndex, "videoAudioDynamicListBox", roleTypeStype, userToken, res)
					}else if(DynamicHotType=="liveBackDynamicListBox"){
						var resDataLen = res.data.length;
						if(resDataLen>0){
							$(".liveBackDynamicListBoxSameAddMore").click(function(){
								liveBackDynamicListBoxIndex++;
								getDynamicByTypeV3(uid, pageSize, liveBackDynamicListBoxIndex, DynamicHotType, roleTypeStype, userToken,dynamicType);
							})
						}else {
							$(".liveBackDynamicListBoxSameAddMore").stop().hide();
							$(".liveBackDynamicListBoxSameAddEnd").stop().show();
						}
						dynamicFun(uid, pageSize, pageIndex, "liveBackDynamicListBox", roleTypeStype, userToken, res)
						
					}
					
					
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
    }




	function dynamicFun(uid, pageSize, pageIndex, DynamicHotType, roleTypeStype, userToken, res) {
		//console.log(res);
		$(res.data).each(function(i, k) {
			var objectType = k.objectType; //动态类型
			var isAgree = k.object.isAgree;
			var isAgreeLogo = k.object.isAgree + k.object.id + DynamicHotType;
			var categoryName = k.object.liverInfo.uid + k.object.id + DynamicHotType;
			var columnName = k.object.columnName;
			var locationHrefId = k.object.publishTime + k.object.id + DynamicHotType;
			var locationHrefLiveId = k.publishTime + k.object.id + DynamicHotType;
			var objectId = k.object.id;
			var deleteId = k.object.isAgree + k.object.id + DynamicHotType + "deleteId";
			var isFreeId = k.object.isAgree + k.object.id + DynamicHotType + "isFreeId";
			var isFreeIdBox = k.object.isAgree + k.object.id + DynamicHotType + "isFreeIdBox";
			var isFreeLogo = k.object.isAgree + k.object.id + DynamicHotType + "isFreeLogo";
			var chooseId = k.object.isAgree + k.object.id + DynamicHotType + "chooseId";
			var deleteDynamicByTypeId = k.id;
			var nowColumnId = k.object.columnId;
			var imgNoOwnCover = k.object.isAgree + k.object.id + DynamicHotType + "imgNoOwnCover";
			var commentCountId=k.object.isAgree + k.object.id + DynamicHotType + "commentCountId"+i;
			//console.log(columnName);
			//console.log(categoryName);
			//  console.log(isAgreeLogo);
			//console.log(DynamicHotType);
			if(objectType == 1) { //文章或短评
				var type = k.object.type;
				//console.log(isAgree);
				if(type == 1) { //短评
					var media = k.object.media;
					if(media == "") { //无图短评
						var shortViewNullImg =
							'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
							'<div class="BoxWrapT">' +
							'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
							'<div class="liveBoxWrapTR fl">' +
							'<p>' + k.object.liverInfo.nickName + '</p>' +
							'<p>' + format(new Date(k.publishTime)) + '</p>' +
							'</div>' +
							'<div class="fr deleteBtn deleteBtnSame">' +
							'<img src="images/gengduo_56.png" />' +
							'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
							'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
							'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
							'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
							'</div>' +
							'</div>' +
							'</div>' +
							'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
							'<ul class="sameBottom borderSameBottom">' +
							'<li class="fr sameBottomList">分享</li>' +
							'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
							'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
							'</ul>' +
							'</div>';
						if(DynamicHotType == "anchorOwnhotNews") {
							$(".allAllDynamicListBox").append(shortViewNullImg);
						} else if(DynamicHotType == "anchorOwnTab1") {
							$(".liveListBoxIndexSameBoxHotNews").append(shortViewNullImg);
						}
						$(document).on("click", "#" + locationHrefId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/shortView?id=" + id;
						});
						//短评删除

					} else {
						var shortViewImg = (media.split(','));
						var len = shortViewImg.length;
						var shortid = k.object.id + DynamicHotType;
						if(len == 1) { //1张图
							var shortViewOneImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<a href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImgOne" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewOneImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewOneImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});
						} else if(len == 2) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewTwoImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewTwoImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 3) {
							var shortViewTwoImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewTwoImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewTwoImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 4) {
							var shortViewThreeImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewThreeImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewThreeImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 5) {
							var shortViewFourImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewFourImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewFourImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 6) {
							var shortViewFiveImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewFiveImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewFiveImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 7) {
							var shortViewSixImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewSixImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewSixImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 8) {
							var shortViewSevenImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[7] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[7] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewSevenImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewSevenImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						} else if(len == 9) {
							var shortViewEightImg =
								'<div class="artileBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
								'<div class="shortViewImgBox">' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[7] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[7] + '">' +
								'</a>' +
								'<a class="shortViewImgWrap" href="' + shortViewImg[8] + '" data-lightbox="' + shortid + '">' +
								'<img class="shortViewImg" src="' + shortViewImg[8] + '">' +
								'</a>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(shortViewEightImg);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(shortViewEightImg);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/shortView?id=" + id;
							});

						}
					}
					$("#" + chooseId).stop().hide();
					$("#" + isFreeId).stop().hide();
					$("#" + isFreeIdBox).css({
						"height": "35px",
					})
				} else if(type == 2) { //长文章
					var coverUrl = k.object.userCoverUrl;
					var articleid = k.object.id;
					var article_content = htmlEncode(k.object.content);
					if(coverUrl == "") { //无图文章——//判断文章里面是否有图片，如果有显示第一张
						var articleContent = k.object.content;
						var content = htmlEncode(articleContent);
						var imgReg = /<img.*?(?:>|\/>)/gi;
						//匹配src属性
						var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
						var imgArr = content.match(imgReg); //'所有已成功匹配图片的数组
						// console.log(imgArr);
						if(imgArr == null) {
							var nullImgArticleBox =
								'<div class="NullartileBoxWrap" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<div class="fr deleteBtn deleteBtnSame">' +
								'<img src="images/gengduo_56.png" />' +
								'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
								'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
								'<p id=' + chooseId + ' objectId=' + objectId + ' type="2" fatherId=' + locationHrefId + ' uid=' + roleTypeStype + ' token=' + userToken + ' nowColumnId=' + nowColumnId + '>选择专栏</p>' +
								'<p id=' + isFreeId + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>编辑</p>' +
								'</div>' +
								'</div>' +
								'</div>' +
								'<h2> ' + k.object.title + ' </h2>' +
								'<p class="articleContent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>';
							if(DynamicHotType == "anchorOwnhotNews") {
								$(".allAllDynamicListBox").append(nullImgArticleBox);
							} else if(DynamicHotType == "anchorOwnTab1") {
								$(".liveListBoxIndexSameBoxHotNews").append(nullImgArticleBox);
							}else if(DynamicHotType == "articleDynamicListBox") {
								$(".articleDynamicListBox").append(nullImgArticleBox);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/article?id=" + id;
							});
							$(".headImgUrlCircle").one("error", function(e) {
								$(this).attr("src", "images/anchorHead.png");
							});
						} else {
							src = imgArr[0].match(srcReg);
								//获取图片地址
								if(src[1]) {
									// console.log(src[1]);
									var ImgArticleBox =
										' <div class="imgArticleBoxWrap" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
										'<div class="BoxWrapT">' +
										'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
										'<div class="liveBoxWrapTR fl">' +
										'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
										'<p>' + format(new Date(k.publishTime)) + '</p>' +
										'</div>' +
										'<div class="fr deleteBtn deleteBtnSame">' +
										'<img src="images/gengduo_56.png" />' +
										'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
										'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
										'<p id=' + chooseId + ' objectId=' + objectId + ' type="2" uid=' + roleTypeStype + ' token=' + userToken + ' fatherId=' + locationHrefId + ' nowColumnId=' + nowColumnId + '>选择专栏</p>' +
										'<p id=' + isFreeId + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>编辑</p>' +
										'</div>' +
										'</div>' +
										'</div>' +
										'<div class="liveBoxWrapBL fl">' +
										'<img id=' + imgNoOwnCover + ' src="' + src[1] + '">' +
										'</div>' +
										'<div class="imgArticleBoxWrapBR fr">' +
										'<div class="imgArticleBoxWrapBRT">' +
										'<h3>' + k.object.title + '</h3>' +
										'<p class="imgArticleBoxWrapBCentent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
										'</div>' +
										'<div class="imgArticleBoxWrapBRB sameBottom">' +
										'<li class="fr sameBottomList">分享</li>' +
										'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
										'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
										'</div>' +
										'</div>' +
										'</div>'
									if(DynamicHotType == "anchorOwnhotNews") {
										$(".allAllDynamicListBox").append(ImgArticleBox);
									} else if(DynamicHotType == "anchorOwnTab1") {
										$(".liveListBoxIndexSameBoxHotNews").append(ImgArticleBox);
									}else if(DynamicHotType == "articleDynamicListBox") {
									   $(".articleDynamicListBox").append(ImgArticleBox);
								    }
									//console.log(src[1]);
	                                 if(src[1].indexOf("http://mmbiz.qpic.cn/mmbiz_png")==0){
	                                 	$("#"+imgNoOwnCover).attr("src", "images/vedioCoverUrl.jpg");
	                                 }
									$(document).on("click", "#" + locationHrefId, function(e) {
										var id = $(this).attr("objectId");
										window.location.href = "/article?id=" + id;
									});
									$("#" + imgNoOwnCover).one("error", function(e) {
										$(this).attr("src", "images/vedioCoverUrl.jpg");
									});
									$(".headImgUrlCircle").one("error", function(e) {
										$(this).attr("src", "images/anchorHead.png");
									});
								 }
							
						}

					} else { //有图文章
						var ImgArticleBox =
							' <div class="imgArticleBoxWrap" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
							'<div class="BoxWrapT">' +
							'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
							'<div class="liveBoxWrapTR fl">' +
							'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
							'<p>' + format(new Date(k.publishTime)) + '</p>' +
							'</div>' +
							'<div class="fr deleteBtn deleteBtnSame">' +
							'<img src="images/gengduo_56.png" />' +
							'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
							'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
							'<p id=' + chooseId + ' objectId=' + objectId + ' type="2" uid=' + roleTypeStype + ' token=' + userToken + ' fatherId=' + locationHrefId + ' nowColumnId=' + nowColumnId + '>选择专栏</p>' +
							'<p id=' + isFreeId + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>编辑</p>' +
							'</div>' +
							'</div>' +
							'</div>' +
							'<div class="liveBoxWrapBL fl">' +
							'<img src="' + k.object.userCoverUrl + '!220X164' + '">' +
							'</div>' +
							'<div class="imgArticleBoxWrapBR fr">' +
							'<div class="imgArticleBoxWrapBRT">' +
							'<h3>' + k.object.title + '</h3>' +
							'<p class="imgArticleBoxWrapBCentent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
							'</div>' +
							'<div class="imgArticleBoxWrapBRB sameBottom">' +
							'<li class="fr sameBottomList">分享</li>' +
							'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
							'<li class="fr sameBottomList likeWatchLogin" likeType="1" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
							'</div>' +
							'</div>' +
							'</div>'
						if(DynamicHotType == "anchorOwnhotNews") {
							$(".allAllDynamicListBox").append(ImgArticleBox);
						} else if(DynamicHotType == "anchorOwnTab1") {
							$(".liveListBoxIndexSameBoxHotNews").append(ImgArticleBox);
						}else if(DynamicHotType == "articleDynamicListBox") {
							$(".articleDynamicListBox").append(ImgArticleBox);
						}

						$(document).on("click", "#" + locationHrefId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/article?id=" + id;
						});
						$(".headImgUrlCircle").one("error", function(e) {
							$(this).attr("src", "images/anchorHead.png");
						});
					}
					// console.log(k);	
				}
				$("#" + isFreeId).stop().hide();
			} else if(objectType == 2) { //视频
				var videoIdCover = locationHrefId + "video";
				var videoNewsWrapBox =
					'<div class="videoNewsWrap" class="videoNewsWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
					'<div class="BoxWrapT">' +
					'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
					'<div class="liveBoxWrapTR fl">' +
					'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
					'<p>' + format(new Date(k.publishTime)) + '</p>' +
					'</div>' +
					'<div class="fr deleteBtn deleteBtnSame">' +
					'<img src="images/gengduo_56.png" />' +
					'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
					'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
					'<p id=' + chooseId + ' objectId=' + objectId + ' type="1" uid=' + roleTypeStype + ' token=' + userToken + ' fatherId=' + locationHrefId + ' nowColumnId=' + nowColumnId + '>选择专栏</p>' +
					'<p id=' + isFreeId + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>编辑</p>' +
					'</div>' +
					'</div>' +
					'</div>' +
					'<div class="videoNewsBoxB">' +
					'<div class="videoNewsBoxBL fl">' +
					'<img src="images/livevideo.png" />' +
					'<img class="vedioCoverUrl" id=' + videoIdCover + ' src="' + k.object.coverUrl + '!220X164">' +
					'<span>' + durationFun(new Date(k.object.duration)) + '</span>' +
					'</div>' +
					'<div class="videoNewsBoxBR fl">' +
					'<p></p>' +
					'<p>' + k.object.topic + '</p>' +
					'<p>' + k.object.watchCount + '人观看</p>' +
					'<ul class="sameBottom borderSameBottom">' +
					'<li class="fr sameBottomList">分享</li>' +
					'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
					'<li class="fr sameBottomList likeWatchLogin" likeType="2" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
					'</ul>' +
					'</div>' +
					'</div>' +
					'</div>';
				if(DynamicHotType == "anchorOwnhotNews") {
					$(".allAllDynamicListBox").append(videoNewsWrapBox);
				} else if(DynamicHotType == "anchorOwnTab1") {
					$(".liveListBoxIndexSameBoxHotNews").append(videoNewsWrapBox);
				}else if(DynamicHotType == "videoAudioDynamicListBox") {
					$(".videoAudioDynamicListBox").append(videoNewsWrapBox);
				}
				$("#" + videoIdCover).one("error", function(e) {
					$(this).attr("src", "images/vedioCoverUrl.jpg");
				});
				$(".headImgUrlCircle").one("error", function(e) {
					$(this).attr("src", "images/anchorHead.png");
				});
				$(document).on("click", "#" + locationHrefId, function(e) {
					var id = $(this).attr("objectId");
					window.location.href = "/video?id=" + id;
				});
				$("#" + isFreeId).stop().hide();

			} else if(objectType == 3) { //直播
				var liveType = k.object.type;
				if(liveType == 0) {
					//console.log(k);
					//console.log(locationHrefLiveId);
					var liveBoxWrap =
						'<div class="videoNewsWrap" class="videoNewsWrapBox" id=' + locationHrefLiveId + ' roomid=' + k.object.roomId + ' uid=' + k.object.liverInfo.uid + '>' +
						'<div class="BoxWrapT">' +
						'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '" />' +
						'<div class="liveBoxWrapTR fl">' +
						'<p>' + k.object.liverInfo.nickName + '<span class="playStyleLive">正在公开直播</span></p>' +
						'<p>' + format(new Date(k.publishTime)) + '</p>' +
						'</div>' +
						'</div>' +
						'<div class="videoNewsBoxB">' +
						'<div class="videoNewsBoxBL fl">' +
						'<img src="images/livevideo.png" style="display: none;" />' +
						'<img class="vedioCoverUrl" src="' + k.object.coverUrl + '!220X164' + '">' +
						'<img src="images/live.png" />' +
						'</div>' +
						'<div class="videoNewsBoxBR fl">' +
						'<p></p>' +
						'<p>' + k.object.topic + '</p>' +
						'<p>' + k.object.watchCount + '人观看</p>' +
						'</div>' +
						'</div>' +
						'</div>';
					if(DynamicHotType == "anchorOwnhotNews") {
						$(".allAllDynamicListBox").append(liveBoxWrap);
					} else if(DynamicHotType == "anchorOwnTab1") {
						$(".liveListBoxIndexSameBoxHotNews").append(liveBoxWrap);
					}
					if(k.object.roomType == 1) {
						$(".playStyleLive").html("正在VIP直播：");
						$(document).on("click", "#" + locationHrefLiveId, function(e) {
							var roomid = $(this).attr("roomid");
							var uid = $(this).attr("uid");
							window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
						});
					} else if(k.object.roomType == 0) {
						$(".playStyleLive").html("正在公开直播：");
						$(document).on("click", "#" + locationHrefLiveId, function(e) {
							var roomid = $(this).attr("roomid");
							var uid = $(this).attr("uid");
							window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
						});
					}
				} else if(liveType == 1) { //回放
					var liveGoBackIdCover = locationHrefId + "liveGoBack";
					var liveBoxWrap =
						'<div class="videoNewsWrap" class="videoNewsWrapBox" id=' + locationHrefId + ' roomid=' + k.object.roomId + ' uid=' + k.object.liverInfo.uid + ' objectId=' + k.object.id + '>' +
						'<div class="BoxWrapT">' +
						'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '" />' +
						'<div class="liveBoxWrapTR fl">' +
						'<p>' + k.object.liverInfo.nickName + '</p>' +
						'<p>' + format(new Date(k.publishTime)) + '</p>' +
						'</div>' +
						'<div class="fr deleteBtn deleteBtnSame">' +
						'<img src="images/gengduo_56.png" />' +
						'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
						'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
						'<p id=' + isFreeId + ' objectId=' + objectId + ' fatherId=' + locationHrefId + ' uid=' + roleTypeStype + ' token=' + userToken + '>编辑</p>' +
						'</div>' +
						'</div>' +
						'</div>' +
						'<div class="videoNewsBoxB">' +
						'<div class="videoNewsBoxBL fl">' +
						'<img src="images/livevideo.png" style="display: none;" />' +
						'<img class="vedioCoverUrl" id=' + liveGoBackIdCover + ' src="' + k.object.coverUrl + '!220X164' + '">' +
						'<img src="images/playback.png" />' +
						'</div>' +
						'<div class="videoNewsBoxBR fl">' +
						'<p></p>' +
						'<p>' + k.object.topic + '</p>' +
						'<p>' + k.object.watchCount + '人观看</p>' +
						'<ul class="sameBottom borderSameBottom">' +
						'<li class="fr sameBottomList">分享</li>' +
						'<li class="fr sameBottomList" id=' + commentCountId + '>' + k.commentCount + '条评论</li>' +
						'<li class="fr sameBottomList likeWatchLogin" likeType="3" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
						'</ul>' +
						'</div>' +
						'</div>' +
						'</div>';
					if(DynamicHotType == "anchorOwnhotNews") {
						$(".allAllDynamicListBox").append(liveBoxWrap);
					} else if(DynamicHotType == "anchorOwnTab1") {
						$(".liveListBoxIndexSameBoxHotNews").append(liveBoxWrap);
					} else if(DynamicHotType == "liveBackDynamicListBox") {
						$(".liveBackDynamicListBox").append(liveBoxWrap);
					}
					$("#"+commentCountId).stop().hide();
					$(document).on("click", "#" + locationHrefId, function(e) {
						var roomid = $(this).attr("roomid");
						var id = $(this).attr("objectId");
						var uid = $(this).attr("uid");
						window.location.href = "/liveLookBack?id=" + id + "&roomid=" + roomid + "&uid=" + uid;
					});
					$("#" + liveGoBackIdCover).one("error", function(e) {
						$(this).attr("src", "images/vedioCoverUrl.jpg");
					});
					$("#" + chooseId).stop().hide();
				}

			} else if(objectType == 4) { //回答
				//console.log(k);
				var answerBox =
					'<div class="topicBoxWrap" id=' + locationHrefId + ' objectId=' + objectId + '>' +
					'<div class="BoxWrapT">' +
					'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
					'<div class="liveBoxWrapTR fl">' +
					'<p>' + k.object.liverInfo.nickName + '</p>' +
					'<p>' + format(new Date(k.publishTime)) + '</p>' +
					'</div>' +
					'<div class="fr deleteBtn deleteBtnSame">' +
					'<img src="images/gengduo_56.png" />' +
					'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
					'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
					'</div>' +
					'</div>' +
					'</div>' +
					'<p class="topicTitle">回答了<span>#话题#</span>' + k.object.discuss.discussTitle + '</p>' +
					'<div class="topicBoxBottom">' +
					'<img class="fl" src="images/livehuati.png" />' +
					'<div class="topicBoxBottomR">' +
					'<p>' + removeHTMLTag(htmlEncode(k.object.answerContent)) + ' </p>' +
					'<p><span> ' + k.object.discuss.discussWatchCount + '人看过</span><span>' + k.object.discuss.discussAnswerCount + ' 人回答</span></p>' +
					'</div>' +
					'</div>' +
					'<ul class="sameBottom borderSameBottom">' +
					'<li class="fr sameBottomList">分享</li>' +
					'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
					'<li class="fr sameBottomList likeWatchLogin" likeType="4" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
					'</ul>' +
					"</div>";
				if(DynamicHotType == "anchorOwnhotNews") {
					$(".allAllDynamicListBox").append(answerBox);
				} else if(DynamicHotType == "anchorOwnTab1") {
					$(".liveListBoxIndexSameBoxHotNews").append(answerBox);
				}
				$(document).on("click", "#" + locationHrefId, function(e) {
					var id = $(this).attr("objectId");
					window.location.href = "/topicDetails?id=" + id;
				});
				$("#" + chooseId).stop().hide();
				$("#" + isFreeId).stop().hide();
				$("#" + isFreeIdBox).css({
					"height": "35px",
				})
			} else if(objectType == 5) { //实盘
				var delegateType = k.object.delegateType;
				if(delegateType == 1) { //买入
					var firmBugWrap = "<div class='firmBugWrap'>" +
						"<div class='BoxWrapT'>" +
						"<img class='fl headImgUrlCircle' src=" + k.object.liverInfo.headImgUrl + ">" +
						"<div class='liveBoxWrapTR fl'>" +
						"<p>" + k.object.liverInfo.nickName + "</p>" +
						"<p>" + format(new Date(k.publishTime)) + "</p>" +
						"</div>" +
						"</div>" +
						"<p class='firmBugBox'>" +
						"我的<span>#实盘#</span>有最新的买入操作记录" +
						"</p>" +
						"<div class='firmBugBoxB'>" +
						"<div class='firmBugBoxBL fl'>买</div>" +
						"<div class='firmBugBoxBCL fl'>" +
						"<p>" + k.object.stockName + "</p>" +
						"<p>" + k.object.stockCode + "</p>" +
						"</div>" +
						"<div class='firmBugBoxBCR fl'>" +
						"<p><span>" + k.object.beforePositionRate + "%</span>-><span>" + k.object.changePositionRate + "%</span></p>" +
						"<p><span> 成交价：￥</span>" + k.object.price + "</p>" +
						"</div>" +
						"<div class='firmBugBoxBR fl'>看交易</div>" +
						"</div>" +
						"<ul class='sameBottom'>" +
						"<li class='fr sameBottomList'>分享</li>" +
						"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
						'<li class="fr sameBottomList likeWatchLogin" likeType="5" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
						"</ul>" +
						"</div>"
					if(DynamicHotType == "anchorOwnhotNews") {
						$(".allAllDynamicListBox").append(firmBugWrap);
					} else if(DynamicHotType == "anchorOwnTab1") {
						$(".liveListBoxIndexSameBoxHotNews").append(firmBugWrap);
					}
				} else if(delegateType == -1) { //卖出
					//  console.log(k);
					var firmSellWrap = "<div class='firmBugWrap'>" +
						"<div class='BoxWrapT'>" +
						"<img class='fl headImgUrlCircle' src=" + k.object.liverInfo.headImgUrl + ">" +
						"<div class='liveBoxWrapTR fl'>" +
						"<p>" + k.object.liverInfo.nickName + "</p>" +
						"<p>" + format(new Date(k.publishTime)) + "</p>" +
						"</div>" +
						"</div>" +
						"<p class='firmBugBox'>" +
						"我的<span>#实盘#</span>有最新的卖出操作记录" +
						"</p>" +
						"<div class='firmBugBoxB'>" +
						"<div class='firmBugBoxBLSell fl'>卖</div>" +
						"<div class='firmBugBoxBCL fl'>" +
						"<p>" + k.object.stockName + "</p>" +
						"<p>" + k.object.stockCode + "</p>" +
						"</div>" +
						"<div class='firmBugBoxBCR fl'>" +
						"<p><span>" + k.object.beforePositionRate + "%</span>-><span>" + k.object.changePositionRate + "%</span></p>" +
						"<p>成交价：￥" + k.object.price + "</p>" +
						"</div>" +
						"<div class='firmBugBoxBR fl'>看交易</div>" +
						"</div>" +
						"<ul class='sameBottom'>" +
						"<li class='fr sameBottomList'>分享</li>" +
						"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
						'<li class="fr sameBottomList likeWatchLogin" likeType="5" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
						"</ul>" +
						"</div>"
					if(DynamicHotType == "anchorOwnhotNews") {
						$(".allAllDynamicListBox").append(firmSellWrap);
					} else if(DynamicHotType == "anchorOwnTab1") {
						$(".liveListBoxIndexSameBoxHotNews").append(firmSellWrap);
					}
				}
			} else if(objectType == 6) { //音频
				var audioBox =
					'<div class="NullartileBoxWrap" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
					'<div class="BoxWrapT">' +
					'<img class="fl headImgUrlCircle" src="' + k.object.liverInfo.headImgUrl + '">' +
					'<div class="liveBoxWrapTR fl">' +
					'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
					'<p>' + format(new Date(k.publishTime)) + '</p>' +
					'</div>' +
					'<div class="fr deleteBtn deleteBtnSame">' +
					'<img src="images/gengduo_56.png" />' +
					'<div class="deleteInfoWrap" id=' + isFreeIdBox + '>' +
					'<p id=' + deleteId + ' objectId=' + deleteDynamicByTypeId + ' fatherId=' + locationHrefId + '>删除</p>' +
					'<p id=' + chooseId + ' objectId=' + objectId + ' type="1" uid=' + roleTypeStype + ' token=' + userToken + ' fatherId=' + locationHrefId + '>选择专栏</p>' +
					'<p id=' + isFreeId + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>编辑</p>' +
					'</div>' +
					'</div>' +
					'</div>' +
					'<div class="audioBox">' +
					'<div class="audioBoxL fl">' +
					'<img src="images/audioLogo.png"/>' +
					'<img src="' + k.object.liverInfo.headImgUrl + '">' +
					'</div>' +
					'<p class="fl">' + k.object.topic + '</p>' +
					' <span class="fr">' + durationFun(new Date(k.object.duration)) + '</span>' +
					'</div>' +
					'<ul class="sameBottom borderSameBottom">' +
					'<li class="fr sameBottomList">分享</li>' +
					'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
					'<li class="fr sameBottomList likeWatchLogin" likeType="2" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
					'</ul>' +
					"</div>";
				if(DynamicHotType == "anchorOwnhotNews") {
					$(".allAllDynamicListBox").append(audioBox);
				} else if(DynamicHotType == "anchorOwnTab1") {
					$(".liveListBoxIndexSameBoxHotNews").append(audioBox);
				}else if(DynamicHotType == "videoAudioDynamicListBox") {
					$(".videoAudioDynamicListBox").append(audioBox);
				}
				$(document).on("click", "#" + locationHrefId, function(e) {
					var id = $(this).attr("objectId");
					window.location.href = "/audio?id=" + id;
				});
				$(".headImgUrlCircle").one("error", function(e) {
					$(this).attr("src", "images/anchorHead.png");
				});
				$("#" + isFreeId).stop().hide();
			}

			$("#" + isAgreeLogo).click(function(event){
		    	 event.stopPropagation(); 
		    	 var objectId = $(this).attr("objectId");
		    	 var likeType = $(this).attr("likeType");
		    	 //判断是否点赞
		    	 $.ajax({
		                type: "POST",
		                async: true,
		                dataType: "json",
		                url: "/api/v2/agree/selectAgreeCount.do",
		                data: {
		                    "objectId": objectId,
		                    "uid": roleTypeStype,
		                    "agreeType": 1,
		                },
		                success: function (res) {
		                    if (res.code == 0) {
		                      //  console.log(res);
		                        var isAgree = res.data.isAgree;
		                        // var agreeCount=res.data.agreeCount;
		                        if (isAgree == true) {//已点赞
		                        	//取消点赞
		                        	deleteAgreeFun(roleTypeStype,objectId,1,userToken,isAgreeLogo,isAgree);
		                        }else{
		                        	//点赞
		                        	insertAgreeFun(roleTypeStype,objectId,likeType,1,userToken,isAgreeLogo,isAgree);
		                        }
		                    }
		                }
		            })
		    	 
		    })
			//console.log(userToken);
			if(userToken) { //登录状态——点赞取消赞
				if(isAgree == true) {//已经点赞取消点赞
					$("#" + isAgreeLogo).css({
						"background": "url(../images/rewardP.png) no-repeat left center"
					});
				}
                
			} else { //未登录——登录——点赞取消赞
				$("#" + isAgreeLogo).click(function(event){
				   event.stopPropagation(); 
                   $("#loginAlert").stop().show();
                   $("#loginAlert").load("/login");
                })
			}
			if(columnName) {
				$("#" + categoryName).next().html("《" + columnName + "》");
			} else {
				$("#" + categoryName).stop().hide();
				$("#" + categoryName).next().hide();
			};

			if(userToken == tokenLogin) { //主播身份
				$(".deleteBtnSame").stop().show();
			}

			//删除
			$(document).on("click", "#" + deleteId, function(event) {
				event.stopPropagation();
				var id = $(this).attr("objectId");
				var fatherId = $(this).attr("fatherId");
				deleteDynamicByType(id, deleteId, fatherId);
			});
			//选择专栏
			$(document).on("click", "#" + chooseId, function(event) {
				event.stopPropagation();
				var id = $(this).attr("objectId");
				var fatherId = $(this).attr("fatherId");
				var type = $(this).attr("type"); //type=1视频 type==2//文章
				var uid = $(this).attr("uid");
				var token = $(this).attr("token");
				$(".chooseColumnBox").stop().show();
				var nowColumnId = $(this).attr("nowColumnId");
				getColumnByUid(uid, 1, 20, id, type, token, fatherId, nowColumnId);
			});
			//编辑回放
			$(document).on("click", "#" + isFreeId, function(event) {
				event.stopPropagation();
				var id = $(this).attr("objectId");
				//console.log(id);
				$(".editPlayback").stop().show();
				//获得回放详情页面
				getVideoLivePlaybackInfoFun(roleTypeStype, userToken, id);
			});

		})
	}
	
	
    //点赞函数
    function insertAgreeFun(uid,objectId,likeType,agreeType,token,isAgreeLogo){
    	$.ajax({
			type: "post",
			url: "/api/v2/agree/insertAgree.do",
			async: true,
			data: {
				"uid": uid,
				"objectId": objectId,
				"type": likeType,
				"agreeType":agreeType,
				"token": token,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$("#" + isAgreeLogo).css({
						"background": "url(../images/rewardP.png) no-repeat left center"
					});
					var likeCountBefore=Number($("#" + isAgreeLogo).html());
					$("#" + isAgreeLogo).html(likeCountBefore+1);
				} 
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
    }
   //取消点赞
   function deleteAgreeFun(uid,objectId,agreeType,token,isAgreeLogo){
    	$.ajax({
			type: "post",
			url: "/api/v2/agree/deleteAgree.do",
			async: true,
			data: {
				"uid": uid,
				"objectId": objectId,
				"agreeType":agreeType,
				"token": token,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$("#" + isAgreeLogo).css({
						"background": "url(../images/livereward.png) no-repeat left center"
					});
					var likeCountBefore=Number($("#" + isAgreeLogo).html());
					$("#" + isAgreeLogo).html(likeCountBefore-1);
				
				}else if(res.code==-21){
					
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
    }






	function deleteDynamicByType(id, deleteId, fatherId) {
		$.ajax({
			type: "get",
			url: "/api/v1/dynamic/deleteDynamicByType.do",
			async: true,
			data: {
				"id": id,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					layer.msg("删除成功");
					$("#" + fatherId).remove();
				} else if(res.code == -16) {
					layer.msg("该条动态可能已经被删除了哦");
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
	}

	/*获得主播所有专栏*/
	function getColumnByUid(uid, pageIndex, pageSize, id, type, token, fatherId, nowColumnId) {
		$.ajax({
			type: "post", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v3/column/getColumnByUid.do",
			data: {
				"uid": uid,
				"type": 2, //类型 （0=免费，1=VIP，2=全部）
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(res.data).each(function(i, Q) {
						var columnId = Q.id;
						var chooseColumnListInfoLogo = Q.id + "chooseColumnListInfoLogo";
						var chooseColumnListInfoBox = Q.id + "chooseColumnListInfoBox";
						var chooseColumnListInfoBox =
							'<li class="chooseColumnListInfoBox" id=' + chooseColumnListInfoBox + ' objectId=' + columnId + '>' +
							'<p class="chooseColumnListInfo fl">' + Q.name + '</p>' +
							'<img class="fl chooseColumnListInfoLogo" id=' + chooseColumnListInfoLogo + ' src="../images/tiaoxuan.png"/>' +
							'</li>';
						$(".chooseColumnListBox").append(chooseColumnListInfoBox);
						if(columnId == nowColumnId) {
							$("#" + chooseColumnListInfoLogo).stop().show();
						} else {
							$("#" + chooseColumnListInfoLogo).stop().hide();
						}
					});
					$(".chooseColumnListInfoBox").click(function() {
						var columnId = $(this).attr("objectId"); //专栏id；
						$(".chooseColumnListInfoLogo").stop().hide();
						$(".chooseColumnListInfoLogo").eq($(this).index()).css("display", "block");
						$(".columnChooseSaveBtn").attr("columnId", columnId);
					});
					//保存
					$(".columnChooseSaveBtn").click(function() {
						var columnId = $(this).attr("columnId"); //专栏id；
						editColumnFun(token, columnId, uid, id, type, 0, fatherId);
						$(".chooseColumnBox").stop().hide();
					})

				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
	}

	//operation -操作类型（0-移动至专栏，1-从专栏移除）
	function editColumnFun(token, columnId, uid, id, type, operation, fatherId) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/column/edit.do",
			data: {
				"token": token,
				"columnId": columnId,
				"uid": uid,
				"id": id,
				"type": type,
				"operation": operation,
			},
			success: function(res) {
				//	console.log(res);
				if(res.code == 0) {
					layer.msg("修改成功");
					window.location.href = "userProfile?uid=" + uid + "&tab=2";
				} else if(res.code == -1) { //不选择专栏
					var moveColumnId = GetQueryString("id");
					editColumnFun(token, moveColumnId, uid, id, type, 1);
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})

	}
	//编辑回放(获得回放详情---修改回放信息)
	$(".editLiveGoBackClose").click(function() {
		$(".editPlayback").stop().hide();
	})

	function getVideoLivePlaybackInfoFun(uid, token, id) {
		$.ajax({
			type: "post",
			url: "/api/v3/live/getVideoLivePlaybackInfo4.do",
			async: true,
			data: {
				"uid": uid,
				"token": token,
				"id": id,
			},
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					if(res.data.openness == 1) { //加密回放
						$(".editInputTitlePwdBox").stop().show();
					} else if(res.data.openness == 0) {
						$(".editInputTitlePwdBox").stop().hide();
					}
					$(".editLiveGoBackTitle").val(res.data.topic);
					$("#editLiveBackMe").attr("src", res.data.coverUrl);
					$("#saveEditPlayback").click(function() {
						var livePlaybackTitle = $(".editLiveGoBackTitle").val();
						var livePlaybackCover = $("#editLiveBackMe").attr("src");
						var livePlaybackPsw = $(".editInputTitlePwd").val();
						if(livePlaybackPsw != "") {
							editLivePlaybackInfo(uid, token, id, livePlaybackCover, livePlaybackTitle, "", 1, livePlaybackPsw);
						} else {
							editLivePlaybackInfo(uid, token, id, livePlaybackCover, livePlaybackTitle, "", 0, "");
						}

					})
				}
			}
		})

	}

	function editLivePlaybackInfo(uid, token, id, coverUrl, topic, columnId, openness, authCode) {
		$.ajax({
			type: "post",
			url: "/api/v2/live/edit2.do",
			async: true,
			data: {
				"uid": uid,
				"token": token,
				"id": id,
				"coverUrl": coverUrl,
				"topic": topic,
				"columnId": columnId,
				"openness": openness,
				"authCode": authCode,
			},
			success: function(res) {
				if(res.code == 0) {
					layer.msg("修改成功");
					$(".editPlayback").stop().hide();
					window.location.href = "/userProfile?uid=" + uid + "&tab=2";
				}
			}
		})
	}

	function anchorInfoFun(uid) {
		$.ajax({
			type: "get",
			async: true,
			url: "/api/v1/user/getUserInfo.do",
			data: {
				"uid": uid,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					var headImgUrl = res.data.headImgUrl; //头像
					var nickName = res.data.nickName; //昵称
					var signature = res.data.signature; //签名
					//console.log(signature);
					var resume = res.data.resume; //简介

					var shareUrl = window.location.href;
					var shareTitle = nickName + "的主页";
					var shareDescription = "我是" + nickName + "，下载疯牛直播APP，跟我一起互动";
					shareFun(shareUrl, shareTitle, shareDescription, headImgUrl);
					var roleType = res.data.roleType; //终端用户角色类型{0=普通用户，1=主播，2=主播且操盘手}
					//console.log(roleType);
					if(roleType == 1) {
						$("#traderBnt").stop().hide();
						$(".traderTab1Box").stop().hide();

					} else if(roleType == 2) {
						$("#traderBnt").stop().show();
					}
					$(".fansCount").html(res.data.fansCount);
					$(".userAnchorHeader").html(nickName);
					$(".nickName").html(nickName);
					$(".anchorUid").html(uid);
					$("title").html(nickName + "_股票交易员_炒股高手-疯牛直播");
					$("#keywordsId").attr("content", nickName + "，美股操盘手，股票投资心得，美股交易员，炒股高手，炒股必读，短线黑马，疯牛直播");
					$("#descriptionId").attr("content", resume);
					// console.log(resume);
					if(headImgUrl != "") {
						$(".anchorHeadImg").attr("src", headImgUrl); //头像
						$(".anchorHeaderImg").attr("src", headImgUrl);
						$(".bannerBoxTop").css({
							'background-image': ('url("' + headImgUrl + '")'),
						})
					};
					if(res.data.positionName) {
						$(".positionName").html(res.data.positionName);
						$(".userAnchorPosition").html(res.data.positionName);

					} else {
						$(".positionName").html("认证   : 暂无认证");
						$(".userAnchorPosition").html("");
					};
					if(resume) {
						$(".anchorResume").html(resume);
						$(".userAnchorResume").html("简介：" + resume);
						var num = $(".anchorResume").html();
						if(num.length > 180) {
							$(".anchorResume").html(num.substr(0, 180) + '...');
							$(".userAnchorResume").html(num.substr(0, 180) + '...');
						};
						//简介超过两行打点，一行设计高度
						var num = $(".userAnchorResume").html();
						// console.log(num.length);
						if(num.length < 43) {
							$(".userAnchorResume").css({
								"bottom": "48px",
							})
						}

					} else {
						$(".anchorResume").html("简介   : 暂无简介");
						$(".userAnchorResume").html("简介   : 暂无简介");
					};
					if(signature != undefined && signature != null && signature != "") {
						$(".anchorSignature").html("签名    : " + signature);

					} else {
						$(".anchorSignature").html("签名   : 这个主播很懒，什么都没有留下~");
					};
					//实名认证-认证类型{0=未认证，1=实名认证，2=操盘手认证，3=机构认证}
					if(res.data.authType == 0) {
						$(".authenticationSelection").stop().hide();
					} else if(res.data.authType == 1) {
						$(".authenticationSelection").attr("src", "../images/signMe3.png");
					} else if(res.data.authType == 2) {
						$(".authenticationSelection").attr("src", "../images/signMe1.png");
					} else if(res.data.authType == 3) {
						$(".authenticationSelection").attr("src", "../images/signMe2.png");
					}
				}
			}
		});
	}

	//判断是否已经关注
	function followFun(uid, usertoken, userId) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/checkFollowing.do",
			async: true,
			data: {
				"receptorId": uid,
				"usertoken": usertoken,
				"uid": userId,
			},
			success: function(res) {
			//	console.log(res);
				if(res.data == 0) {
					$(".userAnchorFollowBtn").attr("src", "images/attention.png");
					$(".userAnchorFollowBtn").click(function() {
						addConcern(uid, userId, usertoken);
					})

				}
				if(res.data == 1) {
					$(".userAnchorFollowBtn").attr("src", "images/attentionp.png");
					$(".userAnchorFollowBtn").click(function() {
						cancelConcern(uid, userId, usertoken);
					})

				}
			}
		})
	}

	function getReceptorCount(uid) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/getReceptorCount.do",
			async: true,
			data: {
				"uid": uid,
			},
			success: function(res) {
			//	console.log(res);
				if(res.code == 0) {
					$(".followingNum").html(res.data);
				}
			}
		})
	}
	//取消关注
	function cancelConcern(uid, userId, usertoken) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/deleteFollow.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".userAnchorFollowBtn").attr("src", "images/attention.png");
					var num = Number($(".followingNum").html());
					$(".followingNum").html(num - 1);
				} else if(res.code == -1) {
					addConcern(uid, userId, usertoken);
				}
			}
		})
	}
	//增加关注
	function addConcern(uid, userId, usertoken) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/following.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".userAnchorFollowBtn").attr("src", "images/attentionp.png");
					var num = Number($(".followingNum").html());
					$(".followingNum").html(num + 1);
				} else if(res.code == -1) {
					cancelConcern(uid, userId, usertoken);
				}
			}
		})
	}

	function anchorNewsNum(uid) {
		$.ajax({
			type: "post",
			async: true,
			url: "/api/v1/dynamic/getDynamicCount.do",
			data: {
				"uid": uid,
			},
			success: function(res) {
			//	console.log(res);
				$(".anchorNewsNum").html(res.data);
				if(res.data == 0) {
					$(".liveListBoxIndexSameBoxHotNewsTab1").stop().hide();
				} else {
					$(".liveListBoxIndexSameBoxHotNewsTab1").stop().show();
				}

			}
		});
	}

	//点击视频/回放跳转
	$(document).on("click", ".videoNewsWrapBox", function(e) {
		var id = $(this).attr("videoId");
		window.location.href = "/video?" + "id=" + id;
	});
	//文章
	$(document).on("click", ".NullartileBoxWrapBox", function(e) {
		var id = $(this).attr("articleid");
		window.location.href = "/article?" + "id=" + id;
	});
	//话题
	$(document).on("click", ".topicBoxWrap", function(e) {
		var id = $(this).attr("topicid");
		window.location.href = "/topicDetails?" + "id=" + id;
	});
	//直播间
	$(document).on("click", ".liveBoxWrapB", function(e) {
		var uid = $(this).attr("liveuid");
		window.location.href = "/live?" + "uid=" + uid;
	});
	//买卖
	$(document).on("click", ".firmBugBoxBR", function(e) {
		window.location.href = "/userProfile?" + "uid=" + uid;
	});

	function getAnnouncement(uid) {
		$.ajax({
			type: "get", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v1/live/getAnnouncement.do",
			data: {
				"uid": uid,
			},
			success: function(res) {
				//	console.log(res);
				if(res.code == 0) {
					if(res.data.announcement == "") {
						$("#anchorAnnouncement").stop().hide();
					}
					var announcement = res.data.announcement;
					var announcementImgUrl = res.data.announcementImgUrl;
					if(announcement) {
						$(".anchorAnnouncementInfo").html(announcement);
						var loginnum = $(".anchorAnnouncementInfo").html().length;
						var loginnr = $(".anchorAnnouncementInfo").html();
						if(loginnum > 180) {
							$(".anchorAnnouncementInfo").html(loginnr.substring(0, 180) + "...");

						}

					};
					if(announcementImgUrl) {
						$(".announcementImgUrl").attr("src", announcementImgUrl);
					}

				} else if(res.code == -16) {
					$("#anchorAnnouncement").stop().hide();
				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	function liveListFun(uid, livePageIndex) {
		$.ajax({
			type: "get",
			url: "/api/v2/dynamic/getDynamicByTypeLiveVideo.do",
			async: true,
			data: {
				"uid": uid,
				"pageIndex": livePageIndex,
				"pageSize": 10,
				"objectType": 3,
			},
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					if(res.data == "" && livePageIndex == 1) {
						$(".liveAddMore").stop().hide();
						$(".liveNewsStatus").stop().show();
					}
					if(res.data != "" && res.data != undefined && res.data != null) {
						var liveDataLength = res.data.length;
						if(liveDataLength < 10) {
							$(".liveAddMore").stop().hide();
							$(".liveNewBEnd").stop().show();
						}
					}
					var liveDataLength = res.data.length;
					for(var M = 0; M < liveDataLength; M++) {
						var type = res.data[M].object.type;
						var liveuid = res.data[M].object.liverInfo.uid;
						if(type == 0) {
							var liveListBoxWrap = "<div id='liveBoxWrap'>" +
								"<div class='BoxWrapT'>" +
								"<img class='fl' src=" + res.data[M].object.liverInfo.headImgUrl + ">" +
								"<div class='liveBoxWrapTR fl'>" +
								"<p>" + res.data[M].object.liverInfo.nickName + "</p>" +
								"<p>" + format(new Date(res.data[M].publishTime)) + "</p>" +
								"</div>" +
								"</div>" +
								"<div class='liveBoxWrapB' liveuid=" + liveuid + ">" +
								"<div class='liveBoxWrapBL fl'>" +
								"<img class='vedioCoverUrl' src=" + res.data[M].object.coverUrl + '!220X164' + ">" +
								"<img src='images/livelive.png'/>" +
								"</div>" +
								"<div class='liveBoxWrapBR fl'>" +
								"<p>" + res.data[M].object.topic + "</p>" +
								"<p><span class='fl'>" + res.data[M].object.watchCount + "人在看</span><span class='fr goToAnchorBtn'>观看主播，与主播参与互动>></span></p>" +
								"</div>" +
								"</div>" +
								"</div>";
							$(".liveAddMore").before(liveListBoxWrap);
							$(".vedioCoverUrl").one("error", function(e) {
								$(this).attr("src", "images/vedioCoverUrl.jpg")
							});
						} else if(type == 1 || type == 2) { //回放
							var videoId = res.data[M].object.id;
							var goBackListWrap = "<div id='videoNewsWrap' videoId=" + videoId + " class='videoNewsWrapBox'>" +
								"<div class='BoxWrapT'>" +
								"<img class='fl' src=" + res.data[M].object.liverInfo.headImgUrl + ">" +
								"<div class='liveBoxWrapTR fl'>" +
								"<p>" + res.data[M].object.liverInfo.nickName + "</p>" +
								"<p>" + format(new Date(res.data[M].publishTime)) + "</p>" +
								"</div>" +
								"</div>" +
								"<div class='videoNewsBoxB'>" +
								"<div class='videoNewsBoxBL fl'>" +
								"<img src='images/livevideo.png'/>" +
								"<img class='vedioCoverUrl' src=" + res.data[M].object.coverUrl + '!220X164' + ">" +
								"<img src='images/play.png'/>" +
								"</div>" +
								"<div class='videoNewsBoxBR fl'>" +
								"<p></p>" +
								"<p>" + res.data[M].object.topic + "</p>" +
								"<p>" + res.data[M].object.watchCount + "人在看</p>" +
								"<ul class='sameBottom'>" +
								"<li class='fr sameBottomList'>分享</li>" +
								"<li class='fr sameBottomList'>" + res.data[M].commentCount + "条评论</li>" +
								"<li class='fr sameBottomList'>" + res.data[M].likeCount + "</li>" +
								" </ul>" +
								"</div>" +
								"</div>" +
								"</div>";
							$(".liveAddMore").before(goBackListWrap);
							$(".vedioCoverUrl").one("error", function(e) {
								$(this).attr("src", "images/vedioCoverUrl.jpg")
							});
						}
					}

				}
			}
		});
	}

	function getColumnListNum(uid) {
		$.ajax({
			type: "get",
			async: true,
			url: "/api/v2/column/getColumnInfoByUid.do",
			data: {
				"uid": uid,
			},
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					var getColumListnum = res.data.total;
					//console.log(getColumListnum);
					$(".anchorColumListNum").html(getColumListnum);
					if(getColumListnum == 0) {
						$(".columnAddMore").stop().hide();
						$(".ColumnEnd").stop().hide();
						$(".ColumnNewsStatus").stop().show();
					}
				}

			}
		});
	}
	//实盘信息-获取收益信息接口
	function getProfitInfoByUid(uid) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v1/fo/getProfitInfoByUid.do",
			data: {
				"uid": uid,
			},
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					if(res.data == "" || res.data == undefined || res.data == null) {
						$(".joinTime").stop().hide();
						$(".updateTime").stop().hide();
						$(".totalProfitRate").html("--%");
						$(".dailyProfitRate").html("--%");
						$(".weeklyProfitRate").html("--%");
						$(".seasonProfit").html("--%");
						$(".positionRate").html("--%");
						$(".rankWrap").html("No.--");
						$(".totalProfitRate").css({
							"color": "#fe4502"
						});
						$(".dailyProfitRate").css({
							"color": "#fe4502"
						});
						$(".rankWrap").css({
							"color": "#fe4502"
						});

					} else {
						//console.log(res);
						var joinTime = res.data.joinTime + "";
						var joinTime1 = joinTime.substr(0, 4) + "年" + joinTime.substr(4, 2) + "月" + joinTime.substr(6, 2) + "日";
						$(".joinTime").html("（" + joinTime1 + "加入)");
						$(".totalProfitRate").html(Number(res.data.totalProfitRate).toFixed(2) + "%");
						var updateTime = format(new Date(res.data.updateTime));
						$(".updateTime").html("更新时间：" + updateTime);
						$(".dailyProfitRate").html(Number(res.data.dailyProfitRate).toFixed(2) + "%");
						$(".positionRate").html(Number(res.data.positionRate).toFixed(2) + "%");
						$(".weeklyProfitRate").html(res.data.weeklyProfitRate + "%");
						$(".seasonProfit").html(res.data.seasonProfit + "%");
						$(".monthlyProfitRate").html(res.data.monthlyProfitRate + "%");
						$(".rank").html(res.data.ranking);
						if(res.data.totalProfitRate < 0) {
							$(".totalProfitRate").css({
								"color": "#24c670"
							})
						} else {
							$(".totalProfitRate").css({
								"color": "#fe4502"
							})
						}

						if(res.data.dailyProfitRate < 0) {
							$(".dailyProfitRate").css({
								"color": "#24c670"
							})
						} else {
							$(".dailyProfitRate").css({
								"color": "#fe4502"
							})
						}

						if(res.data.weeklyProfitRate < 0) {
							$(".weeklyProfitRate").css({
								"color": "#24c670"
							})
						} else {
							$(".weeklyProfitRate").css({
								"color": "#fe4502"
							})
						}

						if(res.data.monthlyProfitRate < 0) {
							$(".monthlyProfitRate").css({
								"color": "#24c670"
							})
						} else {
							$(".monthlyProfitRate").css({
								"color": "#fe4502"
							})
						}
					}

				}
			}
		});
	}
	//当前持仓-不收费
//	getPositionsByUid(uid);
//	function getPositionsByUid(uid) {
//		$.ajax({
//			type: "get",
//			async: true,
//			dataType: "json",
//			url: "/api/v1/fo/getPositionsByUid.do",
//			data: {
//				"uid": uid,
//			},
//			success: function(res) {
//				// console.log(res);
//				if(res.code == 0) {
//					//					if(res.data.positions) {
//					// 						console.log(res.data.positions.length);
//					if(res.data.positions.length == 0) {
//						$(".getPositionListNull").stop().show();
//						$(".nowTraderBox").stop().hide();
//					}
//					var getPositionList = res.data.positions.length;
//					$(".totalPositionRate").html("(仓位：" + res.data.totalPositionRate + "%)");
//					//					}
//					//					} else {
//					//						$(".getPositionListNull").stop().show();
//					//						$(".nowTraderBox").stop().hide();
//					//					}
//					$(res.data.positions).each(function(i, B) {
//						//console.log(B);
//						var getPositionListBox = "<tr class='getPositionListBox'>" +
//							"<td class='boxOne'><span>" + B.stockName + "</span><span>(" + B.stockCode + ")</span></td>" +
//							"<td class='boxTwo'>" + (Number(B.marketValue)).toFixed(2) + "</td>" +
//							"<td class='boxThree'>" + (Number(B.cost)).toFixed(2) + "</td>" +
//							"<td class='boxFour'>" + (Number(B.positionRate)).toFixed(2) + "%</td>" +
//							"<td class='boxFive profitRate' id=" + B.id + ">" + (Number(B.profitRate)).toFixed(2) + "%</td>" +
//							"</tr>";
//						$("#nowTraderBox").append(getPositionListBox);
//						if(B.profitRate < 0) {
//							$("#" + B.id).css({
//								"color": "#24c670"
//							})
//						} else {
//							$("#" + B.id).css({
//								"color": "#fe4502"
//							})
//						}
//					})
//
//				} else if(res.code == -16) {
//					$("#traderOwn").stop().hide();
//					$(".traderStatus").stop().show();
//				}
//			}
//		});
//	}

    var getPositionIndex=1;
   //当前持仓-收费
	function getPositionsByUid(uid,userUid,pageIndex,pageSize,token) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v4/fo/getPosition.do",
			data: {
				"traderId": uid,
				"uid": userUid,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					var isSubscribe=res.data.isSubscribe;
					if(isSubscribe==true){
						$(".takeFirmBtn").stop().hide();
						$(".takeFirmIntro").stop().hide();
					}else{
						if(userUid==null||userUid==""||userUid==undefined){
							
						}else{//登录后没有定订阅实盘
							
						}
					}
					if(res.data.positions.length == 0) {
						$(".getPositionListNull").stop().show();
						$(".nowTraderBox").stop().hide();
					}
					var getPositionList = res.data.positions.length;
					if(getPositionList==10){
						getPositionIndex++;
						getPositionsByUid(uid,userUid,getPositionIndex,pageSize,token);
					}
					$(".totalPositionRate").html("(仓位：" + res.data.totalPositionRate + "%)");
					$(res.data.positions).each(function(i, B) {
						//console.log(B);
						var getPositionListBox = "<tr class='getPositionListBox'>" +
							"<td class='boxOne'><span>" + B.stockName + "</span><span>(" + B.stockCode + ")</span></td>" +
							"<td class='boxTwo'>" + B.marketValue + "</td>" +
							"<td class='boxThree'>" + B.cost + "</td>" +
							"<td class='boxFour'>" + (Number(B.positionRate)).toFixed(2) + "%</td>" +
							"<td class='boxFive profitRate' id=" + B.id + ">" + (Number(B.profitRate)).toFixed(2) + "%</td>" +
							"</tr>";
						$("#nowTraderBox").append(getPositionListBox);
						if(B.profitRate < 0) {
							$("#" + B.id).css({
								"color": "#24c670"
							})
						} else {
							$("#" + B.id).css({
								"color": "#fe4502"
							})
						}
					})

				} else if(res.code == -16) {
					$("#traderOwn").stop().hide();
					$(".traderStatus").stop().show();
				}
			}
		});
	}
	/*获取订阅收费详情*/
	function getSubscribeCharge(userUid,uid,objectType,token) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/subscribe/getSubscribeCharge.do",
			data: {
				"objectId": uid,
				"objectType": objectType,
			},
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					var subscribePay=res.data.price;
					$(".payMoneyBoxWrap").stop().show();
					payFun(userUid, token, subscribePay,uid);
					$(".columnMoneyAlert").html(res.data.price+"牛币");
					if(res.data.type==1){//收费类型（1=周期收费，2=永久收费）
						$(".columnDayAlert").html(res.data.dayNumber+"天");
					}else{
						$(".columnDayAlert").html("全期");
					}
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	
	//获取用户的余额数
	function payFun(userId, usertoken, subscribePay,uid) {
		/*充值接口*/
		$.ajax({
			type: "POST",
			async: true,
			dataType: "json",
			url: "/api/v1/account/selectByWhere.do",
			data: {
				"uid": userId,
				"coinType": "RECHARGE_COIN",
				"token": usertoken,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".balanceCoin").html(res.data[0].coinNumber + "牛币");
					var coinNumberUserid = res.data[0].coinNumber;
					//console.log(subscribePay);
					//console.log(coinNumberUserid);
					if(subscribePay > coinNumberUserid) {
						$(".payColumnUpBtn").html("余额不足，去充值");
						$(".payColumnUpBtn").click(function() {
							$(".payMoneyBoxWrap").stop().hide();
							$("#n_money").stop().show();
							$("#exceptWrap").stop().show()
						});
						wxUnifiedOrder(userId,usertoken);
					} else {
						$(".payColumnUpBtn").html("立即支付");
						$(".payColumnUpBtn").click(function(){
							insertFirmFun(userId,uid,3,usertoken);
							$(".payMoneyBoxWrap").stop().hide();
						});
						
					}
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		});
	}
	function wxUnifiedOrder(userId,usertoken) {
		$(".qitaMoney").focus(function() {
			$(this).removeAttr("placeholder");
			$(".moneyAlert").stop().show()
		});
		$(".qitaMoney").blur(function() {
			$(this).attr("placeholder", "其他金额");
			$(".moneyAlert").stop().hide()
		});
		$(".payBtn").click(function() {
			var totalFee = "";
			if($(".qitaMoney").val() != "") {
				totalFee = parseInt($(".qitaMoney").val());
				//console.log(totalFee)
			} else {
				totalFee = parseInt($(".money_list").find(".click_effect").children().text())
			}
			$(".weChatPayNum").html(totalFee);
			$.ajax({
				type: "POST",
				async: true,
				dataType: "json",
				url: "/api/v1/order/wxUnifiedOrder.do",
				data: {
					"uid": userId,
					"totalFee": totalFee,
					"tradeType": "NATIVE",
					"token": usertoken,
				},
				success: function(res) {
					if(res.code == 0) {
						$("#n_money").fadeOut(1);
						$("#exceptWrap").fadeIn(1);
						$(".weChatCodeWrap").fadeIn(1);
						var codeUrl = res.data.codeUrl;
						var outTradeNo = res.data.outTradeNo;
						//console.log(outTradeNo);
						jQuery("#weChatPayCode").qrcode({
							render: "canvas",
							foreground: "#000",
							background: "#FFF",
							width: 180,
							height: 180,
							text: codeUrl,
							correctLevel: 2
						});
						intervalTime = setInterval(function() {
							$.ajax({
								type: "POST",
								async: true,
								dataType: "json",
								url: "/api/v1/order/wxFrontNotify.do",
								data: {
									"uid": userId,
									"outTradeNo": outTradeNo,
									"token": usertoken,
								},
								success: function(res) {
									//	console.log(res);
									if(res.code == 0) {
										$(".weChatCodeWrap").stop().hide();
										$(".weChatPaySuccess").stop().show();

									}
								},
								error: function(XMLHttpRequest, textStatus, errorThrown) {
									console.log(XMLHttpRequest.status);
									console.log(XMLHttpRequest.readyState);
									console.log(textStatus)
								}
							})
						}, 3000)
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				}
			})
		})
	}
	
	
	
	//关闭框X
	$(".payMoneyBoxT").click(function(){
		$(".payMoneyBoxWrap").stop().hide();
	})
	//充值弹框
	$(".money_listinfo").click(function() {
		$(this).addClass("click_effect").siblings().removeClass("click_effect")
	});
	/*关闭框*/
	$(".alertClose").click(function() {
		$("#n_money").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".weChatClose").click(function() {
		$(".weChatCodeWrap").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".qitaMoney").val("");
		$("#weChatPayCode").html("");
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".weChatSuccessClose").click(function() {
		$(".weChatPaySuccess").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".qitaMoney").val("");
		$("#weChatPayCode").html("");
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".closePay").click(function(){
		$(".payMoney").stop().hide();
	})
	
	
	/*订阅实盘*/
	function insertFirmFun(userUid,uid,firmType,token) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/subscribe/insert.do",
			data: {
				"uid": userUid,
				"objectId": uid,
				"type": firmType,
				"token": token,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					layer.msg("订阅成功，刷新页面后可见");
				}else if(res.code == -903){
					layer.msg("恭喜您，实盘已经订阅！");
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	
	
	
	
	
	//交易动态——未收费
//	getTransferRecords(uid, 1, 10);
//	function getTransferRecords(uid, pageIndex, pageSize) {
//		$.ajax({
//			type: "get",
//			async: true,
//			dataType: "json",
//			url: "/api/v1/fo/getTransferRecordsByUid.do",
//			data: {
//				"uid": uid,
//				"pageIndex": pageIndex,
//				"pageSize": pageSize,
//			},
//			success: function(res) {
//				console.log(res);
//				if(res.code == 0) {
//					$(res.data).each(function(i, A) {
//						var delegateType = A.transactionType; //委托类别，1=买入，2=卖出
//						var date = A.date + "";
//						var date1 = date.substr(0, 4) + "." + date.substr(4, 2) + "." + date.substr(6, 2);
//						var minuteTime = A.time;
//						var minuteTimeLen = minuteTime.length;
//						if(minuteTimeLen == 7) {
//							minuteTime = "0" + minuteTime;
//						}
//						var minuteTime1 = minuteTime.substr(0, 5);
//						if(delegateType == 1) {
//							var transactionBoxTop = "<div class='transactionBoxTop'>" +
//								"<p class='transactionTime'>" + date1 + "</p>" +
//								"<div class='transactionBoxInfO'>" +
//								"<p>" + minuteTime1 + "</p>" +
//								"<p class='bug'>买</p>" +
//								"<p><span>" + A.stockName + "</span><span>(" + A.stockCode + ")</span></p>" +
//								"<p><span>仓位：</span><span>" + (Number(A.previousPositionRate)).toFixed(2) + "%</span> -> <span>" + (Number(A.currentPositionRate)).toFixed(2) + "%</span></p>" +
//								"<p><span>成交价：</span><span class='price'>￥" + (Number(A.price)).toFixed(2) + "</span></p>" +
//								"</div>" +
//								"</div>"
//							$(".transactionBoxWrap").append(transactionBoxTop);
//						} else if(delegateType == -1) {
//							var transactionBoxTop = "<div class='transactionBoxTop'>" +
//								"<p class='transactionTime'>" + date1 + "</p>" +
//								"<div class='transactionBoxInfO'>" +
//								"<p>" + minuteTime1 + "</p>" +
//								"<p class='smell'>卖</p>" +
//								"<p><span>" + A.stockName + "</span><span>(" + A.stockCode + ")</span></p>" +
//								"<p><span>仓位：</span><span>" + (Number(A.previousPositionRate)).toFixed(2) + "%</span> -> <span>" + (Number(A.currentPositionRate)).toFixed(2) + "%</span></p>" +
//								"<p><span>成交价：</span><span class='price'>￥" + (Number(A.price)).toFixed(2) + "</span></p>" +
//								"</div>" +
//								"</div>"
//							$(".transactionBoxWrap").append(transactionBoxTop);
//						}
//
//					});
//					var timeTitleLen = $(".transactionTime").length;
//					var timeTitle = document.getElementsByClassName("transactionTime");
//					//console.log(timeTitleLen);
//					var timeTitleInnerLast = timeTitle[timeTitleLen - 1].innerHTML;
//					//console.log(timeTitleInnerLast);
//
//					for(var q = 0; q < timeTitleLen; q++) {
//						var timeTitleInner = timeTitle[q].innerHTML;
//						if(timeTitle[q + 1] != undefined && timeTitle[q + 1] != null && timeTitle[q + 1] != "") {
//							var timeTitleInnerNext = timeTitle[q + 1].innerHTML;
//							if(timeTitleInnerNext == timeTitleInner) {
//								timeTitle[q + 1].style.display = "none";
//							}
//						}
//
//					}
//				}
//			},
//			error: function(XMLHttpRequest, textStatus, errorThrown) {
//				console.log(XMLHttpRequest.status);
//				console.log(XMLHttpRequest.readyState);
//				console.log(textStatus);
//			},
//		});
//	}
/*交易动态收费*/
	function getTransferRecords(uid,userId, pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v4/fo/getTransferRecords.do",
			data: {
				"traderId":uid,
				"uid": userId,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					$(res.data.transactionList).each(function(i, A) {
						var delegateType = A.delegateType; //委托类别，1=买入，2=卖出
						var date = A.date + "";
						var date1 = date.substr(0, 4) + "." + date.substr(4, 2) + "." + date.substr(6, 2);
						var minuteTime = A.time;
						var minuteTimeLen = minuteTime.length;
						if(minuteTimeLen == 7) {
							minuteTime = "0" + minuteTime;
						}
						var minuteTime1 = minuteTime.substr(0, 5);
//						console.log(A);
						if(delegateType == 1) {
							var transactionBoxTop = "<div class='transactionBoxTop'>" +
								"<p class='transactionTime'>" + date1 + "</p>" +
								"<div class='transactionBoxInfO'>" +
								"<p>" + minuteTime1 + "</p>" +
								"<p class='bug'>买</p>" +
								"<p><span>" + A.stockName + "</span><span>(" + A.stockCode + ")</span></p>" +
								"<p><span>仓位：</span><span>" + (Number(A.previousPositionRate)).toFixed(2) + "%</span> -> <span>" + (Number(A.currentPositionRate)).toFixed(2) + "%</span></p>" +
								"<p><span>成交价：</span><span class='price'>￥" +fixedNum(A.price)+ "</span></p>" +
								"</div>" +
								"</div>"
							$(".transactionBoxWrap").append(transactionBoxTop);
						} else if(delegateType == 2) {
							var transactionBoxTop = "<div class='transactionBoxTop'>" +
								"<p class='transactionTime'>" + date1 + "</p>" +
								"<div class='transactionBoxInfO'>" +
								"<p>" + minuteTime1 + "</p>" +
								"<p class='smell'>卖</p>" +
								"<p><span>" + A.stockName + "</span><span>(" + A.stockCode + ")</span></p>" +
								"<p><span>仓位：</span><span>" + (Number(A.previousPositionRate)).toFixed(2) + "%</span> -> <span>" + (Number(A.currentPositionRate)).toFixed(2) + "%</span></p>" +
								"<p><span>成交价：</span><span class='price'>￥" + fixedNum(A.price) + "</span></p>" +
								"</div>" +
								"</div>"
							$(".transactionBoxWrap").append(transactionBoxTop);
						}

					});
					var timeTitleLen = $(".transactionTime").length;
					var timeTitle = document.getElementsByClassName("transactionTime");
					//console.log(timeTitleLen);
					var timeTitleInnerLast = timeTitle[timeTitleLen - 1].innerHTML;
					//console.log(timeTitleInnerLast);

					for(var q = 0; q < timeTitleLen; q++) {
						var timeTitleInner = timeTitle[q].innerHTML;
						if(timeTitle[q + 1] != undefined && timeTitle[q + 1] != null && timeTitle[q + 1] != "") {
							var timeTitleInnerNext = timeTitle[q + 1].innerHTML;
							if(timeTitleInnerNext == timeTitleInner) {
								timeTitle[q + 1].style.display = "none";
							}
						}

					}
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	//回到头部
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});

	//交易分页
	var tradePageIndex = 0;

	function tradeWholeNumberFun(tradeWholeNumber) {
		$("#Pagination").pagination(tradeWholeNumber, {
			callback: PageCallback,
			prev_text: "上一页",
			next_text: "下一页 ",
			items_per_page: 10,
			current_page: tradePageIndex
		});

		function PageCallback(tradePageIndex, jq) {
			InitData(tradePageIndex)
		}

		function InitData(tradePageIndex) {
			$(".transactionBoxWrap").empty();
			tradePageIndex = tradePageIndex + 1;
			getTransferRecords(uid, uidLogin,tradePageIndex, 10);
			//getTransferRecords(uid,tradePageIndex, 10);

		}
		$(".allPage").html(tradeWholeNumber / 10);
	};

	//固定右边的个人信息
	$(window).scroll(function() {
		var fixedRightTop = $(this).scrollTop();
		//console.log(fixedRightTop);
		if(fixedRightTop >= 2000) {
			$("#anchorInformation").css({
				"position": "fixed",
				"top": "65px",
				/*"width": "338px",*/
			});
			$(".commentWrapBoxR").css({
				"margin-bottom": "200px",
			});
		} else {
			$("#anchorInformation").css({
				"position": "",
				"margin-left": 0,
			})
		}
	});

	//页面跳转
	function browserRedirect() {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		var bIsMidp = sUserAgent.match(/midp/i) == "midp";
		var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		var bIsAndroid = sUserAgent.match(/android/i) == "android";
		var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
		if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
			window.location.href = "https://www.fntv8.com/m/v5.0/userprofile?uid=" + uid + "";
		}
	}
	browserRedirect();

	/*分享*/
	function shareFun(url, title, description, pic) {
		mobShare.config({
			debug: true, // 开启调试，将在浏览器的控制台输出调试信息
			appkey: '1d102ac0241c0', // appkey
			params: {
				url: url, // 分享链接
				title: title, // 分享标题
				description: description, // 分享内容
				pic: pic, // 分享图片，使用逗号,隔开
				reason: '', //自定义评论内容，只应用与QQ,QZone与朋友网
			},
			callback: function(plat, params) {
				//console.log("分享成功了")
			}

		});

	};

	/*直播列表接口*/
	//tab=1在主页显示 ,tab=4在直播 ，tab=6VIP服务，roleType=0普通用户和游客，roleType=1直播
	function getUserLiveRoomList(visitorUid, liverUid, type, pageIndex, pageSize, roleType, tab) {
		$.ajax({
			type: "get",
			async: true, //是否异步
			url: "/api/v3/live/getUserLiveRoomList.do",
			dataType: "json",
			data: {
				"visitorUid": visitorUid,
				"liverUid": liverUid,
				"type": type, //类型（0=主直播间，1=VIP直播间），不传获取所有
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				if(res.code == 0) {
					if(tab == 1) {
//						console.log(res);
						$(res.data.list).each(function(m, w) {
							var indexTabType = w.type;
						//	console.log(indexTabType);
							var subscribeCycle = w.subscribeCycle;
							var coverUrl = w.coverUrl;
							var indextab1Id = w.roomId + "indexTab1";
							var subscribePayId = w.roomId + "subscribePayTab1";
							var liveListBoxIndexRoomInfoTImgLogoId=w.roomId+"subscribePayLogo1";
							var indextabOneLiveList =
								'<li class="liveListBoxIndexRoomInfo fl" id=' + indextab1Id + ' roomId=' + w.roomId + ' uid=' + w.liverInfo.uid + '>' +
								'<div class="liveListBoxIndexRoomInfoT">' +
								'<img class="liveListBoxIndexRoomInfoTImg" src="' + w.coverUrl + '!120X160" />' +
								'<img class="liveListBoxIndexRoomInfoTImgLogo" id='+liveListBoxIndexRoomInfoTImgLogoId+' src="images/charge.png" />' +
								'</div>' +
								'<div class="liveListBoxIndexRoomInfoB">' +
								'<p>' + w.roomName + '</p>' +
								'<p class="liveTabOneNull" id='+subscribePayId+'><span>' + w.subscribePay + '牛币</span>/<span>' + w.subscribeCycle + '天</span></p>' +
								'</div>' +
								'</li>';
							$(".indextabOneLiveList").append(indextabOneLiveList);
//							if(!subscribeCycle) {
//								$(".liveTabOneNull").stop().hide();
//								$(".liveListBoxIndexRoomInfoTImgLogo").stop().hide();
//							}
							$(".liveListBoxIndexRoomInfoTImg").one("error", function(e) {
								$(this).attr("src", "images/userzjNull.jpg");
							});
							if(indexTabType == 0) {
								$("#"+subscribePayId).remove();
								$("#"+liveListBoxIndexRoomInfoTImgLogoId).remove();
								$(document).on("click", "#" + indextab1Id, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomId");
									window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
								});
							} else if(indexTabType == 1) {
								if(!subscribeCycle) {
								   $("#"+subscribePayId).html("0牛币/0天");
							    }
								$(document).on("click", "#" + indextab1Id, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomId");
									window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
								});
							}

						})

					} else if(tab == 4) {
						if(type == 0) { //0=主直播间，1=VIP直播间
							//console.log(res);
							$(res.data.list).each(function(m, Q) {
								var roomEditId = Q.roomId;
								var roomEditIdStart = Q.roomId + "live";
								var liveTab5Id = Q.roomId + "livetab5";
								var liveTab5IdLatestcontent = Q.roomId + "liveTab5IdLatestcontent";
								var liveRoomBox =
									'<div class="liveBoxSameBox_1" id=' + liveTab5Id + ' roomId=' + Q.roomId + ' uid=' + Q.liverInfo.uid + ' >' +
//									'<img class="fl liveSameCover_1" src="' + Q.coverUrl + '!120X160" />' +
                                    '<div class="liveBoxSameBox_1CTL fl">'+
							           ' <img class="fl liveSameCover_1 liveSameCover_1Live" src="' + Q.coverUrl + '!120X160"/>'+
						                '<p class="liveSameCover_1LiveTitle">'+ Q.roomName +'</p>'+
						            '</div>'+
									'<div class="liveBoxSameBox_1C fl">' +
									'<div class="liveBoxSameBox_1CT">' +
									'<span class="fl liveBoxSameBoxTitle">' + Q.topic + '</span>' +
									'<div class="fr deleteBoxWrap">' +
									//											'<img src=""/>'+
									//											'<div class="deleteInfoWrap deleteInfoWrapLiveRoom">'+
									'<p class="fl editVipLiveRoomEnterBtn" roomId=' + Q.roomId + ' uid=' + Q.liverInfo.uid + ' id=' + Q.roomId + '>编辑</p>' +
									//											'</div>'+
									'</div>' +
									'</div>' +
									'<p class="liveBoxSameBoxSmallTitle" id='+liveTab5IdLatestcontent+'>' + Q.latest.content + '</p>' +
									'<p class="liveBoxSameBox_1CTBottom">' +
									'<span class="fl"><span class="liveJionTime_1">' + Q.partakes + '人参与</span>|<span class="livePayMoneyTime_1">' + Q.subscribers + '人订阅</span></span>' +
									'<span class="fl liveUpdateTime_1">' + formatTwo(new Date(Q.latest.time)) + ' 更新</span>' +
									'<span class="fr startLiveBtn" roomId=' + Q.roomId + ' uid=' + Q.liverInfo.uid + ' id=' + roomEditIdStart + '>开启直播</span>' +
									'</p>' +
									'</div>' +
									'</div>';
								$(".zLiveBox").append(liveRoomBox);
								if(Q.topic == "") {
									$(".updateTitle").html("主题：主播很懒，还没有设置主题哦。");
								};
								$(".liveSameCover_1").one("error", function(e) {
									$(this).attr("src", "images/userzjNull.jpg")
								});
								if(Q.latest.time == undefined) {
									$(".liveUpdateTime_1").stop().hide();
								};
								
								if(Q.latest.content==null||Q.latest.content ==undefined||Q.latest.content==""){
									$("#"+liveTab5IdLatestcontent).html("暂无更新内容");
								}
								//主播角色才可以开启直播和编辑
								if(roleType == 1) {
									$(".deleteBoxWrap").stop().show();
									$(".startLiveBtn").stop().show();
								}
								//点击编辑进行跳转
								$(document).on("click", "#" + roomEditId, function(event) {
									event.stopPropagation();
									//获得直播详情——修改信息——提交
									var editVipRoomId = $(this).attr("roomId");
									$(".editLiveListBox").stop().hide();
									$(".editVipRoomWrapBox").stop().show();
									//获得直播间详情信息
									getLiveRoomInfoVIP(editVipRoomId); //添加编辑
									getRoomAnnouncementList(editVipRoomId, 1, 5);
								});
								//开启直播
								$(document).on("click", "#" + roomEditIdStart, function(event) {
									event.stopPropagation();
									var roomid = $(this).attr("roomId");
									$(".createVideo").stop().show();
									uploadVideoImg(uidLogin, tokenLogin);
									getLiveMessage(roomid, uidLogin, tokenLogin);
								});
								$(document).on("click", "#" + liveTab5Id, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomId");
									window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
								});

							})
						} else if(type == 1) {
							//console.log(res);
							var vipLiveListLen = res.data.list.length;
							//console.log(vipLiveListLen);
							if(vipLiveListLen == 0 && pageIndex == 1) {
								$(".vipLiveBoxWrap").stop().hide();
							}
							if(vipLiveListLen == pageSize) {
								pageIndex++;
								getUserLiveRoomList('', uid, 1, pageIndex, 5, roleType, 4); //VIP直播间列表
							}
							$(res.data.list).each(function(m, Q) {
								//console.log(Q);
								var roomEditVipIdStart = Q.roomId + "livevip";
								var liveVipTab5Id = Q.roomId + "livetab5";
								var subscribePayId=Q.roomId + "livetab5subscribePayId";
								var subscribeCycleId=Q.roomId + "livetab5subscribeCycleId";
								//console.log(Q);
								//								if(Q.subscribePay) {
								var roomEditId = Q.roomId;
								var vipLiveBox =
									'<div class="liveBoxSameBox_1 liveBoxVipBox_1" id=' + liveVipTab5Id + ' roomId=' + Q.roomId + ' uid=' + Q.liverInfo.uid + '>' +
									'<img class="fl liveSameCover_1" src="' + Q.coverUrl + '!120X160"/>' +
									'<div class="liveBoxSameBox_1C fl">' +
									'<div class="liveBoxSameBox_1CT">' +
									'<span class="fl liveBoxSameBoxTitle">' + Q.roomName + '</span>' +
									'<div class="fr deleteBoxWrap">' +
									//												'<img src=""/>'+
									//												'<div class="deleteInfoWrap">'+
									'<p class="fl editVipLiveRoomEnterBtn" roomId=' + Q.roomId + ' uid=' + Q.liverInfo.uid + ' id=' + Q.roomId + '>编辑</p>' +
									//													'<p>删除</p>'+
									//												'</div>'+
									'</div>' +
									'</div>' +
									'<p class="liveBoxSameBoxSmallTitle">' + Q.topic + '</p>' +
									'<p class="liveBoxSameBox_1CTBottom">' +
									'<span class="fl"><span class="liveJionTime_1 liveJionTime_2" id='+subscribePayId+'>' + Q.subscribePay + '牛币/' + Q.subscribeCycle + '天</span>|<span class="livePayMoneyTime_1">' + Q.subscribers + '人订阅</span></span>' +
									'<span class="fl liveUpdateTime_1">' + formatTwo(new Date(Q.latest.time)) + ' 更新</span>' +
									'<span class="fr startLiveBtn" roomId=' + Q.roomId + ' id=' + roomEditVipIdStart + '>开启直播</span>' +
									'</p>' +
									'</div>' +
									'</div>'
								$(".vipLiveBoxWrap").append(vipLiveBox);
								//								}
								$(".liveSameCover_1").one("error", function(e) {
									$(this).attr("src", "images/userzjNull.jpg");
								});
								if(Q.latest.time == undefined) {
									$(".liveUpdateTime_1").stop().hide();
								};
								if(Q.subscribePay==undefined||Q.subscribePay==null||Q.subscribePay==""){
									$("#"+subscribePayId).html("0牛币/0天");
								}
								//主播角色才可以开启直播和编辑
								if(roleType == 1) {
									$(".deleteBoxWrap").stop().show();
									$(".startLiveBtn").stop().show();
								}
								//点击编辑进行跳转
								$(document).on("click", "#" + roomEditId, function(event) {
									event.stopPropagation();
									//获得直播详情——修改信息——提交
									var editVipRoomId = $(this).attr("roomId");
									$(".editLiveListBox").stop().hide();
									$(".editVipRoomWrapBox").stop().show();
									//获得直播间详情信息
									getLiveRoomInfoVIP(editVipRoomId); //添加编辑
									getRoomAnnouncementList(editVipRoomId, 1, 5);
								});
								$(document).on("click", "#" + roomEditVipIdStart, function(event) {
									event.stopPropagation();
									var roomid = $(this).attr("roomId");
									$(".createVideo").stop().show();
									uploadVideoImg(uidLogin, tokenLogin);
									getLiveMessage(roomid, uidLogin, tokenLogin);
								});

								$(document).on("click", "#" + liveVipTab5Id, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomId");
									window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
								});
							})
						}
					} else if(tab == 5 && type == 1) {
						//console.log(res);
						var vipLiveListLen = res.data.list.length;
						// console.log(vipLiveListLen);
						if(vipLiveListLen == 0 && pageIndex == 1) {
							$(".vipBoxWrapLiveTab6").stop().hide();
						} else {
							$(".vipTabFiveBoxNull").stop().hide();
							if(vipLiveListLen == pageSize) {
								tabPageIndex++;
								getUserLiveRoomList('', uid, 1, tabPageIndex, 5, 0, 5); //VIP直播间列表
							}
							$(res.data.list).each(function(m, w) {
								var subscribeCycle = w.subscribeCycle;
								var coverUrl = w.coverUrl;
								var subscribePayId = w.roomId + "subscribePay";
								var subscribePayIdFather = w.roomId + "subscribePayIdFather";
								var liveVipTab6Id = w.roomId + "livetab6"
								var indextabOneLiveList =
									'<li class="liveListBoxIndexRoomInfo fl" id=' + liveVipTab6Id + ' roomId=' + w.roomId + ' uid=' + w.liverInfo.uid + '>' +
									'<div class="liveListBoxIndexRoomInfoT">' +
									'<img class="liveListBoxIndexRoomInfoTImg" src="' + w.coverUrl + '!120X160" />' +
									'<img class="liveListBoxIndexLogo" src="images/charge.png" />' +
									'</div>' +
									'<div class="liveListBoxIndexRoomInfoB">' +
									'<p>' + w.roomName + '</p>' +
									'<p class="liveTabOneNull1" id='+subscribePayIdFather+'><span id=' + subscribePayId + '>' + w.subscribePay + '牛币</span>/<span>' + w.subscribeCycle + '天</span></p>' +
									'</div>' +
									'</li>';
								$(".indextabFiveLiveList").append(indextabOneLiveList);
								$(".liveListBoxIndexRoomInfoTImg").one("error", function(e) {
									$(this).attr("src", "images/userzjNull.jpg");
								});
								if(!subscribeCycle) {
									$("#"+subscribePayIdFather).html("0牛币/0天");
								};

								$(document).on("click", "#" + liveVipTab6Id, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomId");
									window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
								});
							});
						}

					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	/*创建VIP直播间*/
	function createVipRoom(token, uid) {
		var name = $(".liveRoomNameVip").val();
		var topic = $(".liveRoomTitleVip").val();
		var description = $(".descriptionVip").val();
		//console.log(description);
		var descriptionImgUrl = $(".descriptionImgUrlVip").attr("src");
		var coverUrl = $(".liveVipRoomCover").attr("src");
		var subscribePay = $(".niubiBoxVip").val();
		var subscribeCycle = $(".dayBoxVip").val();
		var reg = /^\d{1,5}$/;
		var reg1 = /^\d{1,3}$/;
		if(name == "") {
			$(".nameVipError").stop().show();
			return false;
		} else if(topic == "") {
			$(".topicVipError").stop().show();
			return false;
		} else if(description == "") {
			$(".descriptionVipError").stop().show();
			return false;
		} else if(descriptionImgUrl == "") {
			$(".descriptionVipError").stop().show();
			return false;
		} else if(subscribePay == "") {
			$(".subscribePayVipError").stop().show();
			return false;
		} else if(subscribeCycle == "") {
			$(".subscribePayVipError").stop().show();
			return false;
		} else if(!reg.test(subscribePay)) {
			$(".subscribePayVipError").stop().show();
			return false;
		} else if(!reg1.test(subscribeCycle)) {
			$(".subscribePayVipError").stop().show();
			return false;

		} else {
			createVipRoomStepTwo(token, uid, name, topic, description, descriptionImgUrl, coverUrl, subscribePay, subscribeCycle);
		}

	}

	//创建VIP——调接口
	function createVipRoomStepTwo(token, uid, name, topic, description, descriptionImgUrl, coverUrl, subscribePay, subscribeCycle) {
		$.ajax({
			type: "post", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v3/live/createVipRoom.do",
			data: {
				"token": token,
				"uid": uid,
				"name": name,
				"topic": topic,
				"description": description,
				"descriptionImgUrl": descriptionImgUrl,
				"coverUrl": coverUrl,
				"subscribeType": 1, //订阅类型0-免费，1-周期，2-永久
				"subscribePay": subscribePay,
				"subscribeCycle": subscribeCycle,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					layer.msg('VIP直播间创建成功');
					window.location.href = "/userProfile?uid=" + uid + "&tab=5";
					//					var roomid = res.data;
					//					$(".createVideo").stop().show();
					//					uploadVideoImg(uid, token);
					//					getLiveMessage(roomid, uid, token);
				} else if(res.code == -19) {
					layer.msg('VIP直播间过多，没有权限');
				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});

	}
	//获得input获得焦点，必填提示消失
	$(".liveRoomFromInput").focus(function() {
		$(".liveRoomFromError").stop().hide();
	})

	//获得直播间的详情
	function getLiveRoomInfoVIP(roomId) {
		$.ajax({
			type: "post", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v3/live/getLiveRoomInfo.do",
			data: {
				"roomId": roomId,
			},
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					var type = res.data.type; //type	int	直播间类型，0=主直播间（免费），1=VIP直播间
					if(type == 1) {
						$(".editNiubiBoxVip").val(res.data.subscribePay);
						$(".editDayBoxVip").val(res.data.subscribeCycle);
						$(".editliveRoomNameVip").val(res.data.roomName);
						$(".editliveRoomTitleVip").val(res.data.topic);
						$(".editDescriptionVip").val(res.data.description);
						$(".editDescriptionImgUrlVip").attr("src", res.data.descriptionImgUrl);
						$(".editLiveVipRoomCover").attr("src", res.data.coverUrl);
						//更新VIP直播间的信息
						$(".editStratVipLiveBoxBtn").click(function() {
							//if(tokenLogin!=undefined&&uidLogin!=undefined){
							updateRoomInfoVip(tokenLogin, uidLogin, roomId, 1);
							//}
						});
					} else if(type == 0) {
						$(".editBigTitle").html("编辑直播间");
						$(".liveRoomFromLeftTQ").html("直播间介绍");
						$(".vipPayMoneyDif").stop().hide();
						$(".editNiubiBoxVip").val(res.data.subscribePay);
						$(".editDayBoxVip").val(res.data.subscribeCycle);
						$(".editliveRoomNameVip").val(res.data.roomName);
						$(".editliveRoomTitleVip").val(res.data.topic);
						$(".editDescriptionVip").val(res.data.description);
						$(".editDescriptionImgUrlVip").attr("src", res.data.descriptionImgUrl);
						$(".editLiveVipRoomCover").attr("src", res.data.coverUrl);
						//更新VIP直播间的信息
						$(".editStratVipLiveBoxBtn").click(function() {
							//if(tokenLogin!=undefined&&uidLogin!=undefined){
							updateRoomInfoVip(tokenLogin, uidLogin, roomId, 0);
							//}
						});

					}

					//获取直播间公告列表

				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	//更新直播间信息
	function updateRoomInfoVip(token, uid, roomid, subscribeType) {
		var name = $(".editliveRoomNameVip").val();
		var topic = $(".editliveRoomTitleVip").val();
		var description = $(".editDescriptionVip").val();
		var descriptionImgUrl = $(".editDescriptionImgUrlVip").attr("src");
		var coverUrl = $(".editLiveVipRoomCover").attr("src");
		var subscribePay = $(".editNiubiBoxVip").val();
		var subscribeCycle = $(".editDayBoxVip").val();
		var saveRoomAnnouncement1 = $(".editVipliveNoticeBtn").val();
		if(saveRoomAnnouncement1 != "") {
			saveRoomAnnouncement(uid, token, roomid, saveRoomAnnouncement1);
		}
		if(subscribeType == 1) {
			if(name == "") {
				$(".editNameVipError").stop().show();
				return false;
			} else if(topic == "") {
				$(".editTopicVipError").stop().show();
				return false;
			} else if(description == "") {
				$(".editDescriptionVipError").stop().show();
				return false;
			} else if(descriptionImgUrl == "") {
				$(".editDescriptionVipError").stop().show();
				return false;
			} else if(subscribePay == "") {
				$(".editSubscribePayVipError").stop().show();
				return false;
			} else if(subscribeCycle == "") {
				$(".editSubscribePayVipError").stop().show();
				return false;
			} else {
				updateRoomInfoVipStepTwo(token, uid, roomid, name, topic, description, descriptionImgUrl, coverUrl, subscribeType, subscribePay, subscribeCycle);
			}
		} else if(subscribeType == 0) {
			if(name == "") {
				$(".editNameVipError").stop().show();
				return false;
			} else if(topic == "") {
				$(".editTopicVipError").stop().show();
				return false;
			} else if(description == "") {
				$(".editDescriptionVipError").stop().show();
				return false;
			} else if(descriptionImgUrl == "") {
				$(".editDescriptionVipError").stop().show();
				return false;
			} else {
				updateRoomInfoVipStepTwo(token, uid, roomid, name, topic, description, descriptionImgUrl, coverUrl, subscribeType, subscribePay, subscribeCycle);
			}
		}

	}

	//更新——调接口
	function updateRoomInfoVipStepTwo(token, uid, roomid, name, topic, description, descriptionImgUrl, coverUrl, subscribeType, subscribePay, subscribeCycle) {
		$.ajax({
			type: "post", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v3/live/updateRoomInfo.do",
			data: {
				"token": token,
				"uid": uid,
				"roomId": roomid,
				"name": name,
				"topic": topic,
				"description": description,
				"descriptionImgUrl": descriptionImgUrl,
				"coverUrl": coverUrl,
				"subscribeType": subscribeType, //订阅类型0-免费，1-周期，2-永久
				"subscribePay": subscribePay,
				"subscribeCycle": subscribeCycle,
			},
			success: function(res) {
				if(res.code == 0) {
				//	console.log(res);
					layer.msg('直播间编辑成功');
					window.location.href = "/userProfile?uid=" + uid + "&tab=5";
					//$(".createVideo").stop().show();
					//liveProgressFun(uid,token,roomid);
					//uploadVideoImg(uid, token);
					//getLiveMessage(roomid, uid, token);

				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});

	}
	$(".liveRoomFromNoticeBtn").focus(function() {
		$(".liveRoomFromNotice").stop().show();
	})
	//获取直播间的公告
	function getRoomAnnouncementList(roomId, pageIndex, pageSize) {
		$.ajax({
			type: "get", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v3/live/getRoomAnnouncementList.do",
			data: {
				"roomId": roomId,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.length > 0) {
						$(".editVipliveNoticeBtn").val(res.data[0].content);
					}
					$(res.data).each(function(m, Q) {
						var delRoomAnnouncementId = Q.id;
						var delRoomAnnouncementTime = Q.time;
						var liveRoomFromNoticeVip =
							'<li id=' + Q.time + '>' +
							'<img src="images/historyOld.png"/>' +
							'<span class="contentNotice">' + Q.content + '</span>' +
							'<span class="contentTime">' + format(new Date(Q.time)) + '</span>' +
							'<img class="fr" id=' + Q.id + ' src="images/closeNotice.png"/>' +
							'</li>';
						$(".liveRoomFromNotice").append(liveRoomFromNoticeVip);
						//删除公告   uidLogin, tokenLogin
						$(document).on("click", "#" + delRoomAnnouncementId, function() {
							//获得直播详情——修改信息——提交
							delRoomAnnouncement(uidLogin, delRoomAnnouncementId, tokenLogin);
							$(this).parent().remove();
						})

					});
				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	//删除公告
	function delRoomAnnouncement(uid, id, token) {
		$.ajax({
			type: "POST", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v3/live/delRoomAnnouncement.do",
			data: {
				"uid": uid,
				"id": id,
				"token": token,
			},
			success: function(res) {
				if(res.code == 0) {
					layer.msg('删除成功');
				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});

	}

	//保存公告

	function saveRoomAnnouncement(uid, token, roomId, content) {
		$.ajax({
			type: "POST", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v3/live/saveRoomAnnouncement.do",
			data: {
				"uid": uid,
				"token": token,
				"roomId": roomId,
				"content": content,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					//					layer.msg('公告保存成功');
				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});

	}

	//编辑视频封面图片
	function uploadVideoImg(uid, token) {
		//var updownimgHref = "http://picture.91qiniu.com/"; //内网
		var updownimgHref = "https://picture.fengniutv.com/";
		$.ajax({
			type: "get", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v1/picture/batchUpload/token.do",
			data: {
				"uid": uid,
				"token": token,
			},
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					var videoEditImgtoken = res.data.uploadToken;
					//七牛上传图片
					var uploader = Qiniu.uploader({
						runtimes: 'html5,flash,html4', //上传模式,依次退化
						browse_button: 'add1Img', //上传选择的点选按钮，**必需**
						uptoken_url: updownimgHref, //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
						uptoken: videoEditImgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
						uptoken_func: function(file) {

						},
						unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
						save_key: false, // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
						domain: updownimgHref, //bucket域名，下载资源时用到，**必需**
						get_new_uptoken: true, //设置上传文件的时候是否每次都重新获取新的token
						container: 'uploadBg1', //上传区域DOM ID，默认是browser_button的父元素，
						max_file_size: '100mb', //最大文件体积限制
						flash_swf_url: 'js/Moxie.swf', //引入flash,相对路径
						max_retries: 3, //上传失败最大重试次数
						dragdrop: true, //开启可拖曳上传
						drop_element: 'uploadBg1', //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
						chunk_size: '4mb', //分块上传时，每片的体积
						auto_start: true, //选择文件后自动上传，若关闭需要自己绑定事件触发上传
						init: {
							'FilesAdded': function(up, files) {
								plupload.each(files, function(file) {
									// 文件添加进队列后,处理相关的事情
								});
							},
							'BeforeUpload': function(up, file) {
								//console.log(file);
								// 每个文件上传前,处理相关的事情
							},
							'UploadProgress': function(up, file) {
								// 每个文件上传时,处理相关的事情
							},
							'FileUploaded': function(up, file, info) {
							//	console.log(info);
								var imgInfoVideoEditinfo = JSON.parse(info);
								coverUrl = updownimgHref + imgInfoVideoEditinfo.key;
							//	console.log(coverUrl);
								$("#uploadBg1").css({
									"background": "url('" + coverUrl + "')",
									"background-size": "100% 100%"
								});
								$(".uploadBgZhe").stop().show();
								$(".addTips").html("修改封面");
								$(".addTips").css("color", "#ffffff");
								$(".deleteAddImg").stop().show();
							},
							'Error': function(up, err, errTip) {
								console.log(up);
								console.log(err);
								console.log(errTip);
								//上传出错时,处理相关的事情
							},
							'UploadComplete': function() {
								//队列文件处理完毕后,处理相关的事情
							}
						}
					});
				}
			},
		});
	}

	//获取直播间基本信息
	function getLiveMessage(roomId, uid, token) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/live/getLiveRoomInfo.do",
			data: {
				"roomId": roomId,
			},
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					var encryption = res.data.encryption;
					var defaultLiveCoverUrl = res.data.defaultLiveCoverUrl;
					//console.log(defaultLiveCoverUrl);
					$("#uploadBg1").css({
						"background": "url('" + defaultLiveCoverUrl + "')",
						"background-size": "100% 100%"
					});
					if(defaultLiveCoverUrl == "") {
						$("#uploadBg1").css({
							"background": "url(images/vedioCoverUrl.jpg)",
							"background-size": "100% 100%"
						});
					}
					if(encryption == 0) { //不允许加密
						$("#isVideoPwd1").stop().hide();
						$("#isVideoPwd2").stop().hide();
						// 开启视频直播
						$("#getCode").click(function() {
							var topic = $("#videoTitle1").val();
							var coverUrl = $("#uploadBg1").css("background-image").split("\"")[1];
							//console.log(topic);
							//console.log(coverUrl);
							if(topic == "") {
								$(".mustImg").stop().show();
								$(".mustTips").stop().show();
								return false;
							}
							if(coverUrl == "" || coverUrl == undefined) {
								return false;
							}
							$.ajax({
								type: "post",
								async: true,
								dataType: "json",
								url: "/api/v3/live/createLive.do",
								data: {
									"roomId": roomId,
									"uid": uid,
									"token": token,
									"topic": topic,
									"coverUrl": coverUrl,
									"device": "Windows"
								},
								success: function(res) {
									//console.log(res);
									if(res.code == 0) {
										var videoTopic = res.data.topic;
										var str = res.data.pushUrl;
										//截取直播流
										function find(str, cha, num) {
											var x = str.indexOf(cha);
											for(var i = 0; i < num; i++) {
												x = str.indexOf(cha, x + 1);
											}
											return x;
										}
										var indexNum = find(str, '/', 3);
										/*获得fms*/
										var fmsUrl = str.substring(0, indexNum);
										var tuiliuUrl = str.substring(indexNum + 1, str.length);
										// console.log(fmsUrl);
										// console.log(tuiliuUrl);
										$("#liveTitle").val(videoTopic);
										$("#getVideoImg2").attr("src", coverUrl);
										$("#FMSURL2").val(fmsUrl);
										$("#maskLayerCode2").val(tuiliuUrl);
										$("#FMSURL3").val(fmsUrl);
										$("#maskLayerCode3").val(tuiliuUrl);
										//点击生成串流码
										$(".createVideo").stop().hide();
										$(".streaCodeFMS").stop().show();
									} else if(res.code == -400) {
										layer.msg("创建聊天室失败");
									}
								}
							})
						})
					} else if(encryption == 1) { //允许加密
						$("#isVideoPwd1").stop().show();
						$("#isVideoPwd2").stop().show();
						// 开启视频直播
						$("#getCode").click(function() {
							var topic = $("#videoTitle1").val();
							var pwd = $("#videoPwd1").val();
							var coverUrl = $("#uploadBg1").css("background-image").split("\"")[1];
							//                          console.log(topic);
							//                          console.log(coverUrl);
							if(topic == "") {
								$(".mustImg").stop().show();
								$(".mustTips").stop().show();
								return false;
							}
							if(coverUrl == "" || coverUrl == undefined) {
								return false;
							}
							// 密码为6位数字
							if(pwd == "" || pwd == null || pwd == undefined) {
								createLiveFun(roomId, uid, token, topic, coverUrl, 0, '');
							} else {
								var pwdstr = $("#videoPwd1").val().trim();
								if(pwdstr.length != 6) {
									reg = /^\d{6}$/;
									if(!reg.test(pwdstr)) {
										$(".pwdTips").stop().show();
										setTimeout('$(".pwdTips").fadeOut()', 2000);
										return false;
									}
								};
								createLiveFun(roomId, uid, token, topic, coverUrl, 1, pwd);
							}
						})
					} else if(res.code == -8) {
						layer.Msg("该直播间正在其他设备直播中，请关闭其他设备的直播后再试");
					}
				}
			}
		})
	}

	function createLiveFun(roomId, uid, token, topic, coverUrl, openness, authCode) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/live/createLive2.do",
			data: {
				"roomId": roomId,
				"uid": uid,
				"token": token,
				"topic": topic,
				"coverUrl": coverUrl,
				"device": "Windows",
				"openness": openness, //0=开放（默认），1=加密的，需要密码观看
				"authCode": authCode
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					//点击生成串流码
					$(".createVideo").stop().hide();
					$(".streaCodeFMS").stop().show();
					var videoTopic = res.data.topic;
					var str = res.data.pushUrl;
					//截取直播流
					function find(str, cha, num) {
						var x = str.indexOf(cha);
						for(var i = 0; i < num; i++) {
							x = str.indexOf(cha, x + 1);
						}
						return x;
					}
					var indexNum = find(str, '/', 3);
					/*获得fms*/
					var fmsUrl = str.substring(0, indexNum);
					var tuiliuUrl = str.substring(indexNum + 1, str.length);
					//console.log(fmsUrl);
					//console.log(tuiliuUrl);
					$("#liveTitle").val(videoTopic);
					$("#getVideoImg2").attr("src", coverUrl);
					$("#FMSURL2").val(fmsUrl);
					$("#maskLayerCode2").val(tuiliuUrl);
					$("#FMSURL3").val(fmsUrl);
					$("#maskLayerCode3").val(tuiliuUrl);
					if(openness == 1) {
						$("#livePwd").val(authCode);
					} else {
						$("#isVideoPwd2").stop().hide();
					}

				} else if(res.code == -8) {
					layer.msg("该直播间正在其他设备直播中，请关闭其他设备的直播后再试");
				}
			}
		})
	}

	//复制
	$("#copyFMSURL").click(function() {
		copyUrl("#FMSURL3", '#copyFMSURL');
	})
	$("#copyMaskLayerCode").click(function() {
		copyUrl("#maskLayerCode3", '#copyMaskLayerCode');
	});
	$("#copyFMSURL1").click(function() {
		copyUrl("#FMSURL2", '#copyFMSURL1');
	})
	$("#copyMaskLayerCode1").click(function() {
		copyUrl("#maskLayerCode2", '#copyMaskLayerCode1');
	})

	function copyUrl(copyContent, copyBtn) {
		var g_url = $(copyContent).val();
		//console.log(g_url);
		var clipboard = new Clipboard(copyBtn, {
			text: function() {
				return g_url; //返回本页的地址
			}
		});
		clipboard.on('success', function(e) {
			//复制成功的弹框显示，2s后消失
			//          $("#copySuccess").stop().show();
			//          setTimeout('$("#copySuccess").fadeOut()', 2000);
			// console.log(e);
			layer.msg('已复制到剪切板');
		});
		clipboard.on('error', function(e) {
			//复制失败的弹框显示，2s后消失
			//          $("#copyFaired").stop().show();
			//          setTimeout('$("#copyFaired").fadeOut()', 2000);
			// console.log(e);
			layer.msg('复制失败请重新复制');
		});
	}

	//下载跳转——mas的obs
	$(document).on("click", ".downLoadMacObs", function(e) {
		var id = $(this).attr("videoId");
		window.location.href = "http://files.fengniutv.com/obs-mac-20.1-installer.rar";
	});

	$(document).on("click", ".downLoadStudioObs", function(e) {
		var id = $(this).attr("videoId");
		window.location.href = "http://files.fengniutv.com/OBS-Studio-20.1-Full-Installer.rar ";
	});

	//使用指南
	$(document).on("click", ".liveUseIntro", function(e) {
		window.location.href = "https://www.fntv8.com/article?id=6502f8ba-4ca5-4ba9-ac61-ca9b767787f4 ";
	});

	//查看更多直播
	$(document).on("click", ".userLiveTabMore", function(e) {
		$(".userLiveTab").addClass("anchorListNewsActive").siblings().removeClass("anchorListNewsActive");
		$("#userLiveTabBox").css("display", "block").siblings(".commentWrapBoxLInner").css("display", "none");
	});

	//查看更多专栏
	$(document).on("click", ".userColumnTabMore", function(e) {
		$(".userColumnTab").addClass("anchorListNewsActive").siblings().removeClass("anchorListNewsActive");
		$("#userColumnTabBox").css("display", "block").siblings(".commentWrapBoxLInner").css("display", "none");
	});

	//查看更多动态
	$(document).on("click", ".userNewsTabMore", function(e) {
		$(".userNewsTab").addClass("anchorListNewsActive").siblings().removeClass("anchorListNewsActive");
		$("#userNewsTabBox").css("display", "block").siblings(".commentWrapBoxLInner").css("display", "none");
	});

	//查看更多实盘
	$(document).on("click", ".userTradeTabMore", function(e) {
		$(".userTradeTab").addClass("anchorListNewsActive").siblings().removeClass("anchorListNewsActive");
		$("#traderListBox").css("display", "block").siblings(".commentWrapBoxLInner").css("display", "none");
	});
	//columnType-createColumn创建直播间  editColumn-编辑直播间
	function createColumn(columnId, token, uid, columnType) {
		var name = $(".ColumnName").val();
		var topic = $(".ColumnIntro").val();
		var description = $(".ColumnIntrodescription").val();
		//console.log(description);
		var descriptionImgUrl = $(".descriptionImgUrlColumn").attr("src");
		var coverUrl = $(".columnRoomCover").attr("src");
		var subscribePay = $(".niubiBoxColumn").val();
		var subscribeCycle = $(".dayBoxColumn").val();
		var dayBoxColumnAll = $(".dayBoxColumnAll").val();
		var reg = /^\d{1,5}$/;
		var reg1 = /^\d{1,3}$/;
		var moneySeleteType = $(".moneySelete").find("option:selected").text();
		if(moneySeleteType == "周期收费") {
			if(subscribePay == "") {
				$(".subscribePayColumnError").stop().show();
				return false;
			} else if(subscribeCycle == "") {
				$(".subscribePayColumnError").stop().show();
				return false;
			} else if(!reg.test(subscribePay)) {
				$(".subscribePayColumnError").stop().show();
				return false;
			} else if(!reg1.test(subscribeCycle)) {
				$(".subscribePayColumnError").stop().show();
				return false;

			}
		}
		if(moneySeleteType == "全期收费") {
			if(dayBoxColumnAll == "") {
				$(".subscribePayColumnError").stop().show();
				return false;
			} else if(!reg.test(dayBoxColumnAll)) {
				$(".subscribePayColumnError").stop().show();
				return false;
			}
		}
		if(name == "") {
			$(".nameColumnError").stop().show();
			return false;
		} else if(topic == "") {
			$(".topicColumnError").stop().show();
			return false;
		} else if(description == "") {
			$(".descriptionColumnError").stop().show();
			return false;
		} else if(descriptionImgUrl == "") {
			$(".descriptionColumnError").stop().show();
			return false;
		} else if(coverUrl == "") {
			$(".ColumnCoverError").stop().show();
			return false;
		} else {
			$(".liveRoomFromError").stop().hide();
			if(moneySeleteType == "周期收费") {
				createColumnStepTwo(columnId, token, uid, name, coverUrl, topic, 1, subscribePay, subscribeCycle, description, descriptionImgUrl, '', '', columnType);
			} else if(moneySeleteType == "全期收费") {
				createColumnStepTwo(columnId, token, uid, name, coverUrl, topic, 2, dayBoxColumnAll, "", description, descriptionImgUrl, '', '', columnType);
			} else {
				createColumnStepTwo(columnId, token, uid, name, coverUrl, topic, 0, "", "", description, descriptionImgUrl, '', '', columnType);
			}

		}

	}
	//subscribeType	是	string	订阅类型0-免费，1-周期，2-永久
	//创建专栏接口
	function createColumnStepTwo(id, token, uid, name, coverUrl, introduction, subscribeType, subscribePay, subscribeCycle, subscribeSummary, summaryUrl, subscribeNotice, userNotice, columnType) {
		$.ajax({
			type: "post", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v2/column/save.do",
			data: {
				"id": id,
				"token": token,
				"uid": uid,
				"name": name,
				"coverUrl": coverUrl,
				"introduction": introduction,
				"subscribeType": subscribeType,
				"subscribePay": subscribePay,
				"subscribeCycle": subscribeCycle, //订阅类型0-免费，1-周期，2-永久
				"subscribeSummary": subscribeSummary,
				"summaryUrl": summaryUrl,
				"subscribeNotice": subscribeNotice,
				"userNotice": userNotice,
			},
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					if(columnType == "createColumn") {
						layer.msg('创建成功');
						window.location.href = "/userProfile?uid=" + uid + "&tab=3";
					} else if(columnType == "editColumn") {
						layer.msg('编辑成功');
						window.location.href = "/userProfile?uid=" + uid + "&tab=3";
					}

				} else if(res.code == -17) {
					layer.msg('专栏名称已存在');
				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});

	}

	//选择专栏消失
	$(".chooseColumnBoxT").click(function() {
		$(".chooseColumnBox").stop().hide();
	});

	$(".columnChooseCancleBtn").click(function() {
		$(".chooseColumnBox").stop().hide();
	});
	
	

})