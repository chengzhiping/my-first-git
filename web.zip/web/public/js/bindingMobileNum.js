$(document).ready(function(){
	var phoneReg = /^[1][34578]\d{9}$/; //手机号码正则
	var passwordReg = /^[0-9a-zA-Z]+$/ //密码正则
	var numReg = new RegExp(/^\d{4}$/); //图形验证码
	var verifyReg = new RegExp(/^\d{6}$/); //短信验证码
	loginFun();
	function loginFun() {
		$.ajax({
			type: "get",
			url: "/userInfos",
			success: function(res) {
				if(res.code == 0) { //登录
					console.log(res);
					uid = res.data.userInfo.uid;
					token = res.data.token;
					var bindAccountsType= res.data.userInfo.bind;//bind=1已绑定 0 未绑定
					//绑定判断
					if(bindAccountsType == 1) {//已经绑定手机号码
						//$(".phone_bind_wrap").stop().hide();
						bindAccountsPhoneFun(uid, token);
					}else{
						$(".phone_bind_wrap").stop().show();
						bindAccountsPhoneFun(uid, token);
					}
				} else if(res.code == -2) { //未登录
					$("#loginAlert").stop().show();
					$("#loginAlert").load("/login");
				}
			}
		})

	}
	function bindAccountsPhoneFun(uid, token) {
		$("#getBangdingYan").click(function() {
			var resetPhone = $("#pnone_size").val();
			if(!phoneReg.test(resetPhone)) {
				layer.msg('手机号码有误，请重新输入');
				return false;
			} else {
				refreshCodeFun();
				$(".phone_bind_wrap").stop().hide();
				$("#numCodeBGBindingMobile").fadeIn(100);
				//图形验证码确认按钮
				$("#verifyGraphBtn").click(function() {
					var graphInput = $("#graphInputBindingMobile").val();
					if(!numReg.test(graphInput)) {
						$("#graphInputBindingMobile").val('');
						layer.msg('验证码有误');
						return false;
					} else {
						$.ajax({ //校验图形验证码
							type: "post",
							url: "/checkGraphCode",
							data: { 'verifiCode': graphInput },
							success: function(res) {
								$("#graphInputBindingMobile").val('');
								// console.log(res);
								if(res.code == 0) { //图形验证码正确
									$("#numCodeBGBindingMobile").fadeOut(100);
									$(".phone_bind_wrap").stop().show();
									$.ajax({ //发送短信验证码
										type: "post",
										url: "/api/v2/user/sendSms.do",
										data: { 'type': 2, 'mobile': resetPhone },
										success: function(res) {
											console.log(res);
											if(res.code == 0) {
												layer.msg('验证码发送成功');
												var times = 60;
												var isinerval;
												$("#getBangdingYan").attr("disabled", true);
												isinerval = setInterval(function() {
													if(times < 0) {
														$("#getBangdingYan").html("获取验证码").attr("disabled", false);
														clearInterval(isinerval);
														return
													}
													$("#getBangdingYan").html(times + "秒后再点击");
													times--
												}, 1000)
												$("#bangdingConfirm").click(function() {
													var resetCode = $("#code_size").val();
													//var resetPassword = $("#pwd_size").val();
													$.ajax({ //重置密码
														type: "post",
														url: "/api/v1/user/bindingMobileV4.do",
														data: { 
															'uid': uid, 
															'token': token,
															'mobile': resetPhone,
															'authCode': resetCode
														},
														success: function(res) {
															console.log(res);
															if(res.code == 0) {
																layer.msg('绑定手机号码成功');
																$(".phone_bind_wrap").stop().hide();
																$("#loginAlert").stop().hide();
																$("#loginRegisterBtn").stop().hide();
																$(".loginSuccess").stop().show();
																if(res.data.userInfo.headImgUrl) {
																	$(".anchorHeadHeader").attr("src", res.data.userInfo.headImgUrl);
																}else{
																	$(".anchorHeadHeader").attr("src", "images/anchorHead.png");
																}
																//绑定成功
//																if(res.data.tag==0){//0=uid未改变，1=uid已改变
//																	
//																}else if(res.data.tag==1){
//																	
//																}
                                                                
															} else if(res.code == -16) {
																layer.msg('用户不存在');
															} else if(res.code == -6) {
																layer.msg('手机验证码无效');
															}else if(res.code == -1){
																layer.msg('验证码不能为空');
															}else if(res.code== -101){
																layer.msg('该手机号码已经绑定，请直接登录');
															}
														},
														error: function(XMLHttpRequest, textStatus, errorThrown) {
															console.log(XMLHttpRequest.status);
															console.log(XMLHttpRequest.readyState);
															console.log(textStatus);
														},
													});
												})
											} else if(res.code == -14) {
												layer.msg('该手机号发送短信次数过于频繁');
											} else if(res.code == -20) {
												layer.msg('系统繁忙，请稍后再试');
											} else if(res.code == -101) {
												layer.msg('手机号已被注册');
											} else if(res.code == -9998) {
												layer.msg('发送失败');
											}
										}
									});
								} else if(res.code == -1) {
									layer.msg('图形验证码有误');
								}
							}
						});
					}
				});
			}
		});
	};
	
	//获取图形验证码
	function refreshCodeFun() {
		$.ajax({
			type: "GET",
			url: "/refreshGraphCode",
			success: function(res) {
				if(res.code == 0) {
					var src = 'data:image/png;base64,' + res.data;
					$(".graphCode").attr("src", src);
				}
			}
		});
	};
	//刷新图形验证码
	$(".graphCode").click(function() {
		refreshCodeFun();
	});
	
	$(".graphCloseBtn").click(function() {
		$(".numCodeBG").stop().hide();
		$(".phone_bind_wrap").stop().show();
	});
	//取消按钮及X
	$(".cancleBindBtn").click(function(){
		exitFun();
	})
	//退出
	function exitFun() {
		$.ajax({
			type: "get",
			url: "/api/logout",
			success: function(res) {
				if(res.code == -2) { //注销成功
					//console.log(res);
					$("#loginAlert").stop().hide();
					$(".phone_bind_wrap").stop().hide();
				}
				window.location.reload();
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},

		});
	};
	
})
