var columnApp = angular.module("columnApp", []);
columnApp.controller("columnCtrl", function ($scope, $http) {
    $("#header").load("/header");
    $("#footer").load("/footer");

    //编辑精选
    $http({url: "/api/v2/discovery/getDiscoveryByType2.do?type=2&pageSize=1&pageIndex=1"})
        .success(function (data, status, headers, config) {
            //console.log(data);
            $scope.editDetail = data.data[0];
        })
        .error(function (data, status, headers, config) {
            // console.log(status);
            // console.log(data);
        })

    // 编辑精选跳转
    $scope.discoveryHref = function (type,id,uid) {
        if(type==1){
            window.open("/article?id="+id);
        }else if(type==2){
            window.open("/video?id="+id);
        }else if(type==3){
            window.open("/live?uid="+uid);
        }else if(type==0){

        }
    };

    //专栏发现
    $scope.editDetailList = [];
    $http({
        url: "/api/v2/video/getRecColumnList.do?pageSize=3&pageIndex=1",
        method: 'GET'
    })
        .success(function (data, status, headers, config) {
            //console.log(data);
            $scope.findDetail = data.data;
            var findLength = $scope.findDetail.length;
            for(var i=0;i< findLength;i++){
                var id = $scope.findDetail[i].id;
                $http({
                    url: "/api/v2/column/getColumnContent.do?pageSize=3&pageIndex=1&columnId="+id,
                    method: 'GET'
                })
                    .success(function (data, status, headers, config) {
                        $scope.editDetailList.push(data.data[0]);
                    })
                    .error(function (data, status, headers, config) {
                        console.log(status);
                        console.log(data);
                    })
            }
        })
        .error(function (data, status, headers, config) {
            console.log(status);
            console.log(data);
        })

    //热门更新
    $http({
        url: "/api/v2/column/getNewContent.do",
        method: 'GET'
    })
        .then(function successCallback(response) {
            // 请求成功执行代码
            $scope.hotUpdate = response.data;
            var hotLength = $scope.hotUpdate.data.length;
            for(var i=0;i<hotLength;i++){
                $scope.hotList = $scope.hotUpdate.data;
            }
        }, function errorCallback(response) {
            // 请求失败执行代码
            console.log(response);
        });

    //专栏推荐
    var pageIndex = 1;
    $scope.allColumnList1 = [];
    $scope.columnLoadMore = function (pageIndex) {
        $http({
            url: "/api/v2/column/getColumnList.do?pageSize=10&pageIndex="+pageIndex,
            method: 'GET'
        })
            .then(function successCallback(response) {
                // 请求成功执行代码
                $scope.allColumn = response.data;
                var length = response.data.data.columns.length;
                if(length<10){
                    $(".loading").stop().hide();
                    $(".loadEnd").stop().show();
                }
                for(var i=0;i<length;i++){
                    $scope.allColumnList = $scope.allColumn.data.columns;
                    $scope.allColumnList1.push($scope.allColumn.data.columns[i]);
                }
            }, function errorCallback(response) {
                // 请求失败执行代码
                console.log(response);
            });
    }
    $scope.columnLoadMore(1);
    $(window).on('scroll', function () {
        if($(document).scrollTop() + $(window).height() >= $(document).height()){
            pageIndex++;
            $scope.columnLoadMore(pageIndex);
        }
    });
})
