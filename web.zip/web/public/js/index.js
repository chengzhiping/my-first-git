var app = new Vue({
	el: '#app',
	data: {
		getHotLiveRoomListData: [] // 轮播图的数据
	},
	created: function () { // 一般进入页面的初始化操作都在里面
		this.getHotLiveRoomList();
		this.silderAnimate();
	},
	methods: {
		getHotLiveRoomList: function () {
			var _this = this
		    axios.get('/api/v3/live/getHotLiveRoomList.do', {
		      params: {
		        pageIndex: 1,
		        pageSize: 6
		      }})
		    .then(function (response) {
		  	  var res = JSON.parse(unCompileStr(response.data));
		  	  if (res && res.code === 0) {
		  		_this.getHotLiveRoomListData = res.data;
		  	  }
		  	  console.log(_this.getHotLiveRoomListData);
		  })
		},
		// 轮播图
		silderAnimate: function () {
			var oBox = document.getElementById('box');
			var oList = document.getElementById('list');
			var aLi = oList.getElementsByTagName('li');
			var oPrev = document.getElementById('prev');
			var oNext = document.getElementById('next');
			var i = 0;
			function animate (obj, json, fn){  //json = {left:200, top:400}
				clearInterval(obj.timer);
				obj.timer = setInterval(function(){
					var bStop = true; //是否可以停止, 是否所有属性都到达了目标值 
					for (var attr in json) {
						var iTarget = json[attr]; //目标值
						var current = 0;
						if (attr == "opacity") { //透明度
							current = parseFloat(getStyleAttr(obj, attr)) * 100;
							current = Math.round(current); //四舍五入
						}
						else { //left,top, width, height
							current = parseFloat(getStyleAttr(obj, attr));
							current = Math.round(current); //四舍五入
						}
						var speed = (iTarget-current)/8;
						speed = speed>0 ? Math.ceil(speed) : Math.floor(speed);
						if (current != iTarget){ //如果至少有一个属性没有到达目标值
							bStop = false; //bStop就设置为false, 表示不可以停止定时器
						}
						if (attr == "opacity"){ //透明度
							obj.style[attr] = (current + speed)/100;
							obj.style.filter = "alpha(opacity=" + (current+speed) + ")";
						}
						else { //left, top, width, height
							obj.style[attr] = current + speed + "rem";
						}
					}
					if (bStop){
						clearInterval(obj.timer); //停止定时器, 停止运动
						if (fn){
							fn();
						}
					}
					
				}, 30);
				
			}
			function getStyleAttr (obj, attr){
				if (window.getComputedStyle){
					return window.getComputedStyle(obj, null)[attr];
				}
				else {
					return obj.currentStyle[attr];
				}
			}
			//克隆第一个li放到最后一个li中
			oList.appendChild( aLi[0].cloneNode(true) );
			oList.style.width = aLi.length * 7.18 + "rem"
			var size = aLi.length;
			var timer = setInterval(function(){
				i++;
				move();
			},4000)
			
			function move(){
				//判断右边界
				if(i>=size){
				oList.style.left = 0;
					i=1;
				}
				//判断左边界
				if(i < 0){
					oList.style.left = -7.18*(size-1) +'rem';
					i=size-2;
				}

				animate(oList,{left:-7.18*i});
				//鼠标移入小点时改变对应样式
				for (var j=0; j<aLi2.length; j++){
					if (j == i){
						aLi2[j].className = "active";
					}
					else {
						aLi2[j].className = "";
					}
				}
				if (i == size-1){
					aLi2[0].className = "active";
				}
			}
				//点击上一页按钮
			oPrev.onclick = function(){
				i--;
				move();
			}
			
			//点击下一页按钮
			oNext.onclick = function(){
				i++;
				move();
			}
			
			//移入大图停止计时器
			oBox.onmouseenter = function(){
				clearInterval(timer);
			}
			
			//移出大图开启计时器
			oBox.onmouseleave = function(){
				timer = setInterval(function(){
					i++;
					move();
				},4000)
			}
			
			//移入小点时显示对应图
			var oList2 = document.getElementById("list2");
			var aLi2 = oList2.getElementsByTagName('li');
			for(var j = 0;j < aLi2.length;j++){
				aLi2[j].index = j;
				aLi2[j].onmouseenter = function(){
						i = this.index;
						move();
				}
			}

		}
	},
	mounted: function () {
		
	}
})
