var topicApp = angular.module("topicApp",['appServices','ngSanitize']);
topicApp.controller('topicCtrl',['$scope','$rootScope','$location','apiFun',function ($scope,$rootScope,$location,apiFun) {
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");

    //APP下载二维码
    $(".saoma").mouseenter(function() {
        $(".indexCode").fadeIn(200);
    });
    $(".saoma").mouseleave(function() {
        $(".indexCode").fadeOut(200);
    });
    //发布话题关闭按钮
    $scope.closeBuild = function () {
        $(".buildTopic").fadeOut(200);
    }



    var getQueryStringId = GetQueryString("id");
    // var getQueryStringId = 'ada592d4-f699-433d-8e89-0f491f2bc7bb';
    var topicUid;
    var userId;
    var userToken;

    //发布内容按钮鼠标经过
    $(".releaseBtn").mouseover(function(){
        $(".releaseBtn img").attr("src","images/releaseiconB.png")
    });
    $(".releaseBtn").mouseout(function(){
        $(".releaseBtn img").attr("src","images/releaseicon.png")
    });
    //等我来答---回答按钮
    $scope.answerBtnO = function (i) {
        $('.answerhover'+i).attr("src","images/releaseiconB.png")
    };
    $scope.answerBtnL = function (i) {
        $('.answerhover'+i).attr("src","images/releaseicon.png")
    };
    //最新话题----回答按钮
    $scope.answerBtnA = function (i) {
        $('.conmentAnswer'+i).attr("src","images/releaseiconB.png")
    };
    $scope.answerBtnB = function (i) {
        $('.conmentAnswer'+i).attr("src","images/releaseicon.png")
    };

    //精选回答
    $scope.homePagekindFun = function (uid) {
        var promisess = apiFun.kindFun(11,3);
        promisess.then(function(res) {
            // console.log(res);
            if(res.code == 0){
                $scope.suggestList = res.data;
                $.each($scope.suggestList, function(i) {
                    $scope.selectAgreeCount2 = function () {
                        $scope.selectAgree = {};
                        $scope.selectAgree.uid = uid;
                        $scope.selectAgree.agreeType = 1;
                        $scope.selectAgree.objectId = $scope.suggestList[i].comment.id;
                        var promisess = apiFun.selectAgreeCountFun($scope.selectAgree);
                        promisess.then(function (result) {
                            if (result.code == 0) {
                                $scope.suggestList[i].agreeCountNum = result.data;
                            }
                        });
                    };
                    $scope.selectAgreeCount2();
                });
                // console.log($scope.suggestList);
            }
        });
    };
    $scope.homePagekindFun();

    //web获取等我来答
    $scope.selectAnswerFun = function () {
        var promisess = apiFun.selectAnswerDiscussFun();
        promisess.then(function(res) {
            // console.log(res);
            $scope.selectAnswer = res.data;
        });
    };
    $scope.selectAnswerFun();

    /*//编辑精选
    $scope.discoveryByType = function () {
        var promisess = apiFun.getDiscoveryByType2Fun(2,1,1);
        promisess.then(function(res) {
            $scope.discovery = res.data[0];
            // console.log($scope.discovery);
        });
    };
    $scope.discoveryByType();*/
    //编辑精选--点击跳转   0=其他，1=文章，2=视频，3=直播
   /* $scope.discoveryHref = function (type,id,uid) {
        if(type==1){
            window.open("/article?id="+id);
        }else if(type==2){
            window.open("/video?id="+id);
        }else if(type==3){
            window.open("/live?uid="+uid);
        }else if(type==0){
        }
    };*/


    //最新话题
    $scope.discussList = [];
    var discussIndex = 1;
    $scope.allDiscussFun = function (uid) {
        $scope.discussParam = {};
        $scope.discussParam.uid = uid;
        $scope.discussParam.type = 1;
        $scope.discussParam.pageIndex = discussIndex;
        $scope.discussParam.pageSize = 5;
        $scope.ifLoading = false; //判断是否正在读取内容的变量----未读取
        var promisess = apiFun.selectAllDiscussFun($scope.discussParam);
        promisess.then(function(res) {
            if(res.code ==0){
                $scope.ifLoading = true; //判断是否正在读取内容的变量----已读取
                $scope.noMore = res.data.length;
                for (var i = 0; i <= res.data.length - 1; i++) {
                    $scope.discussList.push(res.data[i]);
                    // console.log($scope.discussList);
                }
            }
        });
        discussIndex++;
    };


    //获取用户信息    ------检查是否登录
    $scope.userInfoFun = function () {
        var promisess = apiFun.getUserInfoFun();
        promisess.then(function(res) {
            // console.log(res);
            if(res.code == 0){
                $scope.userData = res.data;
                // console.log($scope.userData);
                userToken = $scope.userData.token;
                userId = $scope.userData.userInfo.uid;
                $scope.homePagekindFun(userId);

                //发布内容
                $scope.releaseBtn = function () {
                    $(".buildTopic").fadeIn(200);
                    $scope.insertDiscuss = {};
                    $scope.insertDiscuss.title = '';
                    $scope.insertDiscuss.content = '';
                    $scope.$watch('insertDiscuss', function() {
                        if ($scope.insertDiscuss.title.length > 40){
                            layer.msg('标题不能多于40字！');
                            $scope.insertDiscuss.title = $scope.insertDiscuss.title.substr(0,40);
                        }else if($scope.insertDiscuss.content.length > 400){
                            layer.msg('内容不能多于400字！');
                            $scope.insertDiscuss.content = $scope.insertDiscuss.content.substr(0,400);
                        }else{
                            $scope.topicBtn = function () {
                                if($scope.insertDiscuss.title.length < 6){
                                    layer.msg('标题不能少于6字！');
                                }else{
                                    $scope.disabled = true;
                                    $scope.insertDiscuss.uid = userId;
                                    $scope.insertDiscuss.userToken = userToken;
                                    $scope.insertDiscuss.coinNumber = 0;
                                    var promisess = apiFun.insertDiscussFun($scope.insertDiscuss);
                                    promisess.then(function(res) {
                                        $scope.disabled = false;
                                        // console.log(res);
                                        if(res.code ==0){
                                            $(".buildTopic").fadeOut(200);
                                            layer.msg('话题发布成功！');
                                            $scope.insertDiscuss.title = '';
                                            $scope.insertDiscuss.content = '';
                                        }else {
                                            // console.log(res);
                                            layer.msg('发布失败！');
                                        }
                                    });
                                }
                            }
                        }
                    },true);
                };

                //精选回答点赞图标
                $scope.suggestClick = function (index,id,agreeCount,agree) {
                    $scope.agreeApi3 = {};
                    $scope.agreeApi3.objectId = id;
                    $scope.agreeApi3.uid = userId;
                    $scope.agreeApi3.agreeType = 1;
                    var promisess = apiFun.selectAgreeCountFun($scope.agreeApi3);
                    promisess.then(function(result) {
                        // console.log(result);
                        if(res.code == 0){
                            if(result.data.isAgree==true){
                                //取消点赞
                                $scope.delLike = {};
                                $scope.delLike.uid = userId;
                                $scope.delLike.token = userToken;
                                $scope.delLike.objectId = id;
                                $scope.delLike.agreeType = 1;
                                var promisess = apiFun.deleteAgreeFun($scope.delLike);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        // console.log(res);
                                        $("#suggest"+index).find('img').attr('src','../images/rewardIcon.png');
                                        $("#suggest"+index).find('b').removeClass('textColor2').text(result.data.agreeCount-1);
                                    }
                                });
                            }else if(result.data.isAgree==false){
                                //点赞/取消点赞评论   ---start
                                $scope.suggest = {};
                                $scope.suggest.uid = userId;
                                $scope.suggest.type = 4;
                                $scope.suggest.objectId = id;
                                $scope.suggest.agreeType = 1;
                                $scope.suggest.token = userToken;
                                var promisess = apiFun.insertAgreeFun($scope.suggest);
                                promisess.then(function(res) {
                                    // console.log(res);
                                    if(res.code == 0){
                                        $("#suggest"+index).find('img').attr('src','../images/rewardP.png');
                                        $("#suggest"+index).find('b').addClass('textColor2').text(result.data.agreeCount+1);
                                    }
                                });//点赞/取消点赞评论   ---end
                            }
                        }
                    });
                };
                //话题回答点赞图标
                $scope.suggestClickB = function (index,id) {
                    $scope.agreeApi4 = {};
                    $scope.agreeApi4.objectId = id;
                    $scope.agreeApi4.uid = userId;
                    $scope.agreeApi4.agreeType = 1;
                    var promisess = apiFun.selectAgreeCountFun($scope.agreeApi4);
                    promisess.then(function(result) {
                        if(res.code == 0){
                            if(result.data.isAgree==true){
                                //取消点赞
                                $scope.delLike4 = {};
                                $scope.delLike4.uid = userId;
                                $scope.delLike4.token = userToken;
                                $scope.delLike4.objectId = id;
                                $scope.delLike4.agreeType = 1;
                                var promisess = apiFun.deleteAgreeFun($scope.delLike4);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        // console.log(res);
                                        $("#suggest4"+index).find('img').attr('src','../images/rewardIcon.png');
                                        $("#suggest4"+index).find('b').removeClass('textColor2').text(result.data.agreeCount-1);
                                    }
                                });
                            }else if(result.data.isAgree==false){
                                //点赞/取消点赞评论   ---start
                                $scope.suggest4 = {};
                                $scope.suggest4.uid = userId;
                                $scope.suggest4.type = 4;
                                $scope.suggest4.objectId = id;
                                $scope.suggest4.agreeType = 1;
                                $scope.suggest4.token = userToken;
                                var promisess = apiFun.insertAgreeFun($scope.suggest4);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        $("#suggest4"+index).find('img').attr('src','../images/rewardP.png');
                                        $("#suggest4"+index).find('b').addClass('textColor2').text(result.data.agreeCount+1);
                                    }
                                });//点赞/取消点赞评论   ---end
                            }
                        }
                    });
                };

                $scope.allDiscussFun(userId);
                $scope.loadMore = function () {
                    $scope.allDiscussFun(userId);
                };


            }else if(res.code == -2){
                $scope.allDiscussFun();
                $scope.loadMore = function () {
                    $scope.allDiscussFun();
                };
                $scope.suggestClick = function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                };
                $scope.releaseBtn = function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                };
                $scope.suggestClickB = function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                };
            }
        });
    };
    $scope.userInfoFun();



    /*固定条*/
    var IndexpageIndex =1;
    $(".fixed_nav .reload").click(function() {
        $("body,html").animate({
            scrollTop: 1200
        }, 800)
        IndexpageIndex++;
        insertHot(IndexpageIndex, 10, "top");
        $(".insertTopWrap").stop().show(0).delay(4000).hide(0);
        $("#hotTopLoading").show().delay(1000).hide(0);
        $(".insertTop").delay(1000).slideDown(0).delay(3000).slideUp(0);

    })
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn()
        } else {
            $(".goTop").stop().fadeOut()
        }
    });
    $(".goTop").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 800)
    });




}
]);


