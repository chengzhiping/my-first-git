axios.get('/api/v3/live/getHotLiveRoomList.do', {
    params: {
      pageIndex: 1,
      pageSize: 6
    }})
  .then(function (response) {
  	this.data=JSON.parse(unCompileStr(response.data));
  	console.log(this.data);
  })
  .catch(function (error) {
    console.log(error);
  });