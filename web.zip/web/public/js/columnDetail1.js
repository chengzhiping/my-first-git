$(document).ready(function() {
	var columnIdUid;
	var userid;
	//加载头部
	$("#wrapHeader").load("/header");
	//加载底部
	$("#indexFooter").load("/footer");
	//回到头部
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
	var tab = GetQueryString("tab");
	if(tab != "" && tab != undefined && tab != null) {
		//console.log(tab);
		tabFun(tab);
	} else {
		$(".columnMiddleTabTInfo").eq(0).addClass("columnMiddleTabTInfoActive").siblings().remove("columnMiddleTabTInfoActive");
		$(".columnMiddleTabTWrap .columnMiddleTabBox").eq(0).css("display", "block").siblings(".columnMiddleTabBox").css("display", "none");
	}

	function tabFun(tab) {
		$(".columnMiddleTabTInfo").eq(tab - 1).addClass("columnMiddleTabTInfoActive").siblings().remove("columnMiddleTabTInfoActive");
		$(".columnMiddleTabTWrap .columnMiddleTabBox").eq(tab - 1).css("display", "block").siblings(".columnMiddleTabBox").css("display", "none");
	}
	
	$(".columnMiddleTabT .columnMiddleTabTInfo").click(function() {
		$(".columnMiddleTabTWrap .columnMiddleTabBox").eq($(this).index()).css("display", "block").siblings("div").css("display", "none");
		$(this).addClass("columnMiddleTabTInfoActive").siblings("li").removeClass("columnMiddleTabTInfoActive");
	});
	var id = GetQueryString("id");
	//判断是否已登录
	userInfos()

	function userInfos() {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/userInfos",
			success: function(res) {
				if(res.code === 0) {
					//查看用户的牛币
					userid = res.data.userInfo.uid;
					var usertoken = res.data.token;
					subscribetypeFun(id, userid, usertoken);
				} else {
					subscribetypeFun(id, "", ""); //获得专栏详情
					//订阅按钮
					$(".columnSubscribeBtn").click(function() {
						$(".payMoney").stop().hide();
						$("#loginAlert").stop().show();
						$("#loginAlert").load("/login");
					});
					
					$(".checkFollowingBtn").click(function() {
						$("#loginAlert").stop().show();
						$("#loginAlert").load("/login");
					})
				}
			}
		})
	};
   
   
    function getReceptorCount(uid) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/getReceptorCount.do",
			async: true,
			data: {
				"uid": uid,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".followingNum").html(res.data);
				}
			}
		})
	}
   
   //判断是否已经关注
	function followFun(uid, usertoken, userId) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/checkFollowing.do",
			async: true,
			data: {
				"receptorId": uid,
				"usertoken": usertoken,
				"uid": userId,
			},
			success: function(res) {
				//console.log(res);
				if(res.data == 0) {
					$(".checkFollowingBtn").attr("src", "images/attention.png");
					$(".checkFollowingBtn").click(function(){
					   addConcern(uid, userId, usertoken);
					})
				}
				if(res.data == 1) {
					$(".checkFollowingBtn").attr("src", "images/attentionp.png");
					$(".checkFollowingBtn").click(function(){
					    cancelConcern(uid, userId, usertoken);
					})

				}
			}
		})
	}
	
	//取消关注
	function cancelConcern(uid, userId, usertoken) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/deleteFollow.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".checkFollowingBtn").attr("src", "images/attention.png");
					var num = Number($(".followingNum").html());
					$(".followingNum").html(num - 1);
				}else if(res.code==-1){
					addConcern(uid, userId, usertoken);
				}else if(res.code==-9998){
					addConcern(uid, userId, usertoken);
				}
			}
		})
	}
	//增加关注
	function addConcern(uid, userId, usertoken) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/following.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".checkFollowingBtn").attr("src", "images/attentionp.png");
					var num = Number($(".followingNum").html());
					$(".followingNum").html(num + 1);
				}else if(res.code==-1){
					cancelConcern(uid, userId, usertoken);
				}
			}
		})
	}
   
    
    /*获得关注数*/
    function getReceptorCount(uid) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/getReceptorCount.do",
			async: true,
			data: {
				"uid": uid,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".followingNum").html(res.data);
				}
			}
		})
	}
    
    
    
   //获得专栏详情
	function subscribetypeFun(id, userid, usertoken) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v2/column/getColumnDetail.do",
			data: {
				"columnId": id,
				"uid": userid,
			},
			success: function(res) {
				if(res.code === 0) {
					//console.log(res);
					if(res.data.coverUrl) {
						$(".columnTopImg").attr("src", res.data.coverUrl+"!150X200");
					};
					$(".columnIntro").html(res.data.name);
					if(res.data.introduction) {
						$(".columnInner").html(res.data.introduction);
					} else {
						$(".columnInner").html("专栏暂无简介");
					};
					if(res.data.liverInfo.headImgUrl) {
						$(".headImgUrl").attr("src", res.data.liverInfo.headImgUrl+"!60X60");
					};
					$(".nickName").html(res.data.liverInfo.nickName);
					if(res.data.liverInfo.positionName) {
						$(".positionName").html(res.data.liverInfo.positionName);
					} else {
						$(".positionName").html("暂无认证");
					};
					$(".subscribeCount").html(res.data.subscribeCount + "人订阅");
					if(res.data.subscribeType == 0) { //- - subscribeType	string	订阅类型0-免费，1-周期性，2-一次性
						$(".columnMiddleBoxTopB1").html("免费");
						getColumnContent(id,userid,1,10,"free",usertoken);//免费内容
					} else if(res.data.subscribeType == 1) {
						$(".columnAlertBoxPosition").stop().show();
						$(".columnMiddleBoxTopB1").html(res.data.subscribePay + "牛币/" + res.data.subscribeCycle + "天");
						$(".columnAlertBoxInfoInner").html(res.data.subscribePay + "牛币/" + res.data.subscribeCycle + "天")
						getColumnContent(id,userid,1,10,"pay",usertoken);//付费内容
						$(".columnDayAlert").html(res.data.subscribeCycle + "天");
						//免费试看
                       getFreeLook(id,userid,1,10,usertoken);
					} else if(res.data.subscribeType == 2) {
						$(".columnAlertBoxPosition").stop().show();
						$(".columnMiddleBoxTopB1").html(res.data.subscribePay + "牛币/全期");
						$(".columnAlertBoxInfoInner").html(res.data.subscribePay + "牛币/全期");
						$(".columnDayAlert").html("全期");
						getColumnContent(id,userid,1,10,"pay",usertoken);//付费内容
						//免费试看
                        getFreeLook(id,userid,1,10,usertoken);
					}
					
					$(".columnMoneyAlert").html(res.data.subscribePay);
					if(res.data.summary){
						$(".summary").html(htmlEncode(res.data.summary));
					}else{
						$(".columnIntroTab2Box").stop().hide();
						$(".summaryIntro").stop().hide();
					}
					
					//$(".summaryUrl").attr("src", res.data.summaryUrl);
					

					//主播，普通用户
					columnIdUid = res.data.liverInfo.uid;
					$(document).on("click", ".headImgUrl", function(e) {
						window.location.href = "/userProfile?uid=" + columnIdUid;
					});
					//console.log(columnIdUid);
					getReceptorCount(columnIdUid)
					if(userid) {
						followFun(columnIdUid, usertoken, userid)
						if(userid == columnIdUid) { //主播自己
							$(".columnMiddleBoxTopB2").stop().hide();
							$(".columnMiddleBoxTopB4").stop().show();
							$(".columnAlertBoxInfo").stop().hide();
							$(".columnMiddleUserInfo").click(function(){
								window.location.href="/userProfile?uid="+columnIdUid+"&tab=3";
							});
						} else {
							if(res.data.isSubscribe == true) { //是否订阅
								$(".columnMiddleBoxTopB2").stop().hide();
								$(".columnMiddleBoxTopB3").stop().show();
								$(".columnMiddleBoxTopB5").stop().show();
								$(".columnMiddleBoxTopB1").stop().hide();
								//到期时间
								if(res.data.subscribeType == 1){
									$(".columnMiddleBoxTopB5").html(formatTrader(new Date(res.data.expTime)) + "到期");
									$(".columnAlertBoxInfo").html("已订阅："+formatTrader(new Date(res.data.expTime)) + "到期");
								}else if(res.data.subscribeType == 2){
									$(".columnMiddleBoxTopB5").html("已订阅全期");
									$(".columnAlertBoxInfo").html("已订阅全期");
								}
								
								
							} else { //未订阅
								$(".columnMiddleBoxTopB3").stop().hide();
								$(".columnMiddleBoxTopB2").stop().show();
								//免费订阅
								if(res.data.subscribeType == 0) { //- - subscribeType	string	订阅类型0-免费，1-周期性，2-一次性
									$(".columnSubscribeBtn").click(function() {
										insert(userid, id, 1, usertoken);
									});
									
								} else {
									var subscribePay = res.data.subscribePay;
									$(".columnSubscribeBtn").click(function() {
										$(".payMoneyBoxWrap").stop().show();
										payFun(userid, usertoken, subscribePay,id);
										//insert(userid,id,1,usertoken);
									});
									
								}

							}
						}
					}

				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
	}
	//获得专栏内容
	var IndexpageIndex=1;
	var bottomH=150;
	function getColumnContent(id,userid,pageIndex,pageSize,subscribeType,usertoken){
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/column/getColumnContent.do",
			data: {
				"columnId": id,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(pageIndex==1&&res.data==""){
					$(".nullNewNews").stop().show();
					$(".columnNrLoading").stop().hide();
					$(".columnNrNoMore").stop().hide();
				}
				if(pageIndex==1&&res.data.length<10){
					$(".columnNrLoading").stop().hide();
					$(".columnNrNoMore").stop().show();
				}
				if(pageIndex!=1&&res.data==""){
					$(".columnNrLoading").stop().hide();
					$(".columnNrNoMore").stop().show();
				};
				if(pageIndex!=1&&res.data!=""){
					$(window).scroll(function() {
						var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop() + bottomH);
						if($(document).height() <= totalheight) {
							IndexpageIndex++;
							getColumnContent(id,userid,IndexpageIndex,pageSize,subscribeType,usertoken);
						}
					});
				}
				if(res.code === 0) {
					var res=res.data;
					handleDataFun(res,"getColumnContent",subscribeType,userid,id,usertoken);
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
	}
	
	function getFreeLook(id,userid,pageIndex,pageSize,usertoken){
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/column/getFreeLook.do",
			data: {
				"columnId": id,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(pageIndex==1&&res.data.content.length==0){
					   $("#freeLookBoxColumn").stop().hide();
				    }
					var res=res.data.content;
					handleDataFun(res,"getFreeLook","pay",userid,id,usertoken);
					$(".getFreeLookLoading").stop().hide();
					$(".getFreeLookNoMore").stop().show();
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
	}
	
	
	//处理数据
	function handleDataFun(res,dataType,subscribeType,userid,id,usertoken){
		//console.log(res);
		if(subscribeType=="free"){//免费的去掉免费试看
		   $(".freeLookBoxColumn").stop().hide();
		}
		$(res).each(function(i, k) {
			var herfId=k.information.id+subscribeType+dataType+"herfId";
			var objectId=k.information.id;
			var deleteId=k.information.id+subscribeType+dataType+"deleteId";
			var isFreeId=k.information.id+subscribeType+dataType+"isFreeId";
			var isFreeIdBox=k.information.id+subscribeType+dataType+"isFreeIdBox";
			var isFreeLogo=k.information.id+subscribeType+dataType+"isFreeLogo";
			var chooseId=k.information.id+subscribeType+dataType+"chooseId";
			var isFree=k.isFree;//	1-免费试看 2-非免费试看
			var columnId=k.information.columnId;
			if(k.type == 1) { //内容类型（1-视频/音频，2-文章）
				//console.log(k)
				if(k.information.type == 1||k.information.type == 2) { //2.录制视频 3、音频
					var videoIdCover=k.information.id+subscribeType+dataType+"videoIdCover";
					var videoWrap=
					'<div class="videoWrap" id='+herfId+' objectId='+objectId+'>'+
						'<div class="videoL fl">'+
							'<img class="videoCover" id='+videoIdCover+' src="' + k.information.coverUrl + '!220X164">'+
							'<img class="videoSystem" src="images/select.png" />'+ 
							'<span class="videoTime">' + durationFun(new Date(k.information.duration)) + '</span>'+ 
						'</div>'+
						'<div class="videoR fl">'+ 
						  '<p class="videoTitle">' + k.information.topic + '</p>'+ 
						  ' <p class="columnArticleBigBoxRB columnArticleBigBoxRBSame fl"><span id='+isFreeLogo+'>免费试看</span><span>' + format(new Date(k.information.createTime)) + '</span></p>'+
						    '<div class="fr deleteBtn deleteBtnSame">'+
								'<img src="images/gengduo_56.png" />'+
								'<div class="deleteInfoWrap" id='+isFreeIdBox+'>'+
									'<p id='+deleteId+' objectId='+objectId+' type="1" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>删除</p>'+
									'<p id='+chooseId+' objectId='+objectId+' columnId='+columnId+' type="1" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>选择专栏</p>'+
									'<p id='+isFreeId+' objectId='+objectId+' columnId='+id+' isFree='+isFree+' type="1" class="freeLookBtn" isFreeLogoId='+isFreeLogo+'>是否免费试看</p>'+
								'</div>'+
							'</div>'+
						'</div> '+
					'</div>';
					if(dataType=="getColumnContent"){
						$(".columnMiddleTabBoxTab1").append(videoWrap);
						//免费专栏主播视角没有是否免费试看的按钮
						if(subscribeType=="free"){
							$("#"+isFreeId).stop().hide();
				    		$("#"+isFreeIdBox).css({
				    			"height":"70px",
				    		})
						}
					}else if(dataType=="getFreeLook"){
						$(".columnMiddleTabBoxTab2").append(videoWrap);
						$("#"+isFreeId).stop().hide();
			    		$("#"+isFreeIdBox).css({
			    			"height":"70px",
			    		})

					};
					$("#" + videoIdCover).one("error", function(e) {
					   $(this).attr("src", "images/vedioCoverUrl.jpg");
				    });
					if(subscribeType=="free"){//免费专栏可以直接跳转
						$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/video?id=" + id;
					   });
					}else{//付费专栏 判断是否免费试看。免费试看可跳转，不免费试看——判断是否订阅——订阅——可看
						if(isFree==1){
							$("#"+isFreeLogo).stop().show();
							$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/video?id=" + id;
					       });
						}else{//非免费试看
							//是否订阅
							var isSubscribeTypeIntro=$(".columnMiddleBoxTopB2").css("display");
							if(isSubscribeTypeIntro=="block"){//未订阅
								$(document).on("click", "#" + herfId, function(e) {
									$(".payMoney").stop().show();
								})
								
							}else{//已订阅
								$(document).on("click", "#" + herfId, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/video?id=" + id;
								})
								
							}
							
						}
					}
				}else if(k.information.type == 3){//音频
					var ImgArticleWrap=
					'<div class="ImgArticleWrap" id='+herfId+' objectId='+objectId+'>'+
						'<p class="ImgArticleImgTitle">' + k.information.topic + '</p>'+
						'<div class="indexAudioBox">'+
							'<div class="indexAudioBoxL fl">'+
								'<img src="'+ k.information.liverInfo.headImgUrl+'!60X60"/>'+
								'<img src="../images/indexvideo.png"/>'+
							'</div>'+
							'<p class="fl">' + k.information.topic + '</p>'+
							'<p class="fl audioTime">' + durationFun(new Date(k.information.duration)) + '</p>'+
						'</div>'+
						'<p class="columnArticleBigBoxRB columnArticleBigBoxRBSame fl"><span id='+isFreeLogo+'>免费试看</span><span>' + format(new Date(k.information.createTime)) + '</span></p>'+
					    '<div class="fr deleteBtn deleteBtnSame">'+
							'<img src="images/gengduo_56.png" />'+
							'<div class="deleteInfoWrap" id='+isFreeIdBox+'>'+
								'<p id='+deleteId+' objectId='+objectId+' type="1" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>删除</p>'+
								'<p id='+chooseId+' objectId='+objectId+' columnId='+columnId+' type="1" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>选择专栏</p>'+
								'<p id='+isFreeId+' objectId='+objectId+' type="1" columnId='+id+' isFree='+isFree+' class="freeLookBtn" isFreeLogoId='+isFreeLogo+'>是否免费试看</p>'+
							'</div>'+
						'</div>'+
					'</div>';
					
					if(dataType=="getColumnContent"){
						$(".columnMiddleTabBoxTab1").append(ImgArticleWrap);
						if(subscribeType=="free"){
							$("#"+isFreeId).stop().hide();
				    		$("#"+isFreeIdBox).css({
				    			"height":"70px",
				    		})
						}
					}else if(dataType=="getFreeLook"){
						$(".columnMiddleTabBoxTab2").append(ImgArticleWrap);
						$("#"+isFreeId).stop().hide();
			    		$("#"+isFreeIdBox).css({
			    			"height":"70px",
			    		})
					}
					$("#" + videoIdCover).one("error", function(e) {
					   $(this).attr("src", "images/vedioCoverUrl.jpg");
				    });
					if(subscribeType=="free"){//免费专栏可以直接跳转
						$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/audio?id=" + id;
					   });
					}else{//付费专栏 判断是否免费试看。免费试看可跳转，不免费试看——判断是否订阅——订阅——可看
						if(isFree==1){
							$("#"+isFreeLogo).stop().show();
							$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/audio?id=" + id;
					       });
						}else{//非免费试看
							//是否订阅
							var isSubscribeTypeIntro=$(".columnMiddleBoxTopB2").css("display");
							if(isSubscribeTypeIntro=="block"){//未订阅
								$(document).on("click", "#" + herfId, function(e) {
									$(".payMoney").stop().show();
								})
								
							}else{//已订阅
								$(document).on("click", "#" + herfId, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/audio?id=" + id;
								})
								
							}
							
						}
					}
				}
			} else if(k.type == 2) {
				//console.log(k);
				var articleContent = k.information.content;
				var content = htmlEncode(articleContent);
				if(k.information.coverUrl) { //运营设计
					var chooseIdArticleHaveImg=k.information.id+subscribeType+dataType+"chooseIdArticleHaveImg";
			    	var columnArticleBigBox=
			    	'<div class="columnArticleBigBox" id='+herfId+' objectId='+objectId+'>'+
						'<img class="columnArticleBigImg fl" id='+chooseIdArticleImg+' src="' + k.information.coverUrl + '!220X164"/>'+
						'<div class="columnArticleBigBoxR fl">'+
							'<h2>' + k.information.title + '</h2>'+
							'<p class="columnArticleBigImgIntro">'+ removeHTMLTag(content) +'</p>'+
						   ' <p class="columnArticleBigBoxRB fl"><span id='+isFreeLogo+'>免费试看</span><span>' + format(new Date(k.information.createTime)) + '</span></p>'+
						    '<div class="fr deleteBtn">'+
								'<img src="images/gengduo_56.png" />'+
								'<div class="deleteInfoWrap" id='+isFreeIdBox+'>'+
									'<p id='+deleteId+' objectId='+objectId+' type="2" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>删除</p>'+
									'<p id='+chooseId+' objectId='+objectId+' type="2" uid='+userid+' token='+usertoken+' columnId='+columnId+' fatherId='+herfId+'>选择专栏</p>'+
									'<p id='+isFreeId+' objectId='+objectId+' isFree='+isFree+' type="2" columnId='+id+' class="freeLookBtn" isFreeLogoId='+isFreeLogo+'>是否免费试看</p>'+
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>';
					if(dataType=="getColumnContent"){
						$(".columnMiddleTabBoxTab1").append(columnArticleBigBox);
						if(subscribeType=="free"){
							$("#"+isFreeId).stop().hide();
				    		$("#"+isFreeIdBox).css({
				    			"height":"70px",
				    		})
						}
					}else if(dataType=="getFreeLook"){
						$(".columnMiddleTabBoxTab2").append(columnArticleBigBox);
						$("#"+isFreeId).stop().hide();
			    		$("#"+isFreeIdBox).css({
			    			"height":"70px",
			    		})
					};
				   $("#" + chooseIdArticleImg).one("error", function(e) {
					   $(this).attr("src", "images/vedioCoverUrl.jpg");
				    });
					if(subscribeType=="free"){//免费专栏可以直接跳转
						$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/article?id=" + id;
					   });
					}else{//付费专栏 判断是否免费试看。免费试看可跳转，不免费试看——判断是否订阅——订阅——可看
						if(isFree==1){
							$("#"+isFreeLogo).stop().show();
							$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/article?id=" + id;
					       });
						}else{//非免费试看
							//是否订阅
							var isSubscribeTypeIntro=$(".columnMiddleBoxTopB2").css("display");
							if(isSubscribeTypeIntro=="block"){//未订阅
								$(document).on("click", "#" + herfId, function(e) {
									$(".payMoney").stop().show();
								})
								
							}else{//已订阅
								$(document).on("click", "#" + herfId, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/article?id=" + id;
								})
								
							}
							
						}
					}
				}else if(k.information.userCoverUrl){
					var chooseIdArticleHaveImg=k.information.id+subscribeType+dataType+"chooseIdArticleHaveImg";
			    	var columnArticleBigBox=
			    	'<div class="columnArticleBigBox" id='+herfId+' objectId='+objectId+'>'+
						'<img class="columnArticleBigImg fl" id='+chooseIdArticleImg+' src="' + k.information.userCoverUrl + '!220X164"/>'+
						'<div class="columnArticleBigBoxR fl">'+
							'<h2>' + k.information.title + '</h2>'+
							'<p class="columnArticleBigImgIntro">'+ removeHTMLTag(content) +'</p>'+
						   ' <p class="columnArticleBigBoxRB fl"><span id='+isFreeLogo+'>免费试看</span><span>' + format(new Date(k.information.createTime)) + '</span></p>'+
						    '<div class="fr deleteBtn">'+
								'<img src="images/gengduo_56.png" />'+
								'<div class="deleteInfoWrap" id='+isFreeIdBox+'>'+
									'<p id='+deleteId+' objectId='+objectId+' type="2" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>删除</p>'+
									'<p id='+chooseId+' objectId='+objectId+' type="2" uid='+userid+' token='+usertoken+' columnId='+columnId+' fatherId='+herfId+'>选择专栏</p>'+
									'<p id='+isFreeId+' objectId='+objectId+' isFree='+isFree+' type="2" columnId='+id+' class="freeLookBtn" isFreeLogoId='+isFreeLogo+'>是否免费试看</p>'+
								'</div>'+
							'</div>'+
						'</div>'+
					'</div>';
					if(dataType=="getColumnContent"){
						$(".columnMiddleTabBoxTab1").append(columnArticleBigBox);
						if(subscribeType=="free"){
							$("#"+isFreeId).stop().hide();
				    		$("#"+isFreeIdBox).css({
				    			"height":"70px",
				    		})
						}
					}else if(dataType=="getFreeLook"){
						$(".columnMiddleTabBoxTab2").append(columnArticleBigBox);
						$("#"+isFreeId).stop().hide();
			    		$("#"+isFreeIdBox).css({
			    			"height":"70px",
			    		})
					};
				   $("#" + chooseIdArticleImg).one("error", function(e) {
					   $(this).attr("src", "images/vedioCoverUrl.jpg");
				    });
					if(subscribeType=="free"){//免费专栏可以直接跳转
						$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/article?id=" + id;
					   });
					}else{//付费专栏 判断是否免费试看。免费试看可跳转，不免费试看——判断是否订阅——订阅——可看
						if(isFree==1){
							$("#"+isFreeLogo).stop().show();
							$(document).on("click", "#" + herfId, function(e) {
							var id = $(this).attr("objectId");
							window.location.href = "/article?id=" + id;
					       });
						}else{//非免费试看
							//是否订阅
							var isSubscribeTypeIntro=$(".columnMiddleBoxTopB2").css("display");
							if(isSubscribeTypeIntro=="block"){//未订阅
								$(document).on("click", "#" + herfId, function(e) {
									$(".payMoney").stop().show();
								})
								
							}else{//已订阅
								$(document).on("click", "#" + herfId, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/article?id=" + id;
								})
								
							}
							
						}
					}
					
				}else{
					var imgReg = /<img.*?(?:>|\/>)/gi;
					//匹配src属性
					var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
					var imgArr = content.match(imgReg); //'所有已成功匹配图片的数组
					if(imgArr == null) {
						var columnArticleBigBoxNull=
				    	'<div class="columnArticleBigBox columnArticleBigBoxNull" id='+herfId+' objectId='+objectId+'>'+
							'<div class="columnArticleBigBoxR fl columnArticleNullBigBox">'+
								'<h2>' + k.information.title + '</h2>'+
								'<p class="columnArticleBigImgIntro">'+ removeHTMLTag(content) +'</p>'+
							   '<p class="columnArticleBigBoxRB columnArticleBigBoxRBSame fl"><span id='+isFreeLogo+'>免费试看</span><span>' + format(new Date(k.information.createTime)) + '</span></p>'+
							    '<div class="fr deleteBtn deleteBtnSame">'+
									'<img src="images/gengduo_56.png" />'+
									'<div class="deleteInfoWrap" id='+isFreeIdBox+'>'+
										'<p id='+deleteId+' objectId='+objectId+' type="2" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>删除</p>'+
										'<p id='+chooseId+' objectId='+objectId+' columnId='+columnId+' type="2" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>选择专栏</p>'+
										'<p id='+isFreeId+' isFree='+isFree+' objectId='+objectId+' type="2" columnId='+id+' class="freeLookBtn" isFreeLogoId='+isFreeLogo+'>是否免费试看</p>'+
									'</div>'+
								'</div>'+
							'</div>'+
						"</div>";
						if(dataType=="getColumnContent"){
							$(".columnMiddleTabBoxTab1").append(columnArticleBigBoxNull);
							if(subscribeType=="free"){
								$("#"+isFreeId).stop().hide();
					    		$("#"+isFreeIdBox).css({
					    			"height":"70px",
					    		})
							}
						}else if(dataType=="getFreeLook"){
							$(".columnMiddleTabBoxTab2").append(columnArticleBigBoxNull);
							$("#"+isFreeId).stop().hide();
				    		$("#"+isFreeIdBox).css({
				    			"height":"70px",
				    		})
						};
						
//						$("#" + videoIdCover).one("error", function(e) {
//						   $(this).attr("src", "images/vedioCoverUrl.jpg");
//					    });
						if(subscribeType=="free"){//免费专栏可以直接跳转
							$(document).on("click", "#" + herfId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/article?id=" + id;
						   });
						}else{//付费专栏 判断是否免费试看。免费试看可跳转，不免费试看——判断是否订阅——订阅——可看
							if(isFree==1){
								$("#"+isFreeLogo).stop().show();
								$(document).on("click", "#" + herfId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/article?id=" + id;
						       });
							}else{//非免费试看
								//是否订阅
								var isSubscribeTypeIntro=$(".columnMiddleBoxTopB2").css("display");
								if(isSubscribeTypeIntro=="block"){//未订阅
									$(document).on("click", "#" + herfId, function(e) {
										$(".payMoney").stop().show();
									})
									
								}else{//已订阅
									$(document).on("click", "#" + herfId, function(e) {
										var id = $(this).attr("objectId");
										window.location.href = "/article?id=" + id;
									})
									
								}
								
							}
						}
					}else{
						src = imgArr[0].match(srcReg);
						var chooseIdArticleImg=k.information.id+subscribeType+dataType+"chooseIdArticleImg";
						if(src[1]) {
							var columnArticleBigBox=
					    	'<div class="columnArticleBigBox" id='+herfId+' objectId='+objectId+'>'+
								'<img class="columnArticleBigImg fl" id='+chooseIdArticleImg+' src="' +src[1]+ '"/>'+
								'<div class="columnArticleBigBoxR fl">'+
									'<h2>' + k.information.title + '</h2>'+
									'<p class="columnArticleBigImgIntro">'+ removeHTMLTag(content) +'</p>'+
								   ' <p class="columnArticleBigBoxRB fl"><span id='+isFreeLogo+'>免费试看</span><span>' + format(new Date(k.information.createTime)) + '</span></p>'+
								    '<div class="fr deleteBtn">'+
										'<img src="images/gengduo_56.png" />'+
										'<div class="deleteInfoWrap" id='+isFreeIdBox+'>'+
											'<p id='+deleteId+' objectId='+objectId+' type="2" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>删除</p>'+
											'<p id='+chooseId+' objectId='+objectId+' columnId='+columnId+' type="2" uid='+userid+' token='+usertoken+' fatherId='+herfId+'>选择专栏</p>'+
											'<p id='+isFreeId+' objectId='+objectId+' isFree='+isFree+' type="2" columnId='+id+' class="freeLookBtn" isFreeLogoId='+isFreeLogo+'>是否免费试看</p>'+
										'</div>'+
									'</div>'+
								'</div>'+
							'</div>';
							if(dataType=="getColumnContent"){
								$(".columnMiddleTabBoxTab1").append(columnArticleBigBox);
								if(subscribeType=="free"){
									$("#"+isFreeId).stop().hide();
						    		$("#"+isFreeIdBox).css({
						    			"height":"70px",
						    		})
								}
							}else if(dataType=="getFreeLook"){
								$(".columnMiddleTabBoxTab2").append(columnArticleBigBox);
								$("#"+isFreeId).stop().hide();
					    		$("#"+isFreeIdBox).css({
					    			"height":"70px",
					    		})
							};
							$("#" + chooseIdArticleImg).one("error", function(e) {
							   $(this).attr("src", "images/vedioCoverUrl.jpg");
						    });
							if(subscribeType=="free"){//免费专栏可以直接跳转
								$(document).on("click", "#" + herfId, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/article?id=" + id;
							   });
							}else{//付费专栏 判断是否免费试看。免费试看可跳转，不免费试看——判断是否订阅——订阅——可看
								if(isFree==1){
									$("#"+isFreeLogo).stop().show();
									$(document).on("click", "#" + herfId, function(e) {
									var id = $(this).attr("objectId");
									window.location.href = "/article?id=" + id;
							       });
								}else{//非免费试看
									//是否订阅
									var isSubscribeTypeIntro=$(".columnMiddleBoxTopB2").css("display");
									if(isSubscribeTypeIntro=="block"){//未订阅
										$(document).on("click", "#" + herfId, function(e) {
											$(".payMoney").stop().show();
										})
										
									}else{//已订阅
										$(document).on("click", "#" + herfId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/article?id=" + id;
										})
										
									}
									
								}
							}
						}
					}
				}
			}
			
			//删除
			$(document).on("click", "#" + deleteId, function(event) {
			    event.stopPropagation();
				var id = $(this).attr("objectId");
				var type = $(this).attr("type");//type=1音视频 type=2文章
				var uid = $(this).attr("uid");
				var token = $(this).attr("token");
				var fatherId = $(this).attr("fatherId");
				if(type==1){
					deleteVideoAudioFun(uid,token,id,fatherId);
				}else if(type==2){
					deleteArticleFun(id,fatherId);
				}
			});
			//选择专栏
			$(document).on("click", "#" + chooseId, function(event) {
			    event.stopPropagation();
				var id = $(this).attr("objectId");
				var type = $(this).attr("type");//type=1视频 type==2//文章
				var uid = $(this).attr("uid");
				var token = $(this).attr("token");
				var fatherId = $(this).attr("fatherId");
				$(".chooseColumnBox").stop().show();
				getColumnByUid(uid,1,20,id,type,token,fatherId);
			});
			//是否免费试看
			var isfreeLogo=$("#"+isFreeId).attr("isfree");
			if(isfreeLogo==1){
				$("#"+isFreeId).html("取消免费试看")
			}else if(isfreeLogo==2){
				$("#"+isFreeId).html("设为免费试看")
			}
			$(document).on("click", "#" + isFreeId, function(event) {
			    event.stopPropagation();
				var id = $(this).attr("objectId");
				var type = $(this).attr("type");
				var columnId = $(this).attr("columnId");
				var isfree = $(this).attr("isfree");//1-免费试看 2-非免费试看
				var isFreeLogoId = $(this).attr("isFreeLogoId");//1-免费试看 2-非免费试看
				//console.log(isfree);
				//$(".yesNoFreeLookBox").stop().show();
				setFreeLook(id, type, columnId,isFreeLogoId,isFreeId);
			});
	   })
		
	    if(userid==columnIdUid){//主播自己
	    	$(".deleteBtn").stop().show();
		}
		
		
		
		
	}
	clearTimeout(time1);
	/*是否免费试看*/
	var time1,time2,time3,time4,time5,time6,time7;
	for(var i=1;i<8;i++){
		clearTimeout("time"+i);
	}
	function setFreeLook(id, type, columnId,isFreeLogoId,isFreeId) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/column/setFreeLook.do",
			data: {
				"id": id,
				"type": type,
				"columnId": columnId,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.type==1){//1-成功设置免费试看 2-成功取消免费试看
						layer.msg("成功设置免费试看");
						$("#"+isFreeId).html("取消免费试看");
						$("#"+isFreeLogoId).stop().show();
					}else if(res.data.type==2){
						layer.msg("成功取消免费试看");
						$("#"+isFreeLogoId).stop().hide();
						$("#"+isFreeId).html("设为免费试看");
					}
				}else if(res.code == -16){
					layer.msg("音视频不存在");
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})

	}
	
	/*删除状态*/
	//删除音视频
	function deleteVideoAudioFun(uid,token,id,fatherId){
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/video/delete.do",
			data: {
				"uid": uid,
				"token": token,
				"id": id,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					layer.msg("删除成功");
					$("#"+fatherId).remove();
				}else if(res.code == -16){
					layer.msg("该音视频不存在");
					$("#"+fatherId).remove();
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
	}
	//删除文章
	function deleteArticleFun(id,fatherId){
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/article/deleteArticle.do",
			data: {
				"id": id,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					layer.msg("删除成功");
					$("#"+fatherId).remove();
				}else if(res.code==-27){
					layer.msg("已删除");
				    $("#"+fatherId).remove();
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
	}
	/*获得主播所有专栏*/
	function getColumnByUid(uid,pageIndex,pageSize,id,type,token,fatherId){
		$.ajax({
				type: "post", //请求方式
				async: true, //是否异步
				dataType: "json",
				url:"/api/v3/column/getColumnByUid.do",
				data:{
					"uid": uid,
					"type":2,//类型 （0=免费，1=VIP，2=全部）
					"pageIndex":pageIndex,
					"pageSize":pageSize,
				},
				success:function(res){
					//console.log(res);
					if(res.code==0){
						$(res.data).each(function(i,Q){
							var columnId=Q.id;
							var chooseColumnListInfoLogo=Q.id+"chooseColumnListInfoLogo";
							var chooseColumnListInfoBox=Q.id+"chooseColumnListInfoBox";
							var chooseColumnListInfoBox=
							'<li class="chooseColumnListInfoBox" id='+chooseColumnListInfoBox+' objectId='+columnId+'>'+
				    			'<p class="chooseColumnListInfo fl">'+Q.name+'</p>'+
				    			'<img class="fl chooseColumnListInfoLogo" id='+chooseColumnListInfoLogo+' src="../images/tiaoxuan.png"/>'+
		    			    '</li>';
		    			    $(".chooseColumnListBox").append(chooseColumnListInfoBox);
		    			    var nowColumnId = GetQueryString("id");
		    			   
		    			    if(columnId==nowColumnId){
		    			    	$("#"+chooseColumnListInfoLogo).stop().show();
		    			    }else{
		    			    	$("#"+chooseColumnListInfoLogo).stop().hide();
		    			    }
						});
						$(".chooseColumnListInfoBox").click(function(){
							var columnId = $(this).attr("objectId");//专栏id；
							$(".chooseColumnListInfoLogo").stop().hide();
							$(".chooseColumnListInfoLogo").eq($(this).index()).css("display", "block");
							$(".columnChooseSaveBtn").attr("columnId",columnId);
						});
						//保存
						$(".columnChooseSaveBtn").click(function(){
							var columnId = $(this).attr("columnId");//专栏id；
							editColumnFun(token,columnId,uid,id,type,0);
							$(".chooseColumnBox").stop().hide();
							time7=setTimeout(function(){
								parent.location.reload();
							},3000)
						})
						
					}

				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				},
		})
	}
	
	//编辑专栏
	//operation -操作类型（0-移动至专栏，1-从专栏移除）
	function editColumnFun(token,columnId,uid,id,type,operation){
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/column/edit.do",
			data: {
				"token": token,
				"columnId": columnId,
				"uid": uid,
				"id": id,
				"type": type,
				"operation": operation,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					layer.msg("修改成功");
				}else if(res.code == -1){//不选择专栏
					var moveColumnId=GetQueryString("id");
					editColumnFun(token,moveColumnId,uid,id,type,1);
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})
		
		
	}
	
	
	
	
	//新增订阅/重新订阅（type=1专栏订阅，type=2直播间订阅）
	function insert(uid, objectId, type, token) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/subscribe/insert.do",
			data: {
				"uid": uid,
				"objectId": objectId,
				"type": type,
				"token": token,
			},
			success: function(res) {
				if(res.code == 0) {
					layer.msg("订阅成功");
					$(".columnMiddleBoxTopB3").stop().show();
					$(".columnMiddleBoxTopB2").stop().hide();
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		})

	}
	//获取用户的余额数
	function payFun(userId, usertoken, subscribePay,id) {
		/*充值接口*/
		$.ajax({
			type: "POST",
			async: true,
			dataType: "json",
			url: "/api/v1/account/selectByWhere.do",
			data: {
				"uid": userId,
				"coinType": "RECHARGE_COIN",
				"token": usertoken,
			},
			success: function(res) {
				if(res.code == 0) {
					$(".balanceCoin").html(res.data[0].coinNumber + "牛币");
					var coinNumberUserid = res.data[0].coinNumber;
					//console.log(subscribePay);
					//console.log(coinNumberUserid);
					if(subscribePay > coinNumberUserid) {
						$(".payColumnUpBtn").html("余额不足，去充值");
						$(".payColumnUpBtn").click(function() {
							$(".payMoneyBoxWrap").stop().hide();
							$("#n_money").stop().show();
							$("#exceptWrap").stop().show()
						});
						wxUnifiedOrder(userId,usertoken);
					} else {
						$(".payColumnUpBtn").html("立即支付");
						$(".payColumnUpBtn").click(function(){
							insert(userId, id, 1, usertoken);
							$(".payMoneyBoxWrap").stop().hide();
						});
						
					}
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		});
	}
	function wxUnifiedOrder(userId,usertoken) {
		$(".qitaMoney").focus(function() {
			$(this).removeAttr("placeholder");
			$(".moneyAlert").stop().show()
		});
		$(".qitaMoney").blur(function() {
			$(this).attr("placeholder", "其他金额");
			$(".moneyAlert").stop().hide()
		});
		$(".payBtn").click(function() {
			var totalFee = "";
			if($(".qitaMoney").val() != "") {
				totalFee = parseInt($(".qitaMoney").val());
				//console.log(totalFee)
			} else {
				totalFee = parseInt($(".money_list").find(".click_effect").children().text())
			}
			$(".weChatPayNum").html(totalFee);
			$.ajax({
				type: "POST",
				async: true,
				dataType: "json",
				url: "/api/v1/order/wxUnifiedOrder.do",
				data: {
					"uid": userId,
					"totalFee": totalFee,
					"tradeType": "NATIVE",
					"token": usertoken,
				},
				success: function(res) {
					if(res.code == 0) {
						$("#n_money").fadeOut(1);
						$("#exceptWrap").fadeIn(1);
						$(".weChatCodeWrap").fadeIn(1);
						var codeUrl = res.data.codeUrl;
						var outTradeNo = res.data.outTradeNo;
						//console.log(outTradeNo);
						jQuery("#weChatPayCode").qrcode({
							render: "canvas",
							foreground: "#000",
							background: "#FFF",
							width: 180,
							height: 180,
							text: codeUrl,
							correctLevel: 2
						});
						intervalTime = setInterval(function() {
							$.ajax({
								type: "POST",
								async: true,
								dataType: "json",
								url: "/api/v1/order/wxFrontNotify.do",
								data: {
									"uid": userId,
									"outTradeNo": outTradeNo,
									"token": usertoken,
								},
								success: function(res) {
									//	console.log(res);
									if(res.code == 0) {
										$(".weChatCodeWrap").stop().hide();
										$(".weChatPaySuccess").stop().show();

									}
								},
								error: function(XMLHttpRequest, textStatus, errorThrown) {
									console.log(XMLHttpRequest.status);
									console.log(XMLHttpRequest.readyState);
									console.log(textStatus)
								}
							})
						}, 3000)
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				}
			})
		})
	}
	
	
	
	//关闭框X
	$(".payMoneyBoxT").click(function(){
		$(".payMoneyBoxWrap").stop().hide();
	})
	//充值弹框
	$(".money_listinfo").click(function() {
		$(this).addClass("click_effect").siblings().removeClass("click_effect")
	});
	/*关闭框*/
	$(".alertClose").click(function() {
		$("#n_money").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".weChatClose").click(function() {
		$(".weChatCodeWrap").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".qitaMoney").val("");
		$("#weChatPayCode").html("");
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".weChatSuccessClose").click(function() {
		$(".weChatPaySuccess").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".qitaMoney").val("");
		$("#weChatPayCode").html("");
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".closePay").click(function(){
		$(".payMoney").stop().hide();
	})
	
    //专栏介绍
    $(".seeColumnIntro").click(function(){
    	var locationHref=window.location.href;
    	window.location.href=locationHref+"&tab=2";
    })
    
    $(".chooseColumnBoxT").click(function() {
		$(".chooseColumnBox").stop().hide();
	});
    
    
    $(".columnChooseCancleBtn").click(function() {
		$(".chooseColumnBox").stop().hide();
	});
    
    //固定条
    $(window).scroll(function() {
		var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop()+140);
		if($(document).height() <= totalheight) {
			$(".columnAlertBoxInfo").css({
				"bottom":"360px"
			})
		}else{
			$(".columnAlertBoxInfo").css({
				"bottom":"0"
			})
		}
	});
    
    var id = GetQueryString("id");
    //页面跳转
	function browserRedirect() {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		var bIsMidp = sUserAgent.match(/midp/i) == "midp";
		var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		var bIsAndroid = sUserAgent.match(/android/i) == "android";
		var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
		if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
			window.location.href = "https://www.fntv8.com/m/v5.0/columnDetail?id=" + id;
		}
	}
	browserRedirect();
    
    
    
    
    
    
    
    
    
})