$(document).ready(function () {
	var columnId = GetQueryString("id");
    var userId;
    var usertoken;
    var uid;
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");

    //APP下载二维码
    $(".saoma").mouseenter(function() {
        $(".indexCode").fadeIn(200);
    });
    $(".saoma").mouseleave(function() {
        $(".indexCode").fadeOut(200);
    });

    // 检查用户是否登录
    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function (res) {
            // console.log(res);
            if (res.code == -2) { //未登录
                getColumnDetail1();
                columnContent1(1);
                // 专栏内容下拉加载更多
                var pageIndex1=1;
                $(window).on('scroll', function () {
                    if($(document).scrollTop() + $(window).height() >= $(document).height()){
                        pageIndex1++;
                        columnContent1(pageIndex1);
                    }
                });
                $(document).on("click",".columnDetailZanImg",function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
                $(".focus").on("click",function(){
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                });
            }else if(res.code==0){//已登录
                userId = res.data.userInfo.uid;
                usertoken = res.data.token;
                getColumnDetail2();
                columnContent2(1);
                // 专栏内容下拉加载更多
                var pageIndex2=1;
                $(window).on('scroll', function () {
                    if($(document).scrollTop() + $(window).height() >= $(document).height()){
                        pageIndex2++;
                        columnContent2(pageIndex2);
                    }
                });
            }
        }
    })
    // 获取专栏详情(未登录)
    function getColumnDetail1(){
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v2/column/getColumnDetail.do",
            data: {
                "columnId": columnId,
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    var coverUrl=res.data.coverUrl;
                    var name=res.data.name;
                    var introduction=res.data.introduction;
                    var watchCount=res.data.watchCount;
                    var contentCount=res.data.contentCount;
                    var headImgUrl=res.data.liverInfo.headImgUrl;
                    uid=res.data.liverInfo.uid;
                    var nickName=res.data.liverInfo.nickName;
                    $("title").html(name+"_财经资讯-疯牛直播");
                    $("#descriptionId").attr("content",introduction);
                    $("#keywordsId").attr("content",nickName+"，今日大盘走势，今日股评，股市分析，股票博客，股市新闻，股市最新消息，疯牛直播");
                    if(headImgUrl!=""){
                        $(".columnDetailAll .instruction .number .headImg").attr("src",headImgUrl);
                        $(".columnDetailAll .instruction .number .headImg").attr("uid",uid);
                    }
                    $(".topImg .columnImg").attr("style","background-image: url('"+coverUrl+"!158X212"+"')");
                    $(".midleImg .columnTu").attr("src",coverUrl+"!158X212");
                    $(".columnDetailAll .instruction .name").html(name);
                    $(".columnDetailAll .instruction .introduce").html(introduction);
                    $(".columnDetailAll .instruction .number .watch").html(watchCount+"人");
                    $(".columnDetailAll .instruction .number .content").html(contentCount+"条");
                    $(".columnDetailAll .instruction .number .from").html(nickName);
                    $(".columnDetailAll .instruction .number .headImg").click(function () {
                        window.location.href ="/userProfile?uid="+uid;
                    })
                    getColumnList(uid);
                }
            }
        })
    }
    // 获取专栏详情(已登录)
    function getColumnDetail2(){
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v2/column/getColumnDetail.do",
            data: {
                "columnId": columnId,
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    var coverUrl=res.data.coverUrl;
                    var name=res.data.name;
                    var introduction=res.data.introduction;
                    var watchCount=res.data.watchCount;
                    var contentCount=res.data.contentCount;
                    var headImgUrl=res.data.liverInfo.headImgUrl;
                    uid=res.data.liverInfo.uid;
                    var nickName=res.data.liverInfo.nickName;
                    //检查是否关注
                    $.ajax({
                        type: "POST",
                        async: true,
                        dataType: "json",
                        url: "/api/v1/user/checkFollowing.do",
                        data: {
                            "receptorId": uid,
                            "uid": userId,
                            "token": usertoken,
                        },
                        success: function (res) {
                            if (res.code == 0) {
                                // console.log(res);
                                var isFocus = res.data;
                                if (isFocus == 1) {//已关注
                                    $(".focus").attr("src", "../images/attentionp.png");
                                }
                            }
                        }
                    });
                    $("title").html(name);
                    if(headImgUrl!=""){
                        $(".columnDetailAll .instruction .number .headImg").attr("src",headImgUrl);
                        $(".columnDetailAll .instruction .number .headImg").attr("uid",uid);
                    }
                    $(".topImg .columnImg").attr("style","background-image: url('"+coverUrl+"!158X212"+"')");
                    $(".midleImg .columnTu").attr("src",coverUrl+"!158X212");
                    $(".columnDetailAll .instruction .name").html(name);
                    $(".columnDetailAll .instruction .introduce").html(introduction);
                    $(".columnDetailAll .instruction .number .watch").html(watchCount+"人");
                    $(".columnDetailAll .instruction .number .content").html(contentCount+"条");
                    $(".columnDetailAll .instruction .number .from").html(nickName);
                    $(".columnDetailAll .instruction .number .headImg").click(function () {
                        window.location.href ="/userProfile?uid="+uid;
                    })
                    //获取主播专栏列表
                    getColumnList(uid);
                    // 检查是否关注
                    checkFocus(uid);
                }
            }
        })
    }
    //获取主播专栏列表
    function getColumnList(uid){
        $.ajax({
            type: "GET",
            async: true,
            dataType: "json",
            url: "/api/v2/column/getColumnByUid.do",
            data: {
                "uid": uid,
                "pageIndex": 1,
                "pageSize": 5,
            },
            success: function (res) {
                if (res.code == 0) {
                    //console.log(res);
                    var length=res.data.length;
                    if(length==0){
                        $(".elseColumn").stop().hide();
                    }
                    $(res.data).each(function (i, k) {
                        var coverUrl=k.coverUrl;
                        var id=k.id;
                        var introduction=k.introduction;
                        var name=k.name;
                        var elseColumnList="<li><a href='/columnDetail?id="+id+"'>"+
                            "<img src='"+coverUrl+"' alt='' />"+
                            "<div class='right'>"+
                            "<p class='title'>"+name+"</p>"+
                            "<p class='content'>"+introduction+"</p>"+
                            "</div>"+
                            "</a></li>";
                        $(".right .elseColumn ul").append(elseColumnList);
                    })
                }
            }
        })
    }
    // 检查是否关注
    function checkFocus(uid) {
        $(".focus").click(function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v1/user/checkFollowing.do",
                data: {
                    "receptorId": uid,
                    "uid": userId,
                    "token": usertoken,
                },
                success: function (res) {
                    if (res.code == 0) {
                        // console.log(res);
                        var isFocus = res.data;
                        if (isFocus == 1) {//已关注
                            $(".focus").attr("src", "../images/attentionp.png");
                            //取消关注
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/user/deleteFollow.do",
                                data: {
                                    "receptorId": uid,
                                    "uid": userId,
                                    "token": usertoken,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        console.log(res);
                                        $(".focus").attr("src", "./images/attention.png");
                                    }
                                }
                            })
                        } else {
                            //关注
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/user/following.do",
                                data: {
                                    "receptorId": uid,
                                    "uid": userId,
                                    "token": usertoken,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        // console.log(res);
                                        $(".focus").attr("src", "../images/attentionp.png");
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }
    //获取专栏内容(未登录)
    function columnContent1(pageIndex1){
        $.ajax({
            type: "GET",
            async: true,
            dataType: "json",
            url: "/api/v2/column/getColumnContent.do",
            data: {
                "columnId": columnId,
                "pageIndex": pageIndex1,
                "pageSize": 10,
            },
            success: function (res) {
                if (res.code == 0) {
                    //console.log(res);
                    if(res.data=="" && pageIndex1==1){
                        $(".quesheng").stop().show();
                        $(".loading").stop().hide();
                    }
                    var length=res.data.length;
                    if(length<10 && res.data!=""){
                        $(".loading").stop().hide();
                        $(".loadEnd").stop().show();
                    }
                    $(res.data).each(function(i,k) {
                        var type=k.type;
                        var createTime=k.information.createTime;
                        var id=k.information.id;
                        var headImgUrl=k.information.liverInfo.headImgUrl;
                        var uid=k.information.liverInfo.uid;
                        var nickName=k.information.liverInfo.nickName;
                        var title=k.information.title;
                        var content=k.information.content;
                        var topic=k.information.topic;
                        var duration=k.information.duration;
                        var coverUrl=k.information.coverUrl;
                        var watchCount=k.information.watchCount;
                        var praiseCount=k.information.praiseCount;
                        if(type==0){//直播
                            var liveContent="<div class='liveWrap'>"+
                                            "<a href='/live?uid="+uid+"'><div class='liveL fl'>"+
                                            "<img class='liveCover' src='"+coverUrl+"!220X164"+"' />"+
                                            "<img class='liveSystem' src='images/indexlive.png' />"+
                                            "</div></a>"+
                                            "<div class='videoR fl'>"+
                                            "<div class='videoRPosition'>"+
                                            "<p class='videoTitle'>"+topic+"</p>"+
                                            "<p class='videoRBottom'>"+
                                            "<span class='videoImgAnchorNickName fl'>"+watchCount+"人已看</span>"+
                                            "<img class='columnDetailZanImg' id='"+id+"' src='../images/rewardIcon.png' alt='' />"+
                                            "<span class='columnDetailZanNum'>"+praiseCount+"</span>"+
                                            "<span class='videoImgTime fl'>"+format(new Date(createTime))+"</span>"+
                                            "</p></div></div></div>";
                            $(".loading").before(liveContent);
                        }else if(type==1){//视频
                            var videoContent="<div class='videoWrap'>"+
                                            "<a href='/video?id="+id+"'><div class='videoL fl'>"+
                                            "<img class='videoCover' src='"+coverUrl+"!220X164"+"' />"+
                                            "<img class='videoSystem' src='images/indexvideo.png' />"+
                                            "<span class='videoTime'>"+formatMS1(duration)+"</span>"+
                                            "</div></a>"+
                                            "<div class='videoR fl'>"+
                                            "<div class='videoRPosition'>"+
                                            "<p class='videoTitle'>"+topic+"</p>"+
                                            "<p class='videoRBottom'>"+
                                            "<span class='videoImgAnchorNickName fl'>"+watchCount+"人已看</span>"+
                                            "<img class='columnDetailZanImg' id='"+id+"' src='../images/rewardIcon.png' alt='' />"+
                                            "<span class='columnDetailZanNum'>"+praiseCount+"</span>"+
                                            "<span class='videoImgTime fl'>"+format(new Date(createTime))+"</span>"+
                                            "</p> </div> </div> </div>";
                            $(".loading").before(videoContent);
                        }else if(type==2){//文章
                            var coverUrl = k.information.coverUrl;
                            if(coverUrl==""){//无图文章
                                var content=htmlEncode(k.information.content);
                                var articleContent="<div class='ImgArticleWrap'>"+
                                                    "<a href='/article?id="+id+"'><p class='ImgArticleImgTitle'>"+title+"</p></a>"+
                                                    "<p class='ImgArticleImgInner'>"+removeHTMLTag(content)+"</p>"+
                                                    "<p>"+
                                                    "<span class='ImgArticleImgAnchorNickName fl'>"+watchCount+"人已看</span>"+
                                                    "<img class='columnDetailZanImg' id='"+id+"' src='../images/rewardIcon.png' alt='' />"+
                                                    "<span class='columnDetailZanNum'>"+praiseCount+"</span>"+
                                                    "<span class='mgArticleImgTime fl'>"+format(new Date(createTime))+"</span>"+
                                                    "</p>"+
                                                    "</div>";
                                $(".loading").before(articleContent);
                                //文章无图，显示内容一行半
                                $(".ImgArticleImgInner").each(function() {
                                    var shortReviewText = $(this).text().substring(0, 80) + "...";
                                    if($(this).text().length > 80) {
                                        $(this).text(shortReviewText);
                                    }
                                });
                            }else{//带图文章
                                var content=htmlEncode(k.information.content);
                                var oneImgarticleContent="<div class='oneImgArticleWrap'>"+
                                                        "<a href='/article?id="+id+"'><img class='fl oneImgArticleImg' src='"+coverUrl+"' /></a>"+
                                                        "<div class='oneImgArticleImgR'>"+
                                                        "<a href='/article?id="+id+"'><p class='oneImgArticleImgTitle'>"+title+"</p></a>"+
                                                        "<p class='oneImgArticleImgInner'>"+removeHTMLTag(content)+"</p>"+
                                                        "<p>"+
                                                        "<span class='oneImgArticleImgAnchorNickName fl'>"+watchCount+"人已看</span>"+
                                                        "<img class='columnDetailZanImg' id='"+id+"' src='../images/rewardIcon.png' alt='' />"+
                                                        "<span class='columnDetailZanNum'>"+praiseCount+"</span>"+
                                                        "<span class='oneImgArticleImgTime fl'>"+format(new Date(createTime))+"</span>"+
                                                        "</p> </div> </div>";
                                $(".loading").before(oneImgarticleContent);
                                //文章无图，显示内容一行半
                                $(".oneImgArticleImgInner").each(function() {
                                    var shortReviewText = $(this).text().substring(0, 60) + "...";
                                    if($(this).text().length > 60) {
                                        $(this).text(shortReviewText);
                                    }
                                });
                            }
                        }
                        $(".videoImgAnchorHead").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        })
                        $(".ImgArticleImgAnchorHead").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        })
                        $(".oneImgArticleImgAnchorHead").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        })
                    })
                    $(".videoTitle").each(function () {
                        var topicLength=$(this).text().length;
                        if(topicLength>29){
                            $(".videoRPosition").css("margin-top","20px");
                        }
                    })
                    $(".columnDetailZanImg").each(function () {
                        var colunmContentId = $(this).attr("id");
                        //判断是否点赞
                        $.ajax({
                            type: "post",
                            async: true,
                            dataType: "json",
                            url: "/api/v2/agree/selectAgreeCount1.do",
                            data: {
                                "objectId": colunmContentId,
                                "agreeType": 1,
                            },
                            success: function (res) {
                                if (res.code == 0) {
                                    //console.log(res);
                                    var agreeCount=res.data.agreeCount;
                                    $("#"+colunmContentId).next().html(agreeCount);
                                }
                            }
                        })
                    })
                }
            }
        })
    }
    //获取专栏内容(已登录)
    function columnContent2(pageIndex2){
        $.ajax({
            type: "GET",
            async: true,
            dataType: "json",
            url: "/api/v2/column/getColumnContent.do",
            data: {
                "columnId": columnId,
                "pageIndex": pageIndex2,
                "pageSize": 10,
            },
            success: function (res) {
                if (res.code == 0) {
                    //console.log(res);
                    if(res.data=="" && pageIndex2==1){
                        $(".quesheng").stop().show();
                        $(".loading").stop().hide();
                    }
                    var length=res.data.length;
                    if(length<10 && res.data!=""){
                        $(".loading").stop().hide();
                        $(".loadEnd").stop().show();
                    }
                    $(res.data).each(function(i,k) {
                        var type=k.type;
                        var createTime=k.information.createTime;
                        var id=k.information.id;
                        var headImgUrl=k.information.liverInfo.headImgUrl;
                        var uid=k.information.liverInfo.uid;
                        var nickName=k.information.liverInfo.nickName;
                        var title=k.information.title;
                        var content=k.information.content;
                        var topic=k.information.topic;
                        var duration=k.information.duration;
                        var coverUrl=k.information.coverUrl;
                        var watchCount=k.information.watchCount;
                        var praiseCount=k.information.praiseCount;
                        if(type==0){//直播
                            var liveContent="<div class='liveWrap'>"+
                                "<a href='/live?uid="+uid+"'><div class='liveL fl'>"+
                                "<img class='liveCover' src='"+coverUrl+"!220X164"+"' />"+
                                "<img class='liveSystem' src='images/indexlive.png' />"+
                                "</div></a>"+
                                "<div class='videoR fl'>"+
                                "<div class='videoRPosition'>"+
                                "<p class='videoTitle'>"+topic+"</p>"+
                                "<p class='videoRBottom'>"+
                                "<span class='videoImgAnchorNickName fl'>"+watchCount+"人已看</span>"+
                                "<img class='columnDetailZanImg' id='"+id+"' src='../images/rewardIcon.png' alt='' />"+
                                "<span class='columnDetailZanNum'>"+praiseCount+"</span>"+
                                "<span class='videoImgTime fl'>"+format(new Date(createTime))+"</span>"+
                                "</p></div></div></div>";
                            $(".loading").before(liveContent);
                        }else if(type==1){//视频
                            var videoContent="<div class='videoWrap'>"+
                                "<a href='/video?id="+id+"'><div class='videoL fl'>"+
                                "<img class='videoCover' src='"+coverUrl+"!220X164"+"' />"+
                                "<img class='videoSystem' src='images/indexvideo.png' />"+
                                "<span class='videoTime'>"+formatMS1(duration)+"</span>"+
                                "</div></a>"+
                                "<div class='videoR fl'>"+
                                "<div class='videoRPosition'>"+
                                "<p class='videoTitle'>"+topic+"</p>"+
                                "<p class='videoRBottom'>"+
                                "<span class='videoImgAnchorNickName fl'>"+watchCount+"人已看</span>"+
                                "<img class='columnDetailZanImg' id='"+id+"' src='../images/rewardIcon.png' alt='' />"+
                                "<span class='columnDetailZanNum'>"+praiseCount+"</span>"+
                                "<span class='videoImgTime fl'>"+format(new Date(createTime))+"</span>"+
                                "</p> </div> </div> </div>";
                            $(".loading").before(videoContent);
                        }else if(type==2){//文章
                            var coverUrl = k.information.coverUrl;
                            if(coverUrl==""){//无图文章
                                var content=htmlEncode(k.information.content);
                                var articleContent="<div class='ImgArticleWrap'>"+
                                    "<a href='/article?id="+id+"'><p class='ImgArticleImgTitle'>"+title+"</p></a>"+
                                    "<p class='ImgArticleImgInner'>"+removeHTMLTag(content)+"</p>"+
                                    "<p>"+
                                    "<span class='ImgArticleImgAnchorNickName fl'>"+watchCount+"人已看</span>"+
                                    "<img class='columnDetailZanImg' id='"+id+"' src='../images/rewardIcon.png' alt='' />"+
                                    "<span class='columnDetailZanNum'>"+praiseCount+"</span>"+
                                    "<span class='mgArticleImgTime fl'>"+format(new Date(createTime))+"</span>"+
                                    "</p>"+
                                    "</div>";
                                $(".loading").before(articleContent);
                                //文章无图，显示内容一行半
                                $(".ImgArticleImgInner").each(function() {
                                    var shortReviewText = $(this).text().substring(0, 80) + "...";
                                    if($(this).text().length > 80) {
                                        $(this).text(shortReviewText);
                                    }
                                });
                            }else{//带图文章
                                var content=htmlEncode(k.information.content);
                                var oneImgarticleContent="<div class='oneImgArticleWrap'>"+
                                    "<a href='/article?id="+id+"'><img class='fl oneImgArticleImg' src='"+coverUrl+"' /></a>"+
                                    "<div class='oneImgArticleImgR'>"+
                                    "<a href='/article?id="+id+"'><p class='oneImgArticleImgTitle'>"+title+"</p></a>"+
                                    "<p class='oneImgArticleImgInner'>"+removeHTMLTag(content)+"</p>"+
                                    "<p>"+
                                    "<span class='oneImgArticleImgAnchorNickName fl'>"+watchCount+"人已看</span>"+
                                    "<img class='columnDetailZanImg' id='"+id+"' src='../images/rewardIcon.png' alt='' />"+
                                    "<span class='columnDetailZanNum'>"+praiseCount+"</span>"+
                                    "<span class='oneImgArticleImgTime fl'>"+format(new Date(createTime))+"</span>"+
                                    "</p> </div> </div>";
                                $(".loading").before(oneImgarticleContent);
                                //文章无图，显示内容一行半
                                $(".oneImgArticleImgInner").each(function() {
                                    var shortReviewText = $(this).text().substring(0, 60) + "...";
                                    if($(this).text().length > 60) {
                                        $(this).text(shortReviewText);
                                    }
                                });
                            }
                        }
                        $(".videoImgAnchorHead").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        })
                        $(".ImgArticleImgAnchorHead").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        })
                        $(".oneImgArticleImgAnchorHead").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        })
                    })
                    $(".columnDetailZanImg").each(function () {
                        var colunmContentId=$(this).attr("id");
                        //console.log(colunmContentId);
                        //判断是否点赞
                        $.ajax({
                            type: "post",
                            async: true,
                            dataType: "json",
                            url: "/api/v2/agree/selectAgreeCount.do",
                            data: {
                                "objectId": colunmContentId,
                                "uid": userId,
                                "agreeType": 1,
                            },
                            success: function (res) {
                                if (res.code == 0) {
                                    //console.log(res);
                                    var isAgree=res.data.isAgree;
                                    var agreeCount=res.data.agreeCount;
                                    $("#"+colunmContentId).next().html(agreeCount);
                                    if(isAgree==true){
                                        $("#"+colunmContentId).attr("src","../images/rewardP.png");
                                        $("#"+colunmContentId).next().css("color","#fe4502");
                                    }
                                    checkZan(colunmContentId,agreeCount);
                                }
                            }
                        })
                    })
                }
            }
        })
    }
    //电脑跳转手机
    function browserRedirect() {
        var sUserAgent = navigator.userAgent.toLowerCase();
        var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
        var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
        var bIsMidp = sUserAgent.match(/midp/i) == "midp";
        var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
        var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
        var bIsAndroid = sUserAgent.match(/android/i) == "android";
        var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
        var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
        if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
            window.location.href = "https://www.fntv8.com/m/columnDetail?id=" + columnId + "";
        }
    }
    browserRedirect();

    //APP下载二维码
    $(".saoma").mouseenter(function() {
        $(".indexCode").fadeIn(200);
    });
    $(".saoma").mouseleave(function() {
        $(".indexCode").fadeOut(200);
    });

    /*回到顶部*/
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn()
        } else {
            $(".goTop").stop().fadeOut()
        }
    });
    $(".goTop").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 800)
    });

    // 检查评论点赞
    function checkZan(id,agreeCount) {
        //判断是否点赞
        $("#"+id).on("click",function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v2/agree/selectAgreeCount.do",
                data: {
                    "objectId": id,
                    "uid": userId,
                    "agreeType":1,
                },
                success: function (res) {
                    if (res.code == 0) {
                        //console.log(res);
                        var isAgree=res.data.isAgree;
                        if(isAgree==true){//已点赞
                            //取消点赞
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/deleteAgree.do",
                                data: {
                                    "objectId": id,
                                    "uid": userId,
                                    "token": usertoken,
                                    "agreeType":1,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        //console.log(res);
                                        $("#"+id).attr("src","../images/rewardIcon.png");
                                        $("#"+id).next().css("color","#a9a9a9");
                                        var praiseCount1 = $("#"+id).next().html();
                                        var praiseCount2 = Number(praiseCount1) - 1;
                                        $("#"+id).next().html(praiseCount2);
                                    }
                                }
                            })
                        }else{
                            //点赞接口
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/insertAgree.do",
                                data: {
                                    "objectId": id,
                                    "uid": userId,
                                    "token": usertoken,
                                    "type":4,
                                    "agreeType":1,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        //console.log(res);
                                        $("#"+id).attr("src","../images/rewardP.png");
                                        var praiseCount1 = $("#"+id).next().html();
                                        var praiseCount2 = Number(praiseCount1) + 1;
                                        $("#"+id).next().html(praiseCount2);
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }
})