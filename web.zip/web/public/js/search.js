$(document).ready(function() {
	//加载头部
	$("#wrapHeader").load("/header");
	//加载底部
	$("#indexFooter").load("/footer");

	$("#title li").bind("click", function() {
		var index = $(this).index();
		$(this).addClass("active").siblings().removeClass("active");
		$("#content .currenta").eq(index).show().siblings("#content .currenta").hide()
	});
	
	
	
})
