$(document).ready(function(){
	function clickFun(obj){
		$(obj).click(function(){
			$(this).stop().hide();
			$(".rulesAlertBox1").stop().hide();
	    });
	};
	clickFun(".rulesAlertBoxImg");
	clickFun(".rulesAlertBoxImg1");
	clickFun(".rulesAlertBoxImg2");
	clickFun(".rulesAlertBoxImg3");
	$(".rulesBtnBox1").click(function(){
		$(".rulesAlertBox1").stop().show();
		$(".rulesAlertBoxImg").stop().show();
	});
	
	$(".rulesBtnBox2").click(function(){
		$(".rulesAlertBox1").stop().show();
		$(".rulesAlertBoxImg1").stop().show();
	});
	
	$(".rulesBtnBox3").click(function(){
		$(".rulesAlertBox1").stop().show();
		$(".rulesAlertBoxImg2").stop().show();
	});
	
	$(".rulesBtnBox4").click(function(){
		$(".rulesAlertBox1").stop().show();
		$(".rulesAlertBoxImg3").stop().show();
	});
	//回到头部
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
	//页面跳转
	function browserRedirect() {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		var bIsMidp = sUserAgent.match(/midp/i) == "midp";
		var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		var bIsAndroid = sUserAgent.match(/android/i) == "android";
		var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
		if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
			window.location.href = "https://www.fntv8.com/m/v5.0/rules"
          //  window.location.href = "http://192.168.8.13:8445/m/v5.0/invite"
		}
	}
	browserRedirect();
	
})
