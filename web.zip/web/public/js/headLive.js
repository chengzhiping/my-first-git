$(document).ready(function() {
	$("body a:first").html("");//去掉友盟的站长统计四个字
	//	//加载头部
	$("#wrapHeader").load("/header");
	//加载底部
	$("#indexFooter").load("/footer");
	//tab
	$(".commentBottomTabTitle").click(function() {
		$(".commentBottomTabBox").eq($(this).index()).css("display", "block").siblings("div").css("display", "none");
		$(this).addClass("commentBottomTabTitleActive").siblings(".commentBottomTabTitle").removeClass("commentBottomTabTitleActive")
		if($(this).index() == 1) {
			$(".commentBottomTab").css({
				"width": "1178px"
			})
		} else {
			$(".commentBottomTab").css({
				"width": "806px"
			})
		}
	});
	
	//主播发现
	$(document).on("click", ".anchorFindBox", function(e) {
		window.location.href = "/headDynamic?tab=3";
	});
	
	//我的订阅
	$(document).on("click", ".subscriptionsBox", function(e) {
		window.location.href = "/me?tab=4";
	});
	getHotLiveRoomList(1, 20, 1); //stateType=1渲染正在直播stateType=2渲染最新热门
	getHotLiveRoomList(1, 10, 2); //视频直播
	var HotLiveRoomListIndex = 1;
	var livingIndex = 1;
	//正在直播——热门直播-轮播内容
	function getHotLiveRoomList(pageIndex, pageSize, stateType) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/live/getHotLiveRoomList.do",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				if(res.code == 0) {
					if(stateType == 1) {
//						console.log(res);
						var latestHotSpotLen = res.data.length;
//						if(latestHotSpotLen == pageSize) {
//							livingIndex++;
//							getHotLiveRoomList(livingIndex, 10, 1);
//						}
						$(res.data).each(function(i, D) {
							var type = D.type; //直播间类型，0=主直播间（免费），1=VIP直播间
							var liveRoomHrefId = D.liverInfo.uid + "liveRoomHrefId";
							if(D.latest.content) {
								var liveContent = D.latest.content;
								if(liveContent.indexOf("igstn") > 0) {
									var anchorAnwserBrforeIm = liveContent.split("igstn")[0];
									var anchorAnwserAfterIm = liveContent.split("igstn")[1];
									var liveCarouselInfo =
										'<div class="liveCarouselInfo" id=' + liveRoomHrefId + ' uid=' + D.liverInfo.uid + ' roomId=' + D.roomId + ' >' +
										'<img class="fl headImgUrl" src="' + D.liverInfo.headImgUrl + '!60X60"/>' +
										'<div class="liveCarouselInfoR fl">' +
										'<p><span>' + D.liverInfo.nickName + '</span><span>' + format(new Date(D.latest.time)) + '</span></p>' +
										'<p>' + anchorAnwserBrforeIm + '回复' + anchorAnwserAfterIm + '</p>' +
										'</div>' +
										'<span class="fr enterLiveRoomBtn">点击进入</span>'+
										'</div>';
									$(".JQ-slide-content").append(liveCarouselInfo);
								} else if(liveContent.indexOf("igugl") > 0){
									//console.log(D);
									var hrefBrforeIm = liveContent.split("igugl")[0];
									var hrefAfterIm = liveContent.split("igugl")[1];
									var liveCarouselInfo =
										'<div class="liveCarouselInfo" id=' + liveRoomHrefId + ' uid=' + D.liverInfo.uid + ' roomId=' + D.roomId + ' >' +
										'<img class="fl headImgUrl" src="' + D.liverInfo.headImgUrl + '!60X60"/>' +
										'<div class="liveCarouselInfoR fl">' +
										'<p><span>' + D.liverInfo.nickName + '</span><span>' + format(new Date(D.latest.time)) + '</span></p>' +
										'<p>' + hrefBrforeIm + '链接网址：' + hrefAfterIm + '</p>' +
										'</div>' +
										'<span class="fr enterLiveRoomBtn">点击进入</span>'+
										'</div>';
									$(".JQ-slide-content").append(liveCarouselInfo);
								}else{
									var liveCarouselInfo =
										'<div class="liveCarouselInfo" id=' + liveRoomHrefId + ' uid=' + D.liverInfo.uid + ' roomId=' + D.roomId + ' >' +
										'<img class="fl headImgUrl" src="' + D.liverInfo.headImgUrl + '!60X60"/>' +
										'<div class="liveCarouselInfoR fl">' +
										'<p><span>' + D.liverInfo.nickName + '</span><span>' + format(new Date(D.latest.time)) + '</span></p>' +
										'<p>' + D.latest.content + '</p>' +
										'</div>' +
										'<span class="fr enterLiveRoomBtn">点击进入</span>'+
										'</div>';
									$(".JQ-slide-content").append(liveCarouselInfo);
								}

							}
							$(".headImgUrl").one("error", function(e) {
								$(this).attr("src", "images/anchorHead.png");
							});
							if(type == 0) {
								$(document).on("click", "#" + liveRoomHrefId, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomId");
									window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
								});
							} else if(type == 1) {
								$(document).on("click", "#" + liveRoomHrefId, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomId");
									window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
								});
							}

						});
						//正在直播的轮播
							var showCount = 4,				// 画面显示的条数
							totalCount = $(".liveCarousel .liveCarouselInfo").length,			// 轮播总条数
							index = 0,						// 轮播总条数下标
							autoTimer,						// 全局变量目的实现左右点击同步
							clickEndFlag = true,	// 设置每张走完才能再点击
							intervalTime = 3000;	// 间隔时间
					
							// 克隆画面显示的条数总数放到最后(实现无缝滚动)
							//console.log('hkdsahfkl', totalCount);
							for (var i = 1; i <= showCount; i++) {
								$(".liveCarousel .liveCarouselInfo:eq("+ (i - 1)  +")").clone(true).appendTo($(".liveCarousel"));
							}
					
							var liHeight = $(".liveCarousel .liveCarouselInfo").height();//一个li的高度
							var totalHeight = ($(".liveCarousel .liveCarouselInfo").length *  $(".liveCarousel .liveCarouselInfo").eq(0).height()) - (showCount*liHeight);//获取li的总高度再减去画面显示的条数的高度
							$(".liveCarousel").height(totalHeight);//给ul赋值高度
					
							
							//	滚动方法
							function upOffset1(){
								$(".liveCarousel").stop().animate({
									top: -index * liHeight
								},400,function(){
									clickEndFlag = true;//图片走完才会true
									if(index == $(".liveCarousel .liveCarouselInfo").length -1) {
										$(".liveCarousel").css({top:0});
										index = 0;
									}
								})
							}
					
							function next1() {
								index++;
								if(index > totalCount) {//判断index为最后一个Li时index为0
									$(".liveCarousel").css({top:0});
									index = 1;
								}
								upOffset1();
							}
							// 自动轮播
							autoTimer = setInterval(next1, intervalTime);
							$(".liveCarousel .liveCarouselInfo").hover(function(){
								clearInterval(autoTimer);
							},function() {
								autoTimer = setInterval(next1, intervalTime);
							})


					} else if(stateType == 2) {
						var latestHotSpotLen = res.data.length;
						if(latestHotSpotLen == pageSize) {
							HotLiveRoomListIndex++;
							getHotLiveRoomList(HotLiveRoomListIndex, 10, 2);
						} else {
							$(".latestHotSpotBoxLoading").stop().hide();
							$(".latestHotSpotBoxNoMore").stop().show();
						}
						$(res.data).each(function(i, M) {
							var sortIdStatus = M.roomId + "status";
							var sortIdCover = M.roomId + "coverUrl";
							var latestContentId = M.roomId + "content";
							var latestTimeId = M.roomId + "time";
							var latestHotSpotId = M.roomId + "href";
							var type = M.type; //直播间类型，0=主直播间（免费），1=VIP直播间
							var content=M.latest.content;
							var latestHotSpotBox =
								'<div class="latestHotSpotBox" uid="' + M.liverInfo.uid + '" roomid="' + M.roomId + '" id="' + latestHotSpotId + '">' +
								'<div class="latestHotSpotBoxL fl">' +
								'<img id="' + sortIdCover + '" src="' + M.coverUrl + '"/>' +
								'<img id="' + sortIdStatus + '" src="images/liveNew.png" alt="" />' +
								'</div>' +
								'<div class="latestHotSpotBoxR fl">' +
								'<p class="latestHotSpotTitle">' + M.topic + '</p>' +
								'<p class="latestHotSpotContent" id="' + latestContentId + '">' + M.latest.content + '</p>' +
								'<div class="latestHotSpotBoxRB">' +
								'<p class="fl">' + M.liverInfo.nickName + '的直播间</p>' +
								'<p class="fl"><span>' + M.partakes + '</span><span>人参与</span><span>' + M.subscribers + '人订阅</span></p>' +
								'<p class="fr" id="' + latestTimeId + '">' + formatV5Time(new Date(M.latest.time)) + ' 更新</p>' +
								'</div>' +
								'</div>' +
								'</div>';
							$(".latestHotSpotBoxLoading").before(latestHotSpotBox);
							//console.log(content);
							if(M.latest.content){
								if(content==undefined||content==null||content==""){
									$("#"+latestContentId).html("直播间暂无内容");
								}
								if(content.indexOf("igstn") > 0){
									var contentBrforeIm = content.split("igstn")[0];
									var contentAfterIm = content.split("igstn")[1];
									$("#"+latestContentId).html(contentBrforeIm+"回复"+contentAfterIm);
								};
								if(content.indexOf("igugl") > 0){
									var iguglBrforeIm = content.split("igugl")[0];
									var iguglAfterIm = content.split("igugl")[1];
									$("#"+latestContentId).html(iguglBrforeIm+"链接"+iguglAfterIm);
								};
							}
							
							var status = M.status; //直播间状态{1=视频直播中，2=主播在线，其他=主播离线}
							if(status != 1) {
								$("#" + sortIdStatus).stop().hide();
							};
							$("#" + sortIdCover).one("error", function(e) {
								$(this).attr("src", "images/hotNull.png");
							});
							var latestLen = JSON.stringify(M.latest).length;
							if(latestLen == 2) {
								$("#" + latestContentId).html("直播间暂无最新内容");
								$("#" + latestTimeId).stop().hide();
							}
							if(type == 0) {
								$(document).on("click", "#" + latestHotSpotId, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomid");
									window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
								});
							} else if(type == 1) {
								$(document).on("click", "#" + latestHotSpotId, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomid");
									window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
								});
							}

						})
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
	}
	//主播推荐
	getDiscovery2();

	function getDiscovery2() {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/discovery/getDiscovery2.do",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					var userArrayLen = res.data.userArray.length;
					var userArray = res.data.userArray;
					if(userArrayLen == 0) {
						$(".anchorRecommend").stop().hide();
					} else if(userArrayLen > 5) {
						userArrayLen = 5;
					} else {
						for(var N = 0; N < userArrayLen; N++) {
							var anchorRecommendList =
								'<li class="anchorRecommendList" uid="' + userArray[N].liverInfo.uid + '">' +
								'<img class="fl" src="' + userArray[N].liverInfo.headImgUrl + '" alt="" />' +
								'<div class="anchorRecommendListR fl">' +
								'<p><span>' + userArray[N].liverInfo.nickName + '</span><span>粉丝：' + userArray[N].funsCount + '</span></p>' +
								'<p>直播主题：' + userArray[N].topic + '</p>' +
								'</div>' +
								'</li>';
							$(".anchorRecommend").append(anchorRecommendList);
							$(document).on("click", ".anchorRecommendList", function(e) {
								var uid = $(this).attr("uid");
								window.location.href = "/userProfile?uid=" + uid;
							});
						}
					}
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
	}
	//视频直播
	$("#VideoLiveRoomList").click(function() {
		getVideoLiveRoomList(1, 8)
	})
	var LiveRoomListIndex = 1;

	function getVideoLiveRoomList(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/live/getVideoLiveRoomList.do",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				if(res.code == 0) {
					var LiveRoomListLen = res.data.length;
					if(LiveRoomListLen == pageSize) {
						LiveRoomListIndex++;
						getVideoLiveRoomList(LiveRoomListIndex, 8);
					} else {
						$(".getVideoLiveRoomListLoading").stop().hide();
						$(".getVideoLiveRoomListNoMore").stop().show();
					}
					$(res.data).each(function(i, Q) {
						var type=Q.type;//直播间类型，0=主直播间（免费），1=VIP直播间
						var sortIdStatus = Q.id + "status";
						var sortIdCover = Q.id + "coverUrl";
						var latestContentId = Q.id + "content";
					    var videoLiveId=Q.id+"videoLive";
						var videoLiveList =
							'<div class="videoLiveBox fl" uid="' + Q.liverInfo.uid + '" roomid="' + Q.roomId + '" id="' + videoLiveId + '" objectId="' + Q.id + '">' +
							'<div class="videoLiveBoxT">' +
							'<img id="' + sortIdCover + '" src="' + Q.coverUrl + '!275X157"/>' +
							'<img id="' + sortIdStatus + '" src="images/live.png"/>' +
							'<img class="selectLogo" src="images/select.png"/>' +
							'</div>' +
							'<div class="videoLiveBoxB">' +
							'<img class="fl" id="' + latestContentId + '" src="' + Q.liverInfo.headImgUrl + '!60X60" alt="" />' +
							'<p class="fl videoLiveBoxTitle">' + Q.topic + '</p>' +
							'<p class="fl videoLiveBoxBb"><span class="fl">' + Q.liverInfo.nickName + '</span><span class="fr">' + Q.watchCount + '人观看</span></p>' +
							'</div>' +
							'</div>';
						$(".getVideoLiveRoomListLoading").before(videoLiveList);
						var status = Q.status; //直播间状态{1=视频直播中，2=主播在线，其他=主播离线}
						//console.log(type);
						if(status != 1) {//回放
							$("#" + sortIdStatus).stop().hide();
							$(document).on("click", "#" + videoLiveId, function(e) {
								var id = $(this).attr("objectId");
								var roomid = $(this).attr("roomid");
								var uid = $(this).attr("uid");
								window.location.href = "/liveLookBack?id=" + id + "&roomid=" + roomid+ "&uid=" + uid;
							});
						}else{//直播
							if(type==0){
								$(document).on("click", "#" + videoLiveId, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomid");
									window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
							    });
							}else if(type==1){
								$(document).on("click", "#" + videoLiveId, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomid");
									window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
							    });
							}
							
						}
						$("#" + sortIdCover).one("error", function(e) {
							$(this).attr("src", "images/vedioCoverUrl.jpg");
						});
						$("#" + latestContentId).one("error", function(e) {
							$(this).attr("src", "images/anchorHead.png");
						});

					})
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		})
	}
	//专场直播
	//$("#getSpecialLive").click(function(){
	getSpecialLive(1, 10);
	//})
	var getSpecialLiveIndex = 1;

	function getSpecialLive(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/live/getSpecialLive.do",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					var getSpecialLiveLen = res.data.length;
					//console.log(getSpecialLiveLen);
					if(getSpecialLiveLen == pageSize) {
						getSpecialLiveIndex++;
						getSpecialLive(getSpecialLiveIndex, 10);
					} else {
						$(".getSpecialLiveLoading").stop().hide();
						$(".getSpecialLiveNoMore").stop().show();
					}
					$(res.data).each(function(i, Q) {
					    var type=Q.type;//直播间类型，0=主直播间（免费），1=VIP直播间
						var sortIdStatus = Q.id + "status";
						var sortIdStatusType = Q.id + "type";
						var sortIdStatusType1 = Q.id + "type1";
						var sortIdCover = Q.id + "coverUrl";
						var latestContentId = Q.id + "content";
						var videoLiveDifId=Q.id+"videoLiveDi";
						var liveBroadcastBox =
							'<div class="liveBroadcastBox" uid="' + Q.liverInfo.uid + '" roomid="' + Q.roomId + '" id="' + videoLiveDifId + '" objectId="' + Q.id + '">' +
							'<div class="liveBroadcastBoxL fl">' +
							'<img id="' + sortIdCover + '" src="' + Q.coverUrl + '!275X157"/>' +
							'<img id="' + sortIdStatus + '" src="images/live.png"/>' +
							'<img class="selectLogo" src="images/select.png"/>' +
							'</div>' +
							'<div class="liveBroadcastBoxR fl">' +
							'<p>' + Q.topic + '</p>' +
							'<p>' +
							'<img src="' + Q.liverInfo.headImgUrl + '!60X60"/>' +
							'<span>' + Q.liverInfo.nickName + '</span>' +
							'<span class="liveBroadcastLogo" id="' + sortIdStatusType + '">直播中</span>' +
							'<span class="liveBroadcastTime" id="' + sortIdStatusType1 + '">' + format(new Date(Q.modifyTime)) + '</span>' +
							'<span>' + Q.watchCount + '人观看</span>' +
							'</p>' +
							'</div>' +
							"</div>";
						$(".getSpecialLiveLoading").before(liveBroadcastBox);
						var status = Q.status; //直播间状态{1=视频直播中，2=主播在线，其他=主播离线}
						//	console.log(status);
						if(status != 1) {
							$("#" + sortIdStatus).attr("src", "images/playback.png");
							$("#" + sortIdStatusType).stop().hide();
							$(document).on("click", "#" + videoLiveDifId, function(e) {
								var id = $(this).attr("objectId");
								var roomid = $(this).attr("roomid");
								var uid = $(this).attr("uid");
								window.location.href = "/liveLookBack?id=" + id + "&roomid=" + roomid+ "&uid=" + uid;
							});
							
						} else {
							$("#" + sortIdStatus).attr("src", "images/live.png");
							$("#" + sortIdStatusType1).stop().hide();
							if(type==0){
								$(document).on("click", "#" + videoLiveDifId, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomid");
									window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
							    });
							}else if(type==1){
								$(document).on("click", "#" + videoLiveDifId, function(e) {
									var uid = $(this).attr("uid");
									var roomid = $(this).attr("roomid");
									window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
							    });
							}
							
						}
						$("#" + sortIdCover).one("error", function(e) {
							$(this).attr("src", "images/vedioCoverUrl.jpg");
						});
						$("#" + latestContentId).one("error", function(e) {
							$(this).attr("src", "images/anchorHead.png");
						});

					})
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		})
	}
	//回到头部
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
	//轮播
	$(".commentTopBoxLCarousel").load("/liveCarousel");
})