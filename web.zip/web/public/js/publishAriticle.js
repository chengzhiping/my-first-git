$(document).ready(function() {
	var id;
	var imgArr = [];
	$(".trumbowyg-editor").after(". ");
	//判断主播是否登录
	loginF();

	function loginF() {
		$.ajax({
			type: "get",
			url: "/userInfos",
			success: function(res) {
				if(res.code == -2) { //未登录
					//登录
					$("#publishViewBtn").click(function() {
						$("#loginAlert").load("/login");
					});

				};
				if(res.code == 0) {
					var uid = roleType = res.data.userInfo.uid;
					var token = res.data.token;
					//发布成功跳转到主播个人页
					$(".gotoUserProfile").click(function() {
						window.open("/userProfile?uid=" + uid);
						$("#publishViewBox").stop().hide();
						$("#loginAlert").stop().hide();
					});
					//上传图片
					uploadImg(uid, token);
					//发布
					publishArticle(uid, token)
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	//标题为空不可以点击发布        
	$(".shortViewContent").on("keyup", function() {
		/*字数倒计数*/
		var num = 30 - ($(this).val().length);
		if(num > 0 && num < 30) {
			$(".shortViewContentNum").html(num);

		} else if(num <= 0) {
			$(".shortViewContentNum").html(0);
		};
		if(num == 30) {
			$(".shortViewContentNum").html(30);

		}
		$(".shortViewContentNum").css(
			'color', "#FE4502"
		);

	});
	//手动上传图片
	function uploadImg(uid, usertoken) {
		$.ajax({
			type: "get", //请求方式
			async: true, //是否异步
			dataType: "json",
			url: "/api/v1/picture/batchUpload/token.do",
			data: {
				"uid": uid,
				"token": usertoken,
			},
			success: function(res) {
				// console.log(res);
				if(res.code == 0) {
					var articleimgtoken = res.data.uploadToken;
					//console.log(articleimgtoken);
					//七牛上传图片
					var uploader = Qiniu.uploader({
						runtimes: 'html5,flash,html4', //上传模式,依次退化
						browse_button: 'addImgIcon', //上传选择的点选按钮，**必需**
						uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
						uptoken: articleimgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
						uptoken_func: function(file) {},
						unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
						save_key: false, // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
						domain: 'upload.qbox.me', //bucket域名，下载资源时用到，**必需**
						get_new_uptoken: true, //设置上传文件的时候是否每次都重新获取新的token
						container: 'customized-buttonpane', //上传区域DOM ID，默认是browser_button的父元素，
						max_file_size: '100mb', //最大文件体积限制
						flash_swf_url: 'js/Moxie.swf', //引入flash,相对路径
						max_retries: 3, //上传失败最大重试次数
						dragdrop: true, //开启可拖曳上传
						drop_element: 'customized-buttonpane', //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
						chunk_size: '4mb', //分块上传时，每片的体积
						auto_start: true, //选择文件后自动上传，若关闭需要自己绑定事件触发上传
						init: {
							'FilesAdded': function(up, files) {
								// plupload.each(files, function(file) {
								//    // 文件添加进队列后,处理相关的事情
								// });
							},
							'BeforeUpload': function(up, file) {
								// 每个文件上传前,处理相关的事情
							},
							'UploadProgress': function(up, file) {
								// 每个文件上传时,处理相关的事情
							},
							'FileUploaded': function(up, file, info) {
								var imgInfo = JSON.parse(info);
							    //var imgUrl = "http://picture.91qiniu.com/"+imgInfo.key;//内网
								var imgUrl = "http://picture.fengniutv.com/" + imgInfo.key;
								var img1 = "<img src='" + imgUrl + "' alt='' >";
								$(".trumbowyg-editor").append(img1+" ");
								imgArr.push(imgUrl);
								var str = $(".trumbowyg-editor").html();
								var media = imgArr.join(",") + ",";
								
								
							},
							'Error': function(up, err, errTip) {
								console.log(errTip);
								//上传出错时,处理相关的事情
							},
							'UploadComplete': function() {
								//队列文件处理完毕后,处理相关的事情
							},
						},
					});
				}
			},
		});
	}

	$("#closed").on("click", function() {
		$("#over").css({
			"display": "none"
		});
		$("#msg").css({
			"display": "none"
		})
	});
	/*排版*/

	$(document).on("click", "#paiban", function(e) {
		$(".trumbowyg-editor p").css({
			"text-indent": "26px",
			"font-size": "13px",
			"line-height": "26px",
			"padding": "0"
		});
		$(".trumbowyg-editor img").css({
			"display": "block",
			"width": "400px",
			"height": "auto",
			"margin": "0 auto"

		});
		$(".trumbowyg-editor span").css({
			"text-indent": "26px",
			"font-size": "13px",
			"line-height": "26px",
			"display": "block",
		});

});
	
	//标题和内容为空的时候，按钮不可点击，否则可点击
		var num, view;
	  $(".shortViewContent").on("keyup", function() {
		/*字数倒计数*/
		num = 30 - ($(this).val().length);
		articleTitle(num, view);
		if(num > 0 && num < 30) {
			$(".shortViewContentNum").html(num);
		} else if(num <= 0) {
			$(".shortViewContentNum").html(0);
		};
		if(num == 30) {
			$(".shortViewContentNum").html(30);
		}
		$(".shortViewContentNum").css(
			'color', "#FE4502"
		);
	});
	//内容不能为空
	$(".trumbowyg-editor").on("keyup", function() {
		view = $(".trumbowyg-textarea").val();
		$(".trumbowyg-editor img").css({
			"display": "block",
			"width": "400px",
			"height": "auto",
			"margin": "0 auto"

		});
		articleTitle(num, view);
	})
	//解决标题和内容为空的情况
	function articleTitle(num, view) {
		// console.log(num);
		if(num < 30 && view != undefined && view != null && view != "" && num != undefined && num != null && num != "") {
			$("#publishViewBtn").css({
				"background": "#fe4502"
			});
			$('#publishViewBtn').removeAttr("disabled");
		} else {
			$("#publishViewBtn").css({
				"background": "#d8d8d8"
			});

		}
	}
	/*图片转存*/
	//思路:用正则拿出来，然后提取网址，再用7牛的sdk存到七牛云那边，用七牛返回的的图片地址替换掉原来的图片地址，把内容传给后台

	//	//图片转存
	var relateImgSrcStr;
	var arr;
	var srcOne //把每次成功上传的图片地址拼成字符串
	var articalNr;
	var src;
	var srcStr;
	//思路:用正则拿出来，然后提取网址，再用7牛的sdk存到七牛云那边~
	function publishArticle(uid, token) {
	$("#publishViewBtn").html("发送中...");
	$(document).on("click", "#publishViewBtn", function(e) {
		var view = $(".trumbowyg-textarea").val();
		var article_title = $(".shortViewContent").val();
		//console.log(view);
	//	console.log(article_title);
		if(view == "" || article_title == "") {
			$("#publishViewBtn").css({
				"background": "#d8d8d8"
			});
			$('#publishViewBtn').attr("disabled", "disabled");
		} else {
			$("#publishViewBtn").css({
				"background": "#fe4502"
			});
			$('#publishViewBtn').removeAttr("disabled");
			relateImgSrcStr = ""; //点击时把上次点击的内容清空
			srcStr = "";
			//获得文章的内容
			articalNr = $(".trumbowyg-textarea").val() + "";
			//console.log(articalNr);
			//匹配图片（g表示匹配所有结果i表示区分大小写）
			var imgReg = /<img.*?(?:>|\/>)/gi;
			//匹配src属性
			var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
			arr = articalNr.match(imgReg); //'所有已成功匹配图片的数组
			if(arr == null) { //文章里面没有图片
				saveOrUpdate(uid, token, view, article_title);
			} else {
				//console.log(arr);
				for(var i = 0; i < arr.length; i++) {
					src = arr[i].match(srcReg);
					//获取图片地址
					if(src[1]) {
						//上传远程图片到七牛云
						$.ajax({
							dataType: "json",
							type: "post",
							async: false,
							url: "/uploadHtml",
							data: {
								"html": src[1],

							},
							success: function(res) {
								if(res.code == 0) {
									srcOne = res.data + "";
									relateImgSrc(srcOne,uid,token,view,article_title);
									//relateImgSrc(srcOne);
									src[1] = src[1] + "";

								}
							},
							error: function(XMLHttpRequest, textStatus, errorThrown) {
								console.log(XMLHttpRequest.status);
								console.log(XMLHttpRequest.readyState);
								console.log(textStatus)
							},
						})

					}

				}
			}

		}

	})
}

	/*替换图片src*/
	var relateImgSrcArr;
	var re; //签掉空格的数组
	var srcRe;
	var newArticleNr;

	function relateImgSrc(srcOne,uid,token,view,article_title) {
		//援用图片地址
		srcStr += src[1] + ",";
		// console.log(srcStr);
		var srcArr = srcStr.split(",");

		var trim1 = function(s) {
			return s.replace(/\s+/g, '');
		}
		srcRe = [];
		for(var i = 0, len = srcArr.length; i < len; i++) {
			if(trim1(srcArr[i]).length > 0) {
				srcRe[srcRe.length] = srcArr[i];
			}
		}
		//七牛返回数据
		relateImgSrcStr += srcOne + ",";
		var relateImgSrcArr = relateImgSrcStr.split(",");
		//去掉""的数组
		var trim = function(s) {
			return s.replace(/\s+/g, '');
		}
		re = [];
		for(var i = 0, len = relateImgSrcArr.length; i < len; i++) {
			if(trim(relateImgSrcArr[i]).length > 0) {
				re[re.length] = relateImgSrcArr[i];
			}
		}
		var arrLength = arr.length;
//		console.log(srcRe);
//		console.log(arr);
// 		console.log(re);
		var newHtml;
		var newHtmlArr=[];//写的图片数组
		var newView;
		if(arrLength==re.length){
			for (var q=0;q<re.length;q++){
				newHtml="<img src='"+re[q]+"'>";
                newHtmlArr.push(newHtml);
//			   //替换原来的html
              if(arr.length==newHtmlArr.length){
                  //console.log(arr);
                  //console.log(newHtml);
                  newView=view.replace(arr[q],newHtml);
                 // console.log(newView);
                  saveOrUpdate(uid, token, newView, article_title);
              }
		   }
			
		}
		 
//		 
//		 console.log(view);
        

	}
	/*调后台接口发布文章*/
	function saveOrUpdate(uid, usertoken, view, article_title) {
		$.ajax({
			dataType: "json",
			type: "post",
			async: true,
			url: "/api/v1/article/saveOrUpdate.do",
			data: {
				"uid": uid,
				"token": usertoken,
				"type": 2,
				"content": view,
				"title": article_title,
			},
			success: function(res) {
				// console.log(res);
				if(res.code == 0) {
					id = res.data;
					window.location.href = "article?id=" + id;
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		})
	}

	//wang富文本编辑器

	//关闭页面
	$(".closeShortPage").click(function() {
		$("#publishViewBox").stop().hide();
		$("#loginAlert").stop().hide();
	});

	$(".successClose").click(function() {
		$("#publishViewBox").stop().hide();
		$("#loginAlert").stop().hide();
	});

	$(".imgLenTenClose").click(function() {
		$("#imgLenTen").stop().hide();
	})

})