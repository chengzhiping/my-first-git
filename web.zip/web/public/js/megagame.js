window.onload = function(){
	var vm = new Vue({
		el:"#megagame",
		data:{
			test:"2018疯牛直播全国操盘手大赛",
			styleObj:[{
				rotate:65,
				name:1
			},{
				rotate:21.23,
				name:2
			},{
				rotate:49.00,
				name:3
			},{
				rotate:99,
				name:4
			},{
				rotate:48.41,
				name:5
			},{
				rotate:52,
				name:6
			}]
		},
		computed:{
			rotateStyle:function(){
				return {}
			}
		},
		mounted:function(){		
			
			this.scrollInit()
		},
		created: function () {
			console.log("vue测试页面0000")
		  },
		methods:{	
			chooseWeek:function(){
				console.log("chooseWeek")
			},	
			chooseSeason:function(){
				console.log("chooseSeason")
			},	
			scrollInit:function(){
				$("#scrollBar").mCustomScrollbar({
					callbacks:{
						onScrollStart:function(){},
						onScroll:function(){},
						onTotalScroll:function(){
							 console.log("加载更多")
						},
						onTotalScrollBack:function(){},
						onTotalScrollOffset:80,
						whileScrolling:false,
						whileScrollingInterval:0
					},
					scrollInertia:300
				});

				$("#scrollBar2").mCustomScrollbar({
					callbacks:{
						onScrollStart:function(){},
						onScroll:function(){},
						onTotalScroll:function(){
							 console.log("加载更多2")
						},
						onTotalScrollBack:function(){},
						onTotalScrollOffset:80,
						whileScrolling:false,
						whileScrollingInterval:0
					},
					scrollInertia:300
				});
				$("#scrollBar3").mCustomScrollbar({
					callbacks:{
						onScrollStart:function(){},
						onScroll:function(){},
						onTotalScroll:function(){
							 console.log("加载更多3")
						},
						onTotalScrollBack:function(){},
						onTotalScrollOffset:80,
						whileScrolling:false,
						whileScrollingInterval:0
					},
					scrollInertia:300
				});

			},
			



			
		}


	});
}
