$(document).ready(function () {
    var phoneReg = /^[1][34578]\d{9}$/;//手机号码正则
    var passwordReg = /^[0-9a-zA-Z]+$/  //密码正则
    var numReg = new RegExp(/^\d{4}$/); //图形验证码
    var verifyReg = new RegExp(/^\d{6}$/); //短信验证码
    if(window.location.hash == '#forget'){
        $(".signBar").css("display","none");
        $(".forgetBar").css("display","block");
    };
    $("#forgetBtn").click(function () {
        $(".signBar").css("display","none");
        $(".forgetBar").css("display","block");
    });
    $("#returnLogin").click(function () {
        window.location.hash = '#login';
        $(".signBar").css("display","block");
        $(".forgetBar").css("display","none");
    });
    //关闭图形验证码弹框
    $(".graphCloseBtn").click(function () {
        $("#numCodeBG").fadeOut(100);
    });
    //关闭登录弹框
    $(".loginClose").click(function () {
        $(".loginBar").fadeOut(100);
        $("#loginAlert").fadeOut(100);
        var href=window.location.href;
        var sear = new RegExp('#');
        if(sear.test(href)) {
            href=href.split("#");
            window.location.href=href[0];
        }
    });
    //5秒快速注册
    $("#signupFun").click(function () {
        $(".loginInfo").css("display","none");
        $(".registerInfo").css("display","block");
        $(".underline").addClass('underlineHover');
    });
    //立即登陆
    $("#signinFun").click(function () {
        $(".loginInfo").css("display","block");
        $(".registerInfo").css("display","none");
        $(".underline").removeClass('underlineHover');
    });
    //登录注册tab
    $(".tabMenu span").click(function(){
        var num =$(".tabMenu span").index(this);
        $(".tabContent .tabCon").hide();
        $(".tabContent .tabCon").eq(num).show().siblings().hide();
    });
    $(".tabMenu span:nth-of-type(1)").click(function(){
        $(".underline").removeClass('underlineHover');
    });
    $(".tabMenu span:nth-of-type(2)").click(function(){
        $(".underline").addClass('underlineHover');
    });

    if(window.location.hash == '#signup'){
        $(".underline").addClass('underlineHover');
        $(".loginInfo").css("display","none");
        $(".registerInfo").css("display","block");
    };
    //短信验证码登录tab
    $("#tabCodeFun").click(function () {
        $(".codeloginBar").css({"display":"block"});
        $(".accountloginBar").css({"display":"none"});
    });
    //帐号密码登录tab
    $("#tabaccountFun").click(function () {
        $(".codeloginBar").css({"display":"none"});
        $(".accountloginBar").css({"display":"block"});
    });
    //获取图形验证码
    function refreshCodeFun() {
        $.ajax({
            type: "GET",
            url: "/refreshGraphCode",
            success: function(res){
                if(res.code==0){
                    var src = 'data:image/png;base64,'+res.data;
                    $(".graphCode").attr("src",src);
                }
            }
        });
    };
    //刷新图形验证码
    $(".graphCode").click(function () {
        refreshCodeFun();
    });
    //获取验证码按钮  ----弹出图形验证码弹框--发送短信验证码
    $("#getGraphCodeA").click(function(){
        var verifyPhone = $("#verifyPhone").val();
        if (!phoneReg.test(verifyPhone)){
            layer.msg('手机号码有误，请重新输入');
            return false;
        }else {
            refreshCodeFun();
            $("#numCodeBG").fadeIn(100);
            //图形验证码确认按钮
            $("#verifyGraphBtn").click(function(){
                var graphInput = $("#graphInput").val();
                var verifyPhone = $("#verifyPhone").val();
                if (!numReg.test(graphInput)){
                    $("#graphInput").val('');
                    layer.msg('验证码有误');
                    return false;
                }else {
                    $.ajax({//校验图形验证码
                        type: "post",
                        url: "/checkGraphCode",
                        data:{'verifiCode':graphInput},
                        success: function(result){
                            $("#graphInput").val('');
                            // console.log(res);
                            if(result.code == 0){//图形验证码正确
                                $("#numCodeBG").fadeOut(100);
                                $.ajax({//发送短信验证码
                                    type: "post",
                                    url: "/api/v2/user/sendSms.do",
                                    data:{'type':4,'mobile':verifyPhone},
                                    success: function(res){
                                        // console.log(res);
                                        if(res.code == 0){
                                            layer.msg('验证码发送成功');
                                        }else if(res.code == -14){
                                            layer.msg('该手机号发送短信次数过于频繁');
                                        }else if(res.code == -20){
                                            layer.msg('系统繁忙，请稍后再试');
                                        }else{
                                            // console.log(res);
                                            layer.msg('发送失败');
                                        }
                                    }
                                });
                            }else if(result.code == -1){
                                layer.msg('图形验证码有误');
                            }
                        }
                    });
                }
            });
        }
    });
    $("#getGraphCodeB").click(function(){
        var signupInput = $("#signupInput").val();
        if (!phoneReg.test(signupInput)){
            layer.msg('手机号码有误，请重新输入');
            return false;
        }else {
            $.ajax({
                type: "post",
                url: "/api/v1/user/getIsRegister.do",
                data: {'mobile': signupInput},
                success: function (result) {
                    // console.log(result);
                    if(result.code == -101){
                        layer.msg('手机号已被注册');
                    }else{
                        refreshCodeFun();
                        $("#numCodeBG").fadeIn(100);
                        //图形验证码确认按钮
                        $("#verifyGraphBtn").click(function(){
                            var graphInput = $("#graphInput").val();
                            var signupInput = $("#signupInput").val();
                            if (!numReg.test(graphInput)){
                                $("#graphInput").val('');
                                layer.msg('验证码有误');
                                return false;
                            }else {
                                $.ajax({//校验图形验证码
                                    type: "post",
                                    url: "/checkGraphCode",
                                    data:{'verifiCode':graphInput},
                                    success: function(resp){
                                        $("#graphInput").val('');
                                        if(resp.code == 0){//图形验证码正确
                                            $("#numCodeBG").fadeOut(100);
                                            $.ajax({//发送短信验证码
                                                type: "post",
                                                url: "/api/v2/user/sendSms.do",
                                                data:{'type':0,'mobile':signupInput},
                                                success: function(res){
                                                    // console.log(res);
                                                    if(res.code == 0){
                                                        layer.msg('验证码发送成功');
                                                    }else if(res.code == -14){
                                                        layer.msg('该手机号发送短信次数过于频繁');
                                                    }else if(res.code == -20){
                                                        layer.msg('系统繁忙，请稍后再试');
                                                    }else if(res.code == -101){
                                                        layer.msg('手机号已被注册');
                                                    }else{
                                                        layer.msg('发送失败');
                                                    }
                                                }
                                            });
                                        }else if(resp.code == -1){
                                            layer.msg('图形验证码有误');
                                        }
                                    }
                                });
                            }
                        });
                    }
                }
            });
        }
    });
    //账号密码登录
    $("#accountLogin").change(function(){
        var accountLogin = $("#accountLogin").val();
        if (!phoneReg.test(accountLogin)){
            layer.msg('手机号码有误，请重新输入');
        }
    });
    $("#accountLoginBtn").click(function () {
        var accountLogin = $("#accountLogin").val();
        var accountLoginPass = $("#accountLoginPass").val();
        if (!phoneReg.test(accountLogin)){
            layer.msg('手机号码有误，请重新输入');
            return false;
        }else if(accountLoginPass == ''){
            layer.msg('请输入正确的密码');
            return false;
        }else{
            $.ajax({
                type: "post",
                url: "/api/v1/user/login.do",
                data:{'mobile':accountLogin,'password':accountLoginPass},
                success: function(res){
                    // console.log(res);
                    if(res.code == 0){
                        // console.log(res);
                        window.location.reload(true);
                    }else if(res.code == -16){//帐号不存在
                        layer.msg('帐号不存在');
                    }else if(res.code == -100){//账号或密码不匹配
                        layer.msg('账号或密码不匹配');
                    }
                }
            });
        };
    });

    //验证码登录
    $("#verifyLoginbtn").click(function () {
        var verifyPhone = $("#verifyPhone").val();
        var msgCode = $("#msgCode").val();
        if (!phoneReg.test(verifyPhone)){
            layer.msg('手机号码有误，请重新输入');
            return false;
        }else if(msgCode == ''){
            layer.msg('请输入正确的短信验证码');
            return false;
        }else{
            $.ajax({
                type: "post",
                url: "/api/v2/user/login.do",
                data:{
                    mobile: verifyPhone,
                    authCode: msgCode,
                    loginSource: 'WEB官网'
                },
                success: function(res){
                    // console.log(res);
                    if(res.code == 0){
                        window.location.reload(true);
                    }else if(res.code == -6){
                        layer.msg('短信验证码无效');
                    }
                }
            });
        };
    });

    //注册
    $("#registerBtn").click(function () {
        var signupInput = $("#signupInput").val();
        var signupCode = $("#signupCode").val();
        var signupPassword = $("#signupPassword").val();
        var signupNick = $("#signupNick").val();
        if (!phoneReg.test(signupInput)){
            layer.msg('手机号码有误，请重新输入');
            return false;
        }else if(!verifyReg.test(signupCode)){
            layer.msg('请输入正确的短信验证码');
            return false;
        }else if(!passwordReg.test(signupPassword) || signupPassword.length < 6 || signupPassword.length > 20){
            layer.msg('请按要求设置密码');
            return false;
        }else if(signupNick.length > 10 || signupNick.length < 1){
            layer.msg('请按要求设置昵称');
            return false;
        }else{
            $.ajax({
                type: "post",
                url: "/api/v1/user/register.do",
                data:{
                    mobile: signupInput,
                    password: signupPassword,
                    nickName: signupNick,
                    authCode: signupCode
                },
                success: function(res){
                    // console.log(res);
                    if(res.code == 0){
                        window.location.reload(true);
                    }else if(res.code == -6){
                        layer.msg('手机验证码无效');
                    }else if(res.code == -104){
                        layer.msg('昵称已存在');
                    }else{
                        // console.log(res);
                        layer.msg(res.msg);
                    }
                }
            });
        };
    });

    //忘记密码
    $("#resetPhone").change(function(){
        var resetPhone = $("#resetPhone").val();
        if (!phoneReg.test(resetPhone)){
            layer.msg('手机号码有误，请重新输入');
        }
    });
    $("#resetCodeBtn").click(function(){
        var resetPhone = $("#resetPhone").val();
        if (!phoneReg.test(resetPhone)){
            layer.msg('手机号码有误，请重新输入');
            return false;
        }else {
            refreshCodeFun();
            $("#numCodeBG").fadeIn(100);
            //图形验证码确认按钮
            $("#verifyGraphBtn").click(function(){
                var graphInput = $("#graphInput").val();
                var resetPhone = $("#resetPhone").val();
                if (!numReg.test(graphInput)){
                    $("#graphInput").val('');
                    layer.msg('验证码有误');
                    return false;
                }else {
                    $.ajax({//校验图形验证码
                        type: "post",
                        url: "/checkGraphCode",
                        data:{'verifiCode':graphInput},
                        success: function(res){
                            $("#graphInput").val('');
                            // console.log(res);
                            if(res.code == 0){//图形验证码正确
                                $("#numCodeBG").fadeOut(100);
                                $.ajax({//发送短信验证码
                                    type: "post",
                                    url: "/api/v2/user/sendSms.do",
                                    data:{'type':1,'mobile':resetPhone},
                                    success: function(res){
                                        // console.log(res);
                                        if(res.code == 0){
                                            layer.msg('验证码发送成功');
                                            $("#resetBtn").click(function () {
                                                var resetCode = $("#resetCode").val();
                                                var resetPassword = $("#resetPassword").val();
                                                $.ajax({//重置密码
                                                    type: "post",
                                                    url: "/api/v1/user/resetPwd.do",
                                                    data: {'mobile': resetPhone,'password':resetPassword,'authCode':resetCode},
                                                    success: function (res) {
                                                        // console.log(res);
                                                        if(res.code == 0){
                                                            layer.msg('重置成功');
                                                            window.location.hash = '#login';
                                                            $(".signBar").css("display","block");
                                                            $(".forgetBar").css("display","none");
                                                        }else if(res.code == -16){
                                                            layer.msg('用户不存在');
                                                        }else if(res.code == -6){
                                                            layer.msg('手机验证码无效');
                                                        }
                                                    }
                                                });
                                            })
                                        }else if(res.code == -14){
                                            layer.msg('该手机号发送短信次数过于频繁');
                                        }else if(res.code == -20){
                                            layer.msg('系统繁忙，请稍后再试');
                                        }else if(res.code == -101){
                                            layer.msg('手机号已被注册');
                                        }else if(res.code == -9998){
                                            layer.msg('发送失败');
                                        }
                                    }
                                });
                            }else if(res.code == -1){
                                layer.msg('图形验证码有误');
                            }
                        }
                    });
                }
            });
        }
    });
});

