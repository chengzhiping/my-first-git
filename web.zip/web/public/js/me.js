var uid;
var token;
$(document).ready(function() {
	var phoneReg = /^[1][34578]\d{9}$/; //手机号码正则
	var passwordReg = /^[0-9a-zA-Z]+$/ //密码正则
	var numReg = new RegExp(/^\d{4}$/); //图形验证码
	var verifyReg = new RegExp(/^\d{6}$/); //短信验证码
	$(".headerWrap").load("/header");
	$("#footerBox").load("/footer");
	//回到头部
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800);
	});
	//tab
	tabFun(".meBoxWrapLInfo", "meBoxWrapLInfoActive", ".meBoxWrapRList");
	//基本信息
	tabFun(".sameMeTopTitle", "sameMeTopActive", ".basicInformation");
	//消息中心
	tabFun(".myNewsTopList", "sameMeTopActive", ".myNewsBottomInfo");
	//评论
	tabFun(".myNewsDiscussList", "myNewsDiscussListActive", ".myNewsDiscussBoxList");
	//专栏直播间
	tabFun(".liveAndculumnList", "sameMeTopActive", ".meliveAndculumn");
	//我的已购
	tabFun(".boughtList", "sameMeTopActive", ".meBoughtListBox");

	var tab = GetQueryString("tab");
	
	if(tab != "" && tab != undefined && tab != null) {
		//console.log(tab);
		tabFun1(tab);
	} else {
		$(".meBoxWrapLInfo").eq(0).addClass("meBoxWrapLInfoActive").siblings().remove("meBoxWrapLInfoActive");
		$(".meBoxWrapRList").eq(0).css("display", "block").siblings(".meBoxWrapRList").css("display", "none");
	}

	function tabFun1(tab) {
		$(".meBoxWrapLInfo").eq(tab - 1).addClass("meBoxWrapLInfoActive").siblings().remove("meBoxWrapLInfoActive");
		$(".meBoxWrapRList").eq(tab - 1).css("display", "block").siblings(".meBoxWrapRList").css("display", "none");
		var oTop = (tab - 1) * 50;
		$(".meBoxWrapLInfo").eq(tab - 1).css({
			"background-image": "url(../images/meBj1.png)",
			"background-repeat": "no-repeat",
			"background-size": "18px 367px",
			"background-position": 88 + "px " + (-oTop - 0) + "px",
		}).siblings(".meBoxWrapLInfo").css({
			"background-image": "url(../images/meBj2.png)",
			"background-repeat": "no-repeat",
			"background-size": "18px 367px",
			"background-position": 88 + "px " + (-oTop - 0) + "px",
		})
	}
//	var bindType = GetQueryString("bindType");//绑定失败
//	if(bindType != "" && bindType != undefined && bindType != null){
//		if(bindType==1){
//			$(".sameMeTopTitleTab1").eq(1).addClass("sameMeTopActive").siblings().remove("sameMeTopActive");
//			$(".basicInformation").eq(1).css("display", "block").siblings(".basicInformation").css("display", "none");
//			bindingThirdparty();
//		}
//	}else{
//		$(".sameMeTopTitleTab1").eq(0).addClass("sameMeTopActive").siblings().remove("sameMeTopActive");
//		$(".basicInformation").eq(0).css("display", "block").siblings(".basicInformation").css("display", "none");
//	}
	
	function bindingThirdparty(){
		$.ajax({
			type: "get",
			url: "/bindingThirdparty",
			success: function(res) {
				if(res.code == 0) { //绑定成功
					layer.msg("恭喜您，绑定成功");
				}else{
					layer.msg("该账号已被绑定！");
				}
			}
		});
	}
	//左边的图标
	$(".meBoxWrapLList .meBoxWrapLInfo").each(function(i) {
		var oTop = i * 50;
		$(this).css({
			"background-image": "url(../images/meBj2.png)",
			"background-repeat": "no-repeat",
			"background-size": "18px 367px",
			"background-position": 88 + "px " + (-oTop - 0) + "px",
		})
	});

	$(".meBoxWrapLList .meBoxWrapLInfo").click(function(i) {
		var oTop = i * 50;
		$(this).css({
			"background-image": "url(../images/meBj1.png)",
			"background-repeat": "no-repeat",
			"background-size": "18px 367px",
			"background-position": 88 + "px " + (-oTop - 0) + "px",
		}).siblings(".meBoxWrapLInfo").css({
			"background-image": "url(../images/meBj2.png)",
			"background-repeat": "no-repeat",
			"background-size": "18px 367px",
			"background-position": 88 + "px " + (-oTop - 0) + "px",
		})
	});

	//消息中心
	/*直播消息*/
	//登录成功

	loginFun();

	function loginFun() {
		$.ajax({
			type: "get",
			url: "/userInfos",
			success: function(res) {

				if(res.code == 0) { //登录
					//console.log(res);
					uid = res.data.userInfo.uid;
					token = res.data.token;
					nickName = res.data.userInfo.nickName;
					bindAccountsPhoneFun(uid, token);
					getLiveRoomMsgList(uid, token, 1, 10); //直播消息
					selectAgreeList(uid, 2, token, 1, 10); //我的收藏
					selectAgreeList(uid, 1, token, 1, 10); //我的赞
					selectMySubscribe(uid, 3, 2, 0, 1, 10, token) //我的订阅直播间
					selectMySubscribe(uid, 3, 2, 1, 1, 10, token) //我的已购直播间
					selectReceptorFun(uid, 1, 10) //关注的人
					wxUnifiedOrder(uid, token); //支付
					payFun(uid, token) //余额
					//个人资料
					if(res.data.userInfo.headImgUrl) {
						$(".updataBtnBoxMeImg").attr("src", res.data.userInfo.headImgUrl)
					};
					if(res.data.userInfo.nickName) {
						$("#nickNameMe").val(res.data.userInfo.nickName);
					};
					if(res.data.userInfo.signature) {
						$("#signMe").val(res.data.userInfo.signature);
					};
					if(res.data.userInfo.resume) {
						$("#resumeMe").val(res.data.userInfo.resume);
					};
					if(res.data.userInfo.positionName) {
						$("#positionNameMe").html(res.data.userInfo.positionName);
					};
					//认证
					if(res.data.userInfo.authType == 1) { //实名认证
						$(".authTypeMe").attr("src", "../images/signMe3.png");
					} else if(res.data.userInfo.authType == 2) { //操盘手
						$(".authTypeMe").attr("src", "../images/signMe1.png");
					} else if(res.data.userInfo.authType == 3) { //机构认证
						$(".authTypeMe").attr("src", "../images/signMe2.png");
					} else if(res.data.userInfo.authType == 0) { //普通用户
						$(".authTypeMe").stop().hide();
						$(".authTypeMe1").stop().show();
					}

					//修改头像
					descriptionImgUrlVipImg(uid, token, "updataBtnBoxMeBtn", "updataBtnBoxMe", ".updataBtnBoxMeImg")
					updateUserFun(uid, token); //修改基本信息

					//上传身份证
					//上传身份证照片
					descriptionImgUrlVip(uid, token, "realNameAuthenticationBtn", "realNameAuthenticationBox", ".realNameAuthenticationBImg");

					//绑定判断
					//已绑定的账号类型{0=未知，1=手机号，2=邮箱，3=微博，4=微信，5=QQ, 6=自定义用户名}
					var bindAccounts = res.data.userInfo.bindAccounts
					var bindAccountsLen = res.data.userInfo.bindAccounts.length;
					for(var Q = 0; Q < bindAccountsLen; Q++) {
						var bindAccountsType = bindAccounts[Q].type;
						if(bindAccountsType == 1) {
							$(".bindAccountsPhoneNickName").html(bindAccounts[Q].nickName);
							$("#phone_size1").val(bindAccounts[Q].nickName);
							$(".bindAccountsPhoneImg").attr("src", "../images/phoneMeP.png");
							$(".bindAccountsPhoneSure").stop().show();
							$(".bindAccountsPhoneStar").stop().hide();
						} else if(bindAccountsType == 3) {
							$(".bindAccountsWeChatImg").html(bindAccounts[Q].nickName);
							$(".bindAccountsWeChatImg").attr("src", "../images/xinlangMeP.png");
							$(".bindAccountsWeChatSure").stop().show();
							$(".bindAccountsWeChatStar").stop().hide();
						} else if(bindAccountsType == 4) {
							$(".bindAccountsXLImg").html(bindAccounts[Q].nickName);
							$(".bindAccountsXLImg").attr("src", "../images/weixin.png");
							$(".bindAccountsXLSure").stop().show();
							$(".bindAccountsxLStar").stop().hide();
						} else if(bindAccountsType == 5) {
							$(".bindAccountsQQImg").html(bindAccounts[Q].nickName);
							$(".bindAccountsQQImg").attr("src", "../images/QQMeP.png");
							$(".bindAccountsQQSure").stop().show();
							$(".bindAccountsQQStar").stop().hide();
						}

					}
					//充值密码
					$(".bindAccountsPhonePaw").click(function() {
						$(".phone_bind_wrap1").stop().show();
					});

					//实名认证
					selectAuditStatusFun(uid, token);

				} else if(res.code == -2) { //未登录
					$("#loginAlert").stop().show();
					$("#loginAlert").load("/login");
				}
			}
		})

	}

	//修改用户基本信息
	function updateUserFun(uid, token) {
		$(".basicInformationSaveBtn").click(function() {
			var nickName = $("#nickNameMe").val();
			var signature = $("#signMe").val();
			var resume = $("#resumeMe").val();
			$.ajax({
				type: "post",
				async: true,
				dataType: "json",
				url: "/api/v1/user/updateUser.do",
				data: {
					"nickName": nickName,
					"uid": uid,
					"token": token,
					"signature": signature,
					"resume": resume,
				},
				success: function(res) {
					//console.log(res);
					if(res.code == 0) {
						layer.msg("修改成功");
						setTimeout(function(){
						   window.location.reload();
						},1000)
					}else if(res.code == -104){
						layer.msg("昵称已存在");
						setTimeout(function(){
						   window.location.reload();
						},1000)
					}else if(res.code == -15){
						layer.msg("昵称长度应为2-20个字符");
						setTimeout(function(){
						   window.location.reload();
						},1000)
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				}
			})
		})
	}
	//修改手机号码
	//获取图形验证码
	function refreshCodeFun() {
		$.ajax({
			type: "GET",
			url: "/refreshGraphCode",
			success: function(res) {
				if(res.code == 0) {
					var src = 'data:image/png;base64,' + res.data;
					$(".graphCode").attr("src", src);
				}
			}
		});
	};
	//刷新图形验证码
	$(".graphCode").click(function() {
		refreshCodeFun();
	});
	//获取验证码按钮  ----弹出图形验证码弹框--发送短信验证码
	//发送短信token接口-type短信用途类型{0=注册，1=找回密码或修改密码，2=绑定手机号，3=主播申请}
	$("#getreputPassword").click(function() {
		var resetPhone = $("#phone_size1").val();
		if(!phoneReg.test(resetPhone)) {
			layer.msg('手机号码有误，请重新输入');
			return false;
		} else {
			refreshCodeFun();
			$(".phone_bind_wrap1").stop().hide();
			$("#numCodeBG").fadeIn(100);
			//图形验证码确认按钮
			$("#verifyGraphBtn").click(function() {
				var graphInput = $("#graphInput").val();
				if(!numReg.test(graphInput)) {
					$("#graphInput").val('');
					layer.msg('验证码有误');
					return false;
				} else {
					$.ajax({ //校验图形验证码
						type: "post",
						url: "/checkGraphCode",
						data: { 'verifiCode': graphInput },
						success: function(res) {
							$("#graphInput").val('');
							// console.log(res);
							if(res.code == 0) { //图形验证码正确
								$("#numCodeBG").fadeOut(100);
								$.ajax({ //发送短信验证码
									type: "post",
									url: "/api/v2/user/sendSms.do",
									data: { 'type': 1, 'mobile': resetPhone },
									success: function(res) {
										// console.log(res);
										if(res.code == 0) {
											layer.msg('验证码发送成功');
											$(".phone_bind_wrap1").stop().show();
											var times = 60;
											var isinerval;
											$("#getreputPassword").attr("disabled", true);
											isinerval = setInterval(function() {
												if(times < 0) {
													$("#getreputPassword").html("获取验证码").attr("disabled", false);
													clearInterval(isinerval);
													return
												}
												$("#getreputPassword").html(times + "秒后再点击");
												times--
											}, 1000)
											$("#mimaChange").click(function() {
												var resetCode = $("#code_size1").val();
												var resetPassword = $("#pwd_size1").val();
												$.ajax({ //重置密码
													type: "post",
													url: "/api/v1/user/resetPwd.do",
													data: { 'mobile': resetPhone, 'password': resetPassword, 'authCode': resetCode },
													success: function(res) {
														// console.log(res);
														if(res.code == 0) {
															layer.msg('重置成功');
															$(".phone_bind_wrap1").stop().hide();
														} else if(res.code == -16) {
															layer.msg('用户不存在');
														} else if(res.code == -6) {
															layer.msg('手机验证码无效');
														}
													}
												});
											})
										} else if(res.code == -14) {
											layer.msg('该手机号发送短信次数过于频繁');
										} else if(res.code == -20) {
											layer.msg('系统繁忙，请稍后再试');
										} else if(res.code == -101) {
											layer.msg('手机号已被注册');
										} else if(res.code == -9998) {
											layer.msg('发送失败');
										}
									}
								});
							} else if(res.code == -1) {
								layer.msg('图形验证码有误');
							}
						}
					});
				}
			});
		}
	});

	function bindAccountsPhoneFun(uid, token) {
		//绑定手机号码
		$(".bindAccountsPhoneStar").click(function() {
			$(".phone_bind_wrap").stop().show();
		})

		$("#getBangdingYan").click(function() {
			var resetPhone = $("#pnone_size").val();
			if(!phoneReg.test(resetPhone)) {
				layer.msg('手机号码有误，请重新输入');
				return false;
			} else {
				refreshCodeFun();
				$(".phone_bind_wrap").stop().hide();
				$("#numCodeBG").fadeIn(100);
				//图形验证码确认按钮
				$("#verifyGraphBtn").click(function() {
					var graphInput = $("#graphInput").val();
					if(!numReg.test(graphInput)) {
						$("#graphInput").val('');
						layer.msg('验证码有误');
						return false;
					} else {
						$.ajax({ //校验图形验证码
							type: "post",
							url: "/checkGraphCode",
							data: { 'verifiCode': graphInput },
							success: function(res) {
								$("#graphInput").val('');
								// console.log(res);
								if(res.code == 0) { //图形验证码正确
									$("#numCodeBG").fadeOut(100);
									$.ajax({ //发送短信验证码
										type: "post",
										url: "/api/v2/user/sendSms.do",
										data: { 'type': 2, 'mobile': resetPhone },
										success: function(res) {
											// console.log(res);
											if(res.code == 0) {
												layer.msg('验证码发送成功');
												$(".phone_bind_wrap").stop().show();
												var times = 60;
												var isinerval;
												$("#getBangdingYan").attr("disabled", true);
												isinerval = setInterval(function() {
													if(times < 0) {
														$("#getBangdingYan").html("获取验证码").attr("disabled", false);
														clearInterval(isinerval);
														return
													}
													$("#getBangdingYan").html(times + "秒后再点击");
													times--
												}, 1000)
												$("#bangdingConfirm").click(function() {
													var resetCode = $("#code_size").val();
													var resetPassword = $("#pwd_size").val();
													$.ajax({ //重置密码
														type: "post",
														url: "/api/v1/user/bindingMobile.do",
														data: { 'mobile': resetPhone, 'password': resetPassword, 'authCode': resetCode,'uid': uid, 'token': token },
														success: function(res) {
															// console.log(res);
															if(res.code == 0) {
																layer.msg('绑定手机号码成功');
																$(".phone_bind_wrap").stop().hide();
															} else if(res.code == -16) {
																layer.msg('用户不存在');
															} else if(res.code == -6) {
																layer.msg('手机验证码无效');
															}
														}
													});
												})
											} else if(res.code == -14) {
												layer.msg('该手机号发送短信次数过于频繁');
											} else if(res.code == -20) {
												layer.msg('系统繁忙，请稍后再试');
											} else if(res.code == -101) {
												layer.msg('手机号已被注册');
											} else if(res.code == -9998) {
												layer.msg('发送失败');
											}
										}
									});
								} else if(res.code == -1) {
									layer.msg('图形验证码有误');
								}
							}
						});
					}
				});
			}
		});
	}

    //绑定QQ

	//获取直播消息列表
	var getLiveRoomMsgListIndex = 1;
	var bottomH = 150;

	function getLiveRoomMsgList(uid, token, pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/msgCenter/getLiveRoomMsgList.do",
			data: {
				"uid": uid,
				"token": token,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data == "") {
						$(".getLiveRoomMsgListSameAddMore").stop().hide();
						$(".getLiveRoomMsgListSameAddEnd").stop().show();
					}
					if(res.data != "") {
						$(".getLiveRoomMsgListSameAddMore").click(function() {
							getLiveRoomMsgListIndex++;
							getLiveRoomMsgList(uid, token, getLiveRoomMsgListIndex, pageSize);
						});
					}
					$(res.data).each(function(q, M) {
						var getLiveRoomMsgListHref = M.msgId + "getLiveRoomMsgListHref";
						var meLiveInformation =
							'<li class="meLiveInformation" id=' + getLiveRoomMsgListHref + ' uid=' + M.uid + ' roomid=' + M.liveRoomId + '>' +
							'<img class="fl" src="' + M.coverUrl + '" />' +
							'<div class="meLiveInformationR fl">' +
							'<p class="meLiveInformationRT">' +
							'<span class="meSameNewsTitle fl">' + M.roomName + '</span>' +
							'<span class="meSameNewsTime fr">' + format(new Date(M.createTime)) + '</span>' +
							'</p>' +
							'<p class="meLiveInformationRSameBottom">' + M.content + '</p>' +
							'</div>' +
							"</li>";
						$(".meLiveInformationBox").append(meLiveInformation);
						$("#" + getLiveRoomMsgListHref).click(function() {
							var uid = $(this).attr("uid");
							var roomid = $(this).attr("roomid");
							window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
						});

					});
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})
	}
	//获得私信列表
	$(".getOfficialLetterListBtn").click(function() { //私信
		$(".mePersonalLetterBox").html("");
		getOfficialLetterList(uid, token, 1, 10);
	})
	var getOfficialLetterListIndex = 1;

	function getOfficialLetterList(uid, token, pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/msgCenter/getOfficialLetterList.do",
			data: {
				"uid": uid,
				"token": token,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.length == 0) {
						$(".getOfficialLetterListSameAddMore").stop().hide();
						$(".getOfficialLetterListSameAddEnd").stop().show();
					}
					if(res.data != "") {
						$(".getOfficialLetterListSameAddMore").click(function() {
							getOfficialLetterListIndex++;
							getOfficialLetterList(uid, token, getOfficialLetterListIndex, pageSize);
						});
					}
					$(res.data).each(function(q, N) {
						var getOfficialLetterListHref = N.senderInfo.uid + "getOfficialLetterListHref";
						var meLiveInformation =
							'<li class="meLiveInformation" id=' + getOfficialLetterListHref + ' senderUid=' + N.senderInfo.uid + '>' +
							'<img class="fl mePersonalLetterImg" src="' + N.senderInfo.headImgUrl + '" />' +
							'<div class="meLiveInformationR fl">' +
							'<p class="meLiveInformationRT">' +
							'<span class="fl meSameNewsTitle">' + N.senderInfo.nickName + '</span>' +
							'<span class="fl meSameNewsLogo">官方</span>' +
							'<span class="fr meSameNewsTime">' + format(new Date(N.sendTime)) + '</span>' +
							'</p>' +
							'<p class="meLiveInformationRSameBottom">' + removeHTMLTag(htmlEncode(N.content)) + '</p>' +
							'</div>' +
							"</li>";
						$(".mePersonalLetterBox").append(meLiveInformation);
						$("#" + getOfficialLetterListHref).click(function() {
							var senderUid = $(this).attr("senderUid");
							$(".mePersonalLetterBoxWrapUp").stop().hide();
							$(".mePersonalLetterDetails").stop().show();
							$(".mePersonalLetterDetailsBWrap").html("");
							getPrivateLetter(uid, token, senderUid, 1, 10);
						});

					});
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})
	}
	//获取用户私信接口
	var getPrivateLetterIndex = 1;

	function getPrivateLetter(uid, token, senderUid, pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/msgCenter/getPrivateLetter.do",
			data: {
				"uid": uid,
				"token": token,
				"senderUid": senderUid,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.length == 0) {
						$(".getPrivateLetterSameAddMore").stop().hide();
						$(".getPrivateLetterSameAddEnd").stop().show();
					}
					if(res.data != "") {
						$(".getPrivateLetterSameAddMore").click(function() {
							getPrivateLetterIndex++
							getPrivateLetter(uid, token, senderUid, getPrivateLetterIndex, 10);
						});
						$(".mePersonalLetterDetailsT").html(res.data[0].senderInfo.nickName + "的私信");
						$(res.data).each(function(q, W) {
							var getPrivateLetter =
								'<div class="mePersonalLetterDetailsB">' +
								'<p class="mePersonalLetterDetailsBT">' + format(new Date(W.sendTime)) + '</p>' +
								'<div class="mePersonalLetterDetailsBB">' +
								'<img class="fl" src="' + W.senderInfo.headImgUrl + '" />' +
								'<div class="mePersonalLetterDetailsBBR fl">' +
								'<p><span>' + W.senderInfo.nickName + '</span><span class="meSameNewsLogo">官方</span></p>' +
								'<p>' + removeHTMLTag(htmlEncode(W.content)) + '</p>' +
								'</div>' +
								'</div>' +
								'</div>';
							$(".mePersonalLetterDetailsBWrap").append(getPrivateLetter);
						});
					}
					//返回按钮
					$(".mePersonalLetterDetailsT").click(function() {
						$(".mePersonalLetterBoxWrapUp").stop().show();
						$(".mePersonalLetterDetails").stop().hide();
					})
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})

	}

	//获取发出的评论列表
	$(".getSendCommentByUidBtn").click(function() {
		$(".myNewsDiscussBoxListSendBox").html("");
		getSendCommentByUid(uid, token, 1, 10);
	});
	var getReceiveCommentByUidSameAddMoreIndex = 1;

	function getSendCommentByUid(uid, token, pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/comment/getSendCommentByUid.do",
			data: {
				"uid": uid,
				"token": token,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.length == 0) {
						$(".getReceiveCommentByUidSameAddMore").stop().hide();
						$(".getReceiveCommentByUidSameAddEnd").stop().show();

					}
					if(res.data != "") {
						$(".getReceiveCommentByUidSameAddMore").click(function() {
							getReceiveCommentByUidSameAddMoreIndex++;
							getSendCommentByUid(uid, token, getReceiveCommentByUidSameAddMoreIndex, 10);
						});
						var res = res.data;
						getSendReceiveCommentByUidData(res, "getSendCommentByUid");
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})

	}
	//获取收到的评论列表
	var getReceiveCommentByUidIndex = 1;
	$(".getReceiveCommentByUidBtn").click(function() {
		$(".myNewsDiscussBoxListGetBox").html("");
		getReceiveCommentByUid(uid, token, 1, 10);
	});

	function getReceiveCommentByUid(uid, token, pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/comment/getReceiveCommentByUid.do",
			data: {
				"uid": uid,
				"token": token,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.length == 0) {
						$(".myNewsDiscussBoxListGetBoxSameAddMore").stop().hide();
						$(".myNewsDiscussBoxListGetBoxSameAddEnd").stop().show();
					}
					if(res.data != "") {
						$(".myNewsDiscussBoxListGetBoxSameAddMore").click(function() {
							getReceiveCommentByUidIndex++;
							getReceiveCommentByUid(uid, token, getReceiveCommentByUidIndex, 10);
						})
						var res = res.data;
						getSendReceiveCommentByUidData(res, "getReceiveCommentByUid");
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})

	}
	//处理发送信息和接收的信息
	function getSendReceiveCommentByUidData(res, getCommentByUidType) {
		//console.log(res);
		$(res).each(function(q, B) {
			var commentType = B.commentType; //评论类型{1=一级评论；2=二级评论}
			var getCommentByUidTypeSend = B.id + "getCommentByUidTypeSend";
			var getCommentByUidTypeSend1 = B.id + "getCommentByUidTypeSend1";
			var articleType = B.articleType; //1短评 2 文章
			var multipleVideo = B.multipleVideoType; //multipleVideo，字段是这个，2是视频，3是音频
			var type = B.type; //{2=专题；3=文章；4=视频；5=直播}
			var typeId = B.id + "typeId" + B.type + getCommentByUidType;
			var locationHrefId = B.id + "locationHrefId" + B.type + getCommentByUidType;
			var locationImgId = B.id + "locationImgId" + B.type + getCommentByUidType;
			if(commentType == 1) {
				var commentTypeOneBox =
					' <div class="myNewsDiscussBoxInfo" id=' + locationHrefId + ' objectId=' + B.objectId + '>' +
					'<img id=' + locationImgId + ' class="fl sameMeImg" src="' + B.commentatorInfo.headImgUrl + '" />' +
					'<div class="meLiveInformationR fl">' +
					'<p class="meLiveInformationRT"><span class="meSameNewsTitle fl">' + B.commentatorInfo.nickName + '</span><span class="meSameNewsTime fr">' + format(new Date(B.time)) + '</span></p>' +
					'<p class="myNewsDiscussSend">' + B.comment + '</p>' +
					'<p class="myNewsDiscussSendBottom">' +
					'<span id=' + getCommentByUidTypeSend + '>评论了我：</span>' +
					'<img id=' + typeId + ' src="images/meVideoLogo.png" />' +
					'<span>' + B.objectInfo + '</span>' +
					'</p>' +
					'</div>' +
					'</div>';
				if(getCommentByUidType == "getSendCommentByUid") {
					$(".myNewsDiscussBoxListSendBox").append(commentTypeOneBox);
				} else {
					$(".myNewsDiscussBoxListGetBox").append(commentTypeOneBox);
				}
			} else if(commentType == 2) {
				var commentTypeTwoBox =
					'<div class="myNewsDiscussBoxInfo" id=' + locationHrefId + ' objectId=' + B.objectId + '>' +
					'<img id=' + locationImgId + ' class="fl sameMeImg" src="' + B.commentatorInfo.headImgUrl + '" />' +
					'<div class="meLiveInformationR fl">' +
					'<p class="meLiveInformationRT"><span class="meSameNewsTitle fl">' + B.commentatorInfo.nickName + '</span><span class="meSameNewsTime fr">' + format(new Date(B.time)) + '</span></p>' +
					'<p class="myNewsDiscussSendTwo"><span>回复了' + B.parentCommentObj.parentCommentatorInfo.nickName + '：</span><span>' + B.comment + '</span></p>' +
					'<p class="myNewsDiscussSend">' + B.parentCommentObj.parentComment + '</p>' +
					'<p class="myNewsDiscussSendBottom">' +
					'<span id=' + getCommentByUidTypeSend1 + '>我评论了' + B.commentatorInfo.nickName + '：</span>' +
					'<img id=' + typeId + ' src="images/meVideoLogo.png" />' +
					'<span>' + B.objectInfo + '</span>' +
					'</p>' +
					'</div>' +
					"</div>";
				if(getCommentByUidType == "getSendCommentByUid") {
					$(".myNewsDiscussBoxListSendBox").append(commentTypeTwoBox);
				} else {
					$(".myNewsDiscussBoxListGetBox").append(commentTypeTwoBox);
				}
			}
			if(type == 3) {
				$("#" + typeId).attr("src", "../images/meArticleLogoi.png");
				if(articleType == 1) { //短评
					$("#" + locationHrefId).click(function() {
						var id = $(this).attr("objectId");
						window.location.href = "/shortView?id=" + id;
					})

				} else if(articleType == 2) { //文章
					$("#" + locationHrefId).click(function() {
						var id = $(this).attr("objectId");
						window.location.href = "/article?id=" + id;
					})

				}
			} else if(type == 4) {
				if(multipleVideo == 2) { //视频
					$("#" + typeId).attr("src", "../images/meVideoLogo.png");
					$("#" + locationHrefId).click(function() {
						var id = $(this).attr("objectId");
						window.location.href = "/video?id=" + id;
					})
				} else if(multipleVideo == 3) { //音频
					$("#" + typeId).attr("src", "../images/meAudioLogo.png");
					$("#" + locationHrefId).click(function() {
						var id = $(this).attr("objectId");
						window.location.href = "/audio?id=" + id;
					})
				}
			}
			//缺省头像
			$("#" + locationImgId).one("error", function(e) {
				$(this).attr("src", "../images/anchorHead.png");
			});

		});
	}
	//消息中心-赞
	$(".getLikeListBtn").click(function() { //私信
		getLikeList(uid, token, 1, 10);
	})
	var getLikeListIndex = 1;

	function getLikeList(uid, token, pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/msgCenter/getLikeList.do",
			data: {
				"uid": uid,
				"token": token,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.length == 0) {
						$(".getLikeListSameAddMore").stop().hide();
						$(".getLikeListSameAddEnd").stop().show();
					}
					if(res.data != "") {
						$(".getLikeListSameAddMore").click(function() {
							getLikeListIndex++;
							getLikeList(uid, token, getLikeListIndex, 10);
						})
						$(res.data).each(function(j, U) {
							var myNewsDiscussSendArea = U.objectId + "myNewsDiscussSendArea" + U.userInfo.uid;
							var myNewsDiscussSendTitle = U.objectId + "myNewsDiscussSendTitle" + U.userInfo.uid;
							var type = U.objectType; //对象类型{1=文章点赞；2=视频点赞；3=直播点赞；4=话题回答、评论点赞；6=专栏点赞；7=话题点赞}
							var articleType = U.articleType; //1短评 2 文章
							var multipleVideo = U.multipleVideoType; //multipleVideo，字段是这个，2是视频，3是音频
							var getLikeListHref = U.objectId + "getLikeListHref" + U.userInfo.uid;
							var getLikeListImg = U.objectId + "getLikeListImg" + U.userInfo.uid;
							var getLikeListHead = U.objectId + "getLikeListHead" + U.userInfo.uid;
							var getLikeListIntro = U.objectId + "getLikeListIntro" + U.userInfo.uid;
							var myNewsDiscussBoxInfo =
								'<div class="myNewsDiscussBoxInfo" id=' + getLikeListHref + ' objectId=' + U.objectId + ' uid='+U.userInfo.uid+' roomId='+U.roomId+'>' +
								'<img class="fl sameMeImg" id=' + getLikeListHead + ' src="' + U.userInfo.headImgUrl + '" />' +
								'<div class="meLiveInformationR fl">' +
								'<p class="meLiveInformationRT meLoveInformationRT"><span class="meSameNewsTitle fl">' + U.userInfo.nickName + '</span><span class="meLoveInformationRTC" id=' + getLikeListIntro + '>赞了我的评论</span><span class="meSameNewsTime fr">' + format(new Date(U.time)) + '</span></p>' +
								'<p class="myNewsDiscussSend" id=' + myNewsDiscussSendArea + '>' + U.commentInfo + '</p>' +
								'<p class="myNewsDiscussSendBottom" id=' + myNewsDiscussSendTitle + '>' +
								'<span></span>' +
								'<img id=' + getLikeListImg + ' src="images/meVideoLogo.png" />' +
								'<span>' + U.objectInfo + '</span>' +
								'</p>' +
								'</div>' +
								'</div>';
							$(".getLikeListBox").append(myNewsDiscussBoxInfo);
							//							if(!U.commentInfo) {
							//								$("#" + myNewsDiscussSendArea).stop().hide();
							//							}
							//							if(!U.objectInfo) {
							//								$("#" + myNewsDiscussSendTitle).stop().hide();
							//							};
							if(type == 1) {
								$("#" + getLikeListImg).attr("src", "../images/meArticleLogoi.png");
								if(articleType == 1) { //短评
									$("#" + getLikeListIntro).html("赞了我的短评");
									$("#" + getLikeListHref).click(function() {
										var id = $(this).attr("objectId");
										window.location.href = "/shortView?id=" + id;
									})
									$("#" + myNewsDiscussSendArea).stop().hide();
								} else if(articleType == 2) { //文章
									$("#" + getLikeListIntro).html("赞了我的文章");
									$("#" + getLikeListHref).click(function() {
										var id = $(this).attr("objectId");
										window.location.href = "/article?id=" + id;
									})
									$("#" + myNewsDiscussSendArea).stop().hide();
								}
							} else if(type == 2) {
								if(multipleVideo == 2) { //视频
									$("#" + getLikeListIntro).html("赞了我的视频");
									$("#" + getLikeListImg).attr("src", "../images/meVideoLogo.png");
									$("#" + getLikeListHref).click(function() {
										var id = $(this).attr("objectId");
										window.location.href = "/video?id=" + id;
									});
									$("#" + myNewsDiscussSendArea).stop().hide();
								} else if(multipleVideo == 3) { //音频
									$("#" + getLikeListIntro).html("赞了我的音频");
									$("#" + getLikeListImg).attr("src", "../images/meAudioLogo.png");
									$("#" + getLikeListHref).click(function() {
										var id = $(this).attr("objectId");
										window.location.href = "/audio?id=" + id;
									});
									$("#" + myNewsDiscussSendArea).stop().hide();
								}
							}else if(type ==3) {
								//console.log(U);
									$("#" + getLikeListIntro).html("赞了我的直播回放");
									$("#" + getLikeListImg).attr("src", "../images/meVideoLogo.png");
									$("#" + getLikeListHref).click(function() {
										var id = $(this).attr("objectId");
										var uid = $(this).attr("uid");
										var roomId = $(this).attr("roomId");
										window.location.href = "/liveLookBack?id=" + id+"&uid="+uid+"&roomid="+roomId;
									});
									$("#" + myNewsDiscussSendArea).stop().hide();
							} else if(type == 4) {
								$("#" + myNewsDiscussSendTitle).stop().hide();
							}else{
								$("#" + getLikeListIntro).html("");
								$("#" + myNewsDiscussSendTitle).stop().hide();
							}
							//缺省头像
							$("#" + getLikeListHead).one("error", function(e) {
								$(this).attr("src", "../images/anchorHead.png");
							});

						})
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})

	}

	//我的收藏与赞
	tabFun(".collectionAndPraiseTitle", "sameMeTopActive", ".collectionAndPraise");
	//获得赞及收藏
	//我的收藏
	$(".agreeSameAddMoreBtn").click(function() {
		$(".selectSameAddMoreBox").html("");
	})
	var agreeSameAddMoreIndex = 1;
	var selectSameAddMoreIndex = 1;

	function selectAgreeList(uid, DynamicHotType, token, pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/agree/selectAgreeList.do",
			data: {
				"uid": uid,
				"agreeType": DynamicHotType, //1获取我的赞，2获取我的收藏
				"token": token,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.length == 0) {
						if(DynamicHotType == 1) {
							$(".agreeSameAddMore").stop().hide();
							$(".agreeSameAddEnd").stop().show();
						} else if(DynamicHotType == 2) {
							$(".selectSameAddMore").stop().hide();
							$(".selectSameAddEnd").stop().show();
						}
					} else {
						if(DynamicHotType == 1) {
							$(".agreeSameAddMore").click(function() {
								agreeSameAddMoreIndex++;
								selectAgreeList(uid, 1, token, agreeSameAddMoreIndex, pageSize);
							})

						} else if(DynamicHotType == 2) {
							$(".selectSameAddMore").click(function() {
								selectSameAddMoreIndex++;
								selectAgreeList(uid, 2, token, selectSameAddMoreIndex, pageSize);
							})
						}
					}
					$(res.data).each(function(i, k) {
						var objectType = k.objectType; //动态类型
						var isAgree = k.object.isAgree;
						var cancelCollectionBtn = k.object.isAgree + k.object.id + DynamicHotType + "cancelCollectionBtn";
						var isAgreeLogo = k.object.isAgree + k.object.id + DynamicHotType;
						var categoryName = k.object.liverInfo.uid + k.object.id + DynamicHotType;
						var columnName = k.object.columnName;
						var locationHrefId = k.object.publishTime + k.object.id + DynamicHotType;
						var locationHrefLiveId = k.publishTime + k.object.id + DynamicHotType;
						var objectId = k.object.id;
						var imgHref = k.object.isAgree + k.object.id + DynamicHotType + "imgHref";
						var commentCountLiveBackId= k.object.isAgree + k.object.id + DynamicHotType + "commentCountLiveBackId";
						//console.log(columnName);
						//console.log(categoryName);
						//  console.log(isAgreeLogo);
						//console.log(DynamicHotType);
						if(objectType == 1) { //文章或短评
							var type = k.object.type;
							//console.log(isAgree);
							if(type == 1) { //短评
								var media = k.object.media;
								if(media == "") { //无图短评
									var objectId = k.object.id;
									var shortViewNullImg =
										'<div class="artileBoxWrap collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
										'<div class="BoxWrapT">' +
										'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
										'<div class="liveBoxWrapTR fl">' +
										'<p>' + k.object.liverInfo.nickName + '</p>' +
										'<p>' + format(new Date(k.publishTime)) + '</p>' +
										'</div>' +
										'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
										'</div>' +
										'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
										'<ul class="sameBottom borderSameBottom">' +
										'<li class="fr sameBottomList">分享</li>' +
										'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
										'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
										'</ul>' +
										'</div>';
									if(DynamicHotType == 1) {
										$(".agreeSameAddMoreBox").before(shortViewNullImg);
										$("#" + cancelCollectionBtn).stop().hide();
									} else if(DynamicHotType == 2) {
										$(".selectSameAddMoreBox").before(shortViewNullImg);
									}
									$(document).on("click", "#" + locationHrefId, function(e) {
										var id = $(this).attr("objectId");
										window.location.href = "/shortView?id=" + id;
									});

								} else {
									var shortViewImg = (media.split(','));
									var len = shortViewImg.length;
									var shortid = k.object.id + DynamicHotType;
									if(len == 1) { //1张图
										var shortViewOneImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<a href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImgOne" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';

										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewOneImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewOneImg);
										}
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});
									} else if(len == 2) {
										var shortViewTwoImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<div class="shortViewImgBox">' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
											'</a>' +
											'</div>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';
										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewTwoImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewTwoImg);
										}
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});

									} else if(len == 3) {
										var shortViewTwoImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + ' >取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<div class="shortViewImgBox">' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
											'</a>' +
											'</div>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';

										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewTwoImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewTwoImg);
										}

										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});

									} else if(len == 4) {
										var shortViewTwoImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<div class="shortViewImgBox">' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
											'</a>' +
											'</div>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';
										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewTwoImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewTwoImg);
										}
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});

									} else if(len == 5) {
										var shortViewTwoImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<div class="shortViewImgBox">' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
											'</a>' +
											'</div>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';
										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewTwoImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewTwoImg);
										}
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});
									} else if(len == 6) {
										var shortViewTwoImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<div class="shortViewImgBox">' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
											'</a>' +
											'</div>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';
										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewTwoImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewTwoImg);
										}
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});

									} else if(len == 7) {
										var shortViewTwoImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<div class="shortViewImgBox">' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
											'</a>' +
											'</div>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';
										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewTwoImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewTwoImg);
										}
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});

									} else if(len == 8) {
										var shortViewTwoImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<div class="shortViewImgBox">' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[7] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[7] + '">' +
											'</a>' +
											'</div>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';
										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewTwoImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewTwoImg);
										}
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});

									} else if(len == 9) {
										var shortViewTwoImg =
											'<div class="artileBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '</p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<p class="articleContent">' + htmlEncode(k.object.content) + '</p>' +
											'<div class="shortViewImgBox">' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[0] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[0] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[1] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[1] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[2] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[2] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[3] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[3] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[4] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[4] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[5] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[5] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[6] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[6] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[7] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[7] + '">' +
											'</a>' +
											'<a class="shortViewImgWrap" href="' + shortViewImg[8] + '" data-lightbox="' + shortid + '">' +
											'<img class="shortViewImg" src="' + shortViewImg[8] + '">' +
											'</a>' +
											'</div>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';
										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(shortViewTwoImg);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(shortViewTwoImg);
										}
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/shortView?id=" + id;
										});

									}
								}
							} else if(type == 2) { //长文章
								var coverUrl = k.object.userCoverUrl;
								var imgNoOwnCover = k.object.id + k.object.userCoverUrl + "imgNoOwnCover";
								var articleid = k.object.id;
								var article_content = htmlEncode(k.object.content);
								if(coverUrl == "") { //无图文章——//判断文章里面是否有图片，如果有显示第一张
									var articleContent = k.object.content;
									var content = htmlEncode(articleContent);
									var imgReg = /<img.*?(?:>|\/>)/gi;
									//匹配src属性
									var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
									var imgArr = content.match(imgReg); //'所有已成功匹配图片的数组
									// console.log(imgArr);
									if(imgArr == null) {
										var nullImgArticleBox =
											'<div class="NullartileBoxWrap  collectionandPraiseSameBox" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
											'<div class="BoxWrapT">' +
											'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
											'<div class="liveBoxWrapTR fl">' +
											'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
											'<p>' + format(new Date(k.publishTime)) + '</p>' +
											'</div>' +
											'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
											'</div>' +
											'<h2> ' + k.object.title + ' </h2>' +
											'<p class="articleContent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
											'<ul class="sameBottom borderSameBottom">' +
											'<li class="fr sameBottomList">分享</li>' +
											'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
											'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
											'</ul>' +
											'</div>';
										if(DynamicHotType == 1) {
											$(".agreeSameAddMoreBox").before(nullImgArticleBox);
											$("#" + cancelCollectionBtn).stop().hide();
										} else if(DynamicHotType == 2) {
											$(".selectSameAddMoreBox").before(nullImgArticleBox);
										};
										$(document).on("click", "#" + locationHrefId, function(e) {
											var id = $(this).attr("objectId");
											window.location.href = "/article?id=" + id;
										});
									} else {
										src = imgArr[0].match(srcReg);
										//获取图片地址
										if(src[1]) {
											// console.log(src[1]);
											var ImgArticleBox =
												' <div class="imgArticleBoxWrap  collectionandPraiseSameBox" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
												'<div class="BoxWrapT">' +
												'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
												'<div class="liveBoxWrapTR fl">' +
												'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
												'<p>' + format(new Date(k.publishTime)) + '</p>' +
												'</div>' +
												'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
												'</div>' +
												'<div class="liveBoxWrapBL fl">' +
												'<img id=' + imgNoOwnCover + ' src="' + src[1] + '!220X164">' +
												'</div>' +
												'<div class="imgArticleBoxWrapBR fr">' +
												'<div class="imgArticleBoxWrapBRT">' +
												'<h3>' + k.object.title + '</h3>' +
												'<p class="imgArticleBoxWrapBCentent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
												'</div>' +
												'<div class="imgArticleBoxWrapBRB sameBottom">' +
												'<li class="fr sameBottomList">分享</li>' +
												'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
												'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
												'</div>' +
												'</div>' +
												'</div>'
											if(DynamicHotType == 1) {
												$(".agreeSameAddMoreBox").before(ImgArticleBox);
												$("#" + cancelCollectionBtn).stop().hide();
											} else if(DynamicHotType == 2) {
												$(".selectSameAddMoreBox").before(ImgArticleBox);
											}
											if(src[1].indexOf("//mmbiz.qpic.cn/mmbiz_png") == 0) {
												$("#" + imgNoOwnCover).attr("src", "images/vedioCoverUrl.jpg");
											}
											$(document).on("click", "#" + locationHrefId, function(e) {
												var id = $(this).attr("objectId");
												window.location.href = "/article?id=" + id;
											});
										}
									}

								} else { //有图文章
									var ImgArticleBox =
										' <div class="imgArticleBoxWrap  collectionandPraiseSameBox" class="NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
										'<div class="BoxWrapT">' +
										'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
										'<div class="liveBoxWrapTR fl">' +
										'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
										'<p>' + format(new Date(k.publishTime)) + '</p>' +
										'</div>' +
										'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
										'</div>' +
										'<div class="liveBoxWrapBL fl">' +
										'<img src="' + k.object.userCoverUrl + '!220X164' + '">' +
										'</div>' +
										'<div class="imgArticleBoxWrapBR fr">' +
										'<div class="imgArticleBoxWrapBRT">' +
										'<h3>' + k.object.title + '</h3>' +
										'<p class="imgArticleBoxWrapBCentent">' + removeHTMLTag(htmlEncode(k.object.content)) + '</p>' +
										'</div>' +
										'<div class="imgArticleBoxWrapBRB sameBottom">' +
										'<li class="fr sameBottomList">分享</li>' +
										'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
										'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
										'</div>' +
										'</div>' +
										'</div>'
									if(DynamicHotType == 1) {
										$(".agreeSameAddMoreBox").before(ImgArticleBox);
										$("#" + cancelCollectionBtn).stop().hide();
									} else if(DynamicHotType == 2) {
										$(".selectSameAddMoreBox").before(ImgArticleBox);
									}
									$(document).on("click", "#" + locationHrefId, function(e) {
										var id = $(this).attr("objectId");
										window.location.href = "/article?id=" + id;
									});
								}
								// console.log(k);	
							}
						} else if(objectType == 2) { //视频
							//console.log(k);
							var videoNewsWrapBox =
								'<div class="videoNewsWrap  collectionandPraiseSameBox" class="videoNewsWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
								'</div>' +
								'<div class="videoNewsBoxB">' +
								'<div class="videoNewsBoxBL fl">' +
								'<img src="images/livevideo.png" />' +
								'<img class="vedioCoverUrl" src="' + k.object.coverUrl + '">' +
								'<span>' + durationFun(new Date(k.object.duration)) + '</span>' +
								'</div>' +
								'<div class="videoNewsBoxBR fl">' +
								'<p></p>' +
								'<p>' + k.object.topic + '</p>' +
								'<p>' + k.object.watchCount + '人观看</p>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								'</div>' +
								'</div>' +
								'</div>';
							if(DynamicHotType == 1) {
								$(".agreeSameAddMoreBox").before(videoNewsWrapBox);
								$("#" + cancelCollectionBtn).stop().hide();
							} else if(DynamicHotType == 2) {
								$(".selectSameAddMoreBox").before(videoNewsWrapBox);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/video?id=" + id;
							});
						} else if(objectType == 3) { //直播
							var liveType = k.object.type;
							if(liveType == 0) {
								//console.log(k);
								//console.log(locationHrefLiveId);
								var liveBoxWrap =
									'<div class="videoNewsWrap  collectionandPraiseSameBox" class="videoNewsWrapBox" id=' + locationHrefLiveId + ' roomid=' + k.object.roomId + ' uid=' + k.object.liverInfo.uid + '>' +
									'<div class="BoxWrapT">' +
									'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + ' />' +
									'<div class="liveBoxWrapTR fl">' +
									'<p>' + k.object.liverInfo.nickName + '<span class="playStyleLive">正在公开直播</span></p>' +
									'<p>' + format(new Date(k.publishTime)) + '</p>' +
									'</div>' +
									'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefLiveId + '>取消收藏</span>' +
									'</div>' +
									'<div class="videoNewsBoxB">' +
									'<div class="videoNewsBoxBL fl">' +
									'<img src="images/livevideo.png" style="display: none;" />' +
									'<img class="vedioCoverUrl" src="' + k.object.coverUrl + '!220X164' + '">' +
									'<img src="images/live.png" />' +
									'</div>' +
									'<div class="videoNewsBoxBR fl">' +
									'<p></p>' +
									'<p>' + k.object.topic + '</p>' +
									'<p>' + k.object.watchCount + '人观看</p>' +
									'</div>' +
									'</div>' +
									'</div>';
								if(DynamicHotType == 1) {
									$(".agreeSameAddMoreBox").before(liveBoxWrap);
									$("#" + cancelCollectionBtn).stop().hide();
								} else if(DynamicHotType == 2) {
									$(".selectSameAddMoreBox").before(liveBoxWrap);
								}
								if(k.object.roomType == 1) {
									$(".playStyleLive").html("正在VIP直播：");
									$(document).on("click", "#" + locationHrefLiveId, function(e) {
										var roomid = $(this).attr("roomid");
										var uid = $(this).attr("uid");
										window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
									});
								} else if(k.object.roomType == 0) {
									$(".playStyleLive").html("正在公开直播：");
									$(document).on("click", "#" + locationHrefLiveId, function(e) {
										var roomid = $(this).attr("roomid");
										var uid = $(this).attr("uid");
										window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
									});
								}
							} else if(liveType == 1) { //回放
								var liveBoxWrap =
									'<div class="videoNewsWrap  collectionandPraiseSameBox" class="videoNewsWrapBox" id=' + locationHrefLiveId + ' roomid=' + k.object.roomId + ' uid=' + k.object.liverInfo.uid + ' objectId=' + k.object.id + '>' +
									'<div class="BoxWrapT">' +
									'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '/>' +
									'<div class="liveBoxWrapTR fl">' +
									'<p>' + k.object.liverInfo.nickName + '</p>' +
									'<p>' + format(new Date(k.publishTime)) + '</p>' +
									'</div>' +
									'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefLiveId + '>取消收藏</span>' +
									'</div>' +
									'<div class="videoNewsBoxB">' +
									'<div class="videoNewsBoxBL fl">' +
									'<img src="images/livevideo.png" style="display: none;" />' +
									'<img class="vedioCoverUrl" src="' + k.object.coverUrl + '!220X164' + '">' +
									'<img src="images/playback.png" />' +
									'</div>' +
									'<div class="videoNewsBoxBR fl">' +
									'<p></p>' +
									'<p>' + k.object.topic + '</p>' +
									'<p>' + k.object.watchCount + '人观看</p>' +
									'<ul class="sameBottom borderSameBottom">' +
									'<li class="fr sameBottomList">分享</li>' +
									'<li class="fr sameBottomList" id='+commentCountLiveBackId+'>' + k.commentCount + '条评论</li>' +
									'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + '>' + k.likeCount + '</li>' +
									'</ul>' +
									'</div>' +
									'</div>' +
									'</div>';
								if(DynamicHotType == 1) {
									$(".agreeSameAddMoreBox").before(liveBoxWrap);
									$("#" + cancelCollectionBtn).stop().hide();
								} else if(DynamicHotType == 2) {
									$(".selectSameAddMoreBox").before(liveBoxWrap);
								}
								$("#"+commentCountLiveBackId).stop().hide();
								$(document).on("click", "#" + locationHrefLiveId, function(e) {
									var roomid = $(this).attr("roomid");
									var id = $(this).attr("objectId");
									var uid = $(this).attr("uid");
									window.location.href = "/liveLookBack?id=" + id + "&roomid=" + roomid + "&uid=" + uid;
								});
							}
						} else if(objectType == 4) { //回答
							//console.log(k);
							var answerBox =
								'<div class="topicBoxWrap  collectionandPraiseSameBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '</p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
								'</div>' +
								'<p class="topicTitle">回答了<span>#话题#</span>' + k.object.discuss.discussTitle + '</p>' +
								'<div class="topicBoxBottom">' +
								'<img class="fl" src="images/livehuati.png" />' +
								'<div class="topicBoxBottomR">' +
								'<p>' + removeHTMLTag(htmlEncode(k.object.answerContent)) + ' </p>' +
								'<p><span> ' + k.object.discuss.discussWatchCount + '人看过</span><span>' + k.object.discuss.discussAnswerCount + ' 人回答</span></p>' +
								'</div>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								"</div>";
							if(DynamicHotType == 1) {
								$(".agreeSameAddMoreBox").before(answerBox);
								$("#" + cancelCollectionBtn).stop().hide();
							} else if(DynamicHotType == 2) {
								$(".selectSameAddMoreBox").before(answerBox);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/topicDetails?id=" + id;
							});
						} else if(objectType == 5) { //实盘
							var delegateType = k.object.delegateType;
							if(delegateType == 1) { //买入
								var firmBugWrap = "<div class='firmBugWrap  collectionandPraiseSameBox'>" +
									"<div class='BoxWrapT'>" +
									"<img class='fl' src=" + k.object.liverInfo.headImgUrl + " id=" + imgHref + ">" +
									"<div class='liveBoxWrapTR fl'>" +
									"<p>" + k.object.liverInfo.nickName + "</p>" +
									"<p>" + format(new Date(k.publishTime)) + "</p>" +
									"</div>" +
									'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
									"</div>" +
									"<p class='firmBugBox'>" +
									"我的<span>#实盘#</span>有最新的买入操作记录" +
									"</p>" +
									"<div class='firmBugBoxB'>" +
									"<div class='firmBugBoxBL fl'>买</div>" +
									"<div class='firmBugBoxBCL fl'>" +
									"<p>" + k.object.stockName + "</p>" +
									"<p>" + k.object.stockCode + "</p>" +
									"</div>" +
									"<div class='firmBugBoxBCR fl'>" +
									"<p><span>" + k.object.beforePositionRate + "%</span>-><span>" + k.object.changePositionRate + "%</span></p>" +
									"<p><span> 成交价：￥</span>" + k.object.price + "</p>" +
									"</div>" +
									"<div class='firmBugBoxBR fl'>看交易</div>" +
									"</div>" +
									"<ul class='sameBottom'>" +
									"<li class='fr sameBottomList'>分享</li>" +
									"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
									"<li class='fr sameBottomList likeWatchLogin' id=" + isAgreeLogo + " objectId=" + objectId + " fatherId=" + locationHrefId + ">" + k.likeCount + "</li>" +
									"</ul>" +
									"</div>"
								if(DynamicHotType == 1) {
									$(".agreeSameAddMoreBox").before(firmSellWrap);
									$("#" + cancelCollectionBtn).stop().hide();
								} else if(DynamicHotType == 2) {
									$(".selectSameAddMoreBox").before(firmSellWrap);
								}
							} else if(delegateType == -1) { //卖出
								//  console.log(k);
								var firmSellWrap = "<div class='firmBugWrap  collectionandPraiseSameBox'>" +
									"<div class='BoxWrapT'>" +
									"<img class='fl' src=" + k.object.liverInfo.headImgUrl + " id=" + imgHref + ">" +
									"<div class='liveBoxWrapTR fl'>" +
									"<p>" + k.object.liverInfo.nickName + "</p>" +
									"<p>" + format(new Date(k.publishTime)) + "</p>" +
									"</div>" +
									'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
									"</div>" +
									"<p class='firmBugBox'>" +
									"我的<span>#实盘#</span>有最新的卖出操作记录" +
									"</p>" +
									"<div class='firmBugBoxB'>" +
									"<div class='firmBugBoxBLSell fl'>卖</div>" +
									"<div class='firmBugBoxBCL fl'>" +
									"<p>" + k.object.stockName + "</p>" +
									"<p>" + k.object.stockCode + "</p>" +
									"</div>" +
									"<div class='firmBugBoxBCR fl'>" +
									"<p><span>" + k.object.beforePositionRate + "%</span>-><span>" + k.object.changePositionRate + "%</span></p>" +
									"<p>成交价：￥" + k.object.price + "</p>" +
									"</div>" +
									"<div class='firmBugBoxBR fl'>看交易</div>" +
									"</div>" +
									"<ul class='sameBottom'>" +
									"<li class='fr sameBottomList'>分享</li>" +
									"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
									"<li class='fr sameBottomList likeWatchLogin' id=" + isAgreeLogo + " objectId=" + objectId + " fatherId=" + locationHrefId + ">" + k.likeCount + "</li>" +
									"</ul>" +
									"</div>"
								if(DynamicHotType == 1) {
									$(".agreeSameAddMoreBox").before(firmSellWrap);
									$("#" + cancelCollectionBtn).stop().hide();
								} else if(DynamicHotType == 2) {
									$(".selectSameAddMoreBox").before(firmSellWrap);
								}
							}
						} else if(objectType == 6) { //音频
							var audioBox =
								'<div class="NullartileBoxWrap  collectionandPraiseSameBox NullartileBoxWrapBox" id=' + locationHrefId + ' objectId=' + objectId + '>' +
								'<div class="BoxWrapT">' +
								'<img class="fl" src="' + k.object.liverInfo.headImgUrl + '" id=' + imgHref + '>' +
								'<div class="liveBoxWrapTR fl">' +
								'<p>' + k.object.liverInfo.nickName + '<span id=' + categoryName + '>更新了专栏</span><span></span></p>' +
								'<p>' + format(new Date(k.publishTime)) + '</p>' +
								'</div>' +
								'<span class="fr cancelCollectionBtn" id=' + cancelCollectionBtn + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>取消收藏</span>' +
								'</div>' +
								'<div class="audioBox">' +
								'<div class="audioBoxL fl">' +
								'<img src="images/audioLogo.png"/>' +
								'<img src="images/anchorHead.png"/>' +
								'</div>' +
								'<p class="fl">' + k.object.topic + '</p>' +
								' <span class="fr">' + durationFun(new Date(k.object.duration)) + '</span>' +
								'</div>' +
								'<ul class="sameBottom borderSameBottom">' +
								'<li class="fr sameBottomList">分享</li>' +
								'<li class="fr sameBottomList">' + k.commentCount + '条评论</li>' +
								'<li class="fr sameBottomList likeWatchLogin" id=' + isAgreeLogo + ' objectId=' + objectId + ' fatherId=' + locationHrefId + '>' + k.likeCount + '</li>' +
								'</ul>' +
								"</div>";
							if(DynamicHotType == 1) {
								$(".agreeSameAddMoreBox").before(audioBox);
								$("#" + cancelCollectionBtn).stop().hide();
							} else if(DynamicHotType == 2) {
								$(".selectSameAddMoreBox").before(audioBox);
							}
							$(document).on("click", "#" + locationHrefId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/audio?id=" + id;
							});
						}

						if(isAgree == true) {
							$("#" + isAgreeLogo).css({
								"background": "url(../images/rewardP.png) no-repeat left center"
							});
						}
						if(uid) { //登录状态——点赞取消赞
							$("#" + isAgreeLogo).click(function(event) {
								var objectId = $(this).attr("objectId");
								var fatherId = $(this).attr("fatherId");
								deleteAgreeFun(uid, token, objectId, 1, isAgreeLogo, fatherId);
								event.stopPropagation();
							})
							//取消收藏
							$("#" + cancelCollectionBtn).click(function(event) {
								var objectId = $(this).attr("objectId");
								var fatherId = $(this).attr("fatherId");
								deleteAgreeFun(uid, token, objectId, 2, cancelCollectionBtn, fatherId);
								event.stopPropagation();
							})

						} else { //未登录——登录——点赞取消赞
							$("#" + isAgreeLogo).click(function(event) {
								$("#loginAlert").stop().show();
								$("#loginAlert").load("/login");
							})
						}
						if(columnName) {
							$("#" + categoryName).next().html("《" + columnName + "》");
						} else {
							$("#" + categoryName).stop().hide();
							$("#" + categoryName).next().hide();
						}

						//缺省头像
						$("#" + imgHref).one("error", function(e) {
							$(this).attr("src", "images/anchorHead.png");
						});

					})

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})

	}
	//取消赞与收藏
	function deleteAgreeFun(uid, token, objectId, agreeType, isAgreeLogoCollectionType, fatherId) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v2/agree/deleteAgree.do",
			data: {
				"uid": uid,
				"token": token,
				"objectId": objectId,
				"agreeType": agreeType,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(agreeType == 1) { //点赞
						$("#" + isAgreeLogoCollectionType).css({
							"background": "url(../images/livereward.png) no-repeat left center"
						});
						$("#" + fatherId).remove();
					} else if(agreeType == 2) {
						//						$("#" + isAgreeLogoCollectionType).html("收藏"); //收藏
						//						$("#" + isAgreeLogoCollectionType).css({
						//							"color": "#ff5038",
						//							"border": "1px solid #ff5038",
						//						});
						$("#" + fatherId).remove();
					}

					//$("#"+locationHrefId).remove();
				} else if(res.code == -21) { //目标不存在

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})

	}
	//订阅专栏
	$(".myBookColumnBtn").click(function() {
		$(".columnSameAddMoreBox").html("");
		selectMySubscribe(uid, 3, 1, 0, 1, 10, token);
	})

	//已购专栏
	$(".boughtListColumnBtn").click(function() {
		$(".meBoughtColumnAddMoreBox").html("");
		selectMySubscribe(uid, 3, 1, 1, 1, 10, token);
	})
	
	//订阅实盘
	$(".myBookFirmBtn").click(function() {
		$(".FireSameAddMoreBox").html("");
		selectMySubscribe(uid, 3, 3, 0, 1, 10, token); 
	})

	//已购实盘
	$(".boughtListFirmBtn").click(function() {
		$(".meBoughtFirmAddMoreBox").html("");
		selectMySubscribe(uid, 3, 3, 1, 1, 10, token);
	})
	var meSubscribeColumnIndex = 1;
	var meBoughtColumnIndex = 1;
	var meSubscribeLiveRoomIndex = 1;
	var meBoughtLiveRoomIndex = 1;
	var meBoughtFirmIndex=1;
	//我的订阅（直播间、专栏）-获取我的订阅/我的已购
	function selectMySubscribe(uid, type, objectType, status, pageIndex, pageSize, token) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			url: "/api/v3/subscribe/selectMySubscribe.do",
			data: {
				"uid": uid,
				"type": type, //类型（type=1未过期订阅，type=2已过期订阅，3=全部订阅）
				"objectType": objectType, //订阅内容类型（1=专栏，2=直播间，3= 实盘）
				"status": status, //0=我的订阅，1=我的已购
				"pageIndex": pageIndex,
				"pageSize": pageSize,
				"token": token,
			},
			success: function(res) {
				if(res.code == 0) {
					if(objectType == 1 && status == 0) { //订阅专栏/
						$(".meSubscribeColumnMore").click(function() {
							meSubscribeColumnIndex++;
							selectMySubscribe(uid, type, 1, 0, meSubscribeColumnIndex, pageSize, token)
						});
						if(res.data == "") {
							$(".meSubscribeColumnMore").stop().hide();
							$(".meSubscribeColumnEnd").stop().show();
						}
						//console.log(res);
						$(res.data).each(function(i, E) {
							var meSubscribeColumnHref = E.id + "meSubscribeColumnHrf";
							var meSubscribeLiveRoomImg = E.id + objectType + status;
							var meSubscribeLiveRoomImgLogo = E.id + objectType + status + "meSubscribeLiveRoomImgLogo";
							var subscribePay = E.subscribePay; //0主直播间 1VIP直播间
							var latestTime = E.id + objectType + status + "latestTime";
							var latestContent = E.id + objectType + status + "latestContent";
							var subscribeType = E.subscribeType; //0免费，1定期 2全期
							var subscribeTypeId = E.id + objectType + status + "subscribeTypeId";
							var columnId = E.id;
							var meSubscribeLiveRoomList =
								'<div class="columnWrapLBox" id=' + meSubscribeColumnHref + ' objectId=' + columnId + '>' +
								'<div class="columnWrapL fl">' +
								'<img id=' + meSubscribeLiveRoomImg + ' src="' + E.coverUrl + '!120X160"/>' +
								'<img id=' + meSubscribeLiveRoomImgLogo + ' src="images/charge.png" alt="" />' +
								'</div>' +
								'	<div class="columnWrapR fl">' +
								'<p class="fl columnWrapRTitle">' + E.name + '</p>' +
								'<p class="fr columnWrapRMoney"><span id=' + subscribeTypeId + '>已购买全期</span></p>' +
								'<p class="columnTitle">' + E.introduction + '</p>' +
								'<p class="columnUpdate"><span>更新：</span><span id=' + latestContent + '>' + E.description + '</span></p>' +
								'</div>';
							$(".columnSameAddMoreBox").append(meSubscribeLiveRoomList);
							if(!E.coverUrl) {
								$("#" + meSubscribeLiveRoomImg).attr("src", "../images/hotNull.png");
							}
							if(subscribePay == 0) {
								$("#" + meSubscribeLiveRoomImgLogo).stop().hide();
							}
							//更新内容或时间为空
							if(!E.description) {
								$("#" + latestContent).html("暂无更新内容");

							}
							if(subscribeType == 0) {
								$("#" + subscribeTypeId).html("免费专栏");
								$("#" + meSubscribeLiveRoomImgLogo).stop().hide();
							} else if(subscribeType == 1) {
								$("#" + subscribeTypeId).html(formatTwo(new Date(E.endTime)) + "到期");
							} else {
								$("#" + subscribeTypeId).html("已购买全期");
							}
							//专栏跳转
							$("#" + meSubscribeColumnHref).click(function() {
								var id = $(this).attr("objectId");
								window.location.href = "/columnDetail?id=" + id;
							})

						})

					} else if(objectType == 2 && status == 0) { //订阅直播间/
						console.log(res);
						$(".meSubscribeLiveRoomMore").click(function() {
							meSubscribeLiveRoomIndex++;
							selectMySubscribe(uid, type, 2, 0, meSubscribeLiveRoomIndex, pageSize, token)
						});
						if(res.data == "") {
							$(".meSubscribeLiveRoomMore").stop().hide();
							$(".meSubscribeLiveRoomEnd").stop().show();
						}
						//console.log(res);
						$(res.data).each(function(i, E) {
							var subscribeType=E.subscribeType;
							//console.log(E);
							var meSubscribeLiveRoomImg = E.roomId + E.uid+ objectType + status;
							var meSubscribeLiveRoomImgLogo = E.roomId + E.uid+ objectType + status + "meSubscribeLiveRoomImgLogo";
							var subscribePay = E.subscribePay; //0主直播间 1VIP直播间
							var latestTime = E.roomId + E.uid+ objectType + status + "latestTime";
							var latestContent = E.roomId + E.uid+ objectType + status + "latestContent";
							var liveAndculumnListIntroLogo = E.roomId + E.uid+ objectType + status + "liveAndculumnListIntroLogo";
							var meSubscribeLiveRoomHrefId = E.roomId + E.uid+ objectType + status+"meSubscribeLiveRoomHrefId";
							var meSubscribeLiveRoomList =
								'<div class="liveBoxSameBox_1 liveBoxVipBox_1" id='+meSubscribeLiveRoomHrefId+' type='+E.type+' uid='+E.uid+' roomId='+E.roomId+'>' +
								'<div class="columnWrapL fl">' +
								'<img id=' + meSubscribeLiveRoomImg + ' src="' + E.coverUrl + '!120X160">' +
								'<img id=' + meSubscribeLiveRoomImgLogo + ' src="images/charge.png" alt="" />' +
								'<p class="liveAndculumnListIntroLogo" id='+liveAndculumnListIntroLogo+'></p>'+
								'</div>' +
								'<div class="liveBoxSameBox_1C fl">' +
								'<div class="liveBoxSameBox_1CT">' +
								'<span class="fl liveBoxSameBoxTitle">' + E.roomName + '</span>' +
								'</div>' +
								'<p class="liveBoxSameBoxSmallTitle" id=' + latestContent + '>' + E.latest.content + '</p>' +
								'<p class="liveBoxSameBox_1CTBottom">' +
								'<span class="fl liveUpdateTime_1" id=' + latestTime + '>' + formatTwo(new Date(E.latest.time)) + '更新</span>' +
								'</p>' +

								'</div>' +
								"</div>";
							$(".meSubscribeLiveRoom").append(meSubscribeLiveRoomList);
							if(!E.coverUrl) {
								$("#" + meSubscribeLiveRoomImg).attr("src", "../images/hotNull.png");
							}
							$("#" + meSubscribeLiveRoomImg).one("error", function(e) {
							  $(this).attr("src", "../images/hotNull.png");
						     });
							if(subscribeType == 0) {//订阅类型（0=免费专栏，1=付费专栏，2=永久订阅）
								$("#" + meSubscribeLiveRoomImgLogo).stop().hide();
								$("#" + liveAndculumnListIntroLogo).stop().hide();
							}else if(subscribeType == 1){
								$("#" + liveAndculumnListIntroLogo).html(formatTwo(new Date(E.endTime)) + "到期");
							}
							//
							$("#" + meSubscribeLiveRoomHrefId).click(function() {
								var uid = $(this).attr("uid");
								var type = $(this).attr("type");
								var roomid = $(this).attr("roomId");
								if(type==0){
									window.location.href = "/liveNew?uid="+uid+"&roomid="+roomid;
								}else if(type==1){
									window.location.href = "/vipLive?uid="+uid+"&roomid="+roomid;
								}
								
							})
							
							
							
							//更新内容或时间为空
							if(!E.latest.content) {
								$("#" + latestTime).stop().hide();
								$("#" + latestContent).html("暂无更新内容");

							}

						})

					} else if(objectType == 1 && status == 1) { //已购专栏
						//console.log(res);
						$(".meBoughtColumnMore").click(function() {
							meBoughtColumnIndex++;
							selectMySubscribe(uid, type, 1, 1, meBoughtColumnIndex, pageSize, token)
						});
						if(res.data == "") {
							$(".meBoughtColumnMore").stop().hide();
							$(".meBoughtColumnEnd").stop().show();
						}
						$(res.data).each(function(i, E) {
							var meSubscribeLiveRoomImg = E.id + objectType + status;
							var meSubscribeLiveRoomImgLogo = E.id + objectType + status + "meSubscribeLiveRoomImgLogo";
							var subscribePay = E.subscribePay; //0主直播间 1VIP直播间
							var latestTime = E.id + objectType + status + "latestTime";
							var latestContent = E.id + objectType + status + "latestContent";
							var startEndTime = E.id + objectType + status + "startEndTime";
							var subscribeType = E.subscribeType; //0免费，1定期 2全期
							var subscribeTypeId = E.id + objectType + status + "subscribeTypeId";
							var meBoughtColumnHref = E.id + objectType + status + "meBoughtColumnHref";
							var startTime = new Date();
							var endTime = E.endTime;
							var columnId = E.id;
							var meBoughtListSameBoxList =
								'<div class="meBoughtListSameBox" id=' + meBoughtColumnHref + ' objectId=' + columnId + '>' +
								'<img class="fl" id=' + meSubscribeLiveRoomImg + ' src="' + E.coverUrl + '!120X160"/>' +
								'<span>' + E.name + '</span>' +
								'<span>' + formatTwo(new Date(E.startTime)) + '购买</span>' +
								'<span>' + formatTwo(new Date(E.endTime)) + '到期</span>' +
								'<span>' + E.subscribePay + '牛币</span>' +
								'<span id=' + startEndTime + '>已到期</span>' +
								' </div>';
							$(".meBoughtColumnAddMoreBox").append(meBoughtListSameBoxList);
							if(!E.coverUrl) {
								$("#" + meSubscribeLiveRoomImg).attr("src", "../images/hotNull.png");
							};
							if(startTime - endTime < 0) {
								$("#" + startEndTime).stop().hide();
							}
							//专栏跳转
							$("#" + meBoughtColumnHref).click(function() {
								var id = $(this).attr("objectId");
								window.location.href = "/columnDetail?id=" + id;
							})
						})

					} else if(objectType == 2 && status == 1) { //已购直播间
						//console.log(res);
						$(".meBoughtLiveRoomMore").click(function() {
							meBoughtLiveRoomIndex++;
							selectMySubscribe(uid, type, 2, 1, meBoughtLiveRoomIndex, pageSize, token)
						});
						if(res.data == "") {
							$(".meBoughtLiveRoomMore").stop().hide();
							$(".meBoughtLiveRoomEnd").stop().show();
						}

						$(res.data).each(function(i, E) {
							var meSubscribeLiveRoomImg = E.roomId + objectType + status;
							var meSubscribeLiveRoomImgLogo = E.roomId + objectType + status + "meSubscribeLiveRoomImgLogo";
							var subscribePay = E.subscribePay; //0主直播间 1VIP直播间
							var latestTime = E.roomId + objectType + status + "latestTime";
							var latestContent = E.roomId + objectType + status + "latestContent";
							var startEndTime = E.roomId + objectType + status + "startEndTime";
							var startTime = new Date();
							var meSubscribeLiveRoomHrefBoughtId = E.roomId + objectType + status + "meSubscribeLiveRoomHrefBoughtId";
							var endTime = E.endTime;
							//console.log(startTime);
							//console.log(endTime);
							var meBoughtListSameBoxList =
								'<div class="meBoughtListSameBox" id='+meSubscribeLiveRoomHrefBoughtId+' type='+E.type+' uid='+E.uid+' roomId='+E.roomId+'>' +
								'<img class="fl" id=' + meSubscribeLiveRoomImg + ' src="' + E.coverUrl + '!120X160"/>' +
								'<span>' + E.roomName + '</span>' +
								'<span>' + formatTwo(new Date(E.startTime)) + '购买</span>' +
								'<span>' + formatTwo(new Date(E.endTime)) + '到期</span>' +
								'<span>' + E.subscribePay + '牛币</span>' +
								'<span id=' + startEndTime + '>已到期</span>' +
								' </div>';
							$(".meBoughtLiveAddMoreBox").append(meBoughtListSameBoxList);
							if(!E.coverUrl) {
								$("#" + meSubscribeLiveRoomImg).attr("src", "../images/hotNull.png");
							};
							if(startTime - endTime < 0) {
								$("#" + startEndTime).stop().hide();
							}
							$("#" + meSubscribeLiveRoomImg).one("error", function(e) {
							  $(this).attr("src", "../images/hotNull.png");
						     });
						     
						     $("#" + meSubscribeLiveRoomHrefBoughtId).click(function() {
								var uid = $(this).attr("uid");
								var type = $(this).attr("type");
								var roomid = $(this).attr("roomId");
								if(type==0){
									window.location.href = "/liveNew?uid="+uid+"&roomid="+roomid;
								}else if(type==1){
									window.location.href = "/vipLive?uid="+uid+"&roomid="+roomid;
								}
								
							})
						})

					}else if(objectType == 3 && status == 0) { //订阅实盘
						console.log(res);
						$(".meSubscribeFirmMore").click(function() {
							meBoughtFirmIndex++;
							selectMySubscribe(uid, type, 3, 0, meBoughtFirmIndex, pageSize, token)
						});
						if(res.data == "") {
							$(".meSubscribeFirmMore").stop().hide();
							$(".meSubscribeFirmEnd").stop().show();
						}

						$(res.data).each(function(i, G) {
							var firmBookListInfoHref=G.uid+"firmBookListInfo";
						    var subscribeType=G.subscribeType;
						    var subscribeTypeFirm=G.uid+"subscribeTypeBook";
							var myBookFirm=
							'<li class="firmBookList" uid='+G.uid+' id='+firmBookListInfoHref+'>'+
								'<div class="firmBookListL fl">'+
									'<p>'+G.totalProfitRate+'%</p>'+
									'<p>总收益</p>'+
								'</div>'+
								'<div class="firmBookListL firmBookListLTwo fl">'+
									'<p>'+G.nickName+'的实盘</p>'+
									'<p>最新收益: <span>'+G.dailyProfitRate+'%</span></p>'+
								'</div>'+
								'<div id='+subscribeTypeFirm+' class="firmBookListR fr">'+formatTwo(new Date(G.endTime))+'到期</div>'+
							'</li>';
							$(".FireSameAddMoreBox").append(myBookFirm);
							$("#"+firmBookListInfoHref).click(function(){
								var uid=$(this).attr("uid");
								window.location.href="/userProfile?uid="+uid+"&tab=4";
							})
							if(subscribeType == 0) {//0-免费，1-周期，2-永久
								$("#"+subscribeTypeFirm).html("免费实盘");
							}else if(subscribeType == 1){
								$("#"+subscribeTypeFirm).html(formatTwo(new Date(G.endTime))+'到期');
							}else if(subscribeType == 2){
								$("#"+subscribeTypeFirm).html("已购买全期");
							}
						})

					}else if(objectType == 3 && status == 1) { //订阅实盘
						$(".meBoughtFirmMore").click(function() {
							meBoughtFirmIndex++;
							selectMySubscribe(uid, type, 3, 1, meBoughtFirmIndex, pageSize, token)
						});
						if(res.data == "") {
							$(".meBoughtFirmMore").stop().hide();
							$(".meBoughtFirmEnd").stop().show();
						}
                       
						$(res.data).each(function(i, S) {
							var subscribeTypeFirmBought=S.uid+"subscribeTypeFirmBought";
							var startTimeFirm = new Date();
							var endTime=S.endTime;
							var startEndTimeFirm=S.startTime+"meBoughtFirmTime"+S.uid+"startTimeFirm";
							var meBoughtListFirmHref=S.startTime+"meBoughtFirmTime"+S.uid;
							var subscribeType=S.subscribeType;
							var meBoughtListFirm=
							'<div class="meBoughtListSameBox" id='+meBoughtListFirmHref+' uid='+S.uid+'>'+
									'<i></i>'+
									'<span class="meBoughtFirmName">'+S.nickName+'的实盘</span>'+
									'<span>'+formatTwo(new Date(S.startTime))+'购买</span>'+
									'<span id='+subscribeTypeFirmBought+'>'+formatTwo(new Date(S.endTime))+'到期</span>'+
									'<span>'+S.subscribePay+'牛币</span>'+
									'<span id='+startEndTimeFirm+'>已到期</span>'+
							 '</div>';
							 $(".meBoughtFirmAddMoreBox").append(meBoughtListFirm);
							 if(startTimeFirm - endTime < 0) {
								$("#" + startEndTimeFirm).stop().hide();
							 };
							 $("#"+meBoughtListFirmHref).click(function(){
								var uid=$(this).attr("uid");
								window.location.href="/userProfile?uid="+uid+"&tab=4";
							 });
							 if(subscribeType == 0) {//0-免费，1-周期，2-永久
								$("#"+subscribeTypeFirmBought).html("免费实盘");
							}else if(subscribeType == 1){
								$("#"+subscribeTypeFirmBought).html(formatTwo(new Date(S.endTime))+'到期');
							}else if(subscribeType == 2){
								$("#"+subscribeTypeFirmBought).html("已购买全期");
							}
						})
                      
					}
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})
	}

	//获得关注的人
	var myConcernBoxSameAddMoreIndex = 1;

	function selectReceptorFun(uid, pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v2/user/selectReceptor.do",
			data: {
				"uid": uid,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(res.data.receptorList != "") {
						$(".myConcernBoxSameAddMore").click(function() {
							myConcernBoxSameAddMoreIndex++;
							selectReceptorFun(uid, myConcernBoxSameAddMoreIndex, pageSize);
						})
					}
					if(res.msg == "该页暂无数据") {
						$(".myConcernBoxSameAddMore").stop().hide();
						$(".myConcernBoxSameAddEnd").stop().show();
					}
					$(res.data.receptorList).each(function(i, D) {
						var headImgUrl = D.uid + D.fansCount + "headImgUrl";
						var myConcernBoxListId = D.uid + D.fansCount + "myConcernBoxListId";
						var myConcernBoxList =
							'<li class="myConcernBoxList" id=' + myConcernBoxListId + ' uid=' + D.uid + '>' +
							'<img class="fl" id=' + headImgUrl + ' src="' + D.headImgUrl + '"/>' +
							'<div class="myConcernBoxListC fl">' +
							'<p><span>' + D.nickName + '</span><span>粉丝：' + D.fansCount + '</span></p>' +
							'<p>' + D.resume + '</p>' +
							'</div>' +
							'<span class="fr myConcernBoxListBtn">已关注</span>' +
							'</li>';
						$(".myConcernBox").append(myConcernBoxList);
						if(!D.headImgUrl) {
							$("#" + headImgUrl).attr("src", "../images/anchorHead.png");
						};
						$("#" + headImgUrl).one("error", function(e) {
							$(this).attr("src", "../images/anchorHead.png");
						});
						$("#" + myConcernBoxListId).click(function() {
							var uid = $(this).attr("uid");
							window.location.href = "/userProfile?uid=" + uid;

						})

					})

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})

	}

	//我的钱包
	function wxUnifiedOrder(userId, usertoken) {
		$(".qitaMoney").focus(function() {
			$(this).removeAttr("placeholder");
			$(".moneyAlert").stop().show()
		});
		$(".qitaMoney").blur(function() {
			$(this).attr("placeholder", "其他金额");
			$(".moneyAlert").stop().hide()
		});
		$(".payBtn").click(function() {
			var totalFee = "";
			if($(".qitaMoney").val() != "") {
				totalFee = parseInt($(".qitaMoney").val());
				//console.log(totalFee)
			} else {
				totalFee = parseInt($(".money_list").find(".click_effect").children().text())
			}
			$(".weChatPayNum").html(totalFee);
			$.ajax({
				type: "POST",
				async: true,
				dataType: "json",
				url: "/api/v1/order/wxUnifiedOrder.do",
				data: {
					"uid": userId,
					"totalFee": totalFee,
					"tradeType": "NATIVE",
					"token": usertoken,
				},
				success: function(res) {
					//console.log(res);
					if(res.code == 0) {
						$("#exceptWrap").fadeIn(1);
						$(".weChatCodeWrap").fadeIn(1);
						var codeUrl = res.data.codeUrl;
						var outTradeNo = res.data.outTradeNo;
						//console.log(outTradeNo);
						jQuery("#weChatPayCode").qrcode({
							render: "canvas",
							foreground: "#000",
							background: "#FFF",
							width: 180,
							height: 180,
							text: codeUrl,
							correctLevel: 2
						});
						intervalTime = setInterval(function() {
							$.ajax({
								type: "POST",
								async: true,
								dataType: "json",
								url: "/api/v1/order/wxFrontNotify.do",
								data: {
									"uid": userId,
									"outTradeNo": outTradeNo,
									"token": usertoken,
								},
								success: function(res) {
									//	console.log(res);
									if(res.code == 0) {
										$(".weChatCodeWrap").stop().hide();
										$(".weChatPaySuccess").stop().show();

									}
								},
								error: function(XMLHttpRequest, textStatus, errorThrown) {
									console.log(XMLHttpRequest.status);
									console.log(XMLHttpRequest.readyState);
									console.log(textStatus)
								}
							})
						}, 3000)
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				}
			})
		})
	}

	//获得用户余额
	function payFun(userId, usertoken) {
		/*充值接口*/
		$.ajax({
			type: "POST",
			async: true,
			dataType: "json",
			url: "/api/v1/account/selectByWhere.do",
			data: {
				"uid": userId,
				"coinType": "RECHARGE_COIN",
				"token": usertoken,
			},
			success: function(res) {
				if(res.code == 0) {
					$(".balanceCoin").html(res.data[0].coinNumber + "牛币");

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		});
	}

	//支付功能
	function wxUnifiedOrder(userId, usertoken) {
		$(".qitaMoney").focus(function() {
			$(this).removeAttr("placeholder");
			$(".moneyAlert").stop().show()
		});
		$(".qitaMoney").blur(function() {
			$(this).attr("placeholder", "其他金额");
			$(".moneyAlert").stop().hide()
		});
		$(".payBtn").click(function() {
			var totalFee = "";
			if($(".qitaMoney").val() != "") {
				totalFee = parseInt($(".qitaMoney").val());
				//console.log(totalFee)
			} else {
				totalFee = parseInt($(".money_list").find(".click_effect").children().text())
			}
			$(".weChatPayNum").html(totalFee);
			$.ajax({
				type: "POST",
				async: true,
				dataType: "json",
				url: "/api/v1/order/wxUnifiedOrder.do",
				data: {
					"uid": userId,
					"totalFee": totalFee,
					"tradeType": "NATIVE",
					"token": usertoken,
				},
				success: function(res) {
					if(res.code == 0) {
						$("#exceptWrap").fadeIn(1);
						$(".weChatCodeWrap").fadeIn(1);
						var codeUrl = res.data.codeUrl;
						var outTradeNo = res.data.outTradeNo;
						//console.log(outTradeNo);
						jQuery("#weChatPayCode").qrcode({
							render: "canvas",
							foreground: "#000",
							background: "#FFF",
							width: 180,
							height: 180,
							text: codeUrl,
							correctLevel: 2
						});
						intervalTime = setInterval(function() {
							$.ajax({
								type: "POST",
								async: true,
								dataType: "json",
								url: "/api/v1/order/wxFrontNotify.do",
								data: {
									"uid": userId,
									"outTradeNo": outTradeNo,
									"token": usertoken,
								},
								success: function(res) {
									//	console.log(res);
									if(res.code == 0) {
										$(".weChatCodeWrap").stop().hide();
										$(".weChatPaySuccess").stop().show();

									}
								},
								error: function(XMLHttpRequest, textStatus, errorThrown) {
									console.log(XMLHttpRequest.status);
									console.log(XMLHttpRequest.readyState);
									console.log(textStatus)
								}
							})
						}, 3000)
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				}
			})
		})
	}

	//关闭框X
	$(".payMoneyBoxT").click(function() {
		$(".payMoneyBoxWrap").stop().hide();
	})
	//充值弹框
	$(".money_listinfo").click(function() {
		$(this).addClass("click_effect").siblings().removeClass("click_effect");
	});
	/*关闭框*/
	$(".alertClose").click(function() {
		$("#exceptWrap").stop().hide();
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".weChatClose").click(function() {
		$(".weChatCodeWrap").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".qitaMoney").val("");
		$("#weChatPayCode").html("");
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".weChatSuccessClose").click(function() {
		$(".weChatPaySuccess").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".qitaMoney").val("");
		$("#weChatPayCode").html("");
		$(".payMoneyBoxWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".closePay").click(function() {
		$(".payMoney").stop().hide();
	})

	//绑定手机号码X
	$(".closeAlertBjSame").click(function() {
		$(".phoneBindWrapSame").stop().hide();
	});
	$("#cancalPswBtn").click(function() {
		$(".phoneBindWrapSame").stop().hide();
	})
	//实名认证
	function selectAuditStatusFun(uid, usertoken) {
		$.ajax({
			url: "/api/v1/anchor/selectAuditStatus.do",
			async: true,
			cache: false,
			type: 'post',
			dataType: "json",
			data: {
				"uid": uid,
				"token": usertoken
			},
			success: function(res) {
				//console.log(res);
				var auditStatus = res.data.auditStatus; // 1未申请，3认证中，4审核通过，5审核未通过
				//判断主播申请状态及相应显示
				if(auditStatus == 1) { //未申请
					$("#anchor_recruit").stop().show();
					auditAnchorFun(uid, token);
				} else if(auditStatus == 3) { //认证中
					$(".approveNoState").stop().show();
					$("#anchor_recruit").stop().hide();
					$(".approveNoStateInfoBtn").stop().hide();
					$(".approveNoStateInfo").html("审核通过后，会发送短信通知至您的手机中。");
					$(".approveNoStateImg").attr("src", "../images/timeMe.png");
				} else if(auditStatus == 4) { //审核通过
					$(".approveNoState").stop().show();
					$("#anchor_recruit").stop().hide();
					$(".approveNoStateInfoBtn").stop().hide();
					$(".approveNoStateInfo").html("您已通过身份认证，开启您的主播之旅吧！");
					$(".approveNoStateImg").attr("src", "../images/passMe.png");
				} else if(auditStatus == 5) { //未通过
					$(".approveNoState").stop().show();
					$("#anchor_recruit").stop().hide();
					$(".approveNoStateInfoBtn").stop().show();
					$(".approveNoStateInfo").html("抱歉，您的身份认证审核未通过！");
					$(".approveNoStateImg").attr("src", "../images/sorryMe.png");

				}

			}
		});
	}

	//申请主播手机验证码
	$("#getPhoneCodeZhubo").click(function() {
		var resetPhone = $("#phone_card").val();
		if(!phoneReg.test(resetPhone)) {
			layer.msg('手机号码有误，请重新输入');
			return false;
		} else {
			refreshCodeFun();
			$("#numCodeBG").fadeIn(100);
			//图形验证码确认按钮
			$("#verifyGraphBtn").click(function() {
				var graphInput = $("#graphInput").val();
				if(!numReg.test(graphInput)) {
					$("#graphInput").val('');
					layer.msg('验证码有误');
					return false;
				} else {
					$.ajax({ //校验图形验证码
						type: "post",
						url: "/checkGraphCode",
						data: { 'verifiCode': graphInput },
						success: function(res) {
							$("#graphInput").val('');
							// console.log(res);
							if(res.code == 0) { //图形验证码正确
								$("#numCodeBG").fadeOut(100);
								$.ajax({ //发送短信验证码
									type: "post",
									url: "/api/v2/user/sendSms.do",
									data: { 'type': 3, 'mobile': resetPhone },
									success: function(res) {
										// console.log(res);
										if(res.code == 0) {
											// layer.msg('验证码发送成功');
											var times = 60;
											var isinerval;
											$("#getPhoneCodeZhubo").attr("disabled", true);
											isinerval = setInterval(function() {
												if(times < 0) {
													$("#getPhoneCodeZhubo").html("获取验证码").attr("disabled", false);
													clearInterval(isinerval);
													return
												}
												$("#getPhoneCodeZhubo").html(times + "秒后再点击");
												times--
											}, 1000)
										} else if(res.code == -14) {
											layer.msg('该手机号发送短信次数过于频繁');
										} else if(res.code == -20) {
											layer.msg('系统繁忙，请稍后再试');
										} else if(res.code == -101) {
											layer.msg('手机号已被注册');
										} else if(res.code == -9998) {
											layer.msg('发送失败');
										}
									}
								});
							} else if(res.code == -1) {
								layer.msg('图形验证码有误');
							}
						}
					});
				}
			});
		}
	});

	//主播申请接口-提交
	function auditAnchorFun(uid, token) {
		$(".anchorRecruitingSave").on('click', function() {
			var fullName = $('#real_name').val(); //真实姓名
			var idNo = $('#id_card').val(); //身份证号
			var mobile = $('#phone_card').val(); //手机号
			var authCode = $('#yz_code').val(); //验证码
			var sketch = $('#approve').val(); //认证简述
			var img = $(".realNameAuthenticationBImg").attr("src"); //图片路径
			$.ajax({
				url: "/api/v1/anchor/auditAnchor.do",
				async: true,
				type: 'post',
				dataType: "json",
				data: {
					"uid": uid,
					"token": token,
					"fullName": fullName,
					"idNo": idNo,
					"mobile": mobile,
					"authCode": authCode,
					"field": "",
					"content": "",
					"sketch": sketch,
					"resume": "",
					"img": img,
					"auditStatus": 2
				},
				success: function(res) {
					//console.log(res);
					if(res.code == 0) {
						$("#anchor_recruit").stop().hide();
						$(".approveNoState").stop().show();
					} else if(res.code == -6) {
						layer.msg("手机验证码错误，请重新输入！");
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus);
				}
			})
		})
	}

	$(".graphCloseBtn").click(function() {
		$("#numCodeBG").stop().hide();
	})

	$(".approveNoStateInfoBtn").click(function() {
		$(".approveNoState").stop().hide();
		$("#anchor_recruit").stop().show();
	});
	
	
	
	
	

})