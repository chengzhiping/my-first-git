var chatRoomId //直播间id
var userId //用户id，游客的是时间戳加6位随机数
var userSig //进入直播间的凭证
var msg;
var usertoken;
var target;
var monetary;
var userNickName;
var selSess = null;
var selType = webim.SESSION_TYPE.GROUP;
//var selToID;
var selSess = null;
var selSessHeadUrl = "img/2017.jpg";
var D //打赏遍历
var uid;
$(document).ready(function() {
	uid = GetQueryString("uid");
	var intervalTime //支付定时器
	clearInterval(s);
	var s = setInterval("sc()", 100);
	//	//加载头部
	$("#wrapHeader").load("/header");
	//加载底部
	$("#indexFooter").load("/footer");
	//tab聊天和回顾
	$(".review li").click(function() {
		$(".chatInnerWrap .chatInner").eq($(this).index()).css("display", "block").siblings("div").css("display", "none");
		$(this).addClass("chatActive").siblings(".review li").removeClass("chatActive");
	});
	//充值弹框
	$(".money_listinfo").click(function() {
		$(this).addClass("click_effect").siblings().removeClass("click_effect")
	});
	/*关闭框*/
	$(".alertClose").click(function() {
		$("#n_money").stop().hide();
		$("#exceptWrap").stop().hide();
		clearInterval(intervalTime)
	});
	$(".weChatClose").click(function() {
		$(".weChatCodeWrap").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".qitaMoney").val("");
		$("#weChatPayCode").html("");
		clearInterval(intervalTime)
	});
	$(".weChatSuccessClose").click(function() {
		$(".weChatPaySuccess").stop().hide();
		$("#exceptWrap").stop().hide();
		$(".qitaMoney").val("");
		$("#weChatPayCode").html("");
		clearInterval(intervalTime)
	});
	//密码框获得焦点，内容清空
	$(".masked_bottom .vedioPwd").focus(function() {
		$(this).val("");
	})
	$(".weChatOweWrapClose").click(function() {
		$(".weChatOweWrap").css("display", "none");
		$("#exceptWrap").stop().hide();
	});
	$(".wechat_pay").click(function() {
		$(".wechatI").show();
		$(".alipayI").hide()
	});
	$(".alipay").click(function() {
		$(".wechatI").hide();
		$(".alipayI").show()
	});
	var watchCount;
	//聊天框获得焦点内容清除
	$(".cs-textarea").focus(function() {
			$(this).val("");
		})
		/*进入直播间-进入直播间*/
		//根据用户ID获取直播、回放列表接口
	var liveContent= setInterval(liveContent1(),30000);
	function liveContent1() {
		$.ajax({
			type: "GET", //请求方式
			async: true, //是否异步
			url: "/api/v1/multiple/getLiveListByUid.do",
			dataType: "json",
			data: {
				"uid": uid,
				"pageIndex": 1,
				"pageSize": 1,
			},
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					var dataLen = res.data.length;
					if(dataLen < 1) {
						//主播没有直播过的现象，没找到直播
					} else {
						var id = res.data[0].id;
						var type = res.data[0].type; //类型{0=正在直播，1=直播回放，2=录制视频}
						var openness = res.data[0].openness; //公开度{-1=私密的，仅主播自己观看，0=开放，1=加密的，需要密码观看，}
						watchCount = res.data[0].watchCount;
						if(type == 0) { //正在直播
							if(openness == 0) { //开放
								//直播详情页接口
								$.ajax({
									type: "post", //请求方式
									async: true, //是否异步
									url: "/api/v1/live/joinLive.do",
									data: {
										"uid": uid,
									},
									dataType: "json",
									success: function(res) {
										//console.log(res);
										sameFun(res);
										$(".refreshicon").click(function() {
		                                     video.load();
		                                     videoReloadFun(res)
	                                    });

									},
									error: function(XMLHttpRequest, textStatus, errorThrown) {
										console.log(XMLHttpRequest.status);
										console.log(XMLHttpRequest.readyState);
										console.log(textStatus);
									},
								});
							};

							if(openness == 1) { //加密
								$("#vedio_masked").css({
									"display": "block",
								});
								$(".sure_btn").on("click", function() {
									var authCode = $("#pwd").val();
									//console.log(authCode);
									$.ajax({
										type: "post", //请求方式
										async: true, //是否异步
										url: "/api/v1/live/joinLive2.do",
										data: {
											"uid": uid,
											"authCode": authCode,
										},
										success: function(res) {
											//var res = JSON.parse(res);
											// console.log(res);
											if(res.code == -111) {
												$(".error_ts").html("密码错误，请重新输入！")
											};
											if(res.code == -7) {
												$(".error_ts").html("密码不能为空，请重新输入！")
											}
											if(res.code == 0) {
												// console.log(res);
												$("#vedio_masked").css({
													"display": "none",
												});
												sameFun(res);
												$(".refreshicon").click(function() {
				                                    video.load();
				                                    videoReloadFun(res);
			                                    });
												
											}
										},
										error: function(XMLHttpRequest, textStatus, errorThrown) {
											console.log(XMLHttpRequest.status);
											console.log(XMLHttpRequest.readyState);
											console.log(textStatus);
										},
									});
								});
								//取消按钮返回上一页
								$(".cancel_btn").on("click", function() {
									window.history.go(-1);

								})

							};
						};
						if(type == 1 || type == 2) { //1=直播回放，2=录制视频
							window.location.href = "/video?" + "id=" + id;
						};
						
					}

				}

			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	
    //视频播放器刷新
    function videoReloadFun(res) {
		target = res.data.id;
		var markNum = res.data.hlsPlayUrl; //视频地址
		markNum = markNum.replace('http', 'https'); //外网网址
		if(Hls.isSupported()) {
			var video = document.getElementById('myVideo');
			var hls = new Hls();
			hls.loadSource(markNum);
			hls.attachMedia(video);
			hls.on(Hls.Events.MANIFEST_PARSED, function() {
				video.play();
			});
		}
	}
	//加密、不加密的情况
	function sameFun(res) {
		//console.log(res);
		var markNum = res.data.hlsPlayUrl; //视频地址
		//var markNum = res.data.rtmpPlayUrl; //视频地址
		markNum = markNum.replace('http', 'https'); //外网网址
		$("#myVideo").attr("preload", coverUrl);
		$("#myVideo").attr("poster", coverUrl);
		if(Hls.isSupported()) {
			var video = document.getElementById('myVideo');
			var hls = new Hls();
			hls.loadSource(markNum);
			hls.attachMedia(video);
			hls.on(Hls.Events.MANIFEST_PARSED, function() {
				video.play();
			});
		}
		target = res.data.id;
		var fansCount = res.data.liverInfo.fansCount; //粉丝数
		//console.log(fansCount);
		var coverUrl = res.data.coverUrl;
		$('.container[data-container]').css('background', ('url("' + coverUrl + '")'));
		chatRoomId = res.data.chatRoomId; //直播间id；
		loginFunBox(chatRoomId);
		var topic = res.data.topic;
		
		//	console.log(markNum);
		var headImgUrl = res.data.liverInfo.headImgUrl; //头像
		var nickName = res.data.liverInfo.nickName; //昵称
		var signature = res.data.liverInfo.signature; //签名
		//console.log(signature);
		var resume = res.data.liverInfo.resume; //简介
		//		var player = new Clappr.Player({
		//			source: markNum,
		//			parentId: "#player"
		//		});
		
		$("title").html(res.data.topic+"-疯牛直播");
		$(".fansCount").html(fansCount);
		// $(".myVideo").prop("src", markNum);
		$(".liveTitle").html(res.data.topic); //标题
		$(".live_info").html("【直播主题】：" + res.data.topic); //标题
		$(".anchorName").html("主播:" + nickName); //昵称
		$(".nickName").html(nickName);
		$(".anchorUid").html(uid);
		$(".watchNum").html(res.data.watchCount + "人在看") //观看数量
        $("title").html(res.data.topic+"_股票直播_股市直播间-疯牛直播");
		$("#keywordsId").attr("content",nickName+"，股票入门视频，股市直播，股市分析，股票投资咨询，股票直播，股票知识，疯牛直播");
		var shareUrl = window.location.href;
		var shareTitle = nickName + "正在直播中：" + topic + "—>点击观看";
		var shareDescription = topic + "，" + nickName + "邀你一同直播互动交流";
		shareFun(shareUrl, shareTitle, shareDescription, coverUrl)
		if(headImgUrl != "") {
			$(".anchorHeadImg").attr("src", headImgUrl); //头像
		};
		if(res.data.positionName) {
			$(".positionName").html("认证 ：" + res.data.positionName);

		} else {
			$(".positionName").html("认证   : 暂无认证");
		};
		if(resume) {
			$(".anchorResume").html("简介：" + resume);
			var num = $(".anchorResume").html();
			if(num.length > 180) {
				$(".anchorResume").html(num.substr(0, 180) + '...');
			}

		} else {
			$(".anchorResume").html("简介   : 暂无简介");
		};
		if(signature != undefined && signature != null && signature != " ") {
			$(".anchorSignature").html("签名    : " + signature);

		} else {
			$(".anchorSignature").html("签名   : 这个主播很懒，什么都没有留下~");
		};
	}
	//直播间广告-根据类型获取banner，广告，文字连接等
	$.ajax({
		type: "POST", //请求方式
		async: true, //是否异步
		dataType: "json",
		url: "/api/v1/banner/selectByType.do",
		data: {
			"type": 28,
			"pageIndex": 1,
			"pageSize": 1,
		},
		success: function(res) {
			// console.log(res);
			if(res.code == 0) {
				var dataLen = res.data.length;
				if(dataLen > 0 && res.data[0].imgUrl != "") {
					$(".liveAdliveAdHref").attr("href", res.data[0].id);
					$(".liveAdliveImg").attr("src", res.data[0].imgUrl);
				} else {
					$(".liveAdliveAdHref").attr("target", "_self");
				}
			}

		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus);
		},
	}); //获得游客获取主播动态
	//主播动态
	$.ajax({
		type: "post",
		async: true,
		dataType: "json",
		data: {
			"uid": uid,
			"pageSize": 3,
			"pageIndex": 1
		},
		url: "/api/v2/dynamic/getLiverDynamicListByAuthor.do",
		success: function(res) {
			if(res.code == 0) {
				if(res.data == "") {
					// console.log(res);
					$(".hotNewB").stop().hide() //缺省
				}
				$(res.data).each(function(i, k) {
					var objectType = k.objectType; //动态类型
					if(objectType == 1) { //文章或短评
						var type = k.object.type;
						if(type == 1) { //短评
							var media = k.object.media;
							if(media == "") { //无图短评
								var shortid = k.object.id;
								var shortViewNullImg = "<div id='artileBoxWrap'>" +
									"<div class='BoxWrapT'>" +
									"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
									"<div class='liveBoxWrapTR fl'>" +
									"<p>" + k.object.liverInfo.nickName + "</p>" +
									"<p>3" + format(new Date(k.publishTime)) + "</p>" +
									"</div>" +
									"</div>" +
									"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
									"<ul class='sameBottom borderSameBottom'>" +
									"<li class='fr sameBottomList'>分享</li>" +
									"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
									"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
									" </ul>" +
									" </div>";
								$(".hotNewB").before(shortViewNullImg);
							} else {
								var shortViewImg = (media.split(','));
								var len = shortViewImg.length;
								var shortid = k.object.id;
								if(len == 1) { //1张图
									var shortViewImg1 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										" <a href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										" <img class='shortViewImgOne' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>";
									$(".hotNewB").before(shortViewImg1);
								} else if(len == 2) { //2张图
									var shortViewImg2 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										"<div class='shortViewImgBox'>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[1] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[1] + ">" +
										"</a>" +
										" </div>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(shortViewImg2);
									//                                     
								} else if(len == 3) { //三张图
									var shortViewImg3 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										"<div class='shortViewImgBox'>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[1] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[1] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[2] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[2] + ">" +
										"</a>" +
										" </div>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(shortViewImg3);
								} else if(len == 4) { //四张图
									var shortViewImg4 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										"<div class='shortViewImgBox'>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[1] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[1] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[2] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[2] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[3] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[3] + ">" +
										"</a>" +
										" </div>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(shortViewImg4);
								} else if(len == 5) { //五张图
									var shortViewImg5 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										"<div class='shortViewImgBox'>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[1] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[1] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[2] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[2] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[3] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[3] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[4] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[4] + ">" +
										"</a>" +
										" </div>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(shortViewImg5);
								} else if(len == 6) { //六张图
									var shortViewImg6 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										"<div class='shortViewImgBox'>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[1] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[1] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[2] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[2] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[3] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[3] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[4] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[4] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[5] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[5] + ">" +
										"</a>" +
										" </div>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(shortViewImg6);
								} else if(len == 7) { //七张图
									var shortViewImg7 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										"<div class='shortViewImgBox'>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[1] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[1] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[2] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[2] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[3] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[3] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[4] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[4] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[5] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[5] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[6] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[6] + ">" +
										"</a>" +
										" </div>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(shortViewImg7);
								} else if(len == 8) { //八张图
									var shortViewImg8 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										"<div class='shortViewImgBox'>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[1] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[1] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[2] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[2] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[3] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[3] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[4] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[4] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[5] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[5] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[6] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[6] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[7] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[7] + ">" +
										"</a>" +
										" </div>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(shortViewImg8);
								} else if(len == 9) { //九张图
									var shortViewImg9 = "<div id='artileBoxWrap'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='articleContent'>" + htmlEncode(k.object.content) + "</p>" +
										"<div class='shortViewImgBox'>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[0] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[0] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[1] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[1] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[2] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[2] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[3] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[3] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[4] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[4] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[5] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[5] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[6] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[6] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[7] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[7] + ">" +
										"</a>" +
										"<a class='shortViewImgWrap' href=" + shortViewImg[8] + " data-lightbox=" + shortid + " >" +
										"<img class='shortViewImg' src=" + shortViewImg[8] + ">" +
										"</a>" +
										" </div>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(shortViewImg9);
								}
							}
						} else if(type == 2) { //长文章
							var coverUrl = k.object.coverUrl;
							var articleid = k.object.id;
							var article_content = htmlEncode(k.object.content);
							if(coverUrl == "") { //无图文章
								if(k.object.columnName == "") { //无图文章
									var NullartileBoxWrap = "<div id='NullartileBoxWrap' articleid=" + articleid + " class='NullartileBoxWrapBox'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<h2>" + k.object.title + "</h2>" +
										"<p class='articleContent'>" + removeHTMLTag(htmlEncode(k.object.content)) + "</p>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(NullartileBoxWrap);
								} else { //无图专栏文章
									var NullartileBoxWrapZL = "<div id='NullartileBoxWrap' articleid=" + articleid + " class='NullartileBoxWrapBox'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<p class='NullartileBoxZL'>更新了专栏<span>#" + k.object.columnName + "#</span></p>" +
										"<h2>" + k.object.title + "</h2>" +
										"<p class='articleContent'>" + removeHTMLTag(htmlEncode(k.object.content)) + "</p>" +
										"<ul class='sameBottom borderSameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										" </ul>" +
										"</div>"
									$(".hotNewB").before(NullartileBoxWrapZL);
								}
								//                                  
							} else { //带图文章
								if(k.object.columnName == "") { //带图文章
									var imgArticleBoxWrap = "<div id='imgArticleBoxWrap' articleid=" + articleid + " class='NullartileBoxWrapBox'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>3" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<div class='liveBoxWrapBL fl'>" +
										"<img src=" + k.object.coverUrl + '!220X164' + ">" +
										"</div>" +
										"<div class='imgArticleBoxWrapBR fr'>" +
										"<div class='imgArticleBoxWrapBRT'>" +
										"<h3>" + k.object.title + "</h3>" +
										"<p class='imgArticleBoxWrapBCentent'>" + removeHTMLTag(htmlEncode(k.object.content)) + "</p>" +
										"</div>" +
										"<div class='imgArticleBoxWrapBRB sameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										"</div>" +
										"</div>" +
										"</div>";
									$(".hotNewB").before(imgArticleBoxWrap);
								} else { //带图专栏
									//	console.log(k.object.columnName);
									var imgArticleBoxWrapZL = "<div id='imgArticleZLBoxWrap' articleid=" + articleid + " class='NullartileBoxWrapBox'>" +
										"<div class='BoxWrapT'>" +
										"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
										"<div class='liveBoxWrapTR fl'>" +
										"<p>" + k.object.liverInfo.nickName + "</p>" +
										"<p>" + format(new Date(k.publishTime)) + "</p>" +
										"</div>" +
										"</div>" +
										"<div class='liveBoxWrapBL fl'>" +
										"<img src=" + k.object.coverUrl + '!220X164' + ">" +
										"</div>" +
										"<div class='imgArticleBoxWrapBR fr'>" +
										"<div class='imgArticleBoxWrapBRT'>" +
										"<p class='articleZL'>更新了专栏<span>#" + k.object.columnName + "#</span></p>" +
										"<h3>" + k.object.title + "</h3>" +
										"<p class='imgArticleBoxWrapBCentent'>" + removeHTMLTag(htmlEncode(k.object.content)) + "</p>" +
										"</div>" +
										"<div class='imgArticleBoxWrapBRB sameBottom'>" +
										"<li class='fr sameBottomList'>分享</li>" +
										"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
										"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
										"</div>" +
										"</div>" +
										"</div>";
									$(".hotNewB").before(imgArticleBoxWrapZL);
								}
							}
						}

					} else if(objectType == 2) { //视频
						var videoId = k.object.id;
						// console.log(k.publishTime);
						// console.log(k)
						if(k.object.columnName == "") { //视频
							var videoNewsWrap = "<div id='videoNewsWrap' videoId=" + videoId + " class='videoNewsWrapBox'>" +
								"<div class='BoxWrapT'>" +
								"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
								"<div class='liveBoxWrapTR fl'>" +
								"<p>" + k.object.liverInfo.nickName + "</p>" +
								"<p>" + format(new Date(k.publishTime)) + "</p>" +
								"</div>" +
								"</div>" +
								"<div class='videoNewsBoxB'>" +
								"<div class='videoNewsBoxBL fl'>" +
								"<img src='images/livevideo.png'/>" +
								"<img class='vedioCoverUrl' src=" + k.object.coverUrl + '!220X164' + ">" +
								"<span>" + durationFun(k.object.duration) + "</span>" +
								"</div>" +
								"<div class='videoNewsBoxBR fl'>" +
								"<p></p>" +
								"<p>" + k.object.topic + "</p>" +
								"<p>" + k.object.watchCount + "人在看</p>" +
								"<ul class='sameBottom borderSameBottom'>" +
								"<li class='fr sameBottomList'>分享</li>" +
								"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
								"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
								" </ul>" +
								"</div>" +
								"</div>" +
								"</div>";
							$(".hotNewB").before(videoNewsWrap);
							$(".vedioCoverUrl").one("error", function(e) {
								$(this).attr("src", "images/vedioCoverUrl.jpg")
							});
							
						} else { //视频专栏
							var videoNewsWrapZL = "<div id='videoNewsWrap' videoId=" + videoId + " class='videoNewsWrapBox'>" +
								"<div class='BoxWrapT'>" +
								"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
								"<div class='liveBoxWrapTR fl'>" +
								"<p>" + k.object.liverInfo.nickName + "</p>" +
								"<p>" + format(new Date(k.publishTime)) + "</p>" +
								"</div>" +
								"</div>" +
								"<div class='videoNewsBoxB'>" +
								"<div class='videoNewsBoxBL fl'>" +
								"<img src='images/livevideo.png'/>" +
								"<img src=" + k.object.coverUrl + '!220X164' + ">" +
								"<span>" + durationFun(k.object.duration) + "</span>" +
								"</div>" +
								"<div class='videoNewsBoxBR fl'>" +
								"<p>更新了专栏 <span>#" + k.object.columnName + "#</span></p>" +
								"<p>" + k.object.topic + "</p>" +
								"<p>" + k.object.watchCount + "人在看</p>" +
								"<ul class='sameBottom borderSameBottom'>" +
								"<li class='fr sameBottomList'>分享</li>" +
								"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
								"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
								" </ul>" +
								"</div>" +
								"</div>" +
								"</div>";
							$(".hotNewB").before(videoNewsWrapZL);
						}
					} else if(objectType == 3) { //直播
						var liveuid = k.object.liverInfo.uid;
						var liveType = k.object.type;
						//  console.log(liveType);
						if(liveType == 0) {
							var liveBoxWrap = "<div id='liveBoxWrap'>" +
								"<div class='BoxWrapT'>" +
								"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
								"<div class='liveBoxWrapTR fl'>" +
								"<p>" + k.object.liverInfo.nickName + "</p>" +
								"<p>" + format(new Date(k.publishTime)) + "</p>" +
								"</div>" +
								"</div>" +
								"<div class='liveBoxWrapB'>" +
								"<div class='liveBoxWrapBL fl'>" +
								"<img class='vedioCoverUrl' src=" + k.object.coverUrl + '!220X164' + ">" +
								"<img src='images/livelive.png'/>" +
								"</div>" +
								"<div class='liveBoxWrapBR fl'>" +
								"<p>" + k.object.topic + "</p>" +
								"<p><span class='fl'>" + k.object.watchCount + "人在看</span><span class='fr goToAnchorBtn'>观看主播，与主播参与互动>></span></p>" +
								"</div>" +
								"</div>" +
								"</div>";
							$(".hotNewB").before(liveBoxWrap);
							$(".vedioCoverUrl").one("error", function(e) {
								$(this).attr("src", "images/vedioCoverUrl.jpg")
							});
						} else if(liveType == 1) { //回放
							var videoId = k.object.id;
							var goBackWrap = "<div id='videoNewsWrap' videoId=" + videoId + " class='videoNewsWrapBox'>" +
								"<div class='BoxWrapT'>" +
								"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
								"<div class='liveBoxWrapTR fl'>" +
								"<p>" + k.object.liverInfo.nickName + "</p>" +
								"<p>" + format(new Date(k.publishTime)) + "</p>" +
								"</div>" +
								"</div>" +
								"<div class='videoNewsBoxB'>" +
								"<div class='videoNewsBoxBL fl'>" +
								"<img src='images/livevideo.png'/>" +
								"<img class='vedioCoverUrl' src=" + k.object.coverUrl + '!220X164' + ">" +
								"<img src='images/play.png'/>" +
								"</div>" +
								"<div class='videoNewsBoxBR fl'>" +
								"<p></p>" +
								"<p>" + k.object.topic + "</p>" +
								"<p>" + k.object.watchCount + "人在看</p>" +
								"<ul class='sameBottom'>" +
								"<li class='fr sameBottomList'>分享</li>" +
								"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
								"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
								" </ul>" +
								"</div>" +
								"</div>" +
								"</div>";
							$(".hotNewB").before(goBackWrap);
							$(".vedioCoverUrl").one("error", function(e) {
								$(this).attr("src", "images/vedioCoverUrl.jpg")
							});
						}

					} else if(objectType == 4) { //话题回答
						// console.log(k);
						var topicid = k.object.discuss.discussId;
						var topicBoxWrap = "<div id='topicBoxWrap' class='topicBoxWrap' topicid=" + topicid + ">" +
							"<div class='BoxWrapT'>" +
							"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
							"<div class='liveBoxWrapTR fl'>" +
							"<p>" + k.object.liverInfo.nickName + "</p>" +
							"<p>" + format(new Date(k.publishTime)) + "</p>" +
							"</div>" +
							"</div>" +
							"<p class='topicTitle'>回答了<span>#话题#</span>：" + k.object.answerContent + "</p>" +
							"<div class='topicBoxBottom'>" +
							"<img class='fl' src='images/livehuati.png'/>" +
							"<div class='topicBoxBottomR'>" +
							"<p>" + k.object.discuss.discussTitle + "</p>" +
							"<p><span>" + k.object.discuss.discussWatchCount + "人看过</span><span>" + k.object.discuss.discussAnswerCount + "人回答</span></p>" +
							"</div>" +
							"</div>" +
							"<ul class='sameBottom'>" +
							"<li class='fr sameBottomList'>分享</li>" +
							"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
							"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
							" </ul>" +
							"</div>"
						$(".hotNewB").before(topicBoxWrap);
					} else if(objectType == 5) { //实盘
						var delegateType = k.object.delegateType;
						if(delegateType == 1) { //买入
							var firmBugWrap = "<div class='firmBugWrap'>" +
								"<div class='BoxWrapT'>" +
								"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
								"<div class='liveBoxWrapTR fl'>" +
								"<p>" + k.object.liverInfo.nickName + "</p>" +
								"<p>" + format(new Date(k.publishTime)) + "</p>" +
								"</div>" +
								"</div>" +
								"<p class='firmBugBox'>" +
								"我的<span>#实盘#</span>有最新的买入操作记录" +
								"</p>" +
								"<div class='firmBugBoxB'>" +
								"<div class='firmBugBoxBL fl'>买</div>" +
								"<div class='firmBugBoxBCL fl'>" +
								"<p>" + k.object.stockName + "</p>" +
								"<p>" + k.object.stockCode + "</p>" +
								"</div>" +
								"<div class='firmBugBoxBCR fl'>" +
								"<p><span>" + k.object.beforePositionRate + "%</span>-><span>" + k.object.changePositionRate + "%</span></p>" +
								"<p>成交价：￥" + k.object.price + "</p>" +
								"</div>" +
								"<div class='firmBugBoxBR fl'>看交易</div>" +
								"</div>" +
								"<ul class='sameBottom'>" +
								"<li class='fr sameBottomList'>分享</li>" +
								"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
								"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
								"</ul>" +
								"</div>"
							$(".hotNewB").before(firmBugWrap);
						} else if(delegateType == -1) { //卖出
							//  console.log(k);
							var firmSellWrap = "<div class='firmBugWrap'>" +
								"<div class='BoxWrapT'>" +
								"<img class='fl' src=" + k.object.liverInfo.headImgUrl + ">" +
								"<div class='liveBoxWrapTR fl'>" +
								"<p>" + k.object.liverInfo.nickName + "</p>" +
								"<p>" + format(new Date(k.publishTime)) + "</p>" +
								"</div>" +
								"</div>" +
								"<p class='firmBugBox'>" +
								"我的<span>#实盘#</span>有最新的卖出操作记录" +
								"</p>" +
								"<div class='firmBugBoxB'>" +
								"<div class='firmBugBoxBLSell fl'>卖</div>" +
								"<div class='firmBugBoxBCL fl'>" +
								"<p>" + k.object.stockName + "</p>" +
								"<p>" + k.object.stockCode + "</p>" +
								"</div>" +
								"<div class='firmBugBoxBCR fl'>" +
								"<p><span>" + k.object.beforePositionRate + "%</span>-><span>" + k.object.changePositionRate + "%</span></p>" +
								"<p>成交价：￥" + k.object.price + "</p>" +
								"</div>" +
								"<div class='firmBugBoxBR fl'>看交易</div>" +
								"</div>" +
								"<ul class='sameBottom'>" +
								"<li class='fr sameBottomList'>分享</li>" +
								"<li class='fr sameBottomList'>" + k.commentCount + "条评论</li>" +
								"<li class='fr sameBottomList'>" + k.likeCount + "</li>" +
								"</ul>" +
								"</div>"
							$(".hotNewB").before(firmSellWrap);
						}
					};

					if(k.object.liverInfo.headImgUrl == '') {
						$(".BoxWrapT img").attr("src", "images/anchorHead.png");
					};
				})
			}

		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus);
		},
	});
	//视频播放器
	var video = $("#myVideo").get(0);
	video.paused = true;
	$(".playicon").hover(function() {
		$(this).attr("src", "images/playicon-P.png")
	}, function() {
		$(this).attr("src", "images/playicon.png")
	});
	$(".playicon").on("click", function() {
		if(video.paused) {
			video.play();
			$(".playicon").attr("src", "images/playicon-p.png")
		} else {
			video.pause();
			$(".playicon").css("display", "none");
			$(".stopicon-P").css("display", "block");
		}
		return false
	});
	$(".stopicon-P").hover(function() {
		$(this).attr("src", "images/stopicon-p.png")
	}, function() {
		$(this).attr("src", "images/stopicon.png")
	});
	$(".stopicon-P").on("click", function() {
		if(video.paused) {
			video.play();
			$(".playicon").css("display", "block");
			$(".stopicon-P").css("display", "none")
		} else {
			video.pause()
		}
		return false
	});
	/*$(".refreshicon").click(function() {
		video.load();
		
	});*/
	$(".refreshicon").hover(function() {
		$(this).attr("src", "images/refreshicon-P.png")
	}, function() {
		$(this).attr("src", "images/refreshicon.png")
	});
	$(".volumeicon").click(function() {
		video.volume = 0;
		$("#range").val(0);
		$(".volumeicon").css("display", "none");
		$(".volumeicon1").css("display", "block");
		$(".range_before").width(0);
		$(".range_center").css({
			"left": "-5px"
		})
		return false
	});
	$(".volumeicon1").click(function() {
		video.volume = 0.5;
		$("#range").val(50);
		$(".volumeicon1").css("display", "none");
		$(".volumeicon").css("display", "block");
		$(".range_before").width(50);
		$(".range_center").css({
			"left": "45px"
		})
		return false
	});
	//声音播放器
	$("#soundBox").mousedown(function(e) {
		var oX = e.pageX - $("#soundBox").offset().left - $(".range_center").width() / 2;
		//判断，不让.drag出.left
		if(oX < 0) {
			oX = 0;
		} else if(oX > $("#soundBox").width() - $(".range_center").width()) {
			oX = $("#soundBox").width() - $(".range_center").width();
		}
		video.volume = oX / 100;
		$(".range_center").css({
			"left": oX + "px",
		});
		$(".range_before").css({
			"width": oX + 10 + "px",
		})

	})
	$(document).bind("mouseup", function() {
		$(this).unbind("mousemove");
	});
	//拖动中间部分改变声音大小

	$(".full_screenicon").hover(function() {
		$(this).attr("src", "images/full-screenicon-P.png")
	}, function() {
		$(this).attr("src", "images/full-screenicon.png")
	});

	function launchFullscreen(element) {
		if(element.requestFullscreen) {
			element.requestFullscreen()
		} else {
			if(element.mozRequestFullScreen) {
				element.mozRequestFullScreen()
			} else {
				if(element.webkitRequestFullscreen) {
					element.webkitRequestFullscreen()
				} else {
					if(element.msRequestFullscreen) {
						element.msRequestFullscreen()
					}
				}
			}
		}
	}
	$(".full_screenicon").on("click", function() {
		launchFullscreen(document.getElementById("myVideo"))
	});
	$("#myVideo").on("timeupdate", function(event) {
		onTrackedVideoFrame(this.currentTime, this.duration)
	});

	function onTrackedVideoFrame(currentTime, duration) {
		$("#current_minute").text(parseInt(currentTime / 60));
		$("#current_second").text(parseInt(currentTime % 60));
		$("#total_minute").text(parseInt(duration / 60));
		$("#total_second").text(parseInt(duration % 60))
	}
	//点击视频/回放跳转
	$(document).on("click", ".videoNewsWrapBox", function(e) {
		var id = $(this).attr("videoId");
		window.location.href = "/video?" + "id=" + id;
	});
	//文章
	$(document).on("click", ".NullartileBoxWrapBox", function(e) {
		var id = $(this).attr("articleid");
		window.location.href = "/article?" + "id=" + id;
	});
	//话题
	$(document).on("click", ".topicBoxWrap", function(e) {
		var id = $(this).attr("topicid");
		window.location.href = "/topicDetails?" + "id=" + id;
	});
	//直播间
	$(document).on("click", ".liveBoxWrapB", function(e) {
		$("body,html").animate({
			scrollTop: 0
		}, 500)
	});
	//买卖
	$(document).on("click", ".firmBugBoxBR", function(e) {
		window.location.href = "/userProfile?" + "uid=" + uid;
	});

	//获得公告接口
	$.ajax({
		type: "get", //请求方式
		async: true, //是否异步
		dataType: "json",
		url: "/api/v1/live/getAnnouncement.do",
		data: {
			"uid": uid,
		},
		success: function(res) {
			if(res.code == 0) {
				if(res.data.announcement == "") {
					$("#anchorAnnouncement").stop().hide();
				}
				var announcement = res.data.announcement;
				var announcementImgUrl = res.data.announcementImgUrl;
				if(announcement) {
					$(".anchorAnnouncementInfo").html(announcement);
					var loginnum = $(".anchorAnnouncementInfo").html().length;
					var loginnr = $(".anchorAnnouncementInfo").html();
					if(loginnum > 180) {
						$(".anchorAnnouncementInfo").html(loginnr.substring(0, 180) + "...");

					}

				};
				if(announcementImgUrl) {
					$(".announcementImgUrl").attr("src", announcementImgUrl);
				}

			}

		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus);
		},
	});
	//	//充值函数
	//	payFun(userId, usertoken);
	function payFun(userId, usertoken) {
		/*充值接口*/
		$.ajax({
			type: "POST",
			async: true,
			dataType: "json",
			url: "/api/v1/account/selectByWhere.do",
			data: {
				"uid": userId,
				"coinType": "RECHARGE_COIN",
				"token": usertoken,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(".coinNiBi").html(res.data[0].coinNumber);
					$(".balanceCoin").html(res.data[0].coinNumber + "牛币");
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		});
	}
	//点击重置按钮
	//	$(".payMoneyBtn").click(function() {
	//		$("#exceptWrap").stop().show();
	//		$("#n_money").stop().show();
	//	})
	$(".qitaMoney").focus(function() {
		$(this).removeAttr("placeholder");
		$(".moneyAlert").stop().show()
	});
	$(".qitaMoney").blur(function() {
		$(this).attr("placeholder", "其他金额");
		$(".moneyAlert").stop().hide()
	});
	$(".payBtn").click(function() {
		var totalFee = "";
		if($(".qitaMoney").val() != "") {
			totalFee = parseInt($(".qitaMoney").val());
			//console.log(totalFee)
		} else {
			totalFee = parseInt($(".money_list").find(".click_effect").children().text())
		}
		$(".weChatPayNum").html(totalFee);
		$.ajax({
			type: "POST",
			async: true,
			dataType: "json",
			url: "/api/v1/order/wxUnifiedOrder.do",
			data: {
				"uid": userId,
				"totalFee": totalFee,
				"tradeType": "NATIVE",
				"token": usertoken,
			},
			success: function(res) {
				if(res.code == 0) {
					$("#n_money").fadeOut(1);
					$("#exceptWrap").fadeIn(1);
					$(".weChatCodeWrap").fadeIn(1);
					var codeUrl = res.data.codeUrl;
					var outTradeNo = res.data.outTradeNo;
					//console.log(outTradeNo);
					jQuery("#weChatPayCode").qrcode({
						render: "canvas",
						foreground: "#000",
						background: "#FFF",
						width: 180,
						height: 180,
						text: codeUrl,
						correctLevel: 2
					});
					intervalTime = setInterval(function() {
						$.ajax({
							type: "POST",
							async: true,
							dataType: "json",
							url: "/api/v1/order/wxFrontNotify.do",
							data: {
								"uid": userId,
								"outTradeNo": outTradeNo,
								"token": usertoken,
							},
							success: function(res) {
								//	console.log(res);
								if(res.code == 0) {
									$(".weChatCodeWrap").stop().hide();
									$(".weChatPaySuccess").stop().show();
									payFun(userId, usertoken);
								}
							},
							error: function(XMLHttpRequest, textStatus, errorThrown) {
								console.log(XMLHttpRequest.status);
								console.log(XMLHttpRequest.readyState);
								console.log(textStatus)
							}
						})
					}, 3000)
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			}
		})
	})

	//打赏动画
	//$(".sendGiftAnimation").delay(5000).hide(0);
	//判断登录注册
	function loginFunBox(chatRoomId){
		$.ajax({
			type: "get",
			url: "/userInfos",
			success: function(res) {
				if(res.code == -2) { //未登录
					alertLoginFun(".isLog"); //登录
					alertLoginFun(".sendGiftBtn"); //打赏
					alertLoginFun(".payMoneyBtn "); //充值
					alertLoginFun(".liveFollow "); //关注
					alertLoginFun("#sendMsgBtn "); //发送
					//访客模式
					var data = new Date();
					var time = data.getTime();
					var time = data.getTime() + "";
					var num = parseInt(1000000 * Math.random()) + ""; //时间戳加六位随机数
					userId = (time + num);
					$.ajax({
						dataType: "json",
						type: "POST", //请求方式
						async: true, //是否异步
						url: "/api/v1/im/createSig.do",
						data: {
							"uid": userId,
						},
						success: function(res) {
							if(res.code == 0) {
								userSig = res.data;
							    userNickHeadurl = 'https://picture.fengniutv.com/anchorHead.png'; //默认头像
							    if(chatRoomId){
							    	chatRoom(chatRoomId, userSig, userId, "游客", userNickHeadurl, '');
							    }
							}
	
						},
						error: function(XMLHttpRequest, textStatus, errorThrown) {
							console.log(XMLHttpRequest.status);
							console.log(XMLHttpRequest.readyState);
							console.log(textStatus);
						},
	
					});
	
				};
				if(res.code == 0) { //登录
					//console.log(res);
					userId = res.data.userInfo.uid;
					usertoken = res.data.token;
					userNickName = res.data.userInfo.nickName;
					userNickHeadurl = res.data.userInfo.headImgUrl;
					payFun(userId, usertoken);
					
					//登录文本框去掉
					$(".login-inside").stop().hide();
					loginSuccessSig(chatRoomId,userId,userNickName,userNickHeadurl); //获得sig
					//是否已经关注
					checkFollowing(uid, userId, usertoken);
	
					$("#sendMsgBtn").click(function() {
	//					onSendMsg(); //发送信息
						onSendMsg(userId, userNickName, userSig, userNickHeadurl, usertoken, "");
					});
					/*打赏*/
					for(D = 1; D < 7; D++) {
						sendGiftFun(D);
					};
					//充值
					$(".payMoneyBtn").click(function() {
						$("#exceptWrap").stop().show();
						$("#n_money").stop().show();
					})
					$(".getFollowBtn").click(function() {
						$.ajax({
							type: "post",
							url: "/api/v1/user/checkFollowing.do",
							async: true,
							data: {
								"receptorId": uid,
								"usertoken": usertoken,
								"uid": userId,
							},
							success: function(res) {
								//							var res = JSON.parse(res);
								if(res.data == 0) {
									addConcern();
									$(".getFollowBtn").html("关注")
								}
								if(res.data == 1) {
									cancelConcern();
									$(".getFollowBtn").html("已关注");
									$(".getFollowBtn").css({
										"background": "#bcc3cf",
									})
								}
							}
						})
					})
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	

	function sendGiftFun(D) {
		$("#sendGiftBtn" + D).click(function() {
			monetary = $("#giftPrice" + D).html();
			//console.log(monetary);
			$.ajax({
				dataType: "json",
				type: "POST",
				async: true,
				url: "/api/v1/account/getToken.do", //打赏认证Token
				data: {
					"uid": userId,
					"token": usertoken,
				},
				success: function(res) {
					if(res.code == 0) {
						var awardToken = res.data;
						$.ajax({
							dataType: "json",
							type: "POST",
							async: true,
							url: "/api/v1/account/award.do", //用户打赏接口
							data: {
								"uid": userId,
								"uidIn": uid,
								"target": target,
								"coinType": "RECHARGE_COIN",
								"monetary": monetary,
								"awardToken": awardToken,
								"channel": "WEB",
								"token": usertoken,
							},
							success: function(res) {
								if(res.code == 0) {
									if(chatRoomId){
										sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, usertoken, '',D);
									}
									payFun(userId, usertoken);
								}
								if(res.code == -706) { //余额不足
									$("#exceptWrap").stop().show();
									$(".weChatOweWrap").stop().show();
									$(".weChatErrorEnter").click(function() {
										$(".weChatOweWrap").stop().hide();
										$("#exceptWrap").stop().show()
										$("#n_money").stop().show();
									})
								}
							},
							error: function(XMLHttpRequest, textStatus, errorThrown) {
								console.log(XMLHttpRequest.status);
								console.log(XMLHttpRequest.readyState);
								console.log(textStatus)
							},
						})
					}
				},
				error: function(XMLHttpRequest, textStatus, errorThrown) {
					console.log(XMLHttpRequest.status);
					console.log(XMLHttpRequest.readyState);
					console.log(textStatus)
				},
			})
		});
	}

	function checkFollowing(uid, userId, usertoken) {
		$.ajax({
			type: "post",
			url: "/api/v1/user/checkFollowing.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				// console.log(res);
				if(res.data == 0) {
					$(".getFollowBtn").html("关注")
				}
				if(res.data == 1) {
					$(".getFollowBtn").html("已关注");
					$(".getFollowBtn").css({
						"background": "#bcc3cf"
					})
				}
			}
		})
	}

	function loginSuccessSig(chatRoomId,userId,userNickName,userNickHeadurl) {
		$.ajax({
			dataType: "json",
			type: "POST", //请求方式
			async: true, //是否异步
			url: "/api/v1/im/createSig.do",
			data: {
				"uid": userId,
			},
			success: function(res) {
				if(res.code == 0) {
					userSig = res.data;
					if(chatRoomId){
						chatRoom(chatRoomId, userSig, userId, userNickName, userNickHeadurl, '');
					}
				};
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},

		});
	}

	function alertLoginFun(obj) {
		$(obj).click(function() {
			$("#loginAlert").stop().show();
			$("#loginAlert").load("/login");
		});
	}

	function cancelConcern() {
		$.ajax({
			type: "post",
			url: "/api/v1/user/deleteFollow.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				$(".getFollowBtn").html("关注");
				$(".getFollowBtn").css({
					"background": "#fe4502",
				});
				var num = Number($(".fansCount").html());
				$(".fansCount").html(num - 1)
			}
		})
	}

	function addConcern() {
		$.ajax({
			type: "post",
			url: "/api/v1/user/following.do",
			async: true,
			data: {
				"receptorId": uid,
				"uid": userId,
				"token": usertoken,
			},
			success: function(res) {
				var num = Number($(".fansCount").html());
				$(".fansCount").html(num + 1);
				getFollowFun();
				$(".getFollowBtn").html("已关注");
				$(".getFollowBtn").css({
					"background": "#bcc3cf",
				})
			}
		})
	}
	/*直播回顾接口*/
	$.ajax({
		type: "get",
		async: true,
		dataType: "json",
		data: {
			"uid": uid,
			"pageIndex": 1,
			"pageSize": 5,
		},
		url: "/api/v1/multiple/getLiveListByUid.do",
		success: function(res) {
			if(res.code == 0) {
				//	console.log(res);
				$(res.data).each(function(m, w) {
					var goBackVideoList = "<li class='goBackVideoList' id=" + w.id + " type=" + w.type + ">" +
						"<div class='goBackVideoL fl'>" +
						"<img src=" + w.coverUrl + '!220X164' + ">" +
						"<img src='images/zhibohuiguxiao.png'/>" +
						"</div>" +
						"<div class='goBackVideoR fr'>" +
						"<p>" + w.topic + "</p>" +
						"</div>" +
						"</li>";
					$(".goBackVideoWrap").append(goBackVideoList);
					$(".goBackVideoList:first").stop().hide();
				});
				$(document).on("click", ".goBackVideoList", function(e) {
					var id = $(this).attr("id");
					var type = $(this).attr("type");
					if(type == 1 || type == 2) {
						//window.open("/video?id=" + id); //转到主播个人页
						window.location.href = "video?id=" + id;
					}
					if(type == 0) {
						//window.open("/live?uid=" + uid); //转到主播个人页
						//window.location.reload();
					}
				})

			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus)
		},
	});
	//官方活动
	$.ajax({
		type: "get",
		async: true,
		dataType: "json",
		data: {
			"type": 6,
		},
		url: "/api/v2/discovery/getDiscoveryByType.do",
		success: function(res) {
			//console.log(res);
			if(res.code == 0) {
				$(res.data).each(function(m, Q) {
					//					if(Q.discoveryObject.bannerType == 5) {
					var officialImg = "<img src=" + Q.discoveryObject.imgUrl + " id=" + Q.objectId + ">";
					$(".officialEventWrap").append(officialImg);
					//					}
				});
				$(document).on("click", ".officialEventWrap img", function(e) {
					var id = $(this).attr("id");
					window.open(id);
				})

			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus);
		},
	});
	/*结束框上面按钮*/
	$(".alertBtnGoBack").click(function() {
		window.location.href = "/";
	});
	$(".alertBtnAnchor").click(function() {
		window.open("/userProfile?uid=" + uid); //转到主播个人页
	});
	$(".anchorBoxR").click(function() {
		window.open("/userProfile?uid=" + uid); //转到主播个人页
	});
	$(".goToAnchorPageBtn").click(function() {
		window.open("/userProfile?uid=" + uid); //转到主播个人页
	});
	$(".hotNewB").click(function() {
		window.open("/userProfile?uid=" + uid); //转到主播个人页
	});
	//分享IM
	$(".-mob-share-list").click(function() {
		shareAnchorFun();
	});

	function shareFun(url, title, description, pic) {
		mobShare.config({
			debug: true, // 开启调试，将在浏览器的控制台输出调试信息
			appkey: '1d102ac0241c0', // appkey
			params: {
				url: url, // 分享链接
				title: title, // 分享标题
				description: description, // 分享内容
				pic: pic, // 分享图片，使用逗号,隔开
				reason: '', //自定义评论内容，只应用与QQ,QZone与朋友网
			},
			callback: function(plat, params) {
				// console.log("分享成功了")
			}

		});

	}
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
	//电脑跳转手机
	function browserRedirect() {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		var bIsMidp = sUserAgent.match(/midp/i) == "midp";
		var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		var bIsAndroid = sUserAgent.match(/android/i) == "android";
		var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
		if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
			window.location.href = "https://www.fntv8.com/m/live?uid=" + uid + "";
		}
	}
	browserRedirect();

})
/*IM*/
function chatRoom(chatRoomId, userSig, userId, userNickName, userNickHeadurl, roomid) {
	//帐号模式，0-表示独立模式，1-表示托管模式，开发者根据自己的模式，改成相应的值。
	var accountMode = 0;
	var sdkAppID = 1400018939; //开发者改成自己的业务id
	var accountType = 8454; //开发者改成自己的业务帐号类型
	var avChatRoomId = chatRoomId; //直播间的id
	sdkLogin(userSig, userId, userNickName, userNickHeadurl); //登录函数
}

function sdkLogin(userSig, userId, userNickName, userNickHeadurl) {
	var isAccessFormalEnv = true; //是否访问正式环境

	if(webim.Tool.getQueryString("isAccessFormalEnv") == "false") {
		isAccessFormalEnv = false; //访问测试环境
	}

	var isLogOn = true; //是否在浏览器控制台打印sdk日志

	//其他对象，选填
	var options = {
		'isAccessFormalEnv': isAccessFormalEnv, //是否访问正式环境，默认访问正式，选填
		'isLogOn': isLogOn //是否开启控制台打印日志,默认开启，选填
	};

	var curPlayAudio = null; //当前正在播放的audio对象

	var openEmotionFlag = false; //是否打开过表情

	if(/debug/gi.test(location.hash)) {
		document.write('<script src="http://sdklog.isd.com/js/vconsole.min.js"></scr' + 'ipt>');
	}
	//当前用户身份
	var loginInfo = {
		'sdkAppID': 1400018939, //用户所属应用id,必填
		'appIDAt3rd': 1400018939, //用户所属应用id，必填
		'accountType': 8454, //用户所属应用帐号类型，必填
		'identifier': userId, //当前用户ID，需要开发者填写
		'identifierNick': userNickName, //当前用户昵称，选填
		'userSig': userSig, //当前用户身份凭证，需要开发者填写
		'headurl': userNickHeadurl //当前用户默认头像，选填
	};
	var onConnNotify = function(resp) {
		switch(resp.ErrorCode) {
			case webim.CONNECTION_STATUS.ON:
				//webim.Log.warn('连接状态正常...');
				break;
			case webim.CONNECTION_STATUS.OFF:
				webim.Log.warn('连接已断开，无法收到新消息，请检查下你的网络是否正常');
				break;
			default:
				webim.Log.error('未知连接状态,status=' + resp.ErrorCode);
				break;
		}
	};

	//监听事件
	var listeners = {
		"onConnNotify": onConnNotify, //选填
		"jsonpCallback": jsonpCallback, //IE9(含)以下浏览器用到的jsonp回调函数,移动端可不填，pc端必填
		//"onBigGroupMsgNotify": onBigGroupMsgNotify, //监听新消息(大群)事件，必填
		"onMsgNotify": onMsgNotify, //监听新消息(私聊(包括普通消息和全员推送消息)，普通群(非直播聊天室)消息)事件，必填
		"onGroupSystemNotifys": onGroupSystemNotifys, //监听（多终端同步）群系统消息事件，必填
		"onGroupInfoChangeNotify": onGroupInfoChangeNotify //监听群资料变化事件，选填
	};
	//监听（多终端同步）群系统消息方法，方法都定义在demo_group_notice.js文件中
	//注意每个数字代表的含义，比如，
	//1表示监听申请加群消息，2表示监听申请加群被同意消息，3表示监听申请加群被拒绝消息等
	var onGroupSystemNotifys = {
		// "1": onApplyJoinGroupRequestNotify, //申请加群请求（只有管理员会收到）
		// "2": onApplyJoinGroupAcceptNotify, //申请加群被同意（只有申请人能够收到）
		// "3": onApplyJoinGroupRefuseNotify, //申请加群被拒绝（只有申请人能够收到）
		// "4": onKickedGroupNotify, //被管理员踢出群(只有被踢者接收到)
		"5": onDestoryGroupNotify, //群被解散(全员接收)
		// "6": onCreateGroupNotify, //创建群(创建者接收)
		// "7": onInvitedJoinGroupNotify, //邀请加群(被邀请者接收)
		//  "8": onQuitGroupNotify, //主动退群(主动退出者接收)
		// "9": onSetedGroupAdminNotify, //设置管理员(被设置者接收)
		//"10": onCanceledGroupAdminNotify, //取消管理员(被取消者接收)
		"11": onRevokeGroupNotify, //群已被回收(全员接收)
		"255": onCustomGroupNotify //用户自定义通知(默认全员接收)
	};
	//web sdk 登录
	webim.login(loginInfo, listeners, options,
		function(identifierNick) {
			//identifierNick为登录用户昵称(没有设置时，为帐号)，无登录态时为空
			webim.Log.info('webim登录成功');
			applyJoinGroup(chatRoomId); //加入加入聊天室
		},
		function(err) {
			layer.msg(err.ErrorInfo);
		}
	); //
}

//IE9(含)以下浏览器用到的jsonp回调函数
function jsonpCallback(rspData) {
	//设置jsonp返回的
	webim.setJsonpLastRspData(rspData);
}
//监听新消息(私聊(包括普通消息、全员推送消息)，普通群(非直播聊天室)消息)事件
//newMsgList 为新消息数组，结构为[Msg]
function onMsgNotify(newMsgList) {
	//console.log(newMsgList);
	//console.warn(newMsgList);
	var sess, newMsg;
	//获取所有聊天会话
	var sessMap = webim.MsgStore.sessMap();

	for(var j in newMsgList) { //遍历新消息

		newMsg = newMsgList[j];
		//console.warn(newMsg);
		if(newMsg.getSession().id() == selToID) { //为当前聊天对象的消息
			selSess = newMsg.getSession();
			//在聊天窗体中新增一条消息
			//console.warn(newMsg);
			addMsg(newMsg);
		}
	}
	//消息已读上报，以及设置会话自动已读标记
	webim.setAutoRead(selSess, true, true);

//	for(var i in sessMap) {
//		sess = sessMap[i];
//		if(selToID != sess.id()) { //更新其他聊天对象的未读消息数
//			updateSessDiv(sess.type(), sess.id(), sess.unread());
//		}
//	}
}
//监听 群资料变化 群提示消息
function onGroupInfoChangeNotify(groupInfo) {
	webim.Log.warn("执行 群资料变化 回调： " + JSON.stringify(groupInfo));
	var groupId = groupInfo.GroupId;
	var newFaceUrl = groupInfo.GroupFaceUrl; //新群组图标, 为空，则表示没有变化
	var newName = groupInfo.GroupName; //新群名称, 为空，则表示没有变化
	var newOwner = groupInfo.OwnerAccount; //新的群主id, 为空，则表示没有变化
	var newNotification = groupInfo.GroupNotification; //新的群公告, 为空，则表示没有变化
	var newIntroduction = groupInfo.GroupIntroduction; //新的群简介, 为空，则表示没有变化
	if(newName) {
		//更新群组列表的群名称
		//To do
		webim.Log.warn("群id=" + groupId + "的新名称为：" + newName);
	}
}
//监听 解散群 系统消息
function onDestoryGroupNotify(notify) {
	webim.Log.warn("执行 解散群 回调：" + JSON.stringify(notify));
	var reportTypeCh = "[群被解散]";
	var content = "群主" + notify.Operator_Account + "已解散该群";
	showGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId, notify.GroupName, content, notify.MsgTime);
}
//监听 群被回收 系统消息
function onRevokeGroupNotify(notify) {
	webim.Log.warn("执行 群被回收 回调：" + JSON.stringify(notify));
	var reportTypeCh = "[群被回收]";
	var content = "该群已被回收";
	showGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId, notify.GroupName, content, notify.MsgTime);
}
//监听 用户自定义 群系统消息
function onCustomGroupNotify(notify) {
	console.log("执行 用户自定义系统消息 回调： %s", JSON.stringify(notify));
	var reportTypeCh = "[用户自定义系统消息]";
	var content = "收到了自己自定义的系统消息";
	addGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId,
		notify.GroupName, content, notify.MsgTime);
}
//进入大群
function applyJoinGroup(groupId) {
	var options = {
		'GroupId': groupId,
		"ReqMsgNumber": 10
	};
	webim.applyJoinGroup(
		options,
		function(resp) {
			//JoinedSuccess:加入成功; WaitAdminApproval:等待管理员审批
			webim.Log.info('进群成功');
			selToID = groupId;
			//			if(resp.JoinedStatus && resp.JoinedStatus == 'JoinedSuccess') {
			//				webim.Log.info('进群成功');
			//				selToID = groupId;
			//			} else {
			//				console.log('进群失败');
			//			}
		},
		function(err) {
			//console.log(err.ErrorInfo);
			webim.Log.info('进群成功');
			selToID = groupId;
		}
	);
	//	//获取历史记录
//	webim.syncGroupMsgs(options,function(resp){
//		$(resp).each(function(Q,M){
//			//console.log(M);
//		})
//		//console.log(resp)
//	},function(err){
//		//console.log(err);
//	})
}
//聊天页面增加一条消息
function addMsg(msg) {
	console.log(msg);
	var isSelfSend, fromAccount, fromAccountNick, sessType, subType;
	fromAccount = msg.getFromAccount();
	if(!fromAccount) {
		fromAccount = '';
	}
	fromAccountNick = msg.getFromAccountNick();
	if(!fromAccountNick) {
		fromAccountNick = fromAccount;
	};
	var imTime = msg.getTime();
	isSelfSend = msg.getIsSend(); //消息是否为自己发的-:true：表示是我发出消息,false：表示是发给我的消息
	var sendTime = formatV5Time(new Date(msg.getTime() * 1000)); //2017-09-29
	var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000)); //20:10
	var getTime = sendTime + " " + sendTimeMin;
	// var getTime = unixTimestamp.getMonth() +"-"+ unixTimestamp.getDay()+" "+unixTimestamp.getHours() +":"+ unixTimestamp.getMinutes();

	var communicationInfo;
	var headerIMG = msg.getHeadurl();
	//console.log(headerIMG);
	if(!headerIMG) {
		headerIMG = 'images/anchorHead.png';
	}
	//解析消息
	//获取会话类型，目前只支持群聊
	//webim.SESSION_TYPE.GROUP-群聊，
	//webim.SESSION_TYPE.C2C-私聊，
	sessType = msg.getSession().type();
	//获取消息子类型
	//会话类型为群聊时，子类型为：webim.GROUP_MSG_SUB_TYPE
	//会话类型为私聊时，子类型为：webim.C2C_MSG_SUB_TYPE
	subType = msg.getSubType();
	switch(subType) {
		case webim.GROUP_MSG_SUB_TYPE.COMMON: //群普通消息
			communicationInfo = convertMsgtoHtml(msg);
			break;
		case webim.GROUP_MSG_SUB_TYPE.REDPACKET: //群红包消息
			communicationInner = "[群红包消息]" + convertMsgtoHtml(msg);
			break;
		case webim.GROUP_MSG_SUB_TYPE.LOVEMSG: //群点赞消息
			//业务自己可以增加逻辑，比如展示点赞动画效果
			communicationInner = "[群点赞消息]" + convertMsgtoHtml(msg);
			//展示点赞动画
			//showLoveMsgAnimation();
			break;
		case webim.GROUP_MSG_SUB_TYPE.TIP: //群提示消息
			communicationInner = "[群提示消息]" + convertMsgtoHtml(msg);
			break;
	}

	//  msgbody.appendChild(msgPre);
	//
	//  onemsg.appendChild(msghead);
	//  onemsg.appendChild(msgbody);
	//  //消息列表
	//  var msgflow = document.getElementsByClassName("msgflow")[0];
	//  msgflow.appendChild(onemsg);
	//  //300ms后,等待图片加载完，滚动条自动滚动到底部
	//  setTimeout(function () {
	//      msgflow.scrollTop = msgflow.scrollHeight;
	//  }, 300);

}
//解析一条消息
function convertMsgtoHtml(msg) {
	console.log(msg);
	var html = "",
		elems, elem, type, content, headurl;
	elems = msg.getElems(); //获取消息包含的元素数组
	headurl = msg.headurl;
	for(var i in elems) {
		elem = elems[i];
		type = elem.getType(); //获取元素类型
		content = elem.getContent(); //获取元素对象
		switch(type) {
			case webim.MSG_ELEMENT_TYPE.TEXT:
				html += convertTextMsgToHtml(content, msg);
				break;
			case webim.MSG_ELEMENT_TYPE.FACE:
				html += convertFaceMsgToHtml(content);
				break;
			case webim.MSG_ELEMENT_TYPE.IMAGE:
				html += convertImageMsgToHtml(content);
				break;
			case webim.MSG_ELEMENT_TYPE.SOUND:
				html += convertSoundMsgToHtml(content);
				break;
			case webim.MSG_ELEMENT_TYPE.FILE:
				html += convertFileMsgToHtml(content);
				break;
			case webim.MSG_ELEMENT_TYPE.LOCATION: //暂不支持地理位置
				//html += convertLocationMsgToHtml(content);
				break;
			case webim.MSG_ELEMENT_TYPE.CUSTOM: //自定义消息
				html += convertCustomMsgToHtml(content, msg);
				break;
			case webim.MSG_ELEMENT_TYPE.GROUP_TIP:
				html += convertGroupTipMsgToHtml(content);
				break;
			default:
				webim.Log.error('未知消息元素类型: elemType=' + type);
				break;
		}
	}
	return html;
}
//解析文本消息元素
function convertTextMsgToHtml(content, msg) {
	//console.log(content);
	//console.log(msg);
	var isSelfSend, fromAccount, fromAccountNick, sessType, subType;
	fromAccount = msg.getFromAccount();
	if(!fromAccount) {
		fromAccount = '';
	}
	fromAccountNick = msg.getFromAccountNick();
	if(!fromAccountNick) {
		fromAccountNick = fromAccount;
	};
	var imTime = msg.getTime();
	isSelfSend = msg.getIsSend(); //消息是否为自己发的-:true：表示是我发出消息,false：表示是发给我的消息
	var sendTime = formatV5Time(new Date(msg.getTime() * 1000)); //2017-09-29
	var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000)); //20:10
	var getTime = sendTime + " " + sendTimeMin;
	// var getTime = unixTimestamp.getMonth() +"-"+ unixTimestamp.getDay()+" "+unixTimestamp.getHours() +":"+ unixTimestamp.getMinutes();

	var communicationInfo;
	var headerIMG = msg.getHeadurl();
	//console.log(headerIMG);
	if(!headerIMG) {
		headerIMG = 'images/anchorHead.png';
	}
	var communicationInfo = content.getText();
	if(communicationInfo.indexOf("igstn") != -1) {//主播带有回复
		var anchorAnwserBrforeIm = communicationInfo.split("igstn")[0];
		var anchorAnwserAfterIm = communicationInfo.split("igstn")[1];
		var anchorAnwserIM =
		'<li  id=' + imTime + '>'+
			'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
			'<p class="chatName">' + fromAccountNick + '</p>'+
			'<p class="bozhu">播主</p>'+
			'<p class="chatTime">' + sendTimeMin + '</p>'+
			'<p class="answerContent">' + anchorAnwserBrforeIm + '</p>'+
			'<p class="chatContent">' + anchorAnwserAfterIm + '</p>'+
		'</li>';
		$(".live_info").after(anchorAnwserIM);
	} else {
		if(fromAccount != uid) {//普通用户
			var anchorSendMsg =
           ' <li id=' + imTime + '>'+
				'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
			    '<p class="chatName">' + fromAccountNick + '</p>'+
				'<p class="chatTime">' + sendTimeMin + '</p>'+
				'<p class="answerContent">'+communicationInfo+'</p>'+
			'</li>';
			$(".live_info").after(anchorSendMsg);
			if(uid == userId) {//主播回复用户
				var noLogin = $("#sendMsg").attr("placeholder");
				if(noLogin === "来说两句吧！") {
					$(document).on("click", "#" + imTime, function(e) {
//						$(".replyUserBox").stop().show();
//						$(".replayUserInfo").html("回复用户：" + fromAccountNick + '(' + fromAccount + ')');
//						$(".replayUserInfo").click(function() {
//							$(".replyUserBox").stop().hide();
							$("#sendMsg").attr("placeholder", "回复用户：" + fromAccountNick + "");
							$("#sendMsg").attr("name", "igstn" + fromAccountNick + ":" + communicationInfo + "");
						//})
					});
				}
			}
		} else {//直播
			var anchorSendMsg =
			'<li  id=' + imTime + '>'+
				'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
				'<p class="chatName">' + fromAccountNick + '</p>'+
				'<p class="bozhu">播主</p>'+
				'<p class="chatTime">' + sendTimeMin + '</p>'+
				'<p class="answerContent">'+communicationInfo+'</p>'+
			'</li>';	
			$(".live_info").after(anchorSendMsg);
			if(uid == userId) {//主播回复自己
				var noLogin = $("#sendMsg").attr("placeholder");
				if(noLogin === "来说两句吧！") {
					$(document).on("click", "#" + imTime, function(e) {
//						$(".replyUserBox").stop().show();
//						$(".replayUserInfo").html("回复用户：" + fromAccountNick + '(' + fromAccount + ')');
//						$(".replayUserInfo").click(function() {
//							$(".replyUserBox").stop().hide();
							$("#sendMsg").attr("placeholder", "回复用户：" + fromAccountNick + "");
							$("#sendMsg").attr("name", "igstn" + fromAccountNick + ":" + communicationInfo + "");
//						})
					});
				}

			}
		}
	}
	//return content.getText();
}
//解析表情消息元素
function convertFaceMsgToHtml(content) {
	var index = content.getIndex();
	var data = content.getData();
	var url = null;
	var emotion = webim.Emotions[index];
	if(emotion && emotion[1]) {
		url = emotion[1];
	}
	if(url) {
		return "<img src='" + url + "'/>";
	} else {
		return data;
	}
}
//解析图片消息元素
function convertImageMsgToHtml(content) {
	var smallImage = content.getImage(webim.IMAGE_TYPE.SMALL); //小图
	var bigImage = content.getImage(webim.IMAGE_TYPE.LARGE); //大图
	var oriImage = content.getImage(webim.IMAGE_TYPE.ORIGIN); //原图
	if(!bigImage) {
		bigImage = smallImage;
	}
	if(!oriImage) {
		oriImage = smallImage;
	}
	return "<img src='" + smallImage.getUrl() + "#" + bigImage.getUrl() + "#" + oriImage.getUrl() + "' style='CURSOR: hand' id='" + content.getImageId() + "' bigImgUrl='" + bigImage.getUrl() + "' onclick='imageClick(this)' />";
}
//解析语音消息元素
//解析语音消息元素
function convertSoundMsgToHtml(content) {
	var second = content.getSecond(); //获取语音时长
	var downUrl = content.getDownUrl();
	if(webim.BROWSER_INFO.type == 'ie' && parseInt(webim.BROWSER_INFO.ver) <= 8) {
		return '[这是一条语音消息]demo暂不支持ie8(含)以下浏览器播放语音,语音URL:' + downUrl;
	}
	return '<audio src="' + downUrl + '" controls="controls" onplay="onChangePlayAudio(this)" preload="none"></audio>';
}
//解析文件消息元素
function convertFileMsgToHtml(content) {
	var fileSize = Math.round(content.getSize() / 1024);
	return '<a href="' + content.getDownUrl() + '" title="点击下载文件" ><i class="glyphicon glyphicon-file">&nbsp;' + content.getName() + '(' + fileSize + 'KB)</i></a>';
}

//解析位置消息元素
function convertLocationMsgToHtml(content) {
	return '经度=' + content.getLongitude() + ',纬度=' + content.getLatitude() + ',描述=' + content.getDesc();
}
////解析自定义消息元素
function convertCustomMsgToHtml(content,msg) {
//	console.log(content);
//	console.log(msg);
	var sendTime = formatV5Time(new Date(msg.getTime() * 1000)); //2017-09-29
	var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000)); //20:10
	var getTime = sendTime + " " + sendTimeMin;
	var headerIMG = msg.getHeadurl();
	//console.log(headerIMG);
	if(!headerIMG) {
		headerIMG = 'images/anchorHead.png';
	}
	var desc = content.getDesc();
	if(desc == "LIVE_CLOSE") { //组名"LIVE_CLOSE",直播结束
		// console.log("直播结束");
		$("#liveEndWrap").stop().show();
		var liveTopic = $(".liveTitle").html();
		// console.log(liveTopic);
		$(".alertTopic").html('主题' + liveTopic);
	}
	/*分享*/
	//	Msg.E…m.Custom {data: "", desc: "share_live", ext: "神马？浮云！好！！！"}
	if(desc == "share_live") { //组名"share_live",分享
		if(content.getExt() != "") {
			var shareAlert = "<p class='giftSendAlert'>" +
				"<span class='giftSendName'>" + content.getExt() + "</span>" +
				"<span class='giftSendStyle'>分享了</span>" +
				"<span class='giftSendNum'>主播</span>" +
				"</p>";

			$(".weChatScrollTop").append(shareAlert);
			$('.weChatScrollTop').scrollTop($('.weChatScrollTop')[0].scrollHeight);
		} else {
			var shareAlert = "<p class='giftSendAlert'>" +
				"<span class='giftSendName'>游客</span>" +
				"<span class='giftSendStyle'>分享了</span>" +
				"<span class='giftSendNum'>主播</span>" +
				"</p>";

			$(".weChatScrollTop").append(shareAlert);
			$('.weChatScrollTop').scrollTop($('.weChatScrollTop')[0].scrollHeight);
		}

	}
	/*关注*/
	if(desc == "guanzhu_zhubo") { //组名"share_live",分享
		if(content.getExt() != "") {
			var followAnchor = "<p class='giftSendAlert'>" +
				"<span class='giftSendName'>" + content.getExt() + "</span>" +
				"<span class='giftSendStyle'>关注了</span>" +
				"<span class='giftSendNum'>主播</span>" +
				"</p>";

			$(".weChatScrollTop").append(followAnchor);
			$('.weChatScrollTop').scrollTop($('.weChatScrollTop')[0].scrollHeight);
		} else {
			var followAnchor = "<p class='giftSendAlert'>" +
				"<span class='giftSendName'>游客</span>" +
				"<span class='giftSendStyle'>关注了</span>" +
				"<span class='giftSendNum'>主播</span>" +
				"</p>";

			$(".weChatScrollTop").append(followAnchor);
			$('.weChatScrollTop').scrollTop($('.weChatScrollTop')[0].scrollHeight);
		}

	}
	/*礼物*/
	if(desc == "givemoney2_zhubo") { //组名为givemoney2_zhubo为打赏
		var data = content.getData(); //打赏的牛币数（1牛币=赞，10牛币=金豆；188牛币=宝箱；999牛币=涨停板；1888牛币=财神爷；8888金币=金牛）
		var ext = content.getExt();
		switch(data) {
			case "1": //赞
				var giftSendAlert = 
				'<li>'+
					'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
					'<p class="chatName">'+ext+'</p>'+
					'<p class="chatTime">'+sendTimeMin+'</p>'+
					'<p class="giftContent">赠送了主播一个<span class="chatPresent"> “赞” </span></p>'+
					'<img class="whatGift" src="images/zan11.png" alt="" />'+
				'</li>';
				var giftAnimation = "<div class='sendGiftAnimation'>" +
					"<p class='sendGiftAnimationL fl'>" +
					"<span class='fl sendGiftName'>" + ext + "</span>" +
					"<span class='fl'>送给主播</span>" +
					"<img class='fl' src='images/giftzan.png' alt='' />" +
					"<i class='fr'>X1</i>" +
					"</p>" +
					"</div>";
				$(".live_info").after(giftSendAlert);
				$(".sendGiftAnimationWrap").append(giftAnimation);
				$('.weChatScrollTop').scrollTop(0);
				/*打赏图像5秒消失*/
				$(".sendGiftAnimation").delay(5000).hide(0);
				break;
			case "10": //金豆
				var giftSendAlert = 
				'<li>'+
					'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
					'<p class="chatName">'+ext+'</p>'+
					'<p class="chatTime">'+sendTimeMin+'</p>'+
					'<p class="giftContent">赠送了主播一个<span class="chatPresent"> “金豆” </span></p>'+
					'<img class="whatGift" src="images/giftjindou.png" alt="" />'+
				'</li>';
				var giftAnimation = "<div class='sendGiftAnimation'>" +
					"<p class='sendGiftAnimationL fl'>" +
					"<span class='fl sendGiftName'>" + ext + "</span>" +
					"<span class='fl'>送给主播</span>" +
					"<img class='fl' src='images/giftjindou.png' alt='' />" +
					"<i class='fr'>X1</i>" +
					"</p>" +
					"</div>";
				$(".live_info").after(giftSendAlert);
				$(".sendGiftAnimationWrap").append(giftAnimation);
				$('.weChatScrollTop').scrollTop(0);
				/*打赏图像5秒消失*/
				$(".sendGiftAnimation").delay(5000).hide(0);
				break;
			case "188": //宝箱
				var giftSendAlert = 
				'<li>'+
					'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
					'<p class="chatName">'+ext+'</p>'+
					'<p class="chatTime">'+sendTimeMin+'</p>'+
					'<p class="giftContent">赠送了主播一个<span class="chatPresent"> “宝箱” </span></p>'+
					'<img class="whatGift" src="images/giftbaoxiang.png" alt="" />'+
				'</li>';
				var giftAnimation = "<div class='sendGiftAnimation'>" +
					"<p class='sendGiftAnimationL fl'>" +
					"<span class='fl sendGiftName'>" + ext + "</span>" +
					"<span class='fl'>送给主播</span>" +
					"<img class='fl' src='images/giftbaoxiang.png' alt='' />" +
					"<i class='fr'>X1</i>" +
					"</p>" +
					"</div>";
				$(".live_info").after(giftSendAlert);
				$(".sendGiftAnimationWrap").append(giftAnimation);
				$('.weChatScrollTop').scrollTop(0);
				/*打赏图像5秒消失*/
				$(".sendGiftAnimation").delay(5000).hide(0);
				break;
			case "999": //涨停板
				var giftSendAlert = 
				'<li>'+
					'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
					'<p class="chatName">'+ext+'</p>'+
					'<p class="chatTime">'+sendTimeMin+'</p>'+
					'<p class="giftContent">赠送了主播一个<span class="chatPresent"> “涨停板” </span></p>'+
					'<img class="whatGift" src="images/giftzhangtingban.png" alt="" />'+
				'</li>';
				var giftAnimation = "<div class='sendGiftAnimation'>" +
					"<p class='sendGiftAnimationL fl'>" +
					"<span class='fl sendGiftName'>" + ext + "</span>" +
					"<span class='fl'>送给主播</span>" +
					"<img class='fl' src='images/giftzhangtingban.png' alt='' />" +
					"<i class='fr'>X1</i>" +
					"</p>" +
					"</div>";
				$(".live_info").after(giftSendAlert);
				$(".sendGiftAnimationWrap").append(giftAnimation);
				$('.weChatScrollTop').scrollTop(0);
				/*打赏图像5秒消失*/
				$(".sendGiftAnimation").delay(5000).hide(0);
				break;
			case "1888": //财神爷
			    var giftSendAlert = 
				'<li>'+
					'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
					'<p class="chatName">'+ext+'</p>'+
					'<p class="chatTime">'+sendTimeMin+'</p>'+
					'<p class="giftContent">赠送了主播一个<span class="chatPresent"> “财神爷” </span></p>'+
					'<img class="whatGift" src="images/giftcaishenye.png" alt="" />'+
				'</li>';
				var giftAnimation = "<div class='sendGiftAnimation'>" +
					"<p class='sendGiftAnimationL fl'>" +
					"<span class='fl sendGiftName'>" + ext + "</span>" +
					"<span class='fl'>送给主播</span>" +
					"<img class='fl' src='images/giftcaishenye.png' alt='' />" +
					"<i class='fr'>X1</i>" +
					"</p>" +
					"</div>";
				$(".live_info").after(giftSendAlert);
				$(".sendGiftAnimationWrap").append(giftAnimation);
				$('.weChatScrollTop').scrollTop(0);
				/*打赏图像5秒消失*/
				$(".sendGiftAnimation").delay(5000).hide(0);
				break;
            case "8888"://金牛
               var giftSendAlert = 
				'<li>'+
					'<img class="chatImg" src="' + headerIMG + '" alt="" />'+
					'<p class="chatName">'+ext+'</p>'+
					'<p class="chatTime">'+sendTimeMin+'</p>'+
					'<p class="giftContent">赠送了主播一个<span class="chatPresent"> “金牛” </span></p>'+
					'<img class="whatGift" src="images/giftjinniu.png" alt="" />'+
				'</li>';
                var giftAnimation = "<div class='sendGiftAnimation'>" +
                    "<p class='sendGiftAnimationL fl'>" +
                    "<span class='fl sendGiftName'>" + ext + "</span>" +
                    "<span class='fl'>送给主播</span>" +
                    "<img class='fl' src='images/giftjinniu.png' alt='' />" +
                    "<i class='fr'>X1</i>" +
                    "</p>" +
                    "</div>";
                $(".live_info").after(giftSendAlert);
				$(".sendGiftAnimationWrap").append(giftAnimation);
				$('.weChatScrollTop').scrollTop(0);
				/*打赏图像5秒消失*/
				$(".sendGiftAnimation").delay(5000).hide(0);
                break;
			default:
				// console.log("没送礼物");
		}
	}
	return giftSendAlert;

}


//解析群提示消息元素
var text = "";

function convertGroupTipMsgToHtml(content) {
	console.log(content);
	var opType, opUserId, userIdList;
	opType = content.getOpType(); //群提示消息类型（操作类型）
	userIdList = content.getUserIdList(); //获取被操作的用户id列表
	//console.log(userIdList);
	switch(opType) {
		case webim.GROUP_TIP_TYPE.JOIN: //加入群
			var userIdListLen = userIdList.length;
			//console.log(userIdListLen);
			if(userIdListLen == 0 || userIdList == "" || userIdList == undefined || userIdList == null) {
				text = "游客";
			} else {
				var userListId = userIdList[0];
				var TagList = "Tag_Profile_IM_Nick";
				var To_AccountArr = [];
				var To_Account = userListId + "";
				var TagListArr = [];
				TagListArr.push(TagList);
				To_AccountArr.push(To_Account);
				var options = {
					"To_Account": To_AccountArr,
					"TagList": TagListArr
				};
				//	console.log(options);
				webim.getProfilePortrait(options,
					function(resp) {
						//console.log(resp);
						var UserProfile = resp.UserProfileItem;
						var To_Account = resp.UserProfileItem[0].To_Account;
						//console.log(To_Account);
						var len = To_Account.length;
						if(len != 18 && len != 19) {
							imNickName = UserProfile[0].ProfileItem[0].Value;
							var enterPersonList = "<p class='enterLiveRoomAlert'>" +
								"<span>欢迎</span>" + "<span class='enterLiveRoomName'>" + imNickName + "</span>" + "<span>来到直播间</span>" +
								"</p>"
							$(".chat_infotop").append(enterPersonList);
							var scrollTop1 = $(".chat_infotop").height();
							$(".chat_infotop").scrollTop(scrollTop1);
						}

					},
					function(err) {
						console.log(err);
					}
				);
			}

			//房间成员数加1
//			memberCount = $('.watchNum').html();
//			$('.watchNum').html(parseInt(memberCount) + 1);
			break;
		case webim.GROUP_TIP_TYPE.QUIT: //退出群
			//text += opUserId + "离开房间";
			//房间成员数减1
			//房间成员数减1
//			memberCount = parseInt($('.watchNum').html());
//			if(memberCount > 0) {
//				$('.watchNum').html(memberCount - 1);
//			}

			break;
		case webim.GROUP_TIP_TYPE.KICK: //踢出群
			text += opUserId + "将";
			userIdList = content.getUserIdList();
			for(var m in userIdList) {
				text += userIdList[m] + ",";
				if(userIdList.length > WEB_IM_GROUP_TIP_MAX_USER_COUNT && m == maxIndex) {
					text += "等" + userIdList.length + "人";
					break;
				}
			}
			text += "踢出该群";
			break;
		case webim.GROUP_TIP_TYPE.SET_ADMIN: //设置管理员
			text += opUserId + "将";
			userIdList = content.getUserIdList();
			for(var m in userIdList) {
				text += userIdList[m] + ",";
				if(userIdList.length > WEB_IM_GROUP_TIP_MAX_USER_COUNT && m == maxIndex) {
					text += "等" + userIdList.length + "人";
					break;
				}
			}
			text += "设为管理员";
			break;
		case webim.GROUP_TIP_TYPE.CANCEL_ADMIN: //取消管理员
			text += opUserId + "取消";
			userIdList = content.getUserIdList();
			for(var m in userIdList) {
				text += userIdList[m] + ",";
				if(userIdList.length > WEB_IM_GROUP_TIP_MAX_USER_COUNT && m == maxIndex) {
					text += "等" + userIdList.length + "人";
					break;
				}
			}
			text += "的管理员资格";
			break;

		case webim.GROUP_TIP_TYPE.MODIFY_GROUP_INFO: //群资料变更
			text += opUserId + "修改了群资料：";
			var groupInfoList = content.getGroupInfoList();
			var type, value;
			for(var m in groupInfoList) {
				type = groupInfoList[m].getType();
				value = groupInfoList[m].getValue();
				switch(type) {
					case webim.GROUP_TIP_MODIFY_GROUP_INFO_TYPE.FACE_URL:
						text += "群头像为" + value + "; ";
						break;
					case webim.GROUP_TIP_MODIFY_GROUP_INFO_TYPE.NAME:
						text += "群名称为" + value + "; ";
						break;
					case webim.GROUP_TIP_MODIFY_GROUP_INFO_TYPE.OWNER:
						text += "群主为" + value + "; ";
						break;
					case webim.GROUP_TIP_MODIFY_GROUP_INFO_TYPE.NOTIFICATION:
						text += "群公告为" + value + "; ";
						break;
					case webim.GROUP_TIP_MODIFY_GROUP_INFO_TYPE.INTRODUCTION:
						text += "群简介为" + value + "; ";
						break;
					default:
						text += "未知信息为:type=" + type + ",value=" + value + "; ";
						break;
				}
			}
			break;

		case webim.GROUP_TIP_TYPE.MODIFY_MEMBER_INFO: //群成员资料变更(禁言时间)
			text += opUserId + "修改了群成员资料:";
			var memberInfoList = content.getMemberInfoList();
			var userId, shutupTime;
			for(var m in memberInfoList) {
				userId = memberInfoList[m].getUserId();
				shutupTime = memberInfoList[m].getShutupTime();
				text += userId + ": ";
				if(shutupTime != null && shutupTime !== undefined) {
					if(shutupTime == 0) {
						text += "取消禁言; ";
					} else {
						text += "禁言" + shutupTime + "秒; ";
					}
				} else {
					text += " shutupTime为空";
				}
				if(memberInfoList.length > WEB_IM_GROUP_TIP_MAX_USER_COUNT && m == maxIndex) {
					text += "等" + memberInfoList.length + "人";
					break;
				}
			}
			break;
		default:
			text += "未知群提示消息类型：type=" + opType;
			break;
	}
	return text;
}

//显示一条群组系统消息
function addGroupSystemMsg(ReportType, reportTypeCh, GroupId, GroupName, content, timestamp) {
	var sysMsgStr = "收到一条群系统消息: type=" + timestamp + ", typeCh=" + reportTypeCh + ",群ID=" + GroupId + ", 群名称=" + GroupName + ", 内容=" + content + ", 时间=" + webim.Tool.formatTimeStamp(msg_time);
	webim.Log.warn(sysMsgStr);
	console.log(sysMsgStr);
}
/*发送消息*/
function onSendMsg(userId, userNickName, userSig, userNickHeadurl, usertoken, roomid) {
	//当前用户身份
	var loginInfo = {
		'sdkAppID': 1400018939, //用户所属应用id,必填
		'appIDAt3rd': 1400018939, //用户所属应用id，必填
		'accountType': 8454, //用户所属应用帐号类型，必填
		'identifier': userId, //当前用户ID，需要开发者填写
		'identifierNick': userNickName, //当前用户昵称，选填
		'userSig': userSig, //当前用户身份凭证，需要开发者填写
		'headurl': userNickHeadurl //当前用户默认头像，选填
	};
	var selSessHeadUrl = ''; //默认群组
	if(!selToID) {
		//layer.msg("你还没有选中好友或者群组，暂不能聊天");
		$("#sendMsg").val('');
		return;
	}
	var msgtosend;
	var communicationData
	var data = new Date();
	var time = data.getTime() + "";
	//获取回复消息内容
	var replayLogo = $("#sendMsg").attr("placeholder");
	if(replayLogo.indexOf("回复用户") != -1) { //是回复用户的话
		var replayNr = $("#sendMsg").attr("name");
		msgtosend = $("#sendMsg").val() + replayNr;
		if(chatRoomId){
		    sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, usertoken, '','');
		}
		var sendInfo = {
			"content": msgtosend,
			//			"itemType": 2,
			//			"media": "",
			//			"sendName": userNickName,
			//			"time": time,
			//			"type": 2,
		};
		communicationData = JSON.stringify(sendInfo); //保存交流回复的样式
	} else {
		//获取消息内容
		msgtosend = $("#sendMsg").val();
		var sendInfo = {
			"content": msgtosend,
			//			"itemType": 1,
			//			"media": "",
			//			"sendName": userNickName,
			//			"time": time,
			//			"type": 1,
		};
		communicationData = JSON.stringify(sendInfo); //保存交流回复的样式
	}
	var msgLen = webim.Tool.getStrBytes(msgtosend);

	if(msgtosend.length < 1) {
		layer.msg("发送的消息不能为空!");
		$("#sendMsg").val('');
		$("#sendMsg").attr("placeholder", "来说两句吧！");
		return;
	}
	var maxLen, errInfo;
	var selType = webim.SESSION_TYPE.GROUP;
	if(selType == webim.SESSION_TYPE.C2C) {
		maxLen = webim.MSG_MAX_LENGTH.C2C;
		errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
	} else {
		maxLen = webim.MSG_MAX_LENGTH.GROUP;
		errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
	}
	if(msgLen > maxLen) {
		layer.msg(errInfo);
		return;
	}
	if(!selSess) {
		var selSess = new webim.Session(selType, selToID, selToID, selSessHeadUrl, Math.round(new Date().getTime() / 1000));
	}
	var isSend = true; //是否为自己发送
	var seq = -1; //消息序列，-1表示sdk自动生成，用于去重
	var random = Math.round(Math.random() * 4294967296); //消息随机数，用于去重
	var msgTime = Math.round(new Date().getTime() / 1000); //消息时间戳
	var subType; //消息子类型
	if(selType == webim.SESSION_TYPE.C2C) {
		subType = webim.C2C_MSG_SUB_TYPE.COMMON;
	} else {
		//webim.GROUP_MSG_SUB_TYPE.COMMON-普通消息,
		//webim.GROUP_MSG_SUB_TYPE.LOVEMSG-点赞消息，优先级最低
		//webim.GROUP_MSG_SUB_TYPE.TIP-提示消息(不支持发送，用于区分群消息子类型)，
		//webim.GROUP_MSG_SUB_TYPE.REDPACKET-红包消息，优先级最高
		subType = webim.GROUP_MSG_SUB_TYPE.COMMON;
	}
	var msg = new webim.Msg(selSess, isSend, seq, random, msgTime, loginInfo.identifier, subType, loginInfo.identifierNick);

	var text_obj, face_obj, tmsg, emotionIndex, emotion, restMsgIndex;
	//解析文本和表情
	var expr = /\[[^[\]]{1,3}\]/mg;
	var emotions = msgtosend.match(expr);
	if(!emotions || emotions.length < 1) {
		text_obj = new webim.Msg.Elem.Text(msgtosend);
		msg.addText(text_obj);
	} else {

		for(var i = 0; i < emotions.length; i++) {
			tmsg = msgtosend.substring(0, msgtosend.indexOf(emotions[i]));
			if(tmsg) {
				text_obj = new webim.Msg.Elem.Text(tmsg);
				msg.addText(text_obj);
			}
			emotionIndex = webim.EmotionDataIndexs[emotions[i]];
			emotion = webim.Emotions[emotionIndex];

			if(emotion) {
				face_obj = new webim.Msg.Elem.Face(emotionIndex, emotions[i]);
				msg.addFace(face_obj);
			} else {
				text_obj = new webim.Msg.Elem.Text(emotions[i]);
				msg.addText(text_obj);
			}
			restMsgIndex = msgtosend.indexOf(emotions[i]) + emotions[i].length;
			msgtosend = msgtosend.substring(restMsgIndex);
		}
		if(msgtosend) {
			text_obj = new webim.Msg.Elem.Text(msgtosend);
			msg.addText(text_obj);
		}
	}

	webim.sendMsg(msg, function(resp) {
		if(selType == webim.SESSION_TYPE.C2C) { //私聊时，在聊天窗口手动添加一条发的消息，群聊时，长轮询接口会返回自己发的消息
			addMsg(msg);
		}
		webim.Tool.setCookie("tmpmsg_" + selToID, '', 0);
		$("#sendMsg").val('');
		$("#sendMsg").attr("placeholder", "来说两句吧！");
		//发送成功后台记录信息
		//saveMsg(userId, usertoken, roomid, communicationData, 1, 2);

	}, function(err) {
		layer.msg(err.ErrorInfo);
		$("#sendMsg").val('');
		$("#sendMsg").attr("placeholder", "来说两句吧！");
	});
}
//发送自定义消息
function sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid,giftBox) {
	//当前用户身份
	var loginInfo = {
		'sdkAppID': 1400018939, //用户所属应用id,必填
		'appIDAt3rd': 1400018939, //用户所属应用id，必填
		'accountType': 8454, //用户所属应用帐号类型，必填
		'identifier': userId, //当前用户ID，需要开发者填写
		'identifierNick': userNickName, //当前用户昵称，选填
		'userSig': userSig, //当前用户身份凭证，需要开发者填写
		'headurl': userNickHeadurl //当前用户默认头像，选填
	};
	if(!selToID) {
		layer.msg("您还没有好友或群组，暂不能聊天");
		return;
	}
	//获取回复消息内容
	var replayLogo = $("#sendMsg").attr("placeholder");
	if(replayLogo.indexOf("回复用户") != -1) { //是回复用户的话
		var replayNr = $("#sendMsg").attr("name");
		var msgtosend = $("#sendMsg").val() + replayNr;
		var data = new Date();
		var time = data.getTime() + "";
		var sendInfo = {
			"content": msgtosend,
			"itemType": 2,
			"media": "",
			"sendName": userNickName,
			"time": time,
			"type": 2,
		};
		var data = JSON.stringify(sendInfo);
		var desc = "pic_live";
		var ext = userNickName;
		var msgLen = webim.Tool.getStrBytes(data);

		if(data.length < 1) {
			layer.msg("发送的消息不能为空!");
			return;
		}
		var maxLen, errInfo;
		var selType = webim.SESSION_TYPE.GROUP;
		if(selType == webim.SESSION_TYPE.C2C) {
			maxLen = webim.MSG_MAX_LENGTH.C2C;
			errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
		} else {
			maxLen = webim.MSG_MAX_LENGTH.GROUP;
			errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
		}
		if(msgLen > maxLen) {
			layer.msg(errInfo);
			return;
		}

		if(!selSess) {
			selSess = new webim.Session(selType, selToID, selToID, userNickHeadurl, Math.round(new Date().getTime() / 1000));
		}
		var msg = new webim.Msg(selSess, true, -1, -1, -1, loginInfo.identifier, 0, loginInfo.identifierNick);
		var custom_obj = new webim.Msg.Elem.Custom(data, desc, ext);
		msg.addCustom(custom_obj);
		//调用发送消息接口
		webim.sendMsg(msg, function(resp) {
			//saveMsg(userId, usertoken, roomid, data, 1, 1);
			if(selType == webim.SESSION_TYPE.C2C) { //私聊时，在聊天窗口手动添加一条发的消息，群聊时，长轮询接口会返回自己发的消息
				addMsg(msg);
				//后台记录发送的消息
			}
		}, function(err) {
			layer.msg(err.ErrorInfo);
		});
	}
	
	//发送打赏
	if(giftBox){
		var data = $("#giftPrice" +giftBox).html();
		//console.log(data);
	    var desc = "givemoney2_zhubo";
	    var ext = userNickName;
	     var msgLen = webim.Tool.getStrBytes(data);
	    if (data.length < 1) {
	        //alert("发送的消息不能为空!");
	        return;
	    }
	    var maxLen, errInfo;
	    var selType = webim.SESSION_TYPE.GROUP;
	    if (selType == webim.SESSION_TYPE.C2C) {
	        maxLen = webim.MSG_MAX_LENGTH.C2C;
	        errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
	    } else {
	        maxLen = webim.MSG_MAX_LENGTH.GROUP;
	        errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
	    }
	    if (msgLen > maxLen) {
	        //alert(errInfo);
	        return;
	    }
	
	    if (!selSess) {
	        selSess = new webim.Session(selType, selToID, selToID, userNickHeadurl, Math.round(new Date().getTime() / 1000));
	    }
	    var msg = new webim.Msg(selSess, true,-1,-1,-1,loginInfo.identifier,0,loginInfo.identifierNick);
	    var custom_obj = new webim.Msg.Elem.Custom(data, desc, ext);
	    msg.addCustom(custom_obj);
	    //调用发送消息接口
	    webim.sendMsg(msg, function (resp) {
	    	//console.log(msg);
	        if(selType==webim.SESSION_TYPE.C2C){//私聊时，在聊天窗口手动添加一条发的消息，群聊时，长轮询接口会返回自己发的消息
	            addMsg(msg);
	        }
	       
	    }, function (err) {
	        //console.log(err.ErrorInfo);
	    });
		
	}
	
}	
	


//记录历史信息
//type：直播间类型{1=普通直播间；2=vip直播间}
//msgType：消息类型{1=直播间主播发言；2=交流用户发言}
//function saveMsg(uid, token, liveRoomId, content, type, msgType) {
//	$.ajax({
//		type: "post",
//		async: true,
//		dataType: "json",
//		url: "/m/v5.0/api/v3/liveRoomMsg/saveMsg.do",
//		data: {
//			"uid": uid,
//			"token": token,
//			"liveRoomId": liveRoomId,
//			"content": content,
//			"type": type,
//			"msgType": msgType,
//		},
//		success: function(res) {
//			if(res.code == 0) {
//				//console.log(res);
//			}
//		},
//		error: function(XMLHttpRequest, textStatus, errorThrown) {
//			console.log(XMLHttpRequest.status);
//			console.log(XMLHttpRequest.readyState);
//			console.log(textStatus);
//		},
//	})
//
//}


function sc() {
	var e = document.getElementsByClassName("weChatScrollTop")[0];
	//console.log(e.scrollHeight);
	e.scrollTop == e.scrollHeight;
	//console.log(e.scrollTop);
}