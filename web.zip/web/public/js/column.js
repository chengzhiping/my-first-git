$(document).ready(function () {
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");

    //APP下载二维码
    $(".saoma").mouseenter(function() {
        $(".indexCode").fadeIn(200);
    });
    $(".saoma").mouseleave(function() {
        $(".indexCode").fadeOut(200);
    });

    /*回到顶部*/
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn()
        } else {
            $(".goTop").stop().fadeOut()
        }
    });
    $(".goTop").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 800)
    });

    //固定右侧
    $(window).scroll(function() {
        var fixedRightTop = $(this).scrollTop();
        //	console.log(fixedRightTop);
        if(fixedRightTop>=905){
            $("#fixedRight").css({
                "position":"fixed",
                "top":"30px",
                "width":"338px",
            });
        }else{
            $("#fixedRight").css({
                "position":"",
                "margin-left":0,
            })
        }
    });
    /*//编辑精选
    $.ajax({
        type: "GET",
        async: true,
        dataType: "json",
        url: "/api/v2/discovery/getDiscoveryByType.do",
        data: {
            "type":2,
            "pageIndex": 1,
            "pageSize": 1,
        },
        success: function (res) {
            if (res.code == 0) {
                //console.log(res);
                if(res.data.length==0){//缺省
                    $(".editor").stop().hide();
                }
                var coverUrl=res.data[0].discoveryObject.coverUrl;
                var title=res.data[0].discoveryObject.title;
                var objectId=res.data[0].objectId;
                var uid=res.data[0].discoveryObject.uid;
                var objectType=res.data[0].objectType;
                //console.log(objectType);
                var editorInner="<img uid="+uid+" objectId="+objectId+"  type="+objectType+" id='editorInnerImg' src='"+coverUrl+"' />"+
                                "<p>"+title+"</p>";
                $(".editor").append(editorInner);
            }
            $(".editor img").each(function () {
                var type=$(this).attr("type");
                var uid=$(this).attr("uid");
                var id=$(this).attr("id");
                $(this).click(function () {
                    if(type==3){//直播
                        window.location.href="/live?uid="+uid;
                    }else if(type==2){//视频
                        window.location.href="/video?id="+id;
                    }else if(type==1){//文章
                        window.location.href="/article?id="+id;
                    }
                })
            })
        }
    })*/
    //专栏发现
    var dataList = [];
    $.ajax({
        type: "GET",
        async: true,
        dataType: "json",
        url: "/api/v2/video/getRecColumnList.do",
        data: {
            "pageIndex": 1,
            "pageSize":3,
        },
        success: function (res) {
            if (res.code == 0) {
                // console.log(res);
                $(res.data).each(function(i,k) {
                    var id=k.id;
                    //获取专栏内容
                    $.ajax({
                        type: "GET",
                        async: true,
                        dataType: "json",
                        url: "/api/v2/column/getColumnContent.do",
                        data: {
                            "columnId": id,
                            "pageIndex":1,
                            "pageSize":1,
                        },
                        success: function (res) {
                            if (res.code == 0) {
                                // console.log(res);
                                var length = res.data.length;
                                var coverUrl = res.data[0].information.coverUrl;
                                var topic = res.data[0].information.topic;
                                var nickName = res.data[0].information.liverInfo.nickName;
                                var columnName = res.data[0].information.columnName;
                                var id=res.data[0].information.id;
                                var columnFindInner = "<li>" +
                                                    "<div class='columnFindImgBox'>"+
                                                    "<img class='columnFindImg' src='"+coverUrl+"' kid='"+id+"' alt=''>" +
                                                    "</div>"+
                                                    "<div class='columnFindText'>" +
                                                    "<p class='title' kid='"+id+"'>"+topic+"</p>" +
                                                    "<p class='name'>"+nickName+"</p>" +
                                                    "<p class='from'>发表于"+columnName+"</p>" +
                                                    "</div>" +
                                                    "</li>";
                                $(".columnFind ul").append(columnFindInner);
                                $(".columnFindImg").each(function () {
                                    var id=$(this).attr("kid");
                                    $(this).on("click",function(){
                                        window.location.href="/video?id="+id;
                                    })
                                })
                                $(".columnLeft .columnFind ul li .title").each(function () {
                                    var id=$(this).attr("kid");
                                    $(this).on("click",function(){
                                        window.location.href="/video?id="+id;
                                    })
                                })
                            }
                        }
                    })
                })
            }
        }
    });

    //专栏推荐
    var pageIndex=1;
    function recommendList(pageIndex) {
        $.ajax({
            type: "GET",
            async: true,
            dataType: "json",
            url: "/api/v2/column/getColumnList.do",
            data: {
                "pageIndex": pageIndex,
                "pageSize": 10,
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    var length=res.data.columns.length;
                    if(res.data.columns=="" && pageIndex==1){
                        $(".quesheng").stop().show();
                        $(".loading").stop().hide();
                    }
                    if(length<10){
                        $(".loading").stop().hide();
                        $(".loadEnd").stop().show();
                    }
                    $(res.data.columns).each(function (i, k) {
                        var coverUrl=k.coverUrl;
                        var headImgUrl=k.liverInfo.headImgUrl;
                        var nickName=k.liverInfo.nickName;
                        var uid=k.liverInfo.uid;
                        var  id=k.id;
                        var name=k.name;
                        var description=k.description;//内容最新主题
                        var introduction=k.introduction;//专栏描述
                        var recommendInner ="<li>"+
                            "<div class='columnImg' id='"+id+"'>"+
                            "<img src='"+coverUrl+"!158X212' alt=''>"+
                            "</div>"+
                            "<div class='introduce'>"+
                            "<p class='name' id='"+id+"'>"+name+"</p>"+
                            "<h1 class='userInfo'>"+
                            "<span class='by'>BY:</span>"+
                            "<img uid='"+uid+"' class='headImgUrl' src='"+headImgUrl+"' alt=''>"+
                            "<span class='from'>"+nickName+"</span>"+
                            "</h1>"+
                            "<p class='content'>"+introduction+"</p>"+
                            "<h2 class='update'><button>更新</button>"+description+"</h2>"+
                            "</div>"+
                            "</li>";
                        $(".recommend ul").append(recommendInner);
                    })
                    $(".headImgUrl").one("error", function(e) {
                        $(this).attr("src", "images/anchorHead.png");
                    });
                    $(".columnImg").each(function(){
                        $(this).on("click",function () {
                            var id=$(this).attr("id");
                            window.location.href="/columnDetail?id="+id;
                        })
                    })
                    $(".recommend ul li .introduce .name").each(function(){
                        $(this).on("click",function () {
                            var id=$(this).attr("id");
                            //console.log(id);
                            window.location.href="/columnDetail?id="+id;
                        })
                    })
                    $(".recommend ul li .introduce img").each(function(){
                        $(this).on("click",function () {
                            var uid=$(this).attr("uid");
                            window.location.href="/userProfile?uid="+uid;
                        })
                    })
                }
            }
        })
    }
    recommendList(1);
    //下拉加载更多
    $(window).on('scroll', function () {
        if($(document).scrollTop() + $(window).height() >= $(document).height()){
            pageIndex++;
            recommendList(pageIndex);
        }
    });

    //获取热门更新专栏
    $.ajax({
        type: "GET",
        async: true,
        dataType: "json",
        url: "/api/v2/column/getNewContent.do",
        success: function (res) {
            if (res.code == 0) {
                //console.log(res);
                if(res.data.length==0){//缺省
                    $(".popular").stop().hide();
                }
                for(var i=0;i<3;i++){
                    var type=res.data[i].type;
                    var headImgUrl=res.data[i].information.liverInfo.headImgUrl;
                   // console.log(headImgUrl);
                    var columnName=res.data[i].information.columnName;
                    var uid=res.data[i].information.liverInfo.uid;
                    var topic=res.data[i].information.topic;
                    var title=res.data[i].information.title;
                    var id=res.data[i].information.id;
                    var createTime=res.data[i].information.createTime;
                    if(type==0){//直播
                        var popularInner ="<li type="+type+" kid="+id+" uid="+uid+">"+
                            "<div class='headerImg'><img src='"+headImgUrl+"'></div>"+
                            "<div class='updateInfo'>"+
                            "<h3>"+topic+"</h3>"+
                            "<p><i>#专栏</i><span>"+columnName+"</span></p>"+
                            "<p class='updateInfoTime' >"+format(new Date(createTime))+"</p>"+
                            "</div>"
                        "</li>";
                        $(".popular ul").append(popularInner);
                        $(".headImgUrl").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        });
                    }else if(type==1){//视频
                        var popularInner ="<li type="+type+" kid="+id+">"+
                            "<div class='headerImg'><img src='"+headImgUrl+"'></div>"+
                            "<div class='updateInfo'>"+
                            "<h3>"+topic+"</h3>"+
                            "<p><i>#专栏</i><span>"+columnName+"</span></p>"+
                            "<p class='updateInfoTime'>"+format(new Date(createTime))+"</p>"+
                            "</div>"
                        "</li>";
                        $(".popular ul").append(popularInner);
                        $(".headImgUrl").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        });
                    }else if(type==2){//文章
                        var popularInner ="<li type="+type+" kid="+id+">"+
                            "<div class='headerImg'><img src='"+headImgUrl+"'></div>"+
                            "<div class='updateInfo'>"+
                            "<h3>"+title+"</h3>"+
                            "<p><i>#专栏</i><span>"+columnName+"</span></p>"+
                            "<p class='updateInfoTime'>"+format(new Date(createTime))+"</p>"+
                            "</div>"
                        "</li>";
                        $(".popular ul").append(popularInner);
                        $(".headImgUrl").one("error", function(e) {
                            $(this).attr("src", "images/anchorHead.png");
                        });
                    }
                }
                $(".popular ul li").each(function () {
                    var uid=$(this).attr("uid");
                    var id=$(this).attr("kid");
                    var type=$(this).attr("type");
                    $(this).click(function () {
                        if(type==0){//直播
                            window.location.href="/live?uid="+uid;
                        }else if(type==1){//视频
                            window.location.href="/video?id="+id;
                        }else if(type==2){//文章
                            window.location.href="/article?id="+id;
                        }
                    })
                })
                $(".columnRight .popular ul li .updateInfo h3").each(function () {
                    var length=$(this).text().length;
                    if(length<=12){
                        $(this).css("height","25px");
                    }
                })
                $(".columnRight .popular ul li:last .updateInfo").css("border","none");
                $(".headerImg img").one("error", function(e) {
                    $(this).attr("src", "images/anchorHead.png");
                });
            }
        }
    })

    // banner跳转
    function bannerDump(obj) {
        $(obj).on("click",function () {
            var type=$(this).attr("type");
            var id=$(this).attr("objectId");
            var uid=$(this).attr("uid");
            if(type==1){//文章
                window.location.href ="/artice?id="+id;
            }else if(type==2){//短评

            }else if(type==3){//视频或回放
                window.location.href ="/video?id="+id;
            }else if(type==4){//直播
                window.location.href ="/live?uid="+uid;
            }else if(type==5){//静态页面
                window.location.href =id;
            }else if(type==6){//个人主播页
                window.location.href ="/userProfile?uid="+uid;
            }else if(type==7){//不跳转
                //window.location.href ="http://www.baidu.com";
            }else if(type==8){//操盘手个人页
                // window.location.href ="/userProfile?uid="+uid;
            }else if(type==9){//个人实盘页
                window.location.href ="/userProfile?uid="+uid;
            }else if(type==10){//话题
                window.location.href ="/topicDetails?id="+id;
            }else if(type==11){//专栏详情页
                window.location.href ="/columnDetail?id="+id;
            }
        })
    }

})