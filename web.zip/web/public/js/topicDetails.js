var topicDetailsApp = angular.module("topicDetailsApp",['appServices','ngSanitize']);
var userInfo;
topicDetailsApp.controller('topicDetailsCtrl',['$scope','$rootScope','$location','apiFun',function ($scope,$rootScope,$location,apiFun) {

    var getQueryStringId = GetQueryString("id");
    // var getQueryStringId = 'ada592d4-f699-433d-8e89-0f491f2bc7bb';
    var topicUid;
    var userId;
    var userToken;
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");
    //APP下载二维码
    $(".saoma").mouseenter(function() {
        $(".indexCode").fadeIn(200);
    });
    $(".saoma").mouseleave(function() {
        $(".indexCode").fadeOut(200);
    });

    //发布内容按钮鼠标经过
    $(".releaseBtn").mouseover(function(){
        $(".releaseBtn img").attr("src","images/releaseiconB.png")
    });
    $(".releaseBtn").mouseout(function(){
        $(".releaseBtn img").attr("src","images/releaseicon.png")
    });
    //回答鼠标经过
    $scope.answerBtnO = function (i) {
        $('.answerhover'+i).attr("src","images/releaseiconB.png")
    };
    $scope.answerBtnL = function (i) {
        $('.answerhover'+i).attr("src","images/releaseicon.png")
    };

    //充值弹框
    $(".money_listinfo").click(function() {
        $(this).addClass("click_effect").siblings().removeClass("click_effect")
    });
    /*关闭框*/
    $(".alertClose").click(function() {
        $("#n_money").stop().hide();
        $("#exceptWrap").stop().hide();
        clearInterval(intervalTime)
    });
    $(".weChatClose").click(function() {
        $(".weChatCodeWrap").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatSuccessClose").click(function() {
        $(".weChatPaySuccess").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatOweWrapClose").click(function() {
        $(".weChatOweWrap").css("display", "none");
        $("#exceptWrap").stop().hide();
    });
    $(".wechat_pay").click(function() {
        $(".wechatI").show();
        $(".alipayI").hide()
    });
    $(".alipay").click(function() {
        $(".wechatI").hide();
        $(".alipayI").show()
    });

    //话题详情
    $scope.selectDiscuss = function () {
        $scope.selectDiscussParams = {};
        $scope.selectDiscussParams.id = getQueryStringId;
        var promisess = apiFun.selectDiscussFun($scope.selectDiscussParams);
        promisess.then(function(res) {
            // console.log(res);
            if(res.code == 0){
                $scope.topicData = res.data;
                topicUid = $scope.topicData.uid;
                var url = window.location.href;
                var title = $scope.topicData.title;
                var shareImg;
                var reg = /<img[^>]*src[=\'\"\s]+([^\"\']*)[\"\']?[^>]*>/gi;
                if (reg.exec(htmlEncode($scope.topicData.content)))
                {
                    shareImg = RegExp.$1;
                }else {
                    shareImg = 'http://picture.fengniutv.com/fntvlogoshare.png';
                };
                //分享
                var description =  $scope.topicData.userInfo.nickName + ':'+htmlEncode($scope.topicData.content);
                shareFun(url, title,description, shareImg);
            }
        });
    };
    $scope.selectDiscuss();

    //精选回答
    $scope.homePagekindFun = function (uid) {
        var promisess = apiFun.kindFun(11,3);
        promisess.then(function(res) {
            // console.log(res);
            if(res.code == 0){
                $scope.suggestList = res.data;
                $.each($scope.suggestList, function(i) {
                    $scope.selectAgreeCount2 = function () {
                        $scope.selectAgree = {};
                        $scope.selectAgree.uid = uid;
                        $scope.selectAgree.agreeType = 1;
                        $scope.selectAgree.objectId = $scope.suggestList[i].comment.id;
                        var promisess = apiFun.selectAgreeCountFun($scope.selectAgree);
                        promisess.then(function (result) {
                            if (result.code == 0) {
                                $scope.suggestList[i].agreeCountNum = result.data;
                            }
                        });
                    };
                    $scope.selectAgreeCount2();
                });
                // console.log($scope.suggestList);
            }
        });
    };
    $scope.homePagekindFun();


    //获取话题回答列表，回答评论列表
    $scope.topicReply = [];
    var topicCommentIndex = 1;
    function TopicCommentFun2(uid) {
        $scope.TopicComment = {};
        $scope.TopicComment.objectId = getQueryStringId;
        $scope.TopicComment.pageIndex = topicCommentIndex;
        $scope.TopicComment.pageSize = 5;
        $scope.TopicComment.uid = uid;
        $('.loading').stop().show();
        $scope.ifLoading = false; //判断是否正在读取内容的变量
        if (!$scope.loading) { //如果页面没有正在读取
            $scope.ifLoading = true; //告知正在读取
            var promisess = apiFun.getTopicCommentListFun3($scope.TopicComment);
            promisess.then(function(res) {
                $('.loading').stop().hide();
                $scope.topicCommentListdata = res.data;
                $scope.noMore = res.data.length;
                if(res.code == 0){
                    for (var i = 0; i <= res.data.length - 1; i++) {
                        $scope.topicReply.push(res.data[i]);
                        // console.log($scope.topicReply);
                    }
                }
            });
            topicCommentIndex ++;
        }
    };


    //web获取等我来答
    $scope.selectAnswerFun = function () {
        var promisess = apiFun.selectAnswerDiscussFun();
        promisess.then(function(res) {
            // console.log(res);
            $scope.selectAnswer = res.data;
        });
    };
    $scope.selectAnswerFun();


    //发表评论富文本框
    var summer = $('#summernote').summernote({
        minHeight: 150,
        lang:'zh-CN',
        placeholder: '说说你的回答...',
        focus: true
    });
    $.ajax({
        type:"get",
        url:"/userInfos",
        success:function (data) {
            var editer = document.getElementById('summernote');
            editer.focus();
            var userData = data;
            if(data.code ==0){
                $scope.selectDiscuss2 = function () {
                    $scope.selectDiscussParams2 = {};
                    $scope.selectDiscussParams2.id = getQueryStringId;
                    $scope.selectDiscussParams2.uid = userData.data.userInfo.uid;
                    topicUid = userData.data.userInfo.uid;
                    userId = userData.data.userInfo.uid;
                    var promisess = apiFun.selectDiscussFun2($scope.selectDiscussParams2);
                    promisess.then(function(res) {
                        // console.log(res);
                        if(res.code == 0){
                            $scope.topicData = res.data;
                            if ($scope.topicData.isAnswer === true){
                                $('.textarea').click(function (event) {
                                    layer.msg('你已回答过此话题');
                                    event.preventDefault();
                                });
                                $("#submitEditor").click(function () {
                                    layer.msg('你已回答过此话题');
                                })
                            }else {
                                $.ajax({
                                    type: "get", //请求方式
                                    url: "/api/v1/picture/batchUpload/token.do",
                                    data: {
                                        "uid": userData.data.userInfo.uid,
                                        "token": userData.data.token
                                    },
                                    success: function(res) {
                                        // console.log(res);
                                        if(res.code == 0) {
                                            var imgdomain = 'picture.91qiniu.com';//内网
                                            // var imgdomain = 'picture.fengniutv.com';//外网
                                            var articleimgtoken = res.data.uploadToken;
                                            var uploader = Qiniu.uploader({
                                                runtimes: 'html5,flash,html4', //上传模式,依次退化
                                                browse_button: 'imguploadBtn', //上传选择的点选按钮，**必需**
                                                // uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                                                uptoken: articleimgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                                                // uptoken_func: function(file) {},
                                                unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                                                save_key: false, // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                                                domain: 'picture.91qiniu.com', //bucket域名，下载资源时用到，**必需**
                                                get_new_uptoken: true, //设置上传文件的时候是否每次都重新获取新的token
                                                // container: 'customized-buttonpane', //上传区域DOM ID，默认是browser_button的父元素，
                                                max_file_size: '2mb', //最大文件体积限制
                                                flash_swf_url: 'js/Moxie.swf', //引入flash,相对路径
                                                max_retries: 3, //上传失败最大重试次数
                                                // dragdrop: false, //开启可拖曳上传
                                                // drop_element: 'customized-buttonpane', //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                                                chunk_size: '1mb', //分块上传时，每片的体积
                                                auto_start: true, //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                                                init: {
                                                    'FilesAdded': function(up, files) {
                                                        // plupload.each(files, function(file) {
                                                        //    // 文件添加进队列后,处理相关的事情
                                                        // });
                                                    },
                                                    'BeforeUpload': function(up, file) {
                                                        // 每个文件上传前,处理相关的事情
                                                    },
                                                    'UploadProgress': function(up, file) {
                                                        // 每个文件上传时,处理相关的事情
                                                    },
                                                    'FileUploaded': function(up, file, info) {
                                                        var imgInfo = JSON.parse(info);
                                                        var imgUrl = "http://"+imgdomain+"/" + imgInfo.key;
                                                        document.execCommand('InsertImage', false, imgUrl);
                                                    },
                                                    'Error': function(up, err, errTip) {
                                                        console.log(errTip);
                                                    },
                                                    'UploadComplete': function() {},
                                                },
                                            });
                                        }
                                    }
                                });
                                $("#submitEditor").click(function () {
                                    var html = summer.summernote('code');
                                    var textEditor = removeHTMLTag2(html);
                                    if(textEditor.length <= 0 && html.indexOf('img') < 0 ){
                                        layer.msg('回答不能为空！');
                                    }else{
                                        $scope.commentInsert = {};
                                        $scope.commentInsert.uid = userData.data.userInfo.uid;
                                        $scope.commentInsert.token = userData.data.token;
                                        $scope.commentInsert.comment = html;
                                        $scope.commentInsert.objectId = getQueryStringId;
                                        $scope.commentInsert.parentId = '';
                                        $scope.commentInsert.type = 1;
                                        var promisess = apiFun.commentInsertFun($scope.commentInsert);
                                        promisess.then(function(result) {
                                            if(result.code ==0){
                                                $scope.topicData.answerCount++;
                                                layer.msg('评论成功！');
                                                $scope.topicReply = [];
                                                topicCommentIndex = 1;
                                                TopicCommentFun2(userId);
                                                summer.summernote('code','');
                                            }else if(result.code ==-802){
                                                layer.msg('你已回答过此话题！');
                                            }
                                        })
                                    }
                                });
                            }
                        }
                    });
                };
                $scope.selectDiscuss2();
            }else{
                $(".textarea").click(function (event) {
                    event.preventDefault();
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
            }
        }
    });

    /*var summer = $('#summernote').summernote({
        minHeight: 150,
        lang:'zh-CN',
        placeholder: '说说你的回答...',
        focus: true,
        /!*callbacks: {
            onPaste: function (ne) {
                var bufferText = ((ne.originalEvent || ne).clipboardData || window.clipboardData).getData('Text/plain');
                //    ne.preventDefault();
                ne.preventDefault ? ne.preventDefault() : (ne.returnValue = false);
                // Firefox fix
                setTimeout(function () {
                    document.execCommand("insertText", false, bufferText);
                }, 10);
            }
        }*!/
    });

    //一键排版
    $(document).ready(function () {
        $("#paiban").click(function () {
            $('#summernote').summernote('focus');//设置焦点
            // $('#summernote').summernote('removeFormat');//清除样式
            // $('#summernote').summernote('indent');//缩进
            // $('#summernote').summernote('outdent');//凸排
            // $('#summernote').summernote('justifyLeft');//左对齐
            // document.execCommand("InsertOrderedList","false",null);
            // document.execCommand("justifyLeft","false",null);//左对齐
            // document.execCommand("Unselect","false",null);//取消选中状态
            document.execCommand("RemoveFormat",false,null);//删除文字格式
            document.execCommand("FormatBlock",false,null);//设置当前块格式化标签
            document.execCommand("SelectAll",false,null);//选中整个文档
            document.execCommand("Unselect",false,null);//清除当前选中区的选中状态


        });
    });*/



    //获取用户信息    ------检查是否登录
    $scope.userInfoFun = function () {
        var promisess = apiFun.getUserInfoFun();
        promisess.then(function(res) {
            // console.log(res);
            if(res.code == 0){
                $scope.userData = res.data;
                // console.log(userId);
                $scope.homePagekindFun(userId);
                userToken = $scope.userData.token;
                $(".weChatErrorEnter").click(function(){
                    payFun(userId, userToken);
                })

                //收藏图标
                $scope.collectingClick = function (index,id,collection) {
                    $scope.agreeApi = {};
                    $scope.agreeApi.objectId = id;
                    $scope.agreeApi.uid = res.data.userInfo.uid;
                    $scope.agreeApi.agreeType = 2;
                    var promisess = apiFun.selectAgreeCountFun($scope.agreeApi);
                    promisess.then(function(result) {
                        // console.log(result);
                        if(res.code == 0){
                            if(result.data.isAgree==true){
                                //取消收藏
                                $scope.delLike = {};
                                $scope.delLike.uid = userId;
                                $scope.delLike.token = userToken;
                                $scope.delLike.objectId = id;
                                $scope.delLike.agreeType = 2;
                                var promisess = apiFun.deleteAgreeFun($scope.delLike);
                                promisess.then(function(res) {
                                        if(res.code == 0){
                                            // console.log(res);
                                            $("#collectingImg"+index).attr("src","../images/collecting.png");
                                            // $("#collectingImg"+index).parent(".clickColor").css("color","#a9a9a9");
                                            $("#collectingImg"+index).siblings(".collectionText").text('收藏').css("color","#a9a9a9");
                                        }
                                    });
                            }else if(result.data.isAgree==false){
                                //收藏
                                $scope.insertAgree = {};
                                $scope.insertAgree.uid = userId;
                                $scope.insertAgree.type = 4;
                                $scope.insertAgree.objectId = id;
                                $scope.insertAgree.agreeType = 2;
                                $scope.insertAgree.token = userToken;
                                var promisess = apiFun.insertAgreeFun($scope.insertAgree);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        // console.log(res);
                                        $("#collectingImg"+index).attr("src","../images/collectingP.png");
                                        // $("#collectingImg"+index).parent(".clickColor").css("color","#fe4502");
                                        $("#collectingImg"+index).siblings(".collectionText").text('已收藏').css("color","#fe4502");
                                    }
                                });
                            }
                        }
                    });
                };

                //点赞图标
                $scope.praiseClick = function (id,agreeCount,agree) {
                    $scope.agreeApi2 = {};
                    $scope.agreeApi2.objectId = id;
                    $scope.agreeApi2.uid = userId;
                    $scope.agreeApi2.agreeType = 1;
                    var promisess = apiFun.selectAgreeCountFun($scope.agreeApi2);
                    promisess.then(function(result) {
                        // console.log(result);
                        if(res.code == 0){
                            if(result.data.isAgree==true){
                                //取消点赞
                                $scope.delLike = {};
                                $scope.delLike.uid = userId;
                                $scope.delLike.token = userToken;
                                $scope.delLike.objectId = id;
                                $scope.delLike.agreeType = 1;
                                var promisess = apiFun.deleteAgreeFun($scope.delLike);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        // console.log(res);
                                        document.getElementsByClassName(id)[0].src = "../images/rewardIcon.png";
                                        document.getElementById(id).innerHTML = result.data.agreeCount-1;
                                        document.getElementById(id).style.color = '#a9a9a9';
                                    }
                                });
                            }else if(result.data.isAgree==false){
                                //点赞
                                $scope.insertAgree = {};
                                $scope.insertAgree.uid = $scope.userData.userInfo.uid;
                                $scope.insertAgree.type = 4;
                                $scope.insertAgree.objectId = id;
                                $scope.insertAgree.agreeType = 1;
                                $scope.insertAgree.token = $scope.userData.token;
                                var promisess = apiFun.insertAgreeFun($scope.insertAgree);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        // console.log(res);
                                        document.getElementsByClassName(id)[0].src = "../images/rewardP.png";
                                        document.getElementById(id).innerHTML = result.data.agreeCount+1;
                                        document.getElementById(id).style.color = '#fe4502';
                                    }
                                });
                            }
                        }
                    });
                };

                //精选回答点赞图标
                $scope.suggestClick = function (index,id) {
                    $scope.agreeApi3 = {};
                    $scope.agreeApi3.objectId = id;
                    $scope.agreeApi3.uid = userId;
                    $scope.agreeApi3.agreeType = 1;
                    var promisess = apiFun.selectAgreeCountFun($scope.agreeApi3);
                    promisess.then(function(result) {
                        // console.log(result);
                        if(res.code == 0){
                            if(result.data.isAgree==true){
                                //取消点赞
                                $scope.delLike = {};
                                $scope.delLike.uid = userId;
                                $scope.delLike.token = userToken;
                                $scope.delLike.objectId = id;
                                $scope.delLike.agreeType = 1;
                                var promisess = apiFun.deleteAgreeFun($scope.delLike);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        // console.log(res);
                                        $("#suggest"+index).find('img').attr('src','../images/rewardIcon.png');
                                        $("#suggest"+index).find('b').removeClass('textColor2').text(result.data.agreeCount-1);
                                    }
                                });
                            }else if(result.data.isAgree==false){
                                //点赞/取消点赞评论   ---start
                                $scope.suggest = {};
                                $scope.suggest.uid = userId;
                                $scope.suggest.type = 4;
                                $scope.suggest.objectId = id;
                                $scope.suggest.agreeType = 1;
                                $scope.suggest.token = userToken;
                                var promisess = apiFun.insertAgreeFun($scope.suggest);
                                promisess.then(function(res) {
                                    // console.log(res);
                                    if(res.code == 0){
                                        $("#suggest"+index).find('img').attr('src','../images/rewardP.png');
                                        $("#suggest"+index).find('b').addClass('textColor2').text(result.data.agreeCount+1);
                                    }
                                });//点赞/取消点赞评论   ---end
                            }
                        }
                    });
                };



                TopicCommentFun2($scope.userData.userInfo.uid);
                $scope.loadMore = function () {
                    TopicCommentFun2($scope.userData.userInfo.uid);
                };

            }else if(res.code == -2){
                TopicCommentFun2();
                $scope.loadMore = function () {
                    TopicCommentFun2();
                };
                $scope.collectingClick = function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                };
                $scope.praiseClick = function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                };
                $scope.suggestClick = function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                };
                $("#submitEditor").click(function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                });
            }
        });
    };
    $scope.userInfoFun();


    //第三方分享
    function shareFun(url, title, description, pic) {
        mobShare.config({
            debug: false, // 开启调试，将在浏览器的控制台输出调试信息
            appkey: '1d102ac0241c0', // appkey
            params: {
                url: url, // 分享链接
                title: title, // 分享标题
                description: description, // 分享内容
                pic: pic, // 分享图片，使用逗号,隔开
                reason: '', //自定义评论内容，只应用与QQ,QZone与朋友网
            },
            callback: function(plat, params) {
                // console.log("分享成功");
            }
        });
    }

    //打赏
    var gift = [
        {niubi:'1',text:'厉害了我的主播！',img:'images/giftzan.png'},
        {niubi:'10',text:'来两颗金豆压压惊！',img:'images/giftjindou.png'},
        {niubi:'188',text:'这是一个神奇的宝箱！',img:'images/giftbaoxiang.png'},
        {niubi:'999',text:'让你的每只股都涨停！',img:'images/giftzhangtingban.png'},
        {niubi:'1888',text:'让你财源滚滚来！',img:'images/giftcaishenye.png'},
        {niubi:'8888',text:'让你牛气冲天，一牛再牛！',img:'images/giftjinniu.png'}
    ];

    function award(uid,uidIn,target,coinType,monetary,awardToken,channel,token) {
        $.ajax({
            type: "post",
            url: "/api/v1/account/award.do",
            data:{
                uid:uid,
                uidIn:uidIn,
                target:target,
                coinType:coinType,
                monetary:monetary,
                awardToken:awardToken,
                channel:channel,
                token:token
            },
            success: function (res) {
                // console.log(res);

                if(res.code == 0){
                    $('.praiseSuccess').fadeIn(200);
                    setTimeout(function () {
                        $('.praiseSuccess').fadeOut(200);
                    },2000);
                }else if(res.code == -706){
                    $("#exceptWrap").stop().show();
                    $(".weChatOweWrap").stop().show();
                    $(".weChatErrorEnter").click(function() {
                        $(".weChatOweWrap").stop().hide();
                        $("#n_money").stop().show()
                    })
                }else{
                    layer.msg('打赏失败！');
                }
            }
        })
    };

    $("body,html").click(function () {
        $(".giftImg").fadeOut(200);
    });


    var conmentid;
    var commentatorid;
    $scope.rewordBtnFun = function ($index,commentID,commentatorId) {
        conmentid = commentID;
        commentatorid = commentatorId;
        $.ajax({
            type: "get",
            url: "/userInfos",
            success: function (res) {
                if(res.code == 0){
                    var appreciationID = "appreciation"+$index;
                    $("#"+appreciationID).children(".giftImg").css("display","inline-block");
                    $(".giftImg img").mouseleave(function () {
                        $(".giftImgHover").css("display","none");
                    });
                    $(".giftImg img").mouseover(function(){
                        var i = $(this).index();
                        $(".giftValue").text(gift[i].niubi);
                        $(".giftText").text(gift[i].text);
                        $(".hoverImg").attr('src',gift[i].img);
                        var moverRight = 220-72*i;
                        $(".giftImgHover").css({"display":"none"});
                        $("#"+appreciationID).children(".giftImgHover").css({"display":"inline-block","right":moverRight+"px"});
                    });

                    var token = res.data.token;
                    var uid = res.data.userInfo.uid;
                    //查询用户账户
                    $.ajax({
                        type: "post",
                        url: "/api/v1/account/selectByWhere.do",
                        data:{
                            uid:uid,
                            coinType:'RECHARGE_COIN',
                            token:token
                        },
                        success: function (res) {
                            if (res.code == 0) {
                                // console.log(res);
                                $(".balanceVal").text(res.data[0].coinNumber);
                            }
                        }
                    });
                }else {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                }
            }
        })
    };

    $scope.rewordImgFun = function (i) {
        $.ajax({
            type: "post",
            url: "/api/v1/account/getToken.do",
            data:{uid:userId,token:userToken},
            success: function (result) {
                if (result.code == 0) {
                    award(userId,commentatorid,conmentid,'RECHARGE_COIN',gift[i].niubi,result.data,'WEB',userToken);
                }
            }
        })
    };
    //电脑跳转手机
    function browserRedirect() {
        var sUserAgent = navigator.userAgent.toLowerCase();
        var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
        var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
        var bIsMidp = sUserAgent.match(/midp/i) == "midp";
        var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
        var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
        var bIsAndroid = sUserAgent.match(/android/i) == "android";
        var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
        var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
        if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
            window.location.href = "https://www.fntv8.com/m/topic?id=" + getQueryStringId + "";
        }
    }
    browserRedirect();


    //充值函数
    function payFun(userId, token) {
        /*充值接口*/
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v1/account/selectByWhere.do",
            data: {
                "uid": userId,
                "coinType": "RECHARGE_COIN",
                "token": token,
            },
            success: function(res) {
                //console.log(res);
                if(res.code == 0) {
                    // console.log(res.data[0].coinNumber);
                    $(".coinNiBi").html(res.data[0].coinNumber);
                    $("#balanceCoin").html(res.data[0].coinNumber + "牛币")
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus);
            }
        });
        //点击重置按钮
        $(".payMoneyBtn").click(function() {
            $("#exceptWrap").stop().show();
            $("#n_money").stop().show();
        })
        $(".qitaMoney").focus(function() {
            $(this).removeAttr("placeholder");
            $(".moneyAlert").stop().show()
        });
        $(".qitaMoney").blur(function() {
            $(this).attr("placeholder", "其他金额");
            $(".moneyAlert").stop().hide()
        });
        $(".payBtn").click(function() {
            var totalFee = "";
            if($(".qitaMoney").val() != "") {
                totalFee = parseInt($(".qitaMoney").val());
                //console.log(totalFee)
            } else {
                totalFee = parseInt($(".money_list").find(".click_effect").children().text())
            }
            $(".weChatPayNum").html(totalFee);
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v1/order/wxUnifiedOrder.do",
                data: {
                    "uid": userId,
                    "totalFee": totalFee,
                    "tradeType": "NATIVE",
                    "token": token,
                },
                success: function(res) {
                    if(res.code == 0) {
                        $("#n_money").fadeOut(1);
                        $(".weChatCodeWrap").fadeIn(1);
                        var codeUrl = res.data.codeUrl;
                        var outTradeNo = res.data.outTradeNo;
                        //console.log(outTradeNo);
                        jQuery("#weChatPayCode").qrcode({
                            render: "canvas",
                            foreground: "#000",
                            background: "#FFF",
                            width: 180,
                            height: 180,
                            text: codeUrl,
                            correctLevel: 2
                        });
                        intervalTime = setInterval(function() {
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/order/wxFrontNotify.do",
                                data: {
                                    "uid": userId,
                                    "outTradeNo": outTradeNo,
                                    "token": token,
                                },
                                success: function(res) {
                                    //	console.log(res);
                                    if(res.code == 0) {
                                        $(".weChatCodeWrap").stop().hide();
                                        $(".weChatPaySuccess").stop().show()
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus)
                                }
                            })
                        }, 3000)
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    console.log(XMLHttpRequest.status);
                    console.log(XMLHttpRequest.readyState);
                    console.log(textStatus);
                }
            })
        })

    }

    /*固定条*/
    var IndexpageIndex =1;
    $(".fixed_nav .reload").click(function() {
        $("body,html").animate({
            scrollTop: 1200
        }, 800)
        IndexpageIndex++;
        insertHot(IndexpageIndex, 10, "top");
        $(".insertTopWrap").stop().show(0).delay(4000).hide(0);
        $("#hotTopLoading").show().delay(1000).hide(0);
        $(".insertTop").delay(1000).slideDown(0).delay(3000).slideUp(0);
    });
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn()
        } else {
            $(".goTop").stop().fadeOut()
        }
    });
    $(".goTop").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 800)
    });

}
]);









