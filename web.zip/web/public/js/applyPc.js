$(document).ready(function() {
	$(".applyFormSchoolBtn").click(function() {
		$("#mCSB_1_container").html("");
		$("#mCSB_2_container").html("");
		getProvinces();
		$(".applyFormSchoolChoose").slideToggle();
		$(".applyFormSchoolChooseR").slideToggle();
		$(this).css({
			'background-image': 'url(../images/NetCup/up.png)',
		});
	})
    /*获取学校*/
    function getProvinces() {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/common-service/api/v1/entered/getProvinces",
			success: function(res) {
				if(res.code == 0) {
					console.log(res);
					$(res.data).each(function(M,N){
						var provinceBoxInfoId="provinceBoxInfo"+N.id;
						var provinceBoxInfo=
					    '<li class="provinceBoxInfo" id='+provinceBoxInfoId+' objectId='+N.id+'>'+N.name+'</li>'
                        $("#mCSB_1_container").append(provinceBoxInfo);
                        //变颜色
	                    tabSmallFun(".provinceBoxInfo", "provinceBoxInfoActive");
	
                        $("#"+provinceBoxInfoId).click(function(){
                        	var pid=$(this).attr("objectId");
                        	$("#mCSB_2_container").html("");
                        	getSchool(pid);
                        })
					})
					var firstId=$(".provinceBoxInfo:first").attr("objectId");
                    console.log(firstId);
					getSchool(firstId);
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
   
    function getSchool(pid) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"pid": pid,
			},
			url: "/common-service/api/v1/entered/getSchool",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					$(res.data.school).each(function(L,G){
						var provinceBoxInfoRId="provinceBoxInfoRId"+G.id;
						var provinceBoxInfoR=
					    '<li class="provinceBoxInfoR" id='+provinceBoxInfoRId+' objectId='+G.id+'>'+G.sname+'</li>'
                        $("#mCSB_2_container").append(provinceBoxInfoR);
                        tabSmallFun(".provinceBoxInfoR", "provinceBoxInfoRActive");
                        $("#"+provinceBoxInfoRId).click(function(){
                        	var objectId=$(this).attr("objectId");
                        	var getSchoolHtml=$(this).html();
                        	$(".applyFormSchoolBtn").html(getSchoolHtml);
                        	$(".applyFormSchoolBtn").css({
                        		"color":"#2c2c2c",
                        	})
                        	$(".applyFormSchoolBtn").attr("objectId",objectId);
                        	$(".applyFormSchoolChoose").stop().hide();
                        	$(".applyFormSchoolChooseR").stop().hide();
                        })
					})
					
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
    var phoneReg = /^[1][34578]\d{9}$/; //手机号码正则
	var passwordReg = /^[0-9a-zA-Z]+$/ //密码正则
	var numReg = new RegExp(/^\d{4}$/); //图形验证码
	var verifyReg = new RegExp(/^\d{6}$/); //短信验证码
   //报名接口
   loginFun();
	//判断是否登录
	function loginFun() {
		$.ajax({
			type: "get",
			url: "/userInfos",
			success: function(res) {
				console.log(res);
				if(res.code == -2) { //未登录
					$("#loginAlert").stop().show();
					$("#loginAlert").load("/login");
				} else if(res.code == 0) { //登录成功
					var userUid = res.data.userInfo.uid;
					var userToken=res.data.token;
					var bindAccounts = res.data.userInfo.bindAccounts
					var bindAccountsLen = res.data.userInfo.bindAccounts.length;
					for(var Q = 0; Q < bindAccountsLen; Q++) {
						var bindAccountsType = bindAccounts[Q].type;
						if(bindAccountsType == 1) {
							$(".bindAccountsPhoneNickName").val(bindAccounts[Q].nickName);
							$(".bindAccountsPhoneNickName").attr("disabled","disabled");
						    $(".phoneCodeHave").stop().hide();
						    $(".applyFormBoxFromCodeBtn").stop().hide();
						}else{
							$(".bindAccountsPhoneNickName").removeAttr("disabled");
						}
					}
					$(".signUpBtnBox").click(function(){
						var sid=$(".applyFormSchoolBtn").attr("objectId");
						var realName=$(".realNameInput").val();
						var resetPhone=$(".bindAccountsPhoneNickName").val();
					//	console.log(realName);
						if(sid==undefined){
							layer.msg("请选择报名大学");
						}else if(realName==""||realName==undefined||realName==null){
							layer.msg("请填写真实姓名");
						}else if(!phoneReg.test(resetPhone)) {
							layer.msg('手机号码有误，请重新输入');
						}else{
							var realName=$(".realNameInput").val();
						    var mobile=$(".bindAccountsPhoneNickName").val();
						    toEntered(userUid,userToken,"",sid,realName,"",mobile,"");
						}
						
					})
					
					bindAccountsPhoneFun(userUid, userToken);
					
				}
			}
		})
	}
	//获取图形验证码
	function refreshCodeFun() {
		$.ajax({
			type: "GET",
			url: "/refreshGraphCode",
			success: function(res) {
				if(res.code == 0) {
					var src = 'data:image/png;base64,' + res.data;
					$(".graphCode").attr("src", src);
				}
			}
		});
	};
	//刷新图形验证码
	$(".graphCode").click(function() {
		refreshCodeFun();
	});
	/*获得手机号码token*/
	function bindAccountsPhoneFun(uid, token) {
		$("#getBangdingYan").click(function() {
			var resetPhone = $("#pnone_size").val();
			if(!phoneReg.test(resetPhone)) {
				layer.msg('手机号码有误，请重新输入');
				return false;
			} else {
				refreshCodeFun();
				$("#numCodeBGPhone").stop().show();
				//图形验证码确认按钮
				$("#verifyGraphBtnPhone").click(function() {
					var graphInputCode = $("#graphInputCode").val();
					if(!numReg.test(graphInputCode)) {
						$("#graphInputCode").val('');
						layer.msg('验证码有误');
						return false;
					} else {
						$.ajax({ //校验图形验证码
							type: "post",
							url: "/checkGraphCode",
							data: { 'verifiCode': graphInputCode },
							success: function(res) {
								$("#graphInputCode").val('');
								// console.log(res);
								if(res.code == 0) { //图形验证码正确
									$("#numCodeBGPhone").fadeOut(100);
									$.ajax({ //发送短信验证码
										type: "post",
										url: "/api/v2/user/sendSms.do",
										data: { 'type': 2, 'mobile': resetPhone },
										success: function(res) {
											// console.log(res);
											if(res.code == 0) {
												layer.msg('验证码发送成功');
												$(".phone_bind_wrap").stop().show();
												var times = 60;
												var isinerval;
												$("#getBangdingYan").attr("disabled", true);
												isinerval = setInterval(function() {
													if(times < 0) {
														$("#getBangdingYan").html("获取验证码").attr("disabled", false);
														clearInterval(isinerval);
														return
													}
													$("#getBangdingYan").html(times + "s");
													$("#getBangdingYan").css({
														"background":"#b3b3b3"
													})
													times--
												}, 1000)
												//报名
												$(".signUpBtnBox").click(function(){
													var sid=$(".applyFormSchoolBtn").attr("objectId");
													var realName=$(".realNameInput").val();
													var resetPhone=$(".bindAccountsPhoneNickName").val();
													var phoneCodeHave=$(".phoneCodeHave").val();
													console.log(realName);
													if(sid==undefined){
														layer.msg("请选择报名大学");
													}else if(realName==""||realName==undefined||realName==null){
														layer.msg("请填写真实姓名");
													}else if(!phoneReg.test(resetPhone)) {
														layer.msg('手机号码有误，请重新输入');
													}else if(phoneCodeHave==""||phoneCodeHave==undefined||phoneCodeHave==null){
														layer.msg('验证码不能为空，请重新输入');
													}else{
														var realName=$(".realNameInput").val();
													    var mobile=$(".bindAccountsPhoneNickName").val();
													    toEntered(uid,token,"",sid,realName,phoneCodeHave,mobile,"");
													}
													
												})
											} else if(res.code == -14) {
												layer.msg('该手机号发送短信次数过于频繁');
											} else if(res.code == -20) {
												layer.msg('系统繁忙，请稍后再试');
											} else if(res.code == -101) {
												layer.msg('手机号已被注册');
											} else if(res.code == -9998) {
												layer.msg('发送失败');
											}
										}
									});
								} else if(res.code == -1) {
									layer.msg('图形验证码有误');
								}
							}
						});
					}
				});
			}
		});
	}
	
	$(".graphCloseBtn").click(function() {
		$("#numCodeBGPhone").stop().hide();
	})
	

    /*报名*/
    function toEntered(uid,token,pid,sid,realName,authCode,mobile,smsToken) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			data: {
				"uid": uid,
				"token": token,
				"pid": pid,
				"sid": sid,
				"realName": realName,
				"authCode": authCode,
				"mobile": mobile,
				"smsToken": smsToken,
			},
			url: "/common-service/api/v1/entered/toEntered",
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					layer.msg("恭喜您，报名成功！");
					var fal=res.data.fal;
					if(fal==true){//有红包
						$(".redPacketBox").stop().show();
						$(".competingPlaces").html(res.data.id);
						//领取红包
						$(".receiveRedPacket").click(function(){
							getRedBagFun(uid,token,"");
						})
					}else{//无无红包返回上一页
					  var time1=setTimeout(function(){
							window.history.go(-1);
						},2000)
					}
					
				}else if(res.code==-222){
					layer.msg("该手机号码已经报名成功");
					var time1=setTimeout(function(){
						window.history.go(-1);
					},2000)
				}else if(res.code==-555){
					layer.msg("报名失败");
				}else if(res.code==-112){
					layer.msg("报名还未开始哦");
				}else if(res.code==-113){
					layer.msg("报名已经结束了");
				}else if(res.code==-15){
					layer.msg("请输入2~4个汉字");
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
   
    //弹框关闭
    $(".closeGetRedPacketBox").click(function(){
    	window.history.go(-1);
    })
     
    /*邀请好友*/
   $(".downLoadAppPcBtn").click(function() {
		window.location.href = "/downLoadAppPc";
	});
   
   
   /*领取红包*/
   function getRedBagFun(uid,token,sign){
   	 $.ajax({
			type: "post",
			async: true,
			dataType: "json",
			data: {
				"uid": uid,
				"token": token,
				"sign": sign,
			},
			url: "/common-service/api/v1/entered/getRedBag",
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					$(".redPacketBox").stop().hide();
					$(".getRedPacketBox").stop().show();
					$(".getRedBagNull").html((res.data)/100+"元");
				}else if(res.code==333){
					$(".redPacketBox").stop().hide();
					$(".getRedPacketBox").stop().show();
					$(".getRedBagNull").html(res.data);
					layer.msg("您已经领取过红包");
				}else if(res.code==-555){
					layer.msg("不好意思，您的红包暂时无法领取，系统核查以后，将由后台直接将红包发放至您的账户，届时您可登陆APP查看！感谢您的理解！");
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
   }
   
   
   
   
   
   
   
   
   
	$("#scrollBar1").mCustomScrollbar({
		callbacks: {
			onScrollStart: function() {},
			onScroll: function() {},
			onTotalScroll: function() {
			},
			onTotalScrollBack: function() {},
			onTotalScrollOffset: 80,
			whileScrolling: false,
			whileScrollingInterval: 0
		},
		scrollInertia: 300
	});

	$("#scrollBar2").mCustomScrollbar({
		callbacks: {
			onScrollStart: function() {},
			onScroll: function() {},
			onTotalScroll: function() {

			},
			onTotalScrollBack: function() {},
			onTotalScrollOffset: 80,
			whileScrolling: false,
			whileScrollingInterval: 0
		},
		scrollInertia: 300
	});
	
	
	//页面跳转
	function browserRedirect() {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		var bIsMidp = sUserAgent.match(/midp/i) == "midp";
		var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		var bIsAndroid = sUserAgent.match(/android/i) == "android";
		var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
		if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
			window.location.href = "https://www.fntv8.com/m/v5.0/signUp"
          //  window.location.href = "http://192.168.8.13:8445/m/v5.0/invite"
		}
	}
	browserRedirect();

})