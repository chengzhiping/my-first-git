var uid;
var token;
$(document).ready(function(){
	$(".chooseLiveListTop").click(function(){
		$(".chooseLiveListBox").stop().hide();
		$("#loginAlert").stop().hide();
	});
	//判断主播是否登录
	$.ajax({
		type: "get",
		url: "/userInfos",
		success: function(res) {
			console.log(res);
			if(res.code == -2) { //未登录
			  //登录
			   $("#loginAlert").stop().show();
			   $("#loginAlert").load("/login");
			};
			if(res.code == 0) {
				uid=roleType=res.data.userInfo.uid;
				token=res.data.token;
				getUserLiveRoomList('',uid,0,1,5);//主直播间
				getUserLiveRoomList('',uid,1,1,5);//VIP直播间列表
			}
		},
		error: function(XMLHttpRequest, textStatus, errorThrown) {
			console.log(XMLHttpRequest.status);
			console.log(XMLHttpRequest.readyState);
			console.log(textStatus);
		},
	});
	
	function getUserLiveRoomList(visitorUid,liverUid,type,pageIndex,pageSize){
		$.ajax({
			type: "get",
			async: true, //是否异步
			url: "/api/v3/live/getUserLiveRoomList.do",
			dataType: "json",
			data: {
				"visitorUid": visitorUid,
				"liverUid":liverUid,
				"type":type,//类型（0=主直播间，1=VIP直播间），不传获取所有
				"pageIndex":pageIndex,
				"pageSize":pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					if(type==0){//0=主直播间，1=VIP直播间
						$(res.data.list).each(function(m, Q) {
							var liveRoomBox=
							'<div class="liveSameCenter liveRoomBox">'+
								'<img class="fl liveCoverUrl" src="'+Q.coverUrl+'"/>'+
								'<div class="fl liveSameCenterC">'+
									'<p>'+
										'<span class="liveTopic">'+Q.roomName+'</span>'+
										'<span class="bugNum fr">'+Q.subscribers+'人订阅</span>'+
										'<span class="jionInNum fr">'+Q.partakes+'参与</span>'+
									'</p>'+
									'<p class="updateTitle">'+Q.topic+'</p>'+
								'</div>'+
								'<span class="fr enterLiveBtn" roomId='+Q.roomId+' uid='+Q.liverInfo.uid+'>进入直播间</span>'+
							'</div>';
							$(".zLiveBox").append(liveRoomBox);
							if(Q.topic==""){
								$(".updateTitle").html("主题：主播很懒，还没有设置主题哦。");
							};
							if(Q.coverUrl==""){
								$(".liveCoverUrl").attr("src","images/userzjNull.jpg");
							};
							
						})
					}else if(type==1){
						var vipLiveListLen=res.data.list.length;
						//console.log(vipLiveListLen);
						if(vipLiveListLen==0){
							$(".vipLiveBoxWrap").stop().hide();
						}
						if(vipLiveListLen==pageSize){
							pageIndex++;
							getUserLiveRoomList('',uid,1,pageIndex,5);//VIP直播间列表
						}
						$(res.data.list).each(function(m, Q) {
							if(Q.subscribePay){
								var vipLiveBox=
								'<div class="liveSameCenter vipLiveBox">'+
									'<img class="fl" src="'+Q.coverUrl+'"/>'+
									'<div class="fl liveSameCenterC">'+
										'<p>'+
											'<span class="liveTopic">'+Q.roomName+'</span>'+
											'<span class="bugNum fr">'+Q.subscribers+'人订阅</span>'+
											'<span class="jionInNum fr">'+Q.subscribePay+'牛币/'+Q.subscribeCycle+'天</span>'+
										'</p>'+
										'<p class="updateTitle">'+Q.topic+'</p>'+
									'</div>'+
									'<span class="fr enterLiveBtn" roomId='+Q.roomId+' uid='+Q.liverInfo.uid+'>进入直播间</span>'+
								'</div>';
								$(".vipLiveBoxWrap").append(vipLiveBox);
							}
							
						})
					}
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	
	$(document).on("click", ".enterLiveBtn", function(e) {
		window.location.href = "/userProfile?uid=" + uid+"&tab=5";
	});
	
	
	
	
})
