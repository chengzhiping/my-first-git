var bestTradersApp = angular.module("bestTradersApp",['appServices']);

bestTradersApp.controller('bestTradersCtrl',['$scope','$rootScope','$location','$filter','apiFun',function ($scope,$rootScope,$location,$filter,apiFun) {
    var uid;
    var token;
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");
    //APP下载二维码
    $(".saoma").mouseenter(function() {
        $(".indexCode").fadeIn(200);
    });
    $(".saoma").mouseleave(function() {
        $(".indexCode").fadeOut(200);
    });
    /*1文章，2短评，3视频或视频回放，4直播，5静态网页，
     6主播个人页,7不跳转，8操盘手个人页，9个人实盘页，10话题，11专栏详情页*/
    //点击跳转
    $scope.traderHref = function (type,id,uid) {
        if(type==1){//文章
            window.location.href ="/article?id="+id;
        }else if(type==2){//短评
            //window.location.href ="";
        }else if(type==3){//视频或回放
            window.location.href ="/video?id="+id;
        }else if(type==4){//直播
            window.location.href ="/live?uid="+uid;
        }else if(type==5){//静态页面
            window.location.href =id;
        }else if(type==6){//个人主播页
            window.location.href ="/userProfile?uid="+uid;
        }else if(type==7){//不跳转
            //window.location.href ="http://www.baidu.com";
        }else if(type==8){//操盘手个人页
            window.location.href ="/userProfile?uid="+uid;
        }else if(type==9){//个人实盘页
            window.location.href ="/userProfile?uid="+uid;
        }else if(type==10){//话题
            window.location.href ="/topicDetails?id="+id;
        }else if(type==11){//专栏详情页
            window.location.href ="/columnDetail?id="+id;
        }
    };


    //根据类型获取banner ----开户参赛
    $scope.selectByType2 = function () {
        $scope.params = {};
        $scope.params.type = 24;
        $scope.params.pageSize = 1;
        $scope.params.pageIndex = 1;
        var promisess = apiFun.selectByTypeFun($scope.params);
        promisess.then(function(data) {
            if(data.code == 0){
                $scope.entryImg2 = data.data[0];
                // console.log($scope.entryImg2);
            }
        });
    };
    $scope.selectByType2();

    //根据类型获取banner ----大赛规则
    $scope.selectByType3 = function () {
        $scope.params = {};
        $scope.params.type = 25;
        $scope.params.pageSize = 1;
        $scope.params.pageIndex = 1;
        var promisess = apiFun.selectByTypeFun($scope.params);
        promisess.then(function(data) {
            if(data.code == 0){
                $scope.entryImg3 = data.data[0];
                // console.log($scope.entryImg3);
            }
        });
    };
    $scope.selectByType3();

    //获取赛事动态
    $scope.traderReportFun = function () {
        var promisess = apiFun.selectTraderReportFun();
        promisess.then(function(data) {
            if(data.code == 0){
                $scope.traderReport = data.data.content;
                // console.log($scope.traderReport);
            }
        });
    };
    $scope.traderReportFun();

    //话题讨论
    $scope.traderDiscussFun = function () {
        var promisess = apiFun.selectTraderDiscussFun();
        promisess.then(function(data) {
            if(data.code == 0){
                $scope.traderDiscuss = data.data;
                // console.log($scope.traderDiscuss);
            }
        });
    };
    $scope.traderDiscussFun();

    //根据类型获取banner ----开户参赛，赢取高额奖励
    $scope.openAccount = function () {
        $scope.params = {};
        $scope.params.type = 24;
        $scope.params.pageSize = 1;
        $scope.params.pageIndex = 1;
        var promisess = apiFun.selectByTypeFun($scope.params);
        promisess.then(function(data) {
            if(data.code == 0){
                $scope.entryImg4 = data.data[0];
                // console.log($scope.entryImg4);
            }
        });
    };
    $scope.openAccount();

    //观点大PK
    $scope.getPk = function (uid) {
        var promisess = apiFun.getPkFun(1,1,uid);
        promisess.then(function(data) {
            if(data.code == 0){
                $scope.pkData = data.data[0];
                // console.log($scope.pkData);
            }
        });
    };
    $scope.getPk('');

    //获取用户信息
    $scope.userData = function () {
        var promisess = apiFun.getUserInfoFun();
        promisess.then(function(data) {
            if(data.code == 0){
                $scope.user = data.data;
                // console.log($scope.user);
                uid = $scope.user.userInfo.uid;
                token = $scope.user.token;
                $scope.getPk(uid);

                $scope.praiseBtn = function (objectId) {
                    $scope.agreeApi5 = {};
                    $scope.agreeApi5.objectId = objectId;
                    $scope.agreeApi5.uid = uid;
                    $scope.agreeApi5.agreeType = 1;
                    var promisess = apiFun.selectAgreeCountFun($scope.agreeApi5);
                    promisess.then(function(res) {
                        if(res.code == 0){
                            var agreeCountNum0 = res.data.agreeCount -1;
                            var agreeCountNum1 = res.data.agreeCount +1;
                            if(res.data.isAgree==true){
                                //取消点赞
                                $scope.delLike = {};
                                $scope.delLike.uid = uid;
                                $scope.delLike.token = token;
                                $scope.delLike.objectId = objectId;
                                $scope.delLike.agreeType = 1;
                                var promisess = apiFun.deleteAgreeFun($scope.delLike);
                                promisess.then(function(result) {
                                    if(result.code == 0){
                                        $(".pkDataimgA").attr("src","images/rewardA.png");
                                        $("#pkagreeCountA").text(agreeCountNum0+'人已赞');
                                    }
                                });
                            }else if(res.data.isAgree==false){
                                //点赞
                                $scope.insertAgree = {};
                                $scope.insertAgree.uid = uid;
                                $scope.insertAgree.type = 2;
                                $scope.insertAgree.objectId = objectId;
                                $scope.insertAgree.agreeType = 1;
                                $scope.insertAgree.token = token;
                                var promisess = apiFun.insertAgreeFun($scope.insertAgree);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        $(".pkDataimgA").attr("src","images/rewardB.png");
                                        $("#pkagreeCountA").text(agreeCountNum1+'人已赞');
                                    }
                                });
                            }
                        }
                    });
                };
                $scope.praiseBtnB = function (objectId) {
                    $scope.agreeApi5 = {};
                    $scope.agreeApi5.objectId = objectId;
                    $scope.agreeApi5.uid = uid;
                    $scope.agreeApi5.agreeType = 1;
                    var promisess = apiFun.selectAgreeCountFun($scope.agreeApi5);
                    promisess.then(function(res) {
                        if(res.code == 0){
                            var agreeCountNum0 = res.data.agreeCount -1;
                            var agreeCountNum1 = res.data.agreeCount +1;
                            if(res.data.isAgree==true){
                                //取消点赞
                                $scope.delLike = {};
                                $scope.delLike.uid = uid;
                                $scope.delLike.token = token;
                                $scope.delLike.objectId = objectId;
                                $scope.delLike.agreeType = 1;
                                var promisess = apiFun.deleteAgreeFun($scope.delLike);
                                promisess.then(function(result) {
                                    if(result.code == 0){
                                        $(".pkDataimgB").attr("src","images/rewardA.png");
                                        $("#pkagreeCountB").text(agreeCountNum0+'人已赞');
                                    }
                                });
                            }else if(res.data.isAgree==false){
                                //点赞
                                $scope.insertAgree = {};
                                $scope.insertAgree.uid = uid;
                                $scope.insertAgree.type = 2;
                                $scope.insertAgree.objectId = objectId;
                                $scope.insertAgree.agreeType = 1;
                                $scope.insertAgree.token = token;
                                var promisess = apiFun.insertAgreeFun($scope.insertAgree);
                                promisess.then(function(res) {
                                    if(res.code == 0){
                                        $(".pkDataimgB").attr("src","images/rewardB.png");
                                        $("#pkagreeCountB").text(agreeCountNum1+'人已赞');
                                    }
                                });
                            }
                        }
                    });
                };

            }else {
                $scope.praiseBtn = function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                };
                $scope.praiseBtnB = function () {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                };

            }
        });
    };
    $scope.userData();

    //交易机会
    $scope.transferRecordsFun = function () {
        var promisess = apiFun.getTransferRecordsFun(6,1);
        promisess.then(function(res) {
            if(res.code == 0){
                $scope.transferdata = res.data;
                $.each($scope.transferdata,function(i) {
                    //总收益
                    var promisess2 = apiFun.getProfitInfoByUidFun($scope.transferdata[i].liverInfo.uid);
                    promisess2.then(function(result) {
                        if(result.code == 0){
                            $scope.profitInfo = result.data;
                            $scope.transferdata[i].profit = $scope.profitInfo;
                        }
                    });
                });
                // console.log($scope.transferdata);
            }
        });
    };
    $scope.transferRecordsFun();


    //收益排行
    var startTime = new Date();
    var weekday = startTime.getDay();
    var monday = new Date(3600000 * 24 * (1 - weekday) + startTime.getTime());
    var monday2 = new Date(3600000 * 24 * (1 - weekday) + startTime.getTime());
    var friday = new Date(3600000 * 24 * (5 - weekday) + startTime.getTime());
    var friday2 = new Date(3600000 * 24 * (5 - weekday) + startTime.getTime());

    $scope.mondayStr = monday.getTime();
    $scope.fridayStr = friday.getTime();
    $scope.lastDisabled = false;
    $scope.nextDisabled = true;

    function getDateStr(dd) {
        var y = dd.getFullYear();
        var m = dd.getMonth() + 1;//获取当前月份的日期
        m = parseInt(m, 10);
        if (m < 10) {
            m = "0" + m;
        }
        var d = dd.getDate();
        d = parseInt(d, 10);
        if (d < 10) {
            d = "0" + d;
        }
        return y + "" + m +"" + d;
    };
    var today = getDateStr(new Date());


    var thisSeason;
    var thisSeason2;
    var profitIndex = 1;
    $scope.profitRankType = 1;

    var thisFrid = getDateStr(friday);

    if(thisFrid <= 20170811){
        $scope.lastDisabled = true;
    }else if(thisFrid >= 20180803){
        $scope.nextDisabled = true;
    };

    $scope.profitRank = [];
    function profitRankFun(type,date,season) {
        $scope.profitRankFun = {};
        $scope.profitRankFun.type = type;
        $scope.profitRankFun.date = date;
        $scope.profitRankFun.season = season;
        $scope.profitRankFun.pageIndex = profitIndex;
        $scope.profitRankFun.pageSize = 5;
        // console.log(date);
        var promisess = apiFun.profitRankByTypeFun($scope.profitRankFun);
        promisess.then(function(res) {
            if(res.code == 0){
                $.each(res.data,function(i) {
                    $scope.profitRank.push(res.data[i]);
                     // console.log($scope.profitRank);
                });
            }
        });
    };
    profitRankFun(1,thisFrid,'');


    //大赛排名 tab
    $scope.rankingBtn = function (type) {
        $scope.nextDisabled = false;
        $scope.lastDisabled = false;
        $scope.profitRank.length = 0;
        profitIndex = 1;
        if(type==1){
            // $scope.nextDisabled = false;
            // $scope.lastDisabled = false;
            if(getDateStr(friday)<=20170811){
                $scope.lastDisabled = true;
            }else if(getDateStr(friday)>=20180803){
                $scope.nextDisabled = true;
            }else if(getDateStr(friday)>=getDateStr(friday2)){
                $scope.nextDisabled = true;
            }
            $scope.mondayStr = monday.getTime();
            $scope.fridayStr = friday.getTime();
            $scope.profitRankType = 1;
            profitRankFun(1,getDateStr(friday),'');
        }else if(type==2){
            $scope.nextDisabled = false;
            $scope.lastDisabled = false;
            $scope.profitRankType = 2;
            if(today <= 20171103){
                thisSeason=1;
                $scope.lastDisabled = true;
                $scope.thisSeasonStr = '2017.08.07-2017.11.03';
            }else if(20171106 <= today <= 20180202){
                thisSeason=2;
                $scope.thisSeasonStr = '2017.11.06-2018.02.02';
            }else if(20180205 <= today <= 20180504){
                thisSeason=3;
                $scope.thisSeasonStr = '2018.02.05-2018.05.04';
            }else if(20180507 <= today <= 20180803){
                thisSeason=4;
                $scope.nextDisabled = true;
                $scope.thisSeasonStr = '2018.05.07-2018.08.03';
            };
            thisSeason2 = thisSeason;
            if(thisSeason>=thisSeason2){
                $scope.nextDisabled = true;
            }
            profitRankFun(2,'',thisSeason);
        }else if(type==3){
            $scope.lastDisabled = true;
            $scope.nextDisabled = true;
            $scope.profitRankType = 3;
            profitRankFun(3,'','');
        }
    };

    $scope.rankingLast = function () {
        $scope.lastDisabled = false;
        $scope.nextDisabled = false;
        // console.log($scope.profitRankType);
        $scope.profitRank.length = 0;
        profitIndex = 1;
        if($scope.profitRankType==1){
            if(getDateStr(friday)==20170811){
                $scope.lastDisabled = true;
                profitRankFun(1,20170811,'');
            }else if(getDateStr(friday)<20170811){
                $scope.lastDisabled = true;
            }else {
                monday = new Date(monday.getTime()-3600000*24*7);
                friday = new Date(friday.getTime()-3600000*24*7);
                // console.log(friday);
                if(getDateStr(friday)==20170811){
                    $scope.lastDisabled = true;
                }
                $scope.mondayStr = monday.getTime();
                $scope.fridayStr = friday.getTime();
                profitRankFun(1,getDateStr(friday),'');
            }
        }else if($scope.profitRankType==2){
            $scope.lastDisabled = false;
            $scope.nextDisabled = false;
            thisSeason--;
            if(thisSeason==1){
                $scope.lastDisabled = true;
                $scope.thisSeasonStr = '2017.08.07-2017.11.03';
            }else if(thisSeason==2){
                $scope.thisSeasonStr = '2017.11.06-2018.02.02';
            }else if(thisSeason==3){
                $scope.thisSeasonStr = '2018.02.05-2018.05.04';
            }else if(thisSeason==4){
                $scope.nextDisabled = true;
                $scope.thisSeasonStr = '2018.05.07-2018.08.03';
            };
            profitRankFun(2,'',thisSeason);
        }else if($scope.profitRankType==3){
            // profitRankFun(3,'','');
        }
    };
    $scope.rankingNext = function () {
        $scope.lastDisabled = false;
        $scope.nextDisabled = false;
        $scope.profitRank.length = 0;
        profitIndex = 1;
        if($scope.profitRankType==1){
            var friDate2 = $filter('date')($scope.fridayStr,'yyyyMMdd');
            if(friDate2==20180803){
                $scope.nextDisabled = true;
                profitRankFun(1,20180803,'');
            }else if(friDate2>20180803){
                $scope.nextDisabled = true;
            }else {
                if(getDateStr(friday)>=getDateStr(friday2)){
                    $scope.nextDisabled = true;
                }else{
                    monday = new Date(monday.getTime()+3600000*24*7);
                    friday = new Date(friday.getTime()+3600000*24*7);
                    if(getDateStr(friday)>=getDateStr(friday2)){
                        $scope.nextDisabled = true;
                    }
                }
                $scope.mondayStr = monday.getTime();
                $scope.fridayStr = friday.getTime();
                profitRankFun(1,getDateStr(friday),'');
            }
        }else if($scope.profitRankType==2){
            $scope.lastDisabled = false;
            $scope.nextDisabled = false;
            thisSeason++;
            if(thisSeason==1){
                $scope.lastDisabled = true;
                $scope.thisSeasonStr = '2017.08.07-2017.11.03';
            }else if(thisSeason==2){
                $scope.thisSeasonStr = '2017.11.06-2018.02.02';
            }else if(thisSeason==3){
                $scope.thisSeasonStr = '2018.02.05-2018.05.04';
            }else if(thisSeason==4){
                $scope.nextDisabled = true;
                $scope.thisSeasonStr = '2018.05.07-2018.08.03';
            };

            if(thisSeason>=thisSeason2){
                $scope.nextDisabled = true;
            }
            profitRankFun(2,'',thisSeason);
        }else if($scope.profitRankType==3){
            // profitRankFun(3,'','');
        }
    };


    var pageIndex2 = 1;
    $scope.profitData = [];
    $scope.getProfitRanking = function (type,date) {
        $scope.profitRankFun2 = {};
        $scope.profitRankFun2.type = type;
        $scope.profitRankFun2.date = date;
        $scope.profitRankFun2.pageIndex = pageIndex2;
        $scope.profitRankFun2.pageSize = 5;
        var promisess = apiFun.profitRankByTypeFun($scope.profitRankFun2);
        promisess.then(function(result) {
            if(result.code == 0){
                $.each(result.data,function(i) {
                    $scope.profitData.push(result.data[i]);
                });
            }
        });
    };
    $scope.getProfitRanking(3,'');

    $scope.periodIndex = 3;
    $scope.profitBtn= function (i) {
        $scope.periodIndex = i;
        pageIndex2 = 1;
        $scope.profitData.length = 0;
        if(i==3){
            $scope.getProfitRanking(3,'');
        }else if(i==1){
            $scope.getProfitRanking(1,getDateStr(friday2));
        }
    };



    $scope.bannerImg = function (type,id,uid) {
        if(type==1){//文章
            window.location.href ="";
        }else if(type==2){//短评
            //window.location.href ="";
        }else if(type==3){//视频或回放
            window.location.href ="/video?id="+id;
        }else if(type==4){//直播
            window.location.href ="/live?uid="+uid;
        }else if(type==5){//静态页面
            window.location.href =id;
        }else if(type==6){//个人主播页
            window.location.href ="/userProfile?uid="+uid;
        }else if(type==7){//不跳转
            //window.location.href ="http://www.baidu.com";
        }else if(type==8){//操盘手个人页
            // window.location.href ="/userProfile?uid="+uid;
        }else if(type==9){//个人实盘页
            window.location.href ="/userProfile?uid="+uid;
        }else if(type==10){//话题
            window.location.href ="/topicDetails?id="+id;
        }else if(type==11){//专栏详情页
            window.location.href ="/columnDetail?id="+id;
        }
    }

    $(document).ready(function () {
        function bannerDump(obj) {
            $(obj).on("click",function () {
                var type=$(this).attr("objectType");
                var id=$(this).attr("objectId");
                var uid=$(this).attr("uid");
                if(type==1){//文章
                    window.location.href ="/article?id="+id;
                }else if(type==2){//短评
                    //window.location.href ="";
                }else if(type==3){//视频或回放
                    window.location.href ="/video?id="+id;
                }else if(type==4){//直播
                    window.location.href ="/live?uid="+uid;
                }else if(type==5){//静态页面
                    window.location.href =id;
                }else if(type==6){//个人主播页
                    window.location.href ="/userProfile?uid="+uid;
                }else if(type==7){//不跳转
                    //window.location.href ="http://www.baidu.com";
                }else if(type==8){//操盘手个人页
                    window.location.href ="/userProfile?uid="+uid;
                }else if(type==9){//个人实盘页
                    window.location.href ="/userProfile?uid="+uid;
                }else if(type==10){//话题
                    window.location.href ="/topicDetails?id="+id;
                }else if(type==11){//专栏详情页
                    window.location.href ="/columnDetail?id="+id;
                }
            })
        };
        $("#scrollBar").mCustomScrollbar({
            callbacks:{
                onScrollStart:function(){},
                onScroll:function(){},
                onTotalScroll:function(){
                    pageIndex2++;
                    if($scope.periodIndex == 3){
                        $scope.getProfitRanking(3,'');
                    }else if($scope.periodIndex == 1){
                        $scope.getProfitRanking(1,getDateStr(friday2));
                    }
                },
                onTotalScrollBack:function(){},
                onTotalScrollOffset:80,
                whileScrolling:false,
                whileScrollingInterval:0
            },
            scrollInertia:300
        });
        $("#scrollBar1").mCustomScrollbar({
            callbacks:{
                onScrollStart:function(){},
                onScroll:function(){},
                onTotalScroll:function(){
                    profitIndex++;
                    if($scope.profitRankType==1){
                        profitRankFun(1,getDateStr(friday),'');
                    }else if($scope.profitRankType==2){
                        profitRankFun(2,'',thisSeason);
                    }else if($scope.profitRankType==3){
                        profitRankFun(3,'','');
                    }
                },
                onTotalScrollBack:function(){},
                onTotalScrollOffset:80,
                whileScrolling:false,
                whileScrollingInterval:0
            },
            scrollInertia:300
        });
        $.ajax({
            type: "post",
            url:"/api/v1/banner/selectByType.do",
            data: {
                "pageIndex": 1,
                "pageSize": 10,
                "type":31,
            },
            success: function (res) {
                if (res.code == 0) {
                    //console.log(res);
                    $(res.data).each(function(i,k) {
                        var imgUrl=k.imgUrl;
                        var bannerType=k.bannerType;
                        var id=k.id;
                        var uid=k.uid;
                        //console.log(bannerType);
                        var imgInner="<li class='bgImg'"+ " style='background-image: url("+imgUrl+")'"+   " objectId="+id+" objectType="+bannerType+" uid="+uid+"></li>";
                        $(".img").append(imgInner);
                    })
                    var size = $(".img li").length;
                    //console.log("size="+size);
                    for (var i = 1; i <= size; i++) {	//创建图片个数相对应的底部数字个数
                        var li = "<li>" + i + "</li>";	//创建li标签，并插入到页面中
                        // $(".num").append(li);
                    };
                    //手动控制图片轮播
                    $(".img li").eq(0).show();	//显示第一张图片
                    $(".num li").eq(0).addClass("active");	//第一张图片底部相对应的数字列表添加active类
                    $(".num li").mouseover(function () {
                        $(this).addClass("active").siblings().removeClass("active");  //鼠标在哪个数字上那个数字添加class为active
                        var index = $(this).index();  //定义底部数字索引值
                        i = index;  //底部数字索引值等于图片索引值
                        $(".img li").eq(index).stop().fadeIn(500).siblings().stop().fadeOut(500);	//鼠标移动到的数字上显示对应的图片
                    });
                    //自动控制图片轮播
                    var i = 0;  //初始i=0
                    var t = setInterval(move, 5000);  //设置定时器，1.5秒切换下一站轮播图
                    //向左切换函数
                    function moveL() {
                        i--;
                        if (i == -1) {
                            i = size - 1;  //如果这是第一张图片再按向左的按钮则切换到最后一张图
                        }
                        $(".num li").eq(i).addClass("active").siblings().removeClass("active");  //对应底部数字添加背景
                        $(".img li").eq(i).fadeIn(500).siblings().fadeOut(500);  //对应图片切换
                    };
                    //向右切换函数
                    function move() {
                        i++;
                        if (i == size) {
                            i = 0;  //如果这是最后一张图片再按向右的按钮则切换到第一张图
                        }
                        $(".num li").eq(i).addClass("active").siblings().removeClass("active");  //对应底部数字添加背景
                        $(".img li").eq(i).fadeIn(500).siblings().fadeOut(500);  //对应图片切换
                    };

                    //左按钮点击事件
                    $(".left").click(function () {
                        moveL();	//点击左键调用向左切换函数
                    });
                    //右按钮点击事件
                    $(".right").click(function () {
                        move();    //点击右键调用向右切换函数
                    });
                    //定时器开始与结束
                    $(".bannerAnimation").hover(function () {
                        clearInterval(t);	//鼠标放在轮播区域上时，清除定时器
                    }, function () {
                        t = setInterval(move, 5000);  //鼠标移开时定时器继续
                    })
                };
                bannerDump(".img li");
            }
        })
    });


}
]);

