$(document).ready(function () {
//	function liveProgressFun(uid,token,roomId){
////		var uid = 123481;
////      var token = "eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiIxMjM0ODEiLCJpYXQiOjE1MDg4Mzc4NzYsImV4cCI6MzA0OTIxMTc1Mn0.rtRhpmWOJCd4gmveH-z7KVaF6EqaA2BZk2Ia3WupRM4";
////      var roomId = "29";
//      uploadVideoImg(uid,token);
//      getLiveMessage(roomId);
//	}
    
    //关闭FMS及串流码弹框
    $("#closeStreaCodeFMS").click(function () {
    	$("#videoTitle1").val("");
    	$("#videoPwd1").val("");
        $(".streaCodeFMS").stop().hide();
    })
    //关闭创建视频直播弹框
    $("#closeCreateVideo").click(function () {
    	$("#videoTitle1").val("");
    	$("#videoPwd1").val("");
        $(".createVideo").stop().hide();
    })
    //取消创建视频直播弹框
    $("#cancalVideo").click(function () {
    	$("#videoTitle1").val("");
    	$("#videoPwd1").val("");
        $(".createVideo").stop().hide();
    })
    //重置串流码
    $("#reputCode").click(function () {
    	$("#videoTitle1").val("");
    	$("#videoPwd1").val("");
        $(".streaCodeFMS").stop().hide();
        $(".createVideo").stop().show();
    })
    //关闭填写参数流程弹框
    $(".closeWriteSteps").click(function () {
    	$("#videoTitle1").val("");
    	$("#videoPwd1").val("");
        $(".writeSteps").stop().hide();
    })
    //点击如何填入参数
    $(".drmpNext").click(function () {
    	//跳链接
//      $(".noticeDownload").stop().hide();
//      $(".writeSteps").stop().show();
    })
    //关闭提示下载弹框
    $(".closeNoticeDownload").click(function () {
    	$("#videoTitle1").val("");
    	$("#videoPwd1").val("");
        $(".noticeDownload").stop().hide();
    })
    // 点击
    $("#startOBS").click(function () {
    	$("#videoTitle1").val("");
    	$("#videoPwd1").val("");
        $(".streaCodeFMS").stop().hide();
        $(".noticeDownload").stop().show();
    })

   
    
    
})