$(document).ready(function () {
	//加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");


    /*回到顶部*/
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn()
        } else {
            $(".goTop").stop().fadeOut()
        }
    });
    $(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
    
    $("#temp1").Slide({
		effect: "scroolY",
		autoPlay: false,
		speed: "normal",
		timer: 3000,
		steps: 5
	});
    getList(1,10);
    //发现专栏
    function getList(pageIndex,pageSize){
    	$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/columnCategory/getList.do",
			data: {
				"type":1,//type	是	int	1-专栏，2-专题
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					$(res.data).each(function(i, k) {
						var getTagListId = k.id;
						var lunboId = k.id + "lunbo";
						var getTagListName = k.name;
						var prevId = k.id + "prev";
						var nextId = k.id + "next";
						//console.log(getTagListId);
						var slideBox =
							'<div class="slide-box">' +
							'<div class="slide-content" id="' + lunboId + '">' +
							'<div class="JQ-slide-nav">' +
							'<p class="fl">' + getTagListName + '</p>' +
							'<img class="next fr" id="' + nextId + '" src="images/rightBefore.png"/>' +
							'<img class="prev fr" id="' + prevId + '" src="images/leftBefore.png"/>' +
							'</div>' +
							'<div class="wrap">' +
							'<ul class="JQ-slide-content" id="' + getTagListId + '">' +

							'</ul>' +
							'</div>' +

							'</div>' +
							'</div>';
						$(".headColumnComment").append(slideBox);
						getColumnListByCategoryId(getTagListId, 1, 20, lunboId);
						$("#"+nextId).hover(function(){
							$(this).attr("src","../images/rightHover.png");
						},function(){
							$(this).attr("src","../images/rightBefore.png");
						});
						$("#"+prevId).hover(function(){
							$(this).attr("src","../images/leftHover.png");
						},function(){
							$(this).attr("src","../images/leftBefore.png");
						})
					});

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
    }
    
    function getColumnListByCategoryId(categoryId,pageIndex,pageSize,lunboId){
    	$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/api/v3/column/getColumnListByCategoryId.do",
			data: {
				"categoryId": categoryId,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					if(res.data.subjectList == undefined || res.data.subjectList == null || res.data.subjectList == "") {
						$("#" + lunboId).parent().remove();
					} else {
						$(res.data.subjectList).each(function(i, M) {
							var subscribeType=M.subscribeType;
							//console.log(subscribeType);//	订阅类型0-免费，1-周期性，2-一次性
							var subscribeType0=M.id+categoryId+"subscribeType0";//
							var subscribeType1=M.id+categoryId+"subscribeType1";//
							var subscribeType2=M.id+categoryId+"subscribeType2";//
						    var descriptionId=M.id+"description";
						    var getColumnListId=M.id+"getColumnListId";
						    var getColumnListIdCover=M.id+"getColumnListIdCover"+categoryId;
						    var charge= M.id + "charge" + categoryId;
							var getColumnList=
							'<li class="paidChoiceBoxBInfo fl" id='+getColumnListId+' objectId='+M.id+'>'+
								'<div class="paidChoiceBoxBInfoT">'+
									'<img id='+getColumnListIdCover+' src="'+M.coverUrl+'!150X200" />'+
									'<img id=' + charge + ' src="images/charge.png" />'+
									'<p>'+M.name+'</p>'+
								'</div>'+
								'<div class="paidChoiceBoxBInfoB">'+
									'<p id='+descriptionId+'>'+M.description+'</p>'+
									'<p>'+M.liverInfo.nickName+'</p>'+
									'<p id='+subscribeType1+'>'+M.subscribePay+'牛币/'+M.subscribeCycle+'天</p>'+
									'<p id='+subscribeType2+'>'+M.subscribePay+'牛币/全期</p>'+
									'<p id='+subscribeType0+'>免费</p>'+
								'</div>'+
							'</li>';
							$("#" + categoryId).append(getColumnList);
							if(subscribeType==0){
								$("#"+subscribeType1).stop().hide();
								$("#"+subscribeType2).stop().hide();
								$("#" + charge).stop().hide();
							}else if(subscribeType==1){
								$("#"+subscribeType0).stop().hide();
								$("#"+subscribeType2).stop().hide();
							}else if(subscribeType==2){
								$("#"+subscribeType0).stop().hide();
								$("#"+subscribeType1).stop().hide();
							}
							
							if(!M.description){
								$("#"+descriptionId).html("暂无更新");
							}
							
							$(document).on("click", "#" + getColumnListId, function(e) {
								var id = $(this).attr("objectId");
								window.location.href = "/columnDetail?id=" + id;
							});
							/*封面*/
                            $("#" + getColumnListIdCover).one("error", function(e) {
								$(this).attr("src", "images/hotNull.png");
							});                        
		
						})

						$("#" + lunboId).Slide({
							//						effect: "scroolLoop",
							effect: "scroolY",
							autoPlay: false,
							speed: "normal",
							timer: 3000,
							steps: 4
						});
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus)
			},
		});
    	
    	
    }
    
   
    
    
    
    
    
    
})