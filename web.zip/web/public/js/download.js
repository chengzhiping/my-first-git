$(document).ready(function() {
	$("#article_footer").load("footer.html");
	$(".downloadListInfo").click(function() {
		$(this).addClass("active").siblings(".downloadListInfo").removeClass("active");
		$("#downloadInnerWrap .downloadInnerTab").eq($(this).index()).css("display", "block").siblings(".downloadInnerTab").css("display", "none")
	});

	function GetQueryString(name) {
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
		var r = window.location.search.substr(1).match(reg);
		if(r != null) {
			return unescape(r[2])
		}
		return null
	}
	var type = GetQueryString("type");
	if(type != null) {
		if(type == "toToolDownload") {
			$("#toToolDownload").addClass("active").siblings(".downloadListInfo").removeClass("active");
			$("#appDownload").stop().hide().siblings(".downloadInner").stop().show()
		} else {
			$("#toAppDownload").addClass("active").siblings(".downloadListInfo").removeClass("active");
			$("#toolDownload").stop().hide().siblings(".downloadInner").stop().show()
		}
	}
	$("#wrap_header").load("/header");
	//加载底部
	$("#article_footer").load("/footer");
});