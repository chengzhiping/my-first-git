var id;
$(document).ready(function() {
	var imgArr = [];
	var uid;
	var usertoken;
    var trumbowygHtml;
    var num;
    $(".trumbowyg-editor").on("keyup", function() {
        trumbowygHtml = $(".trumbowyg-editor").html();
        isablePublish();
    })
    $("#article_title").on("keyup", function() {
        /*字数倒计数*/
        num = $(this).val().length;
        isablePublish();
    });
    function isablePublish() {
        if(num>0 && trumbowygHtml!="" && num !=undefined && trumbowygHtml != undefined) {
            $("#publish_to").css({
                "background":"#fe4502"
            });
            $('#publish_to').removeAttr("disabled");
        }else {
            $("#publish_to").css({
                "background": "#d8d8d8"
            });
            $('#publish_to').attr("disabled", "disabled");
        }
    }

    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function (res) {
            // console.log(res);
            if (res.code == -2) { //未登录
                $("#publish_to").on("click",function(){
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
            }else if(res.code==0){//已登录
                //console.log(res);
                uid = res.data.userInfo.uid;
                usertoken = res.data.token;
                //获取我的专栏
                $.ajax({
                    type: "post", //请求方式
                    async: true, //是否异步
                    dataType: "json",
                    url: "/api/v3/column/getColumnByUid.do",
                    data: {
                        "uid": uid,
                        "type": 2,
                        "pageIndex":1,
                        "pageSize":20
                    },
                    success: function (res) {
                       // console.log(res);
                        if (res.code == 0) {
                            $(res.data).each(function (i, k) {
                                var columnName = k.name;
                                var columnId =k.id;
                               // console.log(columnId);
                                var selectColumn = "<option id="+columnId+">"+columnName+"</option>";
                                $(".top_article select").append(selectColumn);
                            })
                        }
                    }
                })
                $.ajax({
                    type: "get", //请求方式
                    async: true, //是否异步
                    dataType: "json",
                    url: "/api/v1/picture/batchUpload/token.do",
                    data: {
                        "uid": uid,
                        "token": usertoken,
                    },
                    success: function(res) {
                        //console.log(res);
                        if(res.code == 0) {
                            var articleimgtoken = res.data.uploadToken;
                            //console.log(articleimgtoken);
                            //七牛上传封面图片
                            var uploader1 = Qiniu.uploader({
                                runtimes: 'html5,flash,html4', //上传模式,依次退化
                                browse_button: 'add', //上传选择的点选按钮，**必需**
                                uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                                uptoken: articleimgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                                uptoken_func: function(file) {},
                                unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                                save_key: false, // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                                domain: 'upload.qbox.me', //bucket域名，下载资源时用到，**必需**
                                get_new_uptoken: true, //设置上传文件的时候是否每次都重新获取新的token
                                container: 'coverImg', //上传区域DOM ID，默认是browser_button的父元素，
                                max_file_size: '100mb', //最大文件体积限制
                                flash_swf_url: 'js/Moxie.swf', //引入flash,相对路径
                                max_retries: 3, //上传失败最大重试次数
                                dragdrop: true, //开启可拖曳上传
                                drop_element: 'coverImg', //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                                chunk_size: '4mb', //分块上传时，每片的体积
                                auto_start: true, //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                                init: {
                                    'FilesAdded': function(up, files) {
                                        // plupload.each(files, function(file) {
                                        //    // 文件添加进队列后,处理相关的事情
                                        // });
                                    },
                                    'BeforeUpload': function(up, file) {
                                        // 每个文件上传前,处理相关的事情
                                    },
                                    'UploadProgress': function(up, file) {
                                        // 每个文件上传时,处理相关的事情
                                    },
                                    'FileUploaded': function(up, file, info) {
                                        var imgInfo = JSON.parse(info);
                                        var imgUrl = "https://picture.fengniutv.com/" + imgInfo.key;
                                       // var imgUrl = "http://picture.91qiniu.com/" + imgInfo.key;
                                       // console.log(imgUrl);
                                        $(".coverImg .coverImgImg").attr("src",imgUrl);
                                        $("#add").stop().hide();
                                        $(".coverImg .replace").stop().show();
                                        $("#deleteImg").click(function () {
                                            $(".coverImg .coverImgImg").attr("src","");
                                            $("#add").stop().show();
                                            $(".coverImg .replace").stop().hide();
                                        })
                                    },
                                    'Error': function(up, err, errTip) {
                                        // console.log(errTip);
                                        //上传出错时,处理相关的事情
                                    },
                                    'UploadComplete': function() {
                                        //队列文件处理完毕后,处理相关的事情
                                    },
                                },
                            });
                            //七牛更换封面图片
                            var uploader1 = Qiniu.uploader({
                                runtimes: 'html5,flash,html4', //上传模式,依次退化
                                browse_button: 'repalceImg', //上传选择的点选按钮，**必需**
                                uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                                uptoken: articleimgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                                uptoken_func: function(file) {},
                                unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                                save_key: false, // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                                domain: 'upload.qbox.me', //bucket域名，下载资源时用到，**必需**
                                get_new_uptoken: true, //设置上传文件的时候是否每次都重新获取新的token
                                container: 'coverImg', //上传区域DOM ID，默认是browser_button的父元素，
                                max_file_size: '100mb', //最大文件体积限制
                                flash_swf_url: 'js/Moxie.swf', //引入flash,相对路径
                                max_retries: 3, //上传失败最大重试次数
                                dragdrop: true, //开启可拖曳上传
                                drop_element: 'coverImg', //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                                chunk_size: '4mb', //分块上传时，每片的体积
                                auto_start: true, //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                                init: {
                                    'FilesAdded': function(up, files) {
                                        // plupload.each(files, function(file) {
                                        //    // 文件添加进队列后,处理相关的事情
                                        // });
                                    },
                                    'BeforeUpload': function(up, file) {
                                        // 每个文件上传前,处理相关的事情
                                    },
                                    'UploadProgress': function(up, file) {
                                        // 每个文件上传时,处理相关的事情
                                    },
                                    'FileUploaded': function(up, file, info) {
                                        var imgInfo = JSON.parse(info);
                                        var imgUrl = "https://picture.fengniutv.com/" + imgInfo.key;
                                        //var imgUrl = "http://picture.91qiniu.com/" + imgInfo.key;
                                       // console.log(imgUrl);
                                        $(".coverImg .coverImgImg").attr("src",imgUrl);
                                    },
                                    'Error': function(up, err, errTip) {
                                        // console.log(errTip);
                                        //上传出错时,处理相关的事情
                                    },
                                    'UploadComplete': function() {
                                        //队列文件处理完毕后,处理相关的事情
                                    },
                                },
                            });
                            //七牛上传文章图片
                            var uploader = Qiniu.uploader({
                                runtimes: 'html5,flash,html4', //上传模式,依次退化
                                browse_button: 'addImgIcon', //上传选择的点选按钮，**必需**
                                uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                                uptoken: articleimgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                                uptoken_func: function(file) {},
                                unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                                save_key: false, // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                                domain: 'upload.qbox.me', //bucket域名，下载资源时用到，**必需**
                                get_new_uptoken: true, //设置上传文件的时候是否每次都重新获取新的token
                                container: 'customized-buttonpane', //上传区域DOM ID，默认是browser_button的父元素，
                                max_file_size: '100mb', //最大文件体积限制
                                flash_swf_url: 'js/Moxie.swf', //引入flash,相对路径
                                max_retries: 3, //上传失败最大重试次数
                                dragdrop: true, //开启可拖曳上传
                                drop_element: 'customized-buttonpane', //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                                chunk_size: '4mb', //分块上传时，每片的体积
                                auto_start: true, //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                                init: {
                                    'FilesAdded': function(up, files) {
                                        // plupload.each(files, function(file) {
                                        //    // 文件添加进队列后,处理相关的事情
                                        // });
                                    },
                                    'BeforeUpload': function(up, file) {
                                        // 每个文件上传前,处理相关的事情
                                    },
                                    'UploadProgress': function(up, file) {
                                        // 每个文件上传时,处理相关的事情
                                    },
                                    'FileUploaded': function(up, file, info) {
                                        var imgInfo = JSON.parse(info);
                                        var imgUrl = "https://picture.fengniutv.com/" + imgInfo.key;
                                        //var imgUrl = "http://picture.91qiniu.com/" + imgInfo.key;
                                        imgArr.push(imgUrl);
                                        // console.log(imgArr);
                                        var img1 = "<img src='" + imgUrl + "' alt='' >";
                                        $(".trumbowyg-editor").append(img1);
                                    },
                                    'Error': function(up, err, errTip) {
                                        // console.log(errTip);
                                        //上传出错时,处理相关的事情
                                    },
                                    'UploadComplete': function() {
                                        //队列文件处理完毕后,处理相关的事情
                                    },
                                },
                            });
                        }
                    },
                });
                $("#publish_to").on("click", function() {
                    var view = $(".trumbowyg-editor").html();
                    var article_title = $("#article_title").val();
                    var userCoverUrl = $(".coverImgImg").attr("src");
                    var lead = $("#article_lead").val();
                    //console.log(lead);
                    var columnId = $(".top_article select option:selected").attr("id");
                    if(view == "" || article_title == "") {
                        $("#over").css({
                            "display": "block",
                        });
                        $("#msg").css({
                            "display": "block",
                        })
                    } else {
                        $.ajax({
                            dataType: "json",
                            type: "post",
                            async: true,
                            url: "/api/v2/article/saveOrUpdate.do",
                            data: {
                                "uid": uid,
                                "token": usertoken,
                                "type": 2,
                                "content": view,
                                "title": article_title,
                                "lead": lead,
                                "userCoverUrl": userCoverUrl,
                                "columnId": columnId
                            },
                            success: function(res) {
                                console.log(res);
                                if(res.code == 0) {
                                    id = res.data;
                                    //console.log(view);
                                    window.location.href = "article?" + "id=" + id;
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus)
                            },
                        })
                    }
                });
            }
        }
    })
	$("#closed").on("click", function() {
		$("#over").css({
			"display": "none"
		});
		$("#msg").css({
			"display": "none"
		})
	});
	$("#wrap_header").load("header");
});