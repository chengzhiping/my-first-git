window.onload = function(){
	Vue.filter('capitalize', function (value) {
	  	if(value.length>45){
	  		value = value.substring(0,43)+"..."
	  	}
	  	return value
	})
	var vm = new Vue({
		el:"#wrap",
		data:{			
			profitA:true,
			profitB:false,
			profitC:false,
			hotData:[{
				title:'数字数字水煮是噻发积分卡拉萨会计分录撒娇奥斯卡了地方撒六块腹肌奥斯卡了的法律的临时卡的感觉老是卡攻击力卡送过来卢萨卡几点过来撒可根据',
				name:11,
				main:"电子书的主要格式有PDF、EXE、CHM、UMD、PDG、JAR、PDB、TXT、BRM等等，很多流行移动设备都是支持其阅读格式的。手机终端常见的电子书格式为UMD、JAR、TXT这三种。TXT格式的电子书是被手机普遍支持的一种文字格式电子书，这种格式的电子书容量大，所占空间小，所以得到广大爱看电子书人们的支持,而更因为这种格式为手机普遍支持的电子书格式，所以也得到广大手机用户的肯定和喜爱。对于部分手机因无附带TXT电子书阅读器的手机用户，在此向大家推荐一款软件“MOTO TXT”（S40手机可安装此软件）。而随着TXT格式电子书受到越来越多的人们的喜爱，对于TXT格式电子书的需求也逐渐增加。"
			},{
				title:'123456',
				name:22,
				main:"电子书的主要格式有PDF、EXE、CHM、UMD、PDG、JAR、PDB、TXT、BRM等等，很多流行移动设备都是支持其阅读格式的。手机终端常见的电子书格式为UMD、JAR、TXT这三种。TXT格式的电子书是被手机普遍支持的一种文字格式电子书，这种格式的电子书容量大，所占空间小，所以得到广大爱看电子书人们的支持,而更因为这种格式为手机普遍支持的电子书格式，所以也得到广大手机用户的肯定和喜爱。对于部分手机因无附带TXT电子书阅读器的手机用户，在此向大家推荐一款软件“MOTO TXT”（S40手机可安装此软件）。而随着TXT格式电子书受到越来越多的人们的喜爱，对于TXT格式电子书的需求也逐渐增加。"
			}]
		},
		computed:{
			rotateStyle:function(){
				return {}
			}
		},
		mounted:function(){	
			this.fetchData(0);
			this.loadHTML();
		},
		methods:{				
			loadHTML:function(){
				//加载右侧栏，并导入原文件js
				$("#sideBarRight").load("/sideBarRight",function(responseTxt,statusTxt,xhr){
					if(statusTxt=="success")
				    	$result = $(responseTxt); 
	       				$result.find("script").appendTo('#sideBarRight');						
				    if(statusTxt=="error")
				      	console.log('页面加载右侧栏失败')
				})
				//判断在宽度小于1370的屏幕上加载时，缩小左右浮动直接的距离
				var width = document.getElementsByTagName("html")[0].getBoundingClientRect().width;
				if(width<1370){
					$("#wrap").css('width','13.45rem')
				}else{
					$("#wrap").css('width','13.7rem')
				}
				//文本溢出隐藏
				var module = $(".hotMainBoxRight p")
				for(var i=0;i<module.length;i++){
					$clamp(module[i], {clamp: 3});
				}
				
			},
			changeProfit:function(n){
				var This=this;
				This.profitA=false;
				This.profitB=false;
				This.profitC=false;
				switch(n){
					case 0:
						This.profitA=true;
						break
					case 1:
						This.profitB=true;
						break
					case 2:
						This.profitC=true;
						break
				}
				This.fetchData(n);
			},
			fetchData:function(n){
//				$.ajax({
//					type: "GET",
//		            url: "https://dev.fntv8.com/fntv/api/v1/quotation/getQuotation.do",
//		            data: {
//		            	pageIndex:5,
//		            	pageSize:5
//		            },
//		            dataType: "json",
//		            success: function(data){
//                      console.log(data.data)
//                  },
//                  error:function(data){
//                 		console.log(data)
//                  }
//				})
				var a=10*n+4;
				var This=this;
				var data=[{
					rotate:-99.22,
					name:1
				},{
					rotate:83.25,
					name:2
				},{
					rotate:a,
					name:3
				},{
					rotate:63.16,
					name:4
				},{
					rotate:-23.15,
					name:5
				},{
					rotate:-88.25,
					name:6
				}]
				var html='';
				for(var i=0;i<3;i++){
					html+='<li class="profitMainBox">'
					html+=		'<div class="profitMainBoxLeft">'
					html+=			'<div class="profitMainBoxIcon">'
					html+=				'<div class="profitMainBoxIconBox">'
					html+=					'<img src="../images/v5.3/investment/No.'+(i+1)+'.png" alt="" width="100%" height="100%"/>'
					html+=				'</div>'
					html+=			'</div>'
					html+=			'<div class="profitCanvas">'
					html+=				'<div class="profitWarp"> ' 
					html+=					'<div class="wrapper profitLeft">'
					if(data[i].rotate<0){
						html+='<div class="circleProgress leftcircle leftGreen" style="transform:rotate('+(-data[i].rotate>50?-data[i].rotate*3.6-315:-135)+'deg)"></div>'
					}else{
						html+='<div class="circleProgress leftcircle" style="transform:rotate('+(data[i].rotate>50?data[i].rotate*3.6-315:-135)+'deg)"></div>'
					}
					html+=					 '</div>'
					html+=					 '<div class="wrapper profitRight">'
					if(data[i].rotate<0){					
						html+='<div class="circleProgress rightcircle rightGreen" style="transform:rotate('+(-data[i].rotate*3.6-135>45?45:(-135-data[i].rotate*3.6))+'deg)"></div>	'
					}else{
						html+='<div class="circleProgress rightcircle" style="transform:rotate('+(data[i].rotate*3.6-135>45?45:data[i].rotate*3.6-135)+'deg)"></div>	'
					}												    	
					html+=					 '</div>'
					html+=					 '<div class="profitWarpBg">'
					if(data[i].rotate<0){
						html+='<span style="color:#31bc6d;">'+data[i].rotate+'%</span><span>收益</span>'
					}else{
						html+='<span>'+data[i].rotate+'%</span><span>收益</span>'
					}					
					html+=				     '</div>'
					html+=				'</div>'	  
					html+=			'</div>'	
					html+=		'</div>'	
					html+=		'<div class="profitMainBoxRight">'	
					html+=			'<div class="profitMainBoxRightTop">'	
					html+=				'<div class="profitMainBoxTitle">'
					html+=					'XXXXXXXXXXXXXXX长度还没限定'
					html+=					'<div class="profitMainBoxTitleIcon"></div>'
					html+=				'</div>'
					html+=			'</div>'	
					html+=			'<div class="profitMainBoxRightBottom">'
					html+=				'<span><img src="http://pic42.nipic.com/20140617/7003505_213800766156_2.jpg" alt="图标" width="100%" height="100%" /></span>'
					html+=				'<span>XXXX</span><span>27分前</span><span>脱水干货</span>'																				
					html+=			'</div>'
					html+=		'</div>'
					html+='</li>'
				}
				$('.profitMainF').html(html)
				var html2=''
				for(var i=3;i<data.length;i++){
					html2+='<li class="profitMainBox">'
					html2+=		'<div class="profitMainBoxLeft">'
					html2+=			'<div class="profitMainBoxIcon">'
					html2+=				'<div class="profitMainBoxIconBox">'
					html2+=					'<img src="../images/v5.3/investment/No.'+(i+1)+'.png" alt="" width="100%" height="100%"/>'
					html2+=				'</div>'
					html2+=			'</div>'
					html2+=			'<div class="profitCanvas">'
					html2+=				'<div class="profitWarp"> ' 
					html2+=					'<div class="wrapper profitLeft">'
					if(data[i].rotate<0){
						html2+='<div class="circleProgress leftcircle leftGreen" style="transform:rotate('+(-data[i].rotate>50?-data[i].rotate*3.6-315:-135)+'deg)"></div>'
					}else{
						html2+='<div class="circleProgress leftcircle" style="transform:rotate('+(data[i].rotate>50?data[i].rotate*3.6-315:-135)+'deg)"></div>'
					}
					html2+=					 '</div>'
					html2+=					 '<div class="wrapper profitRight">'
					if(data[i].rotate<0){					
						html2+='<div class="circleProgress rightcircle rightGreen" style="transform:rotate('+(-data[i].rotate*3.6-135>45?45:(-135-data[i].rotate*3.6))+'deg)"></div>	'
					}else{
						html2+='<div class="circleProgress rightcircle" style="transform:rotate('+(data[i].rotate*3.6-135>45?45:data[i].rotate*3.6-135)+'deg)"></div>	'
					}												    	
					html2+=					 '</div>'
					html2+=					 '<div class="profitWarpBg">'
					if(data[i].rotate<0){
						html2+='<span style="color:#31bc6d;">'+data[i].rotate+'%</span><span>收益</span>'
					}else{
						html2+='<span>'+data[i].rotate+'%</span><span>收益</span>'
					}	
					html2+=				     '</div>'
					html2+=				'</div>'	  
					html2+=			'</div>'	
					html2+=		'</div>'	
					html2+=		'<div class="profitMainBoxRight">'	
					html2+=			'<div class="profitMainBoxRightTop">'	
					html2+=				'<div class="profitMainBoxTitle">'
					html2+=					'XXXXXXXXXXXXXXX长度还没限定'
					html2+=					'<div class="profitMainBoxTitleIcon"></div>'
					html2+=				'</div>'
					html2+=			'</div>'	
					html2+=			'<div class="profitMainBoxRightBottom">'
					html2+=				'<span><img src="http://pic42.nipic.com/20140617/7003505_213800766156_2.jpg" alt="图标" width="100%" height="100%" /></span>'
					html2+=				'<span>XXXX</span><span>27分前</span><span>脱水干货</span>'																				
					html2+=			'</div>'
					html2+=		'</div>'
					html2+='</li>'
				}
				$('.profitMainS').html(html2)			
			}
		}
	});
}
