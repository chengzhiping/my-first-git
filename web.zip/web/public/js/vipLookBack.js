$(document).ready(function() {
    var uid = GetQueryString("uid");
    var roomid = GetQueryString("roomid");
    var playbackId = GetQueryString("id");
    var userId;
    var userToken;
    var userNickName;
    var userNickHeadurl;
    var target;
    var chatRoomId;
    var D;
    var media = [];
    var imgCount = 0;
    var selSess = null;
    var groupId;
    var kindStatus;
    var lastliveMsgId;
    var lastChatMsgId;
    var selToID;
    $("#header").load("/header");
    $("#footer").load("/footer");
    $(".liveTab .liveTabUl li").click(function() {
        var index = $(this).index();
        $(this).addClass("tabhover").siblings("li").removeClass("tabhover");
        $(".tabcontent").eq(index).show(200).siblings(".tabcontent").hide()
    });
    $(".shareBtn").hover(function() {
        $(".share_inner").stop().show()
    },
    function() {
        $(".share_inner").stop().hide()
    });
    $(".codeBtn").hover(function() {
        $(".erweima").stop().show()
    },
    function() {
        $(".erweima").stop().hide()
    });
    $(".downApp").hover(function() {
        $(".erweima1").stop().show()
    },
    function() {
        $(".erweima1").stop().hide()
    });
    $(".payMoneyInner .closePay").click(function() {
        $(".payMoney").stop().hide()
    });
    $(".alertClose").click(function() {
        $("#n_money").stop().hide();
        $("#exceptWrap").stop().hide();
        clearInterval(intervalTime)
    });
    $(".weChatClose").click(function() {
        $(".weChatCodeWrap").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatSuccessClose").click(function() {
        $(".weChatPaySuccess").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatOweWrapClose").click(function() {
        $(".weChatOweWrap").css("display", "none");
        $("#exceptWrap").stop().hide()
    });
    $("body").css("background", "#ffffff");
    $(".achor").stop().hide();
    $(".shareBtn").stop().hide();
    $(".livingBox").stop().show();
    $(".activity").stop().show();
    $(".liveTab .liveTabUl").css("width", "836px");
    $(".liveNewBody .chatCenter").css({
        "top": "-12px",
        "height": "600px"
    });
    $(".liveNewBody .chatCenter .chatTitle").css({
        "background": "#e7e7e7",
        "margin-bottom": "0"
    });
    $(".liveNewBody .chat").css("height", "540px");
    $(".money_listinfo").click(function() {
        $(this).addClass("click_effect").siblings().removeClass("click_effect")
    });
    /*function qiniuVideo(playBtn, playUrl, playImg) {
        var player = new TcPlayer(playBtn, {
            "m3u8": playUrl,
            "autoplay": true,
            "coverpic": playImg,
            "width": "840",
            "height": "510"
        })
    }*/
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v3/live/getLiveRoomInfo.do",
        data: {
            "roomId": roomid
        },
        success: function(res) {
        	console.log(res);
            if (res.code == 0) {
                chatRoomId = res.data.chatRoomId;
                groupId = chatRoomId;
                $(".liveContentAnchor1 .fansCount").html(res.data.subscribers.count);
                $(".payMoneyInner .topic").html(res.data.roomName);
                $(".payMoneyInner .howmany").html(res.data.subscribePay);
                if (res.data.subscribeCycle) {
                    $(".payMoneyInner .howlong").html(res.data.subscribeCycle + "天")
                };
                if(res.data.liverInfo.headImgUrl == "" || res.data.liverInfo.headImgUrl == undefined){
                }else{
                    $(".anchorSameNickImg").attr("src",res.data.liverInfo.headImgUrl);
                };
                //跳转到主播个人页
                $(".anchorSameNickImg").click(function(){
                	window.location.href="/userProfile?uid="+uid;
                })
                var subscribePay = res.data.subscribePay;
                var type = res.data.type;
                if (type == 1) {
                    $.ajax({
                        type: "get",
                        url: "/userInfos",
                        success: function(res) {
                            if (res.code == -2) {
                                $("#loginAlert").stop().show();
                                $("#loginAlert").load("/login")
                            } else {
                                if (res.code == 0) {
                                    userId = res.data.userInfo.uid;
                                    userToken = res.data.token;
                                    if (userId != uid) {
                                        $.ajax({
                                            type: "post",
                                            async: true,
                                            dataType: "json",
                                            url: "/api/v3/live/getLiveRoomInfo.do1",
                                            data: {
                                                "roomId": roomid,
                                                "uid": userId,
                                                "token": userToken,
                                            },
                                            success: function(res) {
                                                if (res.code == 0) {
                                                    var subscribed = res.data.subscribed;
                                                    if (subscribed) {
                                                        $(".getFollowBtn").html("已订阅");
                                                        $(".getFollowBtn").css({
                                                            "background": "#C6C6C6"
                                                        });
                                                        getPlaybackVideo2(playbackId, userId, userToken)
                                                    } else {
                                                        $(".payMoney").stop().show();
                                                        $(".payMoneyInner .gotoPay").click(function() {
                                                            $.ajax({
                                                                type: "post",
                                                                async: true,
                                                                dataType: "json",
                                                                url: "/api/v2/subscribe/insert.do",
                                                                data: {
                                                                    "uid": userId,
                                                                    "token": userToken,
                                                                    "type": 2,
                                                                    "objectId": roomid
                                                                },
                                                                success: function(res) {
                                                                    if (res.code == 0) {
                                                                        setTimeout("location.reload()", 1000);
                                                                        getPlaybackVideo2(playbackId, userId, userToken)
                                                                    } else {
                                                                        if (res.code == -706) {
                                                                            $(".payMoney").stop().hide();
                                                                            $("#exceptWrap").stop().show();
                                                                            $(".weChatOweWrap").stop().show();
                                                                            $(".weChatOweWrapClose").stop().hide();
                                                                            $(".weChatErrorEnter").click(function() {
                                                                                $(".weChatOweWrap").stop().hide();
                                                                                $("#n_money").stop().show();
                                                                                $(".alertClose").stop().hide();
                                                                                $(".payBtn").click(function() {
                                                                                    var totalFee = "";
                                                                                    if ($(".qitaMoney").val() != "") {
                                                                                        totalFee = parseInt($(".qitaMoney").val())
                                                                                    } else {
                                                                                        totalFee = parseInt($(".money_list").find(".click_effect").children().text())
                                                                                    }
                                                                                    $(".weChatPayNum").html(totalFee);
                                                                                    $.ajax({
                                                                                        type: "POST",
                                                                                        async: true,
                                                                                        dataType: "json",
                                                                                        url: "/api/v1/order/wxUnifiedOrder.do",
                                                                                        data: {
                                                                                            "uid": userId,
                                                                                            "totalFee": totalFee,
                                                                                            "tradeType": "NATIVE",
                                                                                            "token": userToken,
                                                                                        },
                                                                                        success: function(res) {
                                                                                            if (res.code == 0) {
                                                                                                $("#n_money").fadeOut(1);
                                                                                                $("#exceptWrap").fadeIn(1);
                                                                                                $(".weChatCodeWrap").fadeIn(1);
                                                                                                $(".weChatClose").stop().hide();
                                                                                                var codeUrl = res.data.codeUrl;
                                                                                                var outTradeNo = res.data.outTradeNo;
                                                                                                jQuery("#weChatPayCode").qrcode({
                                                                                                    render: "canvas",
                                                                                                    foreground: "#000",
                                                                                                    background: "#FFF",
                                                                                                    width: 180,
                                                                                                    height: 180,
                                                                                                    text: codeUrl,
                                                                                                    correctLevel: 2
                                                                                                });
                                                                                                intervalTime = setInterval(function() {
                                                                                                    $.ajax({
                                                                                                        type: "POST",
                                                                                                        async: true,
                                                                                                        dataType: "json",
                                                                                                        url: "/api/v1/order/wxFrontNotify.do",
                                                                                                        data: {
                                                                                                            "uid": userId,
                                                                                                            "outTradeNo": outTradeNo,
                                                                                                            "token": userToken,
                                                                                                        },
                                                                                                        success: function(res) {
                                                                                                            if (res.code == 0) {
                                                                                                                $(".weChatCodeWrap").stop().hide();
                                                                                                                $(".weChatPaySuccess").stop().show();
                                                                                                                setTimeout("location.reload()", 1000)
                                                                                                            }
                                                                                                        },
                                                                                                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                                                                                                            console.log(XMLHttpRequest.status);
                                                                                                            console.log(XMLHttpRequest.readyState);
                                                                                                            console.log(textStatus)
                                                                                                        }
                                                                                                    })
                                                                                                },
                                                                                                3000)
                                                                                            }
                                                                                        },
                                                                                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                                                                                            console.log(XMLHttpRequest.status);
                                                                                            console.log(XMLHttpRequest.readyState);
                                                                                            console.log(textStatus)
                                                                                        }
                                                                                    })
                                                                                })
                                                                            })
                                                                        }
                                                                    }
                                                                }
                                                            })
                                                        })
                                                    }
                                                }
                                            }
                                        })
                                    } else {
                                        if (uid == userId) {
                                            $(".liveFollow").stop().hide();
                                            zhuboGetVideo(playbackId, userId, userToken)
                                        }
                                    }
                                }
                            }
                        }
                    })
                } else {
                    if (uid == userId) {
                        $(".liveFollow").stop().hide();
                        zhuboGetVideo(playbackId, userId, userToken)
                    } else {
                        $.ajax({
                            type: "post",
                            async: true,
                            dataType: "json",
                            url: "/api/v3/live/getLiveRoomInfo.do1",
                            data: {
                                "roomId": roomid,
                                "uid": userId,
                                "token": userToken,
                            },
                            success: function(res) {
                                if (res.code == 0) {
                                    var subscribed = res.data.subscribed;
                                    if (subscribed == true) {
                                        $(".getFollowBtn").html("已订阅");
                                        $(".getFollowBtn").css({
                                            "background": "#C6C6C6"
                                        })
                                    }
                                }
                            }
                        });
                        $(".getFollowBtn").click(function() {
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/live/getLiveRoomInfo.do1",
                                data: {
                                    "roomId": roomid,
                                    "uid": userId,
                                    "token": userToken,
                                },
                                success: function(res) {
                                    if (res.code == 0) {
                                        var subscribed = res.data.subscribed;
                                        if (subscribed == true) {
                                            $(".getFollowBtn").html("已订阅");
                                            $(".getFollowBtn").css({
                                                "background": "#C6C6C6"
                                            });
                                            cancelDingyue()
                                        } else {
                                            dingyue()
                                        }
                                    }
                                }
                            })
                        })
                    }
                }
            }
        }
    });
    function zhuboGetVideo(playbackId, userId, userToken) {
        $.ajax({
            dataType: "json",
            type: "POST",
            async: true,
            url: "/api/v3/live/getVideoLivePlaybackInfo3.do",
            data: {
                "id": playbackId,
                "uid": userId,
                "token": userToken
            },
            success: function(res) {
                if (res.code == 0) {
                    $("#vedio_masked").stop().hide();
                    var createTime = res.data.createTime;
                    $(".liveContentAnchor1 .liveTitle").html(res.data.topic);
                    $(".liveContentAnchor1B .anchorName").html("来自" + res.data.liverInfo.nickName + "的直播间");
                    $(".liveContentAnchor1B .watchNum").html(res.data.watchCount + "人观看");
                    $(".liveContentAnchor1B .publishTime").html(format(new Date(res.data.createTime)));
                    // qiniuVideo("id_test_video", res.data.playUrl, res.data.coverUrl);
                    $(".myVideo").attr("poster",res.data.coverUrl);
                   // $(".myVideo").attr("src",res.data.playUrl);
                    getVideoDetails(res);
                } else {
                    if (res.code == -111) {
                        $(".error_ts").html("密码错误");
                        $(".error_ts").fadeIn(100).delay(4000).fadeOut(100)
                    }
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus)
            },
        })
    }
    getLiveRoomMsgByUid("", roomid, 1, uid, 10);
    getLiveRoomMsgByUid("", roomid, 2, uid, 10);
    function dingyue() {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v2/subscribe/insert.do",
            data: {
                "uid": userId,
                "token": userToken,
                "type": 2,
                "objectId": roomid
            },
            success: function(res) {
                if (res.code == 0) {
                    var num = Number($(".fansCount").html());
                    $(".fansCount").html(num + 1);
                    $(".getFollowBtn").html("已订阅");
                    $(".getFollowBtn").css({
                        "background": "#C6C6C6"
                    })
                }
            }
        })
    }
    function cancelDingyue() {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v3/subscribe/deleteSubscribe.do",
            data: {
                "uid": userId,
                "token": userToken,
                "type": 2,
                "objectId": roomid
            },
            success: function(res) {
                if (res.code == 0) {
                    $(".getFollowBtn").html("订阅");
                    $(".getFollowBtn").css({
                        "background": "#ff5038"
                    });
                    var num = Number($(".fansCount").html());
                    $(".fansCount").html(num - 1)
                }
            }
        })
    }
    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function(res) {
            if (res.code == -2) {
                kindStatus = 1;
                alertLoginFun(".isLog");
                alertLoginFun(".sendGiftBtn");
                alertLoginFun(".payMoneyBtn ");
                alertLoginFun("#sendMsgBtn ");
                alertLoginFun(".getFollowBtn ");
                getPlaybackVideo(playbackId);
                var data = new Date();
                var time = data.getTime() + "";
                var num = parseInt(1000000 * Math.random()) + "";
                userId = (time + num);
                $.ajax({
                    dataType: "json",
                    type: "POST",
                    async: true,
                    url: "/api/v1/im/createSig.do",
                    data: {
                        "uid": userId,
                    },
                    success: function(res) {
                        if (res.code == 0) {
                            userSig = res.data;
                            userNickHeadurl = "https://picture.fengniutv.com/anchorHead.png";
                            //获取chatRoomId
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/live/getLiveRoomInfo.do",
                                data: {
                                    "roomId": roomid
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        chatRoomId = res.data.chatRoomId;
                                        // console.log("chatRoomId = "+chatRoomId);
                                        if (chatRoomId) {
                                            chatRoom(chatRoomId, userSig, userId, "游客", userNickHeadurl, "")
                                        }
                                    }
                                }
                            })
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        console.log(XMLHttpRequest.status);
                        console.log(XMLHttpRequest.readyState);
                        console.log(textStatus)
                    },
                })
            } else {
                if (res.code == 0) {
                    userId = res.data.userInfo.uid;
                    userToken = res.data.token;
                    userNickName = res.data.userInfo.nickName;
                    userNickHeadurl = res.data.userInfo.headImgUrl;
                    $.ajax({
                        dataType: "json",
                        type: "POST",
                        async: true,
                        url: "/api/v1/im/createSig.do",
                        data: {
                            "uid": userId,
                        },
                        success: function(res) {
                            if (res.code == 0) {
                                userSig = res.data;
                                // userNickHeadurl = "https://picture.fengniutv.com/anchorHead.png";
                                //获取chatRoomId
                                $.ajax({
                                    type: "post",
                                    async: true,
                                    dataType: "json",
                                    url: "/api/v3/live/getLiveRoomInfo.do",
                                    data: {
                                        "roomId": roomid
                                    },
                                    success: function (res) {
                                        if (res.code == 0) {
                                            chatRoomId = res.data.chatRoomId;
                                            // console.log("chatRoomId = "+chatRoomId);
                                            if (chatRoomId) {
                                                chatRoom(chatRoomId, userSig, userId, "游客", userNickHeadurl, "")
                                            }
                                        }
                                    }
                                })
                            }
                        },
                        error: function(XMLHttpRequest, textStatus, errorThrown) {
                            console.log(XMLHttpRequest.status);
                            console.log(XMLHttpRequest.readyState);
                            console.log(textStatus)
                        },
                    });
                    $(".login-inside").stop().hide();
                    addMoreImg(userId, userToken);
                    payFun(userId, userToken);
                    if (userId == uid) {
                        kindStatus = 0;
                        $(".weChatScrollBottom").stop().hide();
                        $(".chat").css("height", "550px");
                        palybackImg(uid, userToken);
                        $("#saveEditPlayback").click(function() {
                            var playbackId = $(this).parent().parent().attr("kid");
                            var coverUrl = $("#uploadInnerImg1").attr("src");
                            var topic = $("#playbackTopic").val();
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/live/edit1.do",
                                data: {
                                    "uid": userId,
                                    "token": userToken,
                                    "id": playbackId,
                                    "coverUrl": coverUrl,
                                    "topic": topic
                                },
                                success: function(res) {
                                    if (res.code == 0) {
                                        $(".editPlayback").stop().hide()
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus)
                                }
                            })
                        });
                        $(document).on("click", ".sendApply",
                        function() {
                            var answer = $(this).siblings(".applyInput").val();
                            var chatContent = $(this).attr("chatContent");
                            var chatName = $(this).attr("chatName");
                            var msgtosend = answer + " igstn " + chatName + ":" + chatContent;
                            if (answer == "") {
                                $(this).next(".sendNull").fadeIn(100).delay(4000).fadeOut(100);
                                return false
                            }
                            onSendMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid, msgtosend)
                        });
                        $(document).on("click", ".deleteWenzi",
                        function() {
                            var id = $(this).attr("id");
                            var deleteId = $(this).attr("kid");
                            var kindofId = $(this).attr("kindofId");
                            if (kindofId == 1) {
                                var playbackId = $(this).attr("playbackId");
                                $.ajax({
                                    type: "post",
                                    async: true,
                                    dataType: "json",
                                    url: "/api/v3/liveRoomMsg/deleteMsg.do2",
                                    data: {
                                        "uid": userId,
                                        "token": userToken,
                                        "id": deleteId,
                                        "objectId": playbackId
                                    },
                                    success: function(res) {
                                        if (res.code == 0) {
                                            $("#kill" + deleteId).parent("#tuwenContent li").remove()
                                        }
                                    },
                                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                                        console.log(XMLHttpRequest.status);
                                        console.log(XMLHttpRequest.readyState);
                                        console.log(textStatus)
                                    }
                                })
                            } else {
                                $.ajax({
                                    type: "post",
                                    async: true,
                                    dataType: "json",
                                    url: "/api/v3/liveRoomMsg/deleteMsg.do1",
                                    data: {
                                        "uid": userId,
                                        "token": userToken,
                                        "id": deleteId
                                    },
                                    success: function(res) {
                                        if (res.code == 0) {
                                            $("#kill" + deleteId).parent("#tuwenContent li").remove()
                                        }
                                    },
                                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                                        console.log(XMLHttpRequest.status);
                                        console.log(XMLHttpRequest.readyState);
                                        console.log(textStatus)
                                    }
                                })
                            }
                        });
                        $(document).on("click", ".deleteChat",
                        function() {
                            var deleteId = $(this).attr("kid");
                            var id = $(this).attr("id");
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/liveRoomMsg/deleteMsg.do1",
                                data: {
                                    "uid": userId,
                                    "token": userToken,
                                    "id": deleteId
                                },
                                success: function(res) {
                                    if (res.code == 0) {
                                        $("#kill" + deleteId).parent("#chatDetail li").remove()
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus)
                                }
                            })
                        })
                    } else {
                        kindStatus = 1;
                        $(".weChatScrollBottom").stop().show();
                        $.ajax({
                            dataType: "json",
                            type: "POST",
                            async: true,
                            url: "/api/v3/live/getVideoLivePlaybackInfo.do",
                            data: {
                                "id": playbackId
                            },
                            success: function(res) {
                                if (res.code == 0) {
                                    var createTime = res.data.createTime;
                                    $(".liveContentAnchor1 .liveTitle").html(res.data.topic);
                                    $(".liveContentAnchor1B .anchorName").html("来自" + res.data.liverInfo.nickName + "的直播间");
                                    $(".liveContentAnchor1B .watchNum").html(res.data.watchCount + "人观看");
                                    $(".liveContentAnchor1B .publishTime").html(format(new Date(res.data.createTime)));
                                    // qiniuVideo("id_test_video", res.data.playUrl, res.data.coverUrl)
                                    $(".myVideo").attr("poster",res.data.coverUrl);
                                  //  $(".myVideo").attr("src",res.data.playUrl);
                                    getVideoDetails(res);
                                } else {
                                    if (res.code == -7) {
                                        $("#vedio_masked").stop().show();
                                        $("#sure_btn").click(function() {
                                            var authCode = $("#pwd").val();
                                            $.ajax({
                                                dataType: "json",
                                                type: "POST",
                                                async: true,
                                                url: "/api/v3/live/getVideoLivePlaybackInfo2.do",
                                                data: {
                                                    "id": playbackId,
                                                    "authCode": authCode
                                                },
                                                success: function(res) {
                                                    if (res.code == 0) {
                                                        $("#vedio_masked").stop().hide();
                                                        var createTime = res.data.createTime;
                                                        $(".liveContentAnchor1 .liveTitle").html(res.data.topic);
                                                        $(".liveContentAnchor1B .anchorName").html("来自" + res.data.liverInfo.nickName + "的直播间");
                                                        $(".liveContentAnchor1B .watchNum").html(res.data.watchCount + "人观看");
                                                        $(".liveContentAnchor1B .publishTime").html(format(new Date(res.data.createTime)));
                                                        // qiniuVideo("id_test_video", res.data.playUrl, res.data.coverUrl)
                                                        $(".myVideo").attr("poster",res.data.coverUrl);
                                                      //  $(".myVideo").attr("src",res.data.playUrl);
                                                        getVideoDetails(res);
                                                    } else {
                                                        if (res.code == -111) {
                                                            $(".error_ts").html("密码错误");
                                                            $(".error_ts").fadeIn(100).delay(4000).fadeOut(100)
                                                        }
                                                    }
                                                },
                                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                                    console.log(XMLHttpRequest.status);
                                                    console.log(XMLHttpRequest.readyState);
                                                    console.log(textStatus)
                                                },
                                            })
                                        })
                                    }
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus)
                            },
                        });
                        $("#sendMsgBtn").click(function() {
                            var msgtosend = $("#sendMsg").val();
                            if (msgtosend == "") {
                                $(".weChatScrollBottom .sendNull").fadeIn(100).delay(4000).fadeOut(100);
                                return false
                            }
                            onSendMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid, msgtosend)
                        });
                        for (D = 1; D < 7; D++) {
                            sendGiftFun(D)
                        }
                        $(".payMoneyBtn").click(function() {
                            $("#exceptWrap").stop().show();
                            $("#n_money").stop().show()
                        })
                    }
                }
            }
        }
    });
    function getPlaybackVideo(playbackId) {
        $.ajax({
            dataType: "json",
            type: "POST",
            async: true,
            url: "/api/v3/live/getVideoLivePlaybackInfo.do",
            data: {
                "id": playbackId
            },
            success: function(res) {
                if (res.code == 0) {
                    var createTime = res.data.createTime;
                    $(".liveContentAnchor1 .liveTitle").html(res.data.topic);
                    $(".liveContentAnchor1B .anchorName").html("来自" + res.data.liverInfo.nickName + "的直播间");
                    $(".liveContentAnchor1B .watchNum").html(res.data.watchCount + "人观看");
                    $(".liveContentAnchor1B .publishTime").html(format(new Date(res.data.createTime)));
                    // qiniuVideo("id_test_video", res.data.playUrl, res.data.coverUrl)
                    $(".myVideo").attr("poster",res.data.coverUrl);
                  //  $(".myVideo").attr("src",res.data.playUrl);
                    getVideoDetails(res);
                } else {
                    if (res.code == -7) {
                        $("#vedio_masked").stop().show();
                        $("#sure_btn").click(function() {
                            var authCode = $("#pwd").val();
                            $.ajax({
                                dataType: "json",
                                type: "POST",
                                async: true,
                                url: "/api/v3/live/getVideoLivePlaybackInfo2.do",
                                data: {
                                    "id": playbackId,
                                    "authCode": authCode
                                },
                                success: function(res) {
                                    if (res.code == 0) {
                                        $("#vedio_masked").stop().hide();
                                        var createTime = res.data.createTime;
                                        $(".liveContentAnchor1 .liveTitle").html(res.data.topic);
                                        $(".liveContentAnchor1B .anchorName").html("来自" + res.data.liverInfo.nickName + "的直播间");
                                        $(".liveContentAnchor1B .watchNum").html(res.data.watchCount + "人观看");
                                        $(".liveContentAnchor1B .publishTime").html(format(new Date(res.data.createTime)));
                                        // qiniuVideo("id_test_video", res.data.playUrl, res.data.coverUrl)
                                        $(".myVideo").attr("poster",res.data.coverUrl);
                                       // $(".myVideo").attr("src",res.data.playUrl);
                                        getVideoDetails(res);
                                    } else {
                                        if (res.code == -111) {
                                            $(".error_ts").html("密码错误");
                                            $(".error_ts").fadeIn(100).delay(4000).fadeOut(100)
                                        }
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus)
                                },
                            })
                        })
                    } else {
                        if (res.code == -111) {
                            $(".error_ts").html("密码错误");
                            $(".error_ts").fadeIn(100).delay(4000).fadeOut(100)
                        }
                    }
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus)
            },
        })
    }
    function getPlaybackVideo2(playbackId, userId, userToken) {
        $.ajax({
            dataType: "json",
            type: "POST",
            async: true,
            url: "/api/v3/live/getVideoLivePlaybackInfo4.do",
            data: {
                "id": playbackId,
                "uid": userId,
                "token": userToken
            },
            success: function(res) {
                if (res.code == 0) {
                    var createTime = res.data.createTime;
                    $(".liveContentAnchor1 .liveTitle").html(res.data.topic);
                    $(".liveContentAnchor1B .anchorName").html("来自" + res.data.liverInfo.nickName + "的直播间");
                    $(".liveContentAnchor1B .watchNum").html(res.data.watchCount + "人观看");
                    $(".liveContentAnchor1B .publishTime").html(format(new Date(res.data.createTime)));
                    // qiniuVideo("id_test_video", res.data.playUrl, res.data.coverUrl)
                    $(".myVideo").attr("poster",res.data.coverUrl);
                   // $(".myVideo").attr("src",res.data.playUrl);
                    getVideoDetails(res);
                } else {
                    if (res.code == -7) {
                        $("#vedio_masked").stop().show();
                        $("#sure_btn").click(function() {
                            var authCode = $("#pwd").val();
                            $.ajax({
                                dataType: "json",
                                type: "POST",
                                async: true,
                                url: "/api/v3/live/getVideoLivePlaybackInfo5.do",
                                data: {
                                    "id": playbackId,
                                    "uid": userId,
                                    "token": userToken,
                                    "authCode": authCode
                                },
                                success: function(res) {
                                    if (res.code == 0) {
                                        console.log(res.data.playUrl);
                                        $("#vedio_masked").stop().hide();
                                        var createTime = res.data.createTime;
                                        $(".liveContentAnchor1 .liveTitle").html(res.data.topic);
                                        $(".liveContentAnchor1B .anchorName").html("来自" + res.data.liverInfo.nickName + "的直播间");
                                        $(".liveContentAnchor1B .watchNum").html(res.data.watchCount + "人观看");
                                        $(".liveContentAnchor1B .publishTime").html(format(new Date(res.data.createTime)));
                                        // qiniuVideo("id_test_video", res.data.playUrl, res.data.coverUrl);
                                        $(".myVideo").attr("poster",res.data.coverUrl);
                                       // $(".myVideo").attr("src",res.data.playUrl);
                                        getVideoDetails(res);
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus)
                                },
                            })
                        })
                    } else {
                        if (res.code == -111) {
                            $(".error_ts").html("密码错误");
                            $(".error_ts").fadeIn(100).delay(4000).fadeOut(100)
                        }
                    }
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus)
            },
        })
    }
    function alertLoginFun(obj) {
        $(obj).click(function() {
            $("#loginAlert").stop().show();
            $("#loginAlert").load("/login")
        })
    }
    function showMsg(uid, token, liveRoomId, content, type, msgType) {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v3/liveRoomMsg/saveMsg.do",
            data: {
                "uid": uid,
                "token": token,
                "liveRoomId": liveRoomId,
                "content": content,
                "type": type,
                "msgType": msgType
            },
            success: function(res) {
                if (res.code == 0) {}
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus)
            }
        })
    }
    $(".payBtn").click(function() {
        var totalFee = "";
        if ($(".qitaMoney").val() != "") {
            totalFee = parseInt($(".qitaMoney").val())
        } else {
            totalFee = parseInt($(".money_list").find(".click_effect").children().text())
        }
        $(".weChatPayNum").html(totalFee);
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v1/order/wxUnifiedOrder.do",
            data: {
                "uid": userId,
                "totalFee": totalFee,
                "tradeType": "NATIVE",
                "token": userToken,
            },
            success: function(res) {
                if (res.code == 0) {
                    $("#n_money").fadeOut(1);
                    $("#exceptWrap").fadeIn(1);
                    $(".weChatCodeWrap").fadeIn(1);
                    var codeUrl = res.data.codeUrl;
                    var outTradeNo = res.data.outTradeNo;
                    jQuery("#weChatPayCode").qrcode({
                        render: "canvas",
                        foreground: "#000",
                        background: "#FFF",
                        width: 180,
                        height: 180,
                        text: codeUrl,
                        correctLevel: 2
                    });
                    intervalTime = setInterval(function() {
                        $.ajax({
                            type: "POST",
                            async: true,
                            dataType: "json",
                            url: "/api/v1/order/wxFrontNotify.do",
                            data: {
                                "uid": userId,
                                "outTradeNo": outTradeNo,
                                "token": userToken,
                            },
                            success: function(res) {
                                if (res.code == 0) {
                                    $(".weChatCodeWrap").stop().hide();
                                    $(".weChatPaySuccess").stop().show();
                                    payFun(userId, usertoken)
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus)
                            }
                        })
                    },
                    3000)
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus)
            }
        })
    });
    function sendGiftFun(D) {
        $("#sendGiftBtn" + D).click(function() {
            monetary = $("#giftPrice" + D).html();
            $.ajax({
                dataType: "json",
                type: "POST",
                async: true,
                url: "/api/v1/account/getToken.do",
                data: {
                    "uid": userId,
                    "token": userToken,
                },
                success: function(res) {
                    if (res.code == 0) {
                        var awardToken = res.data;
                        $.ajax({
                            dataType: "json",
                            type: "POST",
                            async: true,
                            url: "/api/v1/account/award.do",
                            data: {
                                "uid": userId,
                                "uidIn": uid,
                                "target": roomid,
                                "coinType": "RECHARGE_COIN",
                                "monetary": monetary,
                                "awardToken": awardToken,
                                "channel": "WEB",
                                "token": userToken,
                            },
                            success: function(res) {
                                if (res.code == 0) {
                                    //获取chatRoomId
                                    $.ajax({
                                        type: "post",
                                        async: true,
                                        dataType: "json",
                                        url: "/api/v3/live/getLiveRoomInfo.do",
                                        data: {
                                            "roomId": roomid
                                        },
                                        success: function (res) {
                                            if (res.code == 0) {
                                                chatRoomId = res.data.chatRoomId;
                                                // console.log("chatRoomId = "+chatRoomId);
                                                if (chatRoomId) {
                                                    sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid, "", "", "", D);
                                                }
                                                payFun(userId, userToken);
                                            }
                                        }
                                    })
                                    
                                }
                                if (res.code == -706) {
                                    $("#exceptWrap").stop().show();
                                    $(".weChatOweWrap").stop().show();
                                    $(".weChatErrorEnter").click(function() {
                                        $(".weChatOweWrap").stop().hide();
                                        $("#n_money").stop().show()
                                    })
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus)
                            },
                        })
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    console.log(XMLHttpRequest.status);
                    console.log(XMLHttpRequest.readyState);
                    console.log(textStatus)
                },
            })
        })
    }
    function payFun(userId, usertoken) {
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v1/account/selectByWhere.do",
            data: {
                "uid": userId,
                "coinType": "RECHARGE_COIN",
                "token": usertoken,
            },
            success: function(res) {
                if (res.code == 0) {
                    $(".coinNiBi").html(res.data[0].coinNumber);
                    $(".balanceCoin").html(res.data[0].coinNumber + "牛币")
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus)
            }
        })
    }
    function getLiveRoomMsgByUid(id, liveRoomId, msgType, uid, pageSize) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v3/liveRoomMsg/getLiveRoomMsgByUid.do",
            data: {
                "id": id,
                "liveRoomId": liveRoomId,
                "msgType": msgType,
                "uid": uid,
                "pageSize": pageSize
            },
            success: function(res) {
                console.log(res);
                if (res.code == 0) {
                    if (msgType == 1) {
                        if (res.data.length == 0 && id == "") {
                            $("#noZhiboContent").stop().show()
                        }
                        getLiveMsg(res);
                        var liveMsgLength = res.data.length;
                        if (liveMsgLength != 0) {
                            lastliveMsgId = res.data[liveMsgLength - 1].id
                        }
                        $("#zhiboTab").mCustomScrollbar({
                            callbacks: {
                                onScrollStart: function() {},
                                onScroll: function() {},
                                onTotalScroll: function() {
                                    getLiveRoomMsgByUid(lastliveMsgId, liveRoomId, 1, uid, 10)
                                },
                                onTotalScrollBack: function() {},
                                onTotalScrollOffset: 80,
                                whileScrolling: false,
                                whileScrollingInterval: 0
                            },
                            scrollInertia: 300
                        })
                    } else {
                        if (msgType == 2) {
                            if (id == "" && res.data.length == 0) {
                                $("#noChatContent").stop().show()
                            }
                            getChatMsg(res);
                            var liveChatLength = res.data.length;
                            if (liveChatLength != 0) {
                                lastChatMsgId = res.data[liveChatLength - 1].id
                            }
                            $("#chat").mCustomScrollbar({
                                callbacks: {
                                    onScrollStart: function() {},
                                    onScroll: function() {},
                                    onTotalScroll: function() {
                                        getLiveRoomMsgByUid(lastChatMsgId, liveRoomId, 2, uid, 10)
                                    },
                                    onTotalScrollBack: function() {},
                                    onTotalScrollOffset: 80,
                                    whileScrolling: false,
                                    whileScrollingInterval: 0
                                },
                                scrollInertia: 300
                            })
                        }
                    }
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus)
            },
        })
    }
    function getChatMsg(res) {
        $(res.data).each(function(i, k) {
            var sendTime = formatV5Time(new Date(k.sendTime));
            var sendTimeMin = formatV5TimeMin(new Date(k.sendTime));
            var communicationInfo = JSON.parse(k.content).content + "";
            var headerIMG = k.userInfo.headImgUrl + "!60X60";
            if (!headerIMG) {
                headerIMG = "../images/anchorHead.png"
            }
            var killId = "kill" + k.id;
            var fromAccount = k.userInfo.uid;
            var imTime = k.sendTime;
            var cancelId = imTime + "cancel";
            var fromAccountNick = k.userInfo.nickName;
            var answerNick = "回复" + fromAccountNick + "...";
            var anchorAnwserBrforeIm = communicationInfo.split("igstn")[0];
            var anchorAnwserAfterIm = communicationInfo.split("igstn")[1];
            if (communicationInfo.indexOf("igstn") != -1) {
                var chatListInner = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='bozhu'>播主</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<p class='answerContent'>" + anchorAnwserBrforeIm + "</p>" + "<span class='chatContent'>" + anchorAnwserAfterIm + "</span><br />" + "<p class='deleteChat' kid=" + k.id + " id=" + killId + ">删除</p>" + "</li>";
                $(".chatDetail").append(chatListInner);
            } else {
                if (fromAccount != uid) {//
                    var chatListInner = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<br /><span class='chatContent'>" + communicationInfo + "</span><br />"+"<div class='apply'><textarea class='applyInput' placeholder='" + answerNick + "' maxlength='140' ></textarea>" + "<span class='cancalSend' id=" + cancelId + ">取消</span><span class='sendApply'  chatContent=" + communicationInfo + " chatName=" + fromAccountNick + ">发送</span>" + "<p class='sendNull'>不能回复空信息哦！</p></div></li>";
                    $(".chatDetail").append(chatListInner);
                } else {
                    var chatListInner = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<br /><span class='chatContent'>" + communicationInfo + "</span><br />" + "<p class='deleteChat' kid=" + k.id + " id=" + killId + ">删除</p>" + "<p class='answerChat'>回复</p>" + "<div class='apply'><textarea class='applyInput' placeholder='" + answerNick + "' maxlength='140' ></textarea>" + "<span class='cancalSend' id=" + cancelId + ">取消</span><span class='sendApply'  chatContent=" + communicationInfo + " chatName=" + fromAccountNick + ">发送</span>" + "<p class='sendNull'>不能回复空信息哦！</p></div></li>";
                    $(".chatDetail").append(chatListInner);
                }
            }
            $(".answerChat").click(function() {
                $(this).next(".apply").stop().show()
            });
            $("#" + cancelId).click(function() {
                $(this).parent(".apply").stop().hide()
            });
            if (kindStatus == 1) {
                $(".liveNewBody .chat .chatDetail li .deleteChat").stop().hide();
                $(".liveNewBody .chat .chatDetail li .answerChat").stop().hide()
            } else {
                if (kindStatus == 0) {
                    $(".liveNewBody .chat .chatDetail li .deleteChat").stop().show();
                    $(".liveNewBody .chat .chatDetail li .answerChat").stop().show()
                }
            }
        })
    }
    function getLiveMsg(res) {
        $(res.data).each(function(i, k) {
            var content = JSON.parse(k.content);
            var type = content.type;
            var sendTime = formatV5Time(new Date(k.sendTime));
            var sendTimeMin = formatV5TimeMin(new Date(k.sendTime));
            var liveId = k.id;
            var killId = "kill" + k.id;
            var content1 = content.content;
            var media = content.media + "!370X208";
            if (type == 0) {
                if (media == "") {
                    var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "</li>";
                    $("#tuwenContent").append(shortDetailInner)
                } else {
                    var shortViewImg = (media.split(","));
                    var len = shortViewImg.length - 1;
                    if (len == 1) {
                        var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner)
                    } else {
                        if (len == 2) {
                            var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "</ul></li>";
                            $("#tuwenContent").append(shortDetailInner)
                        } else {
                            if (len == 3) {
                                var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "</ul></li>";
                                $("#tuwenContent").append(shortDetailInner)
                            } else {
                                if (len == 4) {
                                    var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent' kid=" + k.id + ">" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "</ul></li>";
                                    $("#tuwenContent").append(shortDetailInner)
                                } else {
                                    if (len == 5) {
                                        var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "</ul></li>";
                                        $("#tuwenContent").append(shortDetailInner)
                                    } else {
                                        if (len == 6) {
                                            var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" + "</ul></li>";
                                            $("#tuwenContent").append(shortDetailInner)
                                        } else {
                                            if (len == 7) {
                                                var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" + "</ul></li>";
                                                $("#tuwenContent").append(shortDetailInner)
                                            } else {
                                                if (len == 8) {
                                                    var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[7] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[7] + "' alt='' /></a></li>" + "</ul></li>";
                                                    $("#tuwenContent").append(shortDetailInner)
                                                } else {
                                                    if (len == 9) {
                                                        var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='0' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[7] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[7] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[8] + "' data-lightbox=" + liveId + "><img src='" + shortViewImg[8] + "' alt='' /></a></li>" + "</ul></li>";
                                                        $("#tuwenContent").append(shortDetailInner)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                if (type == 1) {
                    var playbackId = content.id;
                    var playBackInner = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " playbackId=" + playbackId + " kindofId='1' id=" + killId + ">删除</span>" + "<p class='editWenzi' kid=" + playbackId + "  >编辑</p>" + "<p class='wenziContent'>" + content1 + "</p>" + "<div  kid=" + playbackId + " class='videoBox'>" + "<img class='videoBg' src='" + media + "' alt='' />" + "<p class='videoType'>回看</p>" + "<img class='playBtn' src='images/indexvideo.png' alt='' /></div></li>";
                    $("#tuwenContent").append(playBackInner);
                    $(".videoBg").one("error",
                    function(e) {
                        $(this).attr("src", "../images/vedioCoverUrl.jpg")
                    });
                    $(".editWenzi").click(function() {
                        $(".editPlayback").stop().show();
                        var playbackId = $(this).attr("kid");
                        $(".editPlayback").attr("kid", playbackId)
                    });
                    $("#cancalEditPlayback").click(function() {
                        $(".editPlayback").stop().hide()
                    })
                } else {
                    if (type == 2) {
                        var anchorAnwser = content.content;
                        var anchorAnwserBrfore = anchorAnwser.split("igstn")[0];
                        var anchorAnwserAfter = anchorAnwser.split("igstn")[1];
                        var answerInner = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='2' id=" + killId + ">删除</span>" + "<p class='wenziContent'>" + anchorAnwserBrfore + "</p>" + "<span class=' answerWenzi'>" + anchorAnwserAfter + "</span></li>";
                        $("#tuwenContent").append(answerInner)
                    } else {
                        if (type == 3) {
                            var anchorhref = content.content;
                            var anchorhrefBrfore = anchorhref.split("igugl")[0];
                            var anchorhrefAfter = anchorhref.split("igugl")[1];
                            var linkUrl = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + k.id + " kindofId='3' id=" + killId + ">删除</span>" + "<a href=" + anchorhrefAfter + "><p class='wenziContent'>" + anchorhrefBrfore + "<span style='color: #5286BE'>" + anchorhrefAfter + "</span></p></a></li>";
                            $("#tuwenContent").append(linkUrl)
                        }
                    }
                }
            }
            if (kindStatus == 1) {
                $(".tabcontent .zhiboContent li .deleteWenzi").stop().hide();
                $(".tabcontent .zhiboContent li .editWenzi").stop().hide()
            } else {
                if (kindStatus == 0) {
                    $(".tabcontent .zhiboContent li .deleteWenzi").stop().show();
                    $(".tabcontent .zhiboContent li .editWenzi").stop().show()
                }
            }
        })
        var timeTitleLen = $(".timeDetail").length;
        var timeTitle = document.getElementsByClassName("dayTime");
        var timeTitleInnerLast = timeTitle[timeTitleLen - 1].innerHTML;
        for (var q = 0; q < timeTitleLen; q++) {
            var timeTitleInner = timeTitle[q].innerHTML;
            if (timeTitle[q + 1] != undefined && timeTitle[q + 1] != null && timeTitle[q + 1] != "") {
                var timeTitleInnerNext = timeTitle[q + 1].innerHTML;
                if (timeTitleInnerNext == timeTitleInner) {
                    timeTitle[q + 1].style.display = "none"
                }
            }
        }
    }
    $(document).on("click", "#tuwenContent li .videoBox",
    function() {
        var id = $(this).attr("kid");
        window.location.href = "liveLookBack?id=" + id + "&uid=" + uid + "&roomid=" + roomid
    });
    function addMoreImg(uid, token) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v1/picture/batchUpload/shortViewToken.do",
            data: {
                "uid": uid,
                "token": token,
            },
            success: function(res) {
                if (res.code == 0) {
                    var sortimgtoken = res.data.uploadToken;
                    var uploader6 = Qiniu.uploader({
                        runtimes: "html5,flash,html4",
                        browse_button: "addMoreImage",
                        uptoken_url: "",
                        uptoken: sortimgtoken,
                        uptoken_func: function(file) {},
                        unique_names: true,
                        save_key: false,
                        domain: "upload.qbox.me",
                        get_new_uptoken: true,
                        container: "shortViewImgBox",
                        max_file_size: "100mb",
                        flash_swf_url: "js/Moxie.swf",
                        max_retries: 3,
                        dragdrop: true,
                        drop_element: "shortViewImgBox",
                        chunk_size: "4mb",
                        auto_start: true,
                        init: {
                            "FilesAdded": function(up, files) {},
                            "BeforeUpload": function(up, file) {},
                            "UploadProgress": function(up, file) {},
                            "FileUploaded": function(up, file, info) {
                                var sortimgInfo = JSON.parse(info);
                                var sortimgUrl = "https://picture.fengniutv.com/" + sortimgInfo.key;
                                var addMoreImageInner = "<p class='floatImg' id='floatImg" + imgCount + "'><img src='" + sortimgUrl + "' /><img src='images/shortView5.png' class='perCloseBtn'/></p>";
                                $(".upload_out").before(addMoreImageInner);
                                media.push(sortimgUrl);
                                imgCount++;
                                $(".perCloseBtn").hover(function() {
                                    $(this).attr("src", "images/shortView5P.png")
                                },
                                function() {
                                    $(this).attr("src", "images/shortView5.png")
                                })
                            },
                            "Error": function(up, err, errTip) {
                                console.log(errTip)
                            },
                            "UploadComplete": function() {
                                $(".perCloseBtn").on("click",
                                function() {
                                    var thisUrl = $(this).prev().attr("src");
                                    media.splice($.inArray(thisUrl, media), 1);
                                    $(this).parent().remove()
                                })
                            }
                        }
                    })
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus)
            },
        })
    }
    function palybackImg(uid, token) {
        var updownimgHref = "https://picture.fengniutv.com/";
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v1/picture/batchUpload/token.do",
            data: {
                "uid": uid,
                "token": token,
            },
            success: function(res) {
                if (res.code == 0) {
                    var videoEditImgtoken = res.data.uploadToken;
                    var uploader = Qiniu.uploader({
                        runtimes: "html5,flash,html4",
                        browse_button: "add2Img",
                        uptoken_url: updownimgHref,
                        uptoken: videoEditImgtoken,
                        uptoken_func: function(file) {},
                        unique_names: true,
                        save_key: false,
                        domain: updownimgHref,
                        get_new_uptoken: true,
                        container: "uploadInnerImg1",
                        max_file_size: "100mb",
                        flash_swf_url: "js/Moxie.swf",
                        max_retries: 3,
                        dragdrop: true,
                        drop_element: "uploadInnerImg1",
                        chunk_size: "4mb",
                        auto_start: true,
                        init: {
                            "FilesAdded": function(up, files) {
                                plupload.each(files,
                                function(file) {})
                            },
                            "BeforeUpload": function(up, file) {},
                            "UploadProgress": function(up, file) {},
                            "FileUploaded": function(up, file, info) {
                                var imgInfoVideoEditinfo = JSON.parse(info);
                                coverUrl = updownimgHref + imgInfoVideoEditinfo.key;
                                $("#uploadInnerImg1").attr("src", coverUrl);
                                $(".addTips").html("修改封面");
                                $(".addTips").css("color", "#ffffff")
                            },
                            "Error": function(up, err, errTip) {},
                            "UploadComplete": function() {}
                        }
                    })
                }
            },
        })
    }
    $.ajax({
        type: "get",
        async: true,
        dataType: "json",
        data: {
            "type": 6,
        },
        url: "/api/v2/discovery/getDiscoveryByType.do",
        success: function(res) {
            if (res.code == 0) {
                $(res.data).each(function(m, Q) {
                    if (Q.discoveryObject.bannerType == 5) {
                        var officialImg = "<img src=" + Q.discoveryObject.imgUrl + " id=" + Q.objectId + ">";
                        $(".officialEventWrap").append(officialImg);
                        $(".officialEventWrap img").one("error",
                        function(e) {
                            $(this).attr("src", "images/vedioCoverUrl.jpg")
                        })
                    }
                });
                $(document).on("click", ".officialEventWrap img",
                function(e) {
                    var id = $(this).attr("id");
                    window.open(id)
                })
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            console.log(XMLHttpRequest.status);
            console.log(XMLHttpRequest.readyState);
            console.log(textStatus)
        },
    });
    function browserRedirect() {
        var sUserAgent = navigator.userAgent.toLowerCase();
        var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
        var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
        var bIsMidp = sUserAgent.match(/midp/i) == "midp";
        var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
        var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
        var bIsAndroid = sUserAgent.match(/android/i) == "android";
        var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
        var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
        if (bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
            window.location.href = "https://www.fntv8.com/m/v5.0/liveLookBack?id=" + playbackId + "&roomid=" + roomid
        }
    }
    browserRedirect();
    function chatRoom(chatRoomId, userSig, userId, userNickName, userNickHeadurl, roomid) {
        var accountMode = 0;
        var sdkAppID = 1400018939;
        var accountType = 8454;
        var avChatRoomId = chatRoomId;
        sdkLogin(userSig, userId, userNickName, userNickHeadurl)
    }
    function sdkLogin(userSig, userId, userNickName, userNickHeadurl) {
        var isAccessFormalEnv = true;
        if (webim.Tool.getQueryString("isAccessFormalEnv") == "false") {
            isAccessFormalEnv = false
        }
        var isLogOn = true;
        var options = {
            "isAccessFormalEnv": isAccessFormalEnv,
            "isLogOn": isLogOn
        };
        var curPlayAudio = null;
        var openEmotionFlag = false;
        if (/debug/gi.test(location.hash)) {
            document.write('<script src="http://sdklog.isd.com/js/vconsole.min.js"></scr' + "ipt>")
        }
        var loginInfo = {
            "sdkAppID": 1400018939,
            "appIDAt3rd": 1400018939,
            "accountType": 8454,
            "identifier": userId,
            "identifierNick": userNickName,
            "userSig": userSig,
            "headurl": userNickHeadurl
        };
        var onConnNotify = function(resp) {
            switch (resp.ErrorCode) {
            case webim.CONNECTION_STATUS.ON:
                break;
            case webim.CONNECTION_STATUS.OFF:
                webim.Log.warn("连接已断开，无法收到新消息，请检查下你的网络是否正常");
                break;
            default:
                webim.Log.error("未知连接状态,status=" + resp.ErrorCode);
                break
            }
        };
        var listeners = {
            "onConnNotify": onConnNotify,
            "jsonpCallback": jsonpCallback,
            "onMsgNotify": onMsgNotify,
            "onGroupSystemNotifys": onGroupSystemNotifys,
            "onGroupInfoChangeNotify": onGroupInfoChangeNotify
        };
        var onGroupSystemNotifys = {
            "5": onDestoryGroupNotify,
            "11": onRevokeGroupNotify,
            "255": onCustomGroupNotify
        };
        webim.login(loginInfo, listeners, options,
        function(identifierNick) {
            webim.Log.info("webim登录成功");
            applyJoinGroup(chatRoomId)
        },
        function(err) {
            layer.msg(err.ErrorInfo)
        })
    }
    function jsonpCallback(rspData) {
        webim.setJsonpLastRspData(rspData)
    }
    function onMsgNotify(newMsgList) {
        var sess, newMsg;
        var sessMap = webim.MsgStore.sessMap();
        for (var j in newMsgList) {
            newMsg = newMsgList[j];
            if (newMsg.getSession().id() == selToID) {
                selSess = newMsg.getSession();
                addMsg(newMsg)
            }
        }
        webim.setAutoRead(selSess, true, true)
    }
    function onGroupInfoChangeNotify(groupInfo) {
        webim.Log.warn("执行 群资料变化 回调： " + JSON.stringify(groupInfo));
        groupId = groupInfo.GroupId;
        var newFaceUrl = groupInfo.GroupFaceUrl;
        var newName = groupInfo.GroupName;
        var newOwner = groupInfo.OwnerAccount;
        var newNotification = groupInfo.GroupNotification;
        var newIntroduction = groupInfo.GroupIntroduction;
        if (newName) {
            webim.Log.warn("群id=" + groupId + "的新名称为：" + newName)
        }
    }
    function onDestoryGroupNotify(notify) {
        webim.Log.warn("执行 解散群 回调：" + JSON.stringify(notify));
        var reportTypeCh = "[群被解散]";
        var content = "群主" + notify.Operator_Account + "已解散该群";
        showGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId, notify.GroupName, content, notify.MsgTime)
    }
    function onRevokeGroupNotify(notify) {
        webim.Log.warn("执行 群被回收 回调：" + JSON.stringify(notify));
        var reportTypeCh = "[群被回收]";
        var content = "该群已被回收";
        showGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId, notify.GroupName, content, notify.MsgTime)
    }
    function onCustomGroupNotify(notify) {
        console.log("执行 用户自定义系统消息 回调： %s", JSON.stringify(notify));
        var reportTypeCh = "[用户自定义系统消息]";
        var content = "收到了自己自定义的系统消息";
        addGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId, notify.GroupName, content, notify.MsgTime)
    }
    function applyJoinGroup(groupId) {
        var options = {
            "GroupId": groupId,
            "ReqMsgNumber": 10
        };
        webim.applyJoinGroup(options,
        function(resp) {
            webim.Log.info("进群成功");
            selToID = groupId;
            if (resp.JoinedStatus && resp.JoinedStatus == "JoinedSuccess") {
                webim.Log.info("进群成功");
                selToID = groupId
            } else {
                console.log("进群失败")
            }
        },
        function(err) {
            webim.Log.info("进群成功");
            selToID = groupId
        })
    }
    function addMsg(msg) {
        var isSelfSend, fromAccount, fromAccountNick, sessType, subType;
        fromAccount = msg.getFromAccount();
        if (!fromAccount) {
            fromAccount = ""
        }
        fromAccountNick = msg.getFromAccountNick();
        if (!fromAccountNick) {
            fromAccountNick = fromAccount
        }
        var imTime = msg.getTime();
        isSelfSend = msg.getIsSend();
        var sendTime = formatV5Time(new Date(msg.getTime() * 1000));
        var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000));
        var getTime = sendTime + " " + sendTimeMin;
        var communicationInfo;
        var headerIMG = msg.getHeadurl();
        if (!headerIMG) {
            headerIMG = "images/anchorHead.png"
        }
        sessType = msg.getSession().type();
        subType = msg.getSubType();
        switch (subType) {
        case webim.GROUP_MSG_SUB_TYPE.COMMON:
            communicationInfo = convertMsgtoHtml(msg);
            break;
        case webim.GROUP_MSG_SUB_TYPE.REDPACKET:
            communicationInner = "[群红包消息]" + convertMsgtoHtml(msg);
            break;
        case webim.GROUP_MSG_SUB_TYPE.LOVEMSG:
            communicationInner = "[群点赞消息]" + convertMsgtoHtml(msg);
            break;
        case webim.GROUP_MSG_SUB_TYPE.TIP:
            communicationInner = "[群提示消息]" + convertMsgtoHtml(msg);
            break
        }
    }
    function convertMsgtoHtml(msg) {
        var html = "",
        elems, elem, type, content, headurl;
        elems = msg.getElems();
        headurl = msg.headurl;
        for (var i in elems) {
            elem = elems[i];
            type = elem.getType();
            content = elem.getContent();
            switch (type) {
            case webim.MSG_ELEMENT_TYPE.TEXT:
                html += convertTextMsgToHtml(content, msg);
                break;
            case webim.MSG_ELEMENT_TYPE.FACE:
                html += convertFaceMsgToHtml(content);
                break;
            case webim.MSG_ELEMENT_TYPE.IMAGE:
                html += convertImageMsgToHtml(content);
                break;
            case webim.MSG_ELEMENT_TYPE.SOUND:
                html += convertSoundMsgToHtml(content);
                break;
            case webim.MSG_ELEMENT_TYPE.FILE:
                html += convertFileMsgToHtml(content);
                break;
            case webim.MSG_ELEMENT_TYPE.LOCATION:
                break;
            case webim.MSG_ELEMENT_TYPE.CUSTOM:
                html += convertCustomMsgToHtml(content, msg);
                break;
            case webim.MSG_ELEMENT_TYPE.GROUP_TIP:
                break;
            default:
                webim.Log.error("未知消息元素类型: elemType=" + type);
                break
            }
        }
        return html
    }
    function convertTextMsgToHtml(content, msg) {
        var isSelfSend, fromAccount, fromAccountNick, sessType, subType;
        fromAccount = msg.getFromAccount();
        if (!fromAccount) {
            fromAccount = ""
        }
        fromAccountNick = msg.getFromAccountNick();
        if (!fromAccountNick) {
            fromAccountNick = fromAccount
        }
        var imTime = msg.getTime();
        isSelfSend = msg.getIsSend();
        var sendTime = formatV5Time(new Date(msg.getTime() * 1000));
        var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000));
        var getTime = sendTime + " " + sendTimeMin;
        var uniqueId = msg.uniqueId;
        var communicationInfo;
        var headerIMG = msg.getHeadurl();
        if (!headerIMG) {
            headerIMG = "images/anchorHead.png"
        }
        var str168 = "!168X168";
        if (str168.indexOf(headerIMG) >= 0) {
            console.log("存在168");
            headerIMG = headerIMG.substring(headerIMG.length() - 8, headerIMG.length())
        } else {
            console.log("不存在168")
        }
        console.log(headerIMG);
        var answerNick = "回复" + fromAccountNick + "...";
        var communicationInfo = content.getText();
        if (communicationInfo.indexOf("igstn") != -1) {
            var anchorAnwserBrforeIm = communicationInfo.split("igstn")[0];
            var anchorAnwserAfterIm = communicationInfo.split("igstn")[1];
            var chatListInner = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='bozhu'>播主</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<p class='answerContent'>" + anchorAnwserBrforeIm + "</p>" + "<span class='chatContent'>" + anchorAnwserAfterIm + "</span><br />" + "<p class='deleteChat' kid=" + uniqueId + ">删除</p>" + "</li>";
            $(".chatDetail").prepend(chatListInner)
        } else {
            if (fromAccount != uid) {
                var chatListInner = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<br /><span class='chatContent'>" + communicationInfo + "</span><br />" + "</li>";
                $(".chatDetail").prepend(chatListInner)
            }
        }
    }
    function convertFaceMsgToHtml(content) {
        var index = content.getIndex();
        var data = content.getData();
        var url = null;
        var emotion = webim.Emotions[index];
        if (emotion && emotion[1]) {
            url = emotion[1]
        }
        if (url) {
            return "<img src='" + url + "'/>"
        } else {
            return data
        }
    }
    function convertImageMsgToHtml(content) {
        var smallImage = content.getImage(webim.IMAGE_TYPE.SMALL);
        var bigImage = content.getImage(webim.IMAGE_TYPE.LARGE);
        var oriImage = content.getImage(webim.IMAGE_TYPE.ORIGIN);
        if (!bigImage) {
            bigImage = smallImage
        }
        if (!oriImage) {
            oriImage = smallImage
        }
        return "<img src='" + smallImage.getUrl() + "#" + bigImage.getUrl() + "#" + oriImage.getUrl() + "' style='CURSOR: hand' id='" + content.getImageId() + "' bigImgUrl='" + bigImage.getUrl() + "' onclick='imageClick(this)' />"
    }
    function convertSoundMsgToHtml(content) {
        var second = content.getSecond();
        var downUrl = content.getDownUrl();
        if (webim.BROWSER_INFO.type == "ie" && parseInt(webim.BROWSER_INFO.ver) <= 8) {
            return "[这是一条语音消息]demo暂不支持ie8(含)以下浏览器播放语音,语音URL:" + downUrl
        }
        return '<audio src="' + downUrl + '" controls="controls" onplay="onChangePlayAudio(this)" preload="none"></audio>'
    }
    function convertFileMsgToHtml(content) {
        var fileSize = Math.round(content.getSize() / 1024);
        return '<a href="' + content.getDownUrl() + '" title="点击下载文件" ><i class="glyphicon glyphicon-file">&nbsp;' + content.getName() + "(" + fileSize + "KB)</i></a>"
    }
    function convertLocationMsgToHtml(content) {
        return "经度=" + content.getLongitude() + ",纬度=" + content.getLatitude() + ",描述=" + content.getDesc()
    }
    function convertCustomMsgToHtml(content, msg) {
        var sendTime = formatV5Time(new Date(msg.getTime() * 1000));
        var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000));
        var getTime = sendTime + " " + sendTimeMin;
        var headerIMG = msg.getHeadurl();
        if (!headerIMG) {
            headerIMG = "images/anchorHead.png"
        }
        var desc = content.getDesc();
        if (desc == "LIVE_CLOSE") {
            var liveTopic = $(".liveTitle").html();
            $(".alertTopic").html("主题" + liveTopic)
        }
        var fromAccountNick = msg.fromAccountNick;
       /* var headerIMG = userNickHeadurl;
        var fromAccountNick = userNickName;*/
        var uniqueId = msg.uniqueId;
        var contentImgInfo = JSON.parse(content.data);
        var content1 = contentImgInfo.content;
        var media = contentImgInfo.media;
        var contentImgType = contentImgInfo.type;
        if (contentImgType == 0) {
            if (media == "") {
                var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "</li>";
                $("#tuwenContent").prepend(shortDetailInner)
            } else {
                var shortViewImg = (media.split(","));
                var len = shortViewImg.length - 1;
                if (len == 1) {
                    var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "</ul></li>";
                    $("#tuwenContent").prepend(shortDetailInner)
                } else {
                    if (len == 2) {
                        var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner)
                    } else {
                        if (len == 3) {
                            var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "</ul></li>";
                            $("#tuwenContent").prepend(shortDetailInner)
                        } else {
                            if (len == 4) {
                                var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "</ul></li>";
                                $("#tuwenContent").prepend(shortDetailInner)
                            } else {
                                if (len == 5) {
                                    var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "</ul></li>";
                                    $("#tuwenContent").prepend(shortDetailInner)
                                } else {
                                    if (len == 6) {
                                        var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" + "</ul></li>";
                                        $("#tuwenContent").prepend(shortDetailInner)
                                    } else {
                                        if (len == 7) {
                                            var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" + "</ul></li>";
                                            $("#tuwenContent").prepend(shortDetailInner)
                                        } else {
                                            if (len == 8) {
                                                var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[7] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[7] + "' alt='' /></a></li>" + "</ul></li>";
                                                $("#tuwenContent").prepend(shortDetailInner)
                                            } else {
                                                if (len == 9) {
                                                    var shortDetailInner = "<li>" + "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" + "<p class='wenziContent'>" + content1 + "</p>" + "<ul class='shortImg'>" + "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[7] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[7] + "' alt='' /></a></li>" + "<li><a href='" + shortViewImg[8] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[8] + "' alt='' /></a></li>" + "</ul></li>";
                                                    $("#tuwenContent").prepend(shortDetailInner)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (contentImgType == 1) {
                var playbackId = contentImgInfo.id;
                var playBackInner = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " playbackId=" + playbackId + " kindofId='1'>删除</span>" + "<p class='editWenzi' kid=" + playbackId + "  >编辑</p>" + "<p class='wenziContent'>" + content1 + "</p>" + "<div  kid=" + playbackId + " class='videoBox'>" + "<img class='videoBg' src='" + media + "' alt='' />" + "<p class='videoType'>回看</p>" + "<img class='playBtn' src='images/indexvideo.png' alt='' /></div></li>";
                $("#tuwenContent").prepend(playBackInner);
                $(".videoBg").one("error",
                function(e) {
                    $(this).attr("src", "../images/vedioCoverUrl.jpg")
                });
                $(".editWenzi").click(function() {
                    $(".editPlayback").stop().show();
                    var playbackId = $(this).attr("kid");
                    $(".editPlayback").attr("kid", playbackId)
                });
                $("#cancalEditPlayback").click(function() {
                    $(".editPlayback").stop().hide()
                })
            } else {
                if (contentImgType == 2) {
                    var anchorAnwser = contentImgInfo.content;
                    var anchorAnwserBrfore = anchorAnwser.split("igstn")[0];
                    var anchorAnwserAfter = anchorAnwser.split("igstn")[1];
                    var answerInner = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='2'>删除</span>" + "<p class='wenziContent'>" + anchorAnwserBrfore + "</p>" + "<span class=' answerWenzi'>" + anchorAnwserAfter + "</span></li>";
                    $("#tuwenContent").prepend(answerInner)
                } else {
                    if (contentImgType == 3) {
                        var anchorhref = contentImgInfo.content;
                        var anchorhrefBrfore = anchorhref.split("igugl")[0];
                        var anchorhrefAfter = anchorhref.split("igugl")[1];
                        var linkUrl = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" + "<span class='timeDetail'>" + sendTime + "</span></p>" + "<span class='publishTime'>" + sendTimeMin + "</span>" + "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='3'>删除</span>" + "<p class='wenziContent'>" + anchorhrefBrfore + "  " + anchorhrefAfter + "</p></li>";
                        $("#tuwenContent").prepend(linkUrl)
                    }
                }
            }
        }
        if (kindStatus == 1) {
            $(".tabcontent .zhiboContent li .deleteWenzi").stop().hide();
            $(".tabcontent .zhiboContent li .editWenzi").stop().hide()
        } else {
            if (kindStatus == 0) {
                $(".tabcontent .zhiboContent li .deleteWenzi").stop().show();
                $(".tabcontent .zhiboContent li .editWenzi").stop().show()
            }
        }
        var timeTitleLen = $(".timeDetail").length;
        var timeTitle = document.getElementsByClassName("dayTime");
        var timeTitleInnerLast = timeTitle[timeTitleLen - 1].innerHTML;
        for (var q = 0; q < timeTitleLen; q++) {
            var timeTitleInner = timeTitle[q].innerHTML;
            if (timeTitle[q + 1] != undefined && timeTitle[q + 1] != null && timeTitle[q + 1] != "") {
                var timeTitleInnerNext = timeTitle[q + 1].innerHTML;
                if (timeTitleInnerNext == timeTitleInner) {
                    timeTitle[q + 1].style.display = "none"
                }
            }
        }
        if (desc == "givemoney2_zhubo") {
            var data = content.getData();
            var ext = content.getExt();
            switch (data) {
            case "1":
                var giftSendAlert = "<li><img class='presentBg' src='images/changeSlow.png' alt='' />" + "<div class='absoluteBox'>" + "<p class='presentNick'>" + fromAccountNick + "</p>" + "<p class='send'>送出</p>" + "<img class='gift' src='images/zan11.png' alt='' />" + "<img class='cheng' src='images/cheng.png' alt=''/>" + "<img class='giftnumber' src='images/one.png' alt='' />" + "</div></li>";
                var giftAnimation = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “赞” </span></p>" + "<img class='whatGift' src='images/zan11.png' alt='' /></li>";
                $(".presentJump").prepend(giftSendAlert);
                $(".chatDetail").prepend(giftAnimation);
                $(".chatDetail").scrollTop(0);
                $(".presentJump li").delay(5000).hide(0);
                break;
            case "10":
                var giftSendAlert = "<li><img class='presentBg' src='images/changeSlow.png' alt='' />" + "<div class='absoluteBox'>" + "<p class='presentNick'>" + fromAccountNick + "</p>" + "<p class='send'>送出</p>" + "<img class='gift' src='images/giftjindou.png' alt='' />" + "<img class='cheng' src='images/cheng.png' alt=''/>" + "<img class='giftnumber' src='images/one.png' alt='' />" + "</div></li>";
                var giftAnimation = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “金豆” </span></p>" + "<img class='whatGift' src='images/giftjindou.png' alt='' /></li>";
                $(".presentJump").prepend(giftSendAlert);
                $(".chatDetail").prepend(giftAnimation);
                $(".chatDetail").scrollTop(0);
                $(".presentJump li").delay(5000).hide(0);
                break;
            case "188":
                var giftSendAlert = "<li><img class='presentBg' src='images/changeSlow.png' alt='' />" + "<div class='absoluteBox'>" + "<p class='presentNick'>" + fromAccountNick + "</p>" + "<p class='send'>送出</p>" + "<img class='gift' src='images/giftbaoxiang.png' alt='' />" + "<img class='cheng' src='images/cheng.png' alt=''/>" + "<img class='giftnumber' src='images/one.png' alt='' />" + "</div></li>";
                var giftAnimation = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “宝箱” </span></p>" + "<img class='whatGift' src='images/giftbaoxiang.png' alt='' /></li>";
                $(".presentJump").prepend(giftSendAlert);
                $(".chatDetail").prepend(giftAnimation);
                $(".chatDetail").scrollTop(0);
                $(".presentJump li").delay(5000).hide(0);
                break;
            case "999":
                var giftSendAlert = "<li><img class='presentBg' src='images/changeSlow.png' alt='' />" + "<div class='absoluteBox'>" + "<p class='presentNick'>" + fromAccountNick + "</p>" + "<p class='send'>送出</p>" + "<img class='gift' src='images/giftzhangtingban.png' alt='' />" + "<img class='cheng' src='images/cheng.png' alt=''/>" + "<img class='giftnumber' src='images/one.png' alt='' />" + "</div></li>";
                var giftAnimation = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “涨停板” </span></p>" + "<img class='whatGift' src='images/giftzhangtingban.png' alt='' /></li>";
                $(".presentJump").prepend(giftSendAlert);
                $(".chatDetail").prepend(giftAnimation);
                $(".chatDetail").scrollTop(0);
                $(".presentJump li").delay(5000).hide(0);
                break;
            case "1888":
                var giftSendAlert = "<li><img class='presentBg' src='images/changeSlow.png' alt='' />" + "<div class='absoluteBox'>" + "<p class='presentNick'>" + fromAccountNick + "</p>" + "<p class='send'>送出</p>" + "<img class='gift' src='images/giftcaishenye.png' alt='' />" + "<img class='cheng' src='images/cheng.png' alt=''/>" + "<img class='giftnumber' src='images/one.png' alt='' />" + "</div></li>";
                var giftAnimation = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “财神爷” </span></p>" + "<img class='whatGift' src='images/giftcaishenye.png' alt='' /></li>";
                $(".presentJump").prepend(giftSendAlert);
                $(".chatDetail").prepend(giftAnimation);
                $(".chatDetail").scrollTop(0);
                $(".presentJump li").delay(5000).hide(0);
                break;
            case "8888":
                var giftSendAlert = "<li><img class='presentBg' src='images/changeSlow.png' alt='' />" + "<div class='absoluteBox'>" + "<p class='presentNick'>" + fromAccountNick + "</p>" + "<p class='send'>送出</p>" + "<img class='gift' src='images/giftjinniu.png' alt='' />" + "<img class='cheng' src='images/cheng.png' alt=''/>" + "<img class='giftnumber' src='images/one.png' alt='' />" + "</div></li>";
                var giftAnimation = "<li><img class='chatImg' src='" + headerIMG + "' alt='' />" + "<p class='chatName'>" + fromAccountNick + "</p>" + "<p class='chatTime'>" + sendTimeMin + "</p>" + "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “金牛” </span></p>" + "<img class='whatGift' src='images/giftjinniu.png' alt='' /></li>";
                $(".presentJump").prepend(giftSendAlert);
                $(".chatDetail").prepend(giftAnimation);
                $(".chatDetail").scrollTop(0);
                $(".presentJump li").delay(5000).hide(0);
                break;
            default:
            }
            $("#mCSB_2_container").css("top", "0");
            $("html,body").animate({
                scrollTop: 0
            },
            200)
        }
        return giftSendAlert
    }
    function addGroupSystemMsg(ReportType, reportTypeCh, GroupId, GroupName, content, timestamp) {
        var sysMsgStr = "收到一条群系统消息: type=" + timestamp + ", typeCh=" + reportTypeCh + ",群ID=" + GroupId + ", 群名称=" + GroupName + ", 内容=" + content + ", 时间=" + webim.Tool.formatTimeStamp(msg_time);
        webim.Log.warn(sysMsgStr)
    }
    function onSendMsg(userId, userNickName, userSig, userNickHeadurl, usertoken, roomid, msgtosend) {
        var loginInfo = {
            "sdkAppID": 1400018939,
            "appIDAt3rd": 1400018939,
            "accountType": 8454,
            "identifier": userId,
            "identifierNick": userNickName,
            "userSig": userSig,
            "headurl": userNickHeadurl
        };
        var selSessHeadUrl = "";
        if (!selToID) {
            $("#sendMsg").val("");
            return
        }
        var communicationData;
        var data = new Date();
        var time = data.getTime() + "";
        if (userId != uid) {
            var content = {
                "content": msgtosend,
                "itemType": 2,
                "media": "",
                "sendName": userNickName,
                "type": "2"
            };
            var content1 = JSON.stringify(content)
        } else {
            var content = {
                "content": msgtosend,
                "itemType": 2,
                "media": "",
                "sendName": userNickName,
                "type": "2"
            };
            var content1 = JSON.stringify(content)
        }
        var msgLen = webim.Tool.getStrBytes(msgtosend);
        if (msgtosend.length < 1) {
            layer.msg("发送的消息不能为空!");
            $("#sendMsg").val("");
            $("#sendMsg").attr("placeholder", "来说两句吧！");
            return
        }
        var maxLen, errInfo;
        var selType = webim.SESSION_TYPE.GROUP;
        if (selType == webim.SESSION_TYPE.C2C) {
            maxLen = webim.MSG_MAX_LENGTH.C2C;
            errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)"
        } else {
            maxLen = webim.MSG_MAX_LENGTH.GROUP;
            errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)"
        }
        if (msgLen > maxLen) {
            layer.msg(errInfo);
            return
        }
        if (!selSess) {
            var selSess = new webim.Session(selType, selToID, selToID, selSessHeadUrl, Math.round(new Date().getTime() / 1000))
        }
        var isSend = true;
        var seq = -1;
        var random = Math.round(Math.random() * 4294967296);
        var msgTime = Math.round(new Date().getTime() / 1000);
        var subType;
        if (selType == webim.SESSION_TYPE.C2C) {
            subType = webim.C2C_MSG_SUB_TYPE.COMMON
        } else {
            subType = webim.GROUP_MSG_SUB_TYPE.COMMON
        }
        var msg = new webim.Msg(selSess, isSend, seq, random, msgTime, loginInfo.identifier, subType, loginInfo.identifierNick);
        var text_obj, face_obj, tmsg, emotionIndex, emotion, restMsgIndex;
        var expr = /\[[^[\]]{1,3}\]/mg;
        var emotions = msgtosend.match(expr);
        if (!emotions || emotions.length < 1) {
            text_obj = new webim.Msg.Elem.Text(msgtosend);
            msg.addText(text_obj)
        } else {
            for (var i = 0; i < emotions.length; i++) {
                tmsg = msgtosend.substring(0, msgtosend.indexOf(emotions[i]));
                if (tmsg) {
                    text_obj = new webim.Msg.Elem.Text(tmsg);
                    msg.addText(text_obj)
                }
                emotionIndex = webim.EmotionDataIndexs[emotions[i]];
                emotion = webim.Emotions[emotionIndex];
                if (emotion) {
                    face_obj = new webim.Msg.Elem.Face(emotionIndex, emotions[i]);
                    msg.addFace(face_obj)
                } else {
                    text_obj = new webim.Msg.Elem.Text(emotions[i]);
                    msg.addText(text_obj)
                }
                restMsgIndex = msgtosend.indexOf(emotions[i]) + emotions[i].length;
                msgtosend = msgtosend.substring(restMsgIndex)
            }
            if (msgtosend) {
                text_obj = new webim.Msg.Elem.Text(msgtosend);
                msg.addText(text_obj)
            }
        }
        webim.sendMsg(msg,
        function(resp) {
            $("#sendMsg").val("");
            $(".apply").stop().hide();
            $(".applyInput").val("");
            if (uid != userId) {
                showMsg(userId, userToken, roomid, content1, 1, 2)
            } else {
                showMsg(uid, userToken, roomid, content1, 1, 1);
                showMsg(uid, userToken, roomid, content1, 1, 2)
            }
            $("html,body").animate({
                scrollTop: 0
            },
            200);
            $("#mCSB_2_container").css("top", "0");
            $("#noChatContent").stop().hide()
        },
        function(err) {
            layer.msg(err.ErrorInfo)
        })
    }
    function sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid, msgtosend, publishType, mediaStr, giftBox) {
        var loginInfo = {
            "sdkAppID": 1400018939,
            "appIDAt3rd": 1400018939,
            "accountType": 8454,
            "identifier": userId,
            "identifierNick": userNickName,
            "userSig": userSig,
            "headurl": userNickHeadurl
        };
        if (!selToID) {
            layer.msg("您还没有好友或群组，暂不能聊天");
            return
        }
        if (!giftBox) {
            if (publishType == 1) {
                var sendInfo = {
                    "content": msgtosend,
                    "itemType": 0,
                    "media": "",
                    "sendName": userNickName,
                    "type": "0"
                }
            } else {
                if (publishType == 2) {
                    var sendInfo = {
                        "content": msgtosend,
                        "itemType": 0,
                        "media": mediaStr,
                        "sendName": userNickName,
                        "type": "0"
                    }
                } else {
                    if (publishType == 3) {
                        var sendInfo = {
                            "content": msgtosend,
                            "itemType": 3,
                            "media": "",
                            "sendName": userNickName,
                            "type": "3"
                        }
                    } else {
                        if (publishType == 4) {}
                    }
                }
            }
            var data = JSON.stringify(sendInfo);
            var desc = "pic_live";
            var ext = userNickName;
            var msgLen = webim.Tool.getStrBytes(data);
            if (data.length < 1) {
                layer.msg("发送的消息不能为空!");
                return
            }
            var maxLen, errInfo;
            var selType = webim.SESSION_TYPE.GROUP;
            if (selType == webim.SESSION_TYPE.C2C) {
                maxLen = webim.MSG_MAX_LENGTH.C2C;
                errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)"
            } else {
                maxLen = webim.MSG_MAX_LENGTH.GROUP;
                errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)"
            }
            if (msgLen > maxLen) {
                layer.msg(errInfo);
                return
            }
            if (!selSess) {
                selSess = new webim.Session(selType, selToID, selToID, userNickHeadurl, Math.round(new Date().getTime() / 1000))
            }
            var msg = new webim.Msg(selSess, true, -1, -1, -1, loginInfo.identifier, 0, loginInfo.identifierNick);
            var custom_obj = new webim.Msg.Elem.Custom(data, desc, ext);
            msg.addCustom(custom_obj);
            webim.sendMsg(msg,
            function(resp) {
                if (publishType == 1) {
                    $("#noImgContent").val("")
                } else {
                    if (publishType == 2) {
                        $(".shortViewContent").val("");
                        $(".publishImgBox").stop().hide()
                    } else {
                        if (publishType == 3) {
                            $("#linkUrl").val("");
                            $("#linkUrlDescripe").val("");
                            $(".addLinkUrl").stop().hide()
                        }
                    }
                }
                $("html,body").animate({
                    scrollTop: 0
                },
                200);
                $("#mCSB_1_container").css("top", "0");
                $("#noZhiboContent").stop().hide();
                showMsg(userId, userToken, roomid, data, 1, 1);
                if (selType == webim.SESSION_TYPE.C2C) {}
            },
            function(err) {
                layer.msg(err.ErrorInfo)
            })
        } else {
            var data = $("#giftPrice" + giftBox).html();
            var desc = "givemoney2_zhubo";
            var ext = userNickName;
            var msgLen = webim.Tool.getStrBytes(data);
            if (data.length < 1) {
                return
            }
            var maxLen, errInfo;
            var selType = webim.SESSION_TYPE.GROUP;
            if (selType == webim.SESSION_TYPE.C2C) {
                maxLen = webim.MSG_MAX_LENGTH.C2C;
                errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)"
            } else {
                maxLen = webim.MSG_MAX_LENGTH.GROUP;
                errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)"
            }
            if (msgLen > maxLen) {
                return
            }
            if (!selSess) {
                selSess = new webim.Session(selType, selToID, selToID, userNickHeadurl, Math.round(new Date().getTime() / 1000))
            }
            var msg = new webim.Msg(selSess, true, -1, -1, -1, loginInfo.identifier, 0, loginInfo.identifierNick);
            var custom_obj = new webim.Msg.Elem.Custom(data, desc, ext);
            msg.addCustom(custom_obj);
            webim.sendMsg(msg,
            function(resp) {},
            function(err) {})
        }
    }

    //视频播放器
    var video = $("#myVideo").get(0);
    //播放进度
    video.ontimeupdate = function(){
        var currTime = this.currentTime,    //当前播放时间
            duration = this.duration,       // 视频总时长
            bufferedEnd=this.buffered.end(0);//缓冲进度
        $(".progress .loaded").css("width",(bufferedEnd / 100) * 834 +"px");
        //百分比
        var pre = currTime / duration;
        //显示进度条
        $(".progress .line").css("width",pre * 834 +"px");
        $(".progress_btn").css("left",pre * 834 +"px");
    };
    //跳跃播放
    $(".progress").click(function (e) {
        video.currentTime=(event.offsetX / this.offsetWidth) * video.duration;
    });
    //播放时间显示
    var i = setInterval(function() {
        if(video.readyState > 0) {
            var hours = parseInt(video.duration / (60*60));
            var minutes = parseInt((video.duration - hours*3600)/60);
            var seconds = parseInt(video.duration - minutes*60 - hours*3600 );
            // console.log(hours);
            // console.log(video.duration);
            if (hours < 10) {
                hours = "0" + hours;
            }
            if (minutes < 10) {
                minutes = "0" + minutes;
            }
            if (seconds < 10) {
                seconds = "0" + seconds;
            }
            $(".videoTime .totalTime").html(hours + ":" + minutes + ":" + seconds);

            clearInterval(i);
            $("#myVideo").on(
                "timeupdate",
                function (event) {
                    onTrackedVideoFrame(this.currentTime);
                });
            function onTrackedVideoFrame(currentTime){
                /*var minutes = parseInt(currentTime / 60, 10);
                 var hours = parseInt(minutes / 60);
                 var seconds = parseInt(currentTime % 60);*/
                var hours = parseInt(currentTime / (60*60));
                var minutes = parseInt((currentTime - hours*3600)/60);
                var seconds = parseInt(currentTime - minutes*60 - hours*3600 );
                if (hours < 10) {
                    hours = "0" + hours;
                }
                if (minutes < 10) {
                    minutes = "0" + minutes;
                }
                if (seconds < 10) {
                    seconds = "0" + seconds;
                }
                $(".videoTime .playTime").html(hours + ":" + minutes + ":" + seconds);
            }
        }
    }, 200);

    video.paused = true;
    $(".playicon").hover(function() {
        $(this).attr("src", "images/playicon-P.png")
    }, function() {
        $(this).attr("src", "images/playicon.png")
    });
    $(".playicon").on("click", function() {
        if(video.paused) {
            video.play();
            $(".playicon").attr("src", "images/playicon-p.png")
        } else {
            video.pause();
            $(".playicon").css("display", "none");
            $(".stopicon-P").css("display", "block");
        }
        return false
    });
    $(".stopicon-P").hover(function() {
        $(this).attr("src", "images/stopicon-p.png")
    }, function() {
        $(this).attr("src", "images/stopicon.png")
    });
    $(".stopicon-P").on("click", function() {
        if(video.paused) {
            video.play();
            $(".playicon").css("display", "block");
            $(".stopicon-P").css("display", "none")
        } else {
            video.pause()
        }
        return false
    });
    $(".refreshicon").click(function() {
        video.load();
    });
    $(".refreshicon").hover(function() {
        $(this).attr("src", "images/refreshicon-P.png")
    }, function() {
        $(this).attr("src", "images/refreshicon.png")
    });
    $(".volumeicon").click(function() {
        video.volume = 0;
        $("#range").val(0);
        $(".volumeicon").css("display", "none");
        $(".volumeicon1").css("display", "block");
        $(".range_before").width(0);
        $(".range_center").css({
            "left": "-5px"
        })
        return false
    });
    $(".volumeicon1").click(function() {
        video.volume = 0.5;
        $("#range").val(50);
        $(".volumeicon1").css("display", "none");
        $(".volumeicon").css("display", "block");
        $(".range_before").width(50);
        $(".range_center").css({
            "left": "45px"
        })
        return false
    });
    //声音播放器
    $("#soundBox").mousedown(function(e) {
        var oX = e.pageX - $("#soundBox").offset().left - $(".range_center").width() / 2;
        //判断，不让.drag出.left
        if(oX < 0) {
            oX = 0;
        } else if(oX > $("#soundBox").width() - $(".range_center").width()) {
            oX = $("#soundBox").width() - $(".range_center").width();
        }
        video.volume = oX / 100;
        $(".range_center").css({
            "left": oX + "px",
        });
        $(".range_before").css({
            "width": oX + 10 + "px",
        })

    })
    $(document).bind("mouseup", function() {
        $(this).unbind("mousemove");
    });
    //拖动中间部分改变声音大小

    $(".full_screenicon").hover(function() {
        $(this).attr("src", "images/full-screenicon-P.png")
    }, function() {
        $(this).attr("src", "images/full-screenicon.png")
    });

    function launchFullscreen(element) {
        if(element.requestFullscreen) {
            element.requestFullscreen()
        } else {
            if(element.mozRequestFullScreen) {
                element.mozRequestFullScreen()
            } else {
                if(element.webkitRequestFullscreen) {
                    element.webkitRequestFullscreen()
                } else {
                    if(element.msRequestFullscreen) {
                        element.msRequestFullscreen()
                    }
                }
            }
        }
    }
    $(".full_screenicon").on("click", function() {
        launchFullscreen(document.getElementById("myVideo"))
    });
    $("#myVideo").on("timeupdate", function(event) {
        onTrackedVideoFrame(this.currentTime, this.duration)
    });

    function onTrackedVideoFrame(currentTime, duration) {
        $("#current_minute").text(parseInt(currentTime / 60));
        $("#current_second").text(parseInt(currentTime % 60));
        $("#total_minute").text(parseInt(duration / 60));
        $("#total_second").text(parseInt(duration % 60))
    };


    //加密或者不加密获得视频详情后
    function getVideoDetails(res) {
        console.log(res);
        var playUrl = res.data.playUrl;
       playUrl = playUrl.replace('http', 'https'); //外网视频https
        if(Hls.isSupported()) {
            var video = document.getElementById('myVideo');
            var hls = new Hls();
            hls.loadSource(playUrl);
            hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED, function() {
                video.play();
            });
        }

    };
});