$(document).ready(function() {
	//tab切换
	tabFun(".rankBtnSchool", "active", ".tabContentSchool");

	tabFun(".personOrder", "active", ".personContent");
	loginFun();
	//判断是否登录
	function loginFun() {
		$.ajax({
			type: "get",
			url: "/userInfos",
			success: function(res) {
				//console.log(res);
				if(res.code == -2) { //未登录
					$(".signUpBtn").click(function() {
						$("#loginAlert").stop().show();
						$("#loginAlert").load("/login");
					});
					/*风采视频*/
					getVideosByParams("", "", 1, 1, 2);
				} else if(res.code == 0) { //登录成功
					var userUid = res.data.userInfo.uid;
					getVideosByParams("", userUid, 1, 1, 2);
					getJoinerInfo(userUid, userUid);
				}
			}
		})
	}
	//判断是否报名

	function getJoinerInfo(objectId, uid) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"objectId": objectId,
				"uid": uid,
			},
			url: "/common-service/api/v1/joiner/getJoinerInfo",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					if(res.code == 0) {
						var JoinInfo = JSON.stringify(res.data.JoinInfo);
						if(JoinInfo == "" || JoinInfo == undefined || JoinInfo == null || JoinInfo == '{}') { //游客视角
							$(".signUpBtn").click(function() {
								//console.log("未报名");
								window.location.href = "/applyPc";
							})
						} else { //账户视角
							$(".signUpBtn").stop().hide();
						}
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	/*轮播*/
	selectByType(1, 20);

	function selectByType(pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			data: {
				"type": 37,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/api/v1/banner/selectByType.do",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					$(res.data).each(function(b, D) {
						var bannerType = D.bannerType; //1文章，2短评，3视频，4直播，5静态网页，6主播个人页,7不跳转，8操盘手个人页，9个人实盘页，10话题，11专栏详情页，12=直播间，13=音频,14=回放，15=文字链，16=专题
						var bannerIdHref = D.bannerId + "bannerIdHref";
						var objectId = D.id;
						var uid = D.uid;
						var roomId = D.roomId;
						var swiperList =
							'<li class="swiper-slide" id=' + bannerIdHref + ' bannerType=' + bannerType + ' objectId = ' + objectId + ' uid = ' + uid + ' roomId = ' + roomId + '><img src=' + D.imgUrl + ' alt="" /></li>';
						$(".swiper-wrapper").append(swiperList);

						// 点击banner跳转
						$("#" + bannerIdHref).click(function() {
							var bannerType = $(this).attr("bannerType");
							var id = $(this).attr("objectId");
							var uid = $(this).attr("uid");
							var roomId = $(this).attr("roomId");
							if(bannerType == 1) { //1文章，2短评，3视频，4直播，5静态网页，6主播个人页,7不跳转，8操盘手个人页，9个人实盘页，10话题，11专栏详情页，12=直播间，13=音频,14=回放，15=文字链，16=专题
								window.location.href = "/article?id=" + id;
							} else if(bannerType == 2) {
								window.location.href = "/shortView?id=" + id;
							} else if(bannerType == 3) {
								window.location.href = "/video?id=" + id;
							} else if(bannerType == 4 || bannerType == 12) {
								window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomId;
							} else if(bannerType == 5) {
								window.location.href = id;
							} else if(bannerType == 6) {
								window.location.href = "/userProfile?uid=" + uid;
							} else if(bannerType == 8 || bannerType == 9) {
								window.location.href = "/userProfile?uid=" + uid + "&tab=4";
							} else if(bannerType == 11) {
								window.location.href = "/columnDetail?id=" + id;
							} else if(bannerType == 13) {
								window.location.href = "/audio?id=" + id;
							} else if(bannerType == 14) {
								window.location.href = "/liveLookBack?id=" + id + "&roomid=" + roomId + "&uid=" + uid;
							} else if(bannerType == 16) {
								window.location.href = "/dissertation?id=" + id;
							}
						})
					})
					var swiper = new Swiper('.swiper-container', {
						pagination: {
							el: '.swiper-pagination',
							clickable: true,
						},
						autoplay: {
							delay: 3000,
							disableOnInteraction: false,
						}
					});
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	/*跑马灯*/
	getCarouselListFun();

	function getCarouselListFun() {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/common-service/api/v1/carousel/getCarouselList",
			success: function(res) {
				if(res.code == 0) {
					$(res.data).each(function(Q, M) {
						var noticeList =
							'<li>' + M + '</li>';
						$("marquee").append(noticeList);
					})

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	//高校榜——人气榜
	getTeamPopularityRank(1, 3);

	function getTeamPopularityRank(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/common-service/api/v1/school/getTeamPopularityRank",
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					// console.log(res);
					if(res.data.rank.length == 0 && pageIndex == 1) {
						$(".schoolRankMoodsNull").stop().show();
						$(".schoolRankMoods").stop().hide();
					} else {
						$(res.data.rank).each(function(b, H) {
							var imgId = H.id + "schoolRankMoods" + b;
							var profitId = H.id + "profitSchoolMood" + b;
							var schoolRankMoodsList =
								'<li>' +
								'<p class="rankInner">' +
								'<img id=' + imgId + ' src="../images/NetCup/one.png" alt="" />' +
								'<span class="schoolName">' + H.sname + '</span>' +
								'<span class="schoolNum">' + H.memberCount + '</span>' +
								'<span class="profit isBeginNo" id=' + profitId + '>' + numTrans(H.profitAmount) + '</span>' +
								'<span class="votePeople fr isBeginNo">' + H.popularity + '</span>' +
								'</p>' +
								'<p class="voteBtn fl downLoadAppPcBtn">投票</p>' +
								'<p class="joinSchool fl downLoadAppPcBtn">加入战队</p>' +
								'</li>';
							$(".schoolRankMoodsMore").before(schoolRankMoodsList);
							$(".downLoadAppPcBtn").click(function() {
								window.location.href = "/downLoadAppPc";
							});
							if(b == 1) {
								$("#" + H.id + "schoolRankMoods" + b).attr("src", "../images/NetCup/two.png");
							} else if(b == 2) {
								//console.log(b);
								$("#" + H.id + "schoolRankMoods" + b).attr("src", "../images/NetCup/three.png");
							};
							if(res.data.isBegin == false) {
								$(".isBeginNo").html("未开赛");
								$(".isBeginNo").css({
									"color": "#a9a9a9"
								});
							};
							if(H.profitAmount < 0) {
								$("#" + profitId).css({
									"color": "#31bc6d",
								})
							}
						})
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	//高校榜——收益榜（暂无接口）
	getTeamPopularityRank1(1, 3);

	function getTeamPopularityRank1(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/trade-service/api/v1/trade/getTeamProfitRank",
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					//console.log(res);
					if(res.data == "" || res.data == undefined || res.data == null) {
						$(".schoolMoneyRankNull").stop().show();
						$(".schoolMoneyRank").stop().hide();
					} else {
						if(res.data.rank.length == 0 && pageIndex == 1) {
							$(".schoolMoneyRankNull").stop().show();
							$(".schoolMoneyRank").stop().hide();
						} else {
							$(res.data.rank).each(function(b, H) {
								var imgId = H.id + "schoolMoneyRank" + b;
								var profitId = H.id + "profitSchoolMoney" + b;
								var schoolRankMoodsList =
									'<li>' +
									'<p class="rankInner">' +
									'<img id=' + imgId + ' src="../images/NetCup/one.png" alt="" />' +
									'<span class="schoolName">' + H.sname + '</span>' +
									'<span class="schoolNum">' + H.memberCount + '</span>' +
									'<span class="profit isBeginNo" id=' + profitId + '>' +numTrans(H.profitAmount) + '</span>' +
									'<span class="votePeople fr isBeginNo">' + H.popularity + '</span>' +
									'</p>' +
									'<p class="voteBtn fl downLoadAppPcBtn">投票</p>' +
									'<p class="joinSchool fl downLoadAppPcBtn">加入战队</p>' +
									'</li>';
								$(".schoolMoneyRankMore").before(schoolRankMoodsList);
								$(".downLoadAppPcBtn").click(function() {
									window.location.href = "/downLoadAppPc";
								});
								if(b == 1) {
									$("#" + H.id + "schoolMoneyRank" + b).attr("src", "../images/NetCup/two.png");
								} else if(b == 2) {
									//console.log(b);
									$("#" + H.id + "schoolMoneyRank" + b).attr("src", "../images/NetCup/three.png");
								};
								if(H.profitAmount < 0) {
									$("#" + profitId).css({
										"color": "#31bc6d",
									})
								}
							});
						}
						if(res.data.isBegin == false) {
							$(".isBeginNo").html("未开赛");
							$(".isBeginNo").css({
								"color": "#a9a9a9"
							});
						}
					}

				} else if(res.code == -9998) {
					$(".schoolMoneyRankNull").stop().show();
					$(".schoolMoneyRank").stop().hide();
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	//高校榜——个人收益排行榜
	getProfitRank(1, 3);

	function getProfitRank(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/trade-service/api/v1/trade/getProfitRank",
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					if(res.data == "" || res.data == undefined || res.data == null) {
						$(".personMoneyMoodsNull").stop().show();
						$(".personMoneyMoods").stop().hide();
					} else {
						if(res.data.rank.length == 0 && pageIndex == 1) {
							$(".personMoneyMoodsNull").stop().show();
							$(".personMoneyMoods").stop().hide();
						} else {
							$(res.data.rank).each(function(b, H) {
								var imgId = H.uid + "schoolRankMoods" + b;
								var profitId = H.id + "profitPersonMoney" + b;
								var schoolRankMoodsList =
									'<li>' +
									'<p class="rankInner">' +
									'<img id=' + imgId + ' src="../images/NetCup/one.png" alt="" />' +
									'<span class="schoolName">' + H.name + '</span>' +
									'<span class="schoolNum">' + H.id + '</span>' +
									'<span class="profit isBeginNo" id=' + profitId + '>' + numTrans(H.profit) + '</span>' +
									'<span class="votePeople fr isBeginNo">' + H.popularity + '</span>' +
									'</p>' +
									'<p class="fl personFromSchool">' + H.teamName + '</p>' +
									'<p class="fr downLoadAppPcBtn personFromSchoolVoteBtn">投票</p>' +
									'</li>';
								$(".personMoneyMoodsMore").before(schoolRankMoodsList);
								$(".downLoadAppPcBtn").click(function() {
									window.location.href = "/downLoadAppPc";
								});
								if(b == 1) {
									$("#" + H.uid + "schoolRankMoods" + b).attr("src", "../images/NetCup/two.png");
								} else if(b == 2) {
									//console.log(b);
									$("#" + H.uid + "schoolRankMoods" + b).attr("src", "../images/NetCup/three.png");
								};
								if(H.profit < 0) {
									$("#" + profitId).css({
										"color": "#31bc6d",
									})
								}
							});
						}
						if(res.data.isBegin == false) {
							$(".isBeginNo").html("未开赛");
							$(".isBeginNo").css({
								"color": "#a9a9a9"
							});
						}
					}

				} else if(res.code == -9998) {
					$(".personMoneyMoodsNull").stop().show();
					$(".personMoneyMoods").stop().hide();
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	//个人榜——人气榜
	getPopularityRank(1, 3);

	function getPopularityRank(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/common-service/api/v1/joiner/getPopularityRank",
			success: function(res) {
				console.log(res);
				if(res.code == 0) {
					//	console.log(res);
					if(res.data.rank.length == 0 && pageIndex == 1) {
						$(".personRankMoodsNull").stop().show();
						$(".personRankMoods").stop().hide();
					} else {
						$(res.data.rank).each(function(q, F) {
							var imgId = F.uid + "personOrderList" + q;
							var profitId = F.uid + "profitPresonMood" + q;
							var personRankMoodsList =
								'<li class="personOrderList">' +
								'<p class="rankInner">' +
								'<img id=' + imgId + ' src="../images/NetCup/one.png" alt="" />' +
								'<span class="schoolName">' + F.name + '</span>' +
								'<span class="schoolNum">' + F.id + '</span>' +
								'<span class="profit isBeginNo" id=' + profitId + '>' + numTrans(F.profit) + '</span>' +
								'<span class="votePeople fr isBeginNo">' + F.popularity + '</span>' +
								'</p>' +
								'<p class="fl personFromSchool">' + F.teamName + '</p>' +
								'<p class="fr downLoadAppPcBtn personFromSchoolVoteBtn">投票</p>' +
								'</li>';
							$(".personRankMoodsMore").before(personRankMoodsList);
							$(".downLoadAppPcBtn").click(function() {
								window.location.href = "/downLoadAppPc";
							});
							if(q == 1) {
								$("#" + F.uid + "personOrderList" + q).attr("src", "../images/NetCup/two.png");
							} else if(q == 2) {
								//console.log(b);
								$("#" + F.uid + "personOrderList" + q).attr("src", "../images/NetCup/three.png");
							};
							if(F.profit < 0) {
								$("#" + profitId).css({
									"color": "#31bc6d",
								})
							}
						});
					}
					if(res.data.isBegin == false) {
						$(".isBeginNo").html("未开赛");
						$(".isBeginNo").css({
							"color": "#a9a9a9"
						});
					}

				} else if(res.code == -9998) {
					$(".personRankMoodsNull").stop().show();
					$(".personRankMoods").stop().hide();
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	function getVideosByParams(uid, userId, isRec, pageIndex, pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			data: {
				"uid": uid,
				"userId": userId,
				"isRec": isRec,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/common-service/api/v1/video/getVideosByParams",
			success: function(res) {
				if(res.code == 0) {
					if(res.data.videoList.length == 0) {
						$(".styleVideoListNull").stop().show();
					} else {
						$(res.data.videoList).each(function(b, D) {
							var videoHrefId = D.id + "videoHrefId";
							var type = D.type;
							var objectId = D.id;
							var isAgree = D.isAgree;
							var isAgreeId = D.id + "videoIsAgree";
							var styleVideoInfoList =
								'<li class="styleVideoInfo fl" id=' + videoHrefId + ' hrefType=' + type + ' objectId=' + objectId + '>' +
								'<div class="styleVideoInfoL">' +
								'<img src="' + D.coverUrl + '" alt="" />' +
								'<img src="../images/bigPlay.png" alt="" />' +
								'</div>' +
								'<div class="videoInner styleVideoInfoR">' +
								'<span class="videoTitleNew fl">' + D.realName + '</span>' +
								'<span class="zanNum fr" id=' + isAgreeId + '>' + D.praiseCount + '</span>' +
								'</p>' +
								'</div>' +
								'</li>';
							$(".styleVideoList").append(styleVideoInfoList);
							if(isAgree == true) {
								$("#" + isAgreeId).css({
									"background": "url(../images/NetCup/praiseP.png) no-repeat left center",
									"color": "#d9a668"

								});
							} else {
								$("#" + isAgreeId).css({
									"background": "url(../images/NetCup/praise.png) no-repeat left center",
									"color": "#939393"
								})

							}
							$("#" + videoHrefId).click(function() {
								window.location.href = "/downLoadAppPc";

								//							var id=$(this).attr("objectId");
								//							var hrefType=$(this).attr("hrefType");//2-视频 3-音频
								//							if(hrefType==2){
								//								window.location.href="/video?id="+id;
								//							}else if(hrefType==3){
								//								window.location.href="/audio?id="+id;
								//							}

							})
						})
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	//赛事动态
	homeIndex(1, 10);
	var bottomH = 150; //距离底部多少像素开始加载
	var homeIndexPageIndex = 1
	$(window).scroll(function() {
		var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop() + bottomH);
		if($(document).height() <= totalheight) {
			homeIndexPageIndex++;
			homeIndex(homeIndexPageIndex, 10);
		}
	});

	function homeIndex(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/api/v3/homePage/eventDynamics.do",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					var hotVideoLen = res.data.length;
					//console.log(hotVideoLen);
					if(hotVideoLen != pageSize) {
						$("#hotLoadinggetLabelFlow").delay(0).hide(0);
						$(".getLabelFlowNoMore").delay(0).show(0);
					} else {
						$("#hotLoadinggetLabelFlow").stop().show();
						$(".getLabelFlowNoMore").stop().hide();
					};
					$(res.data).each(function(i, M) {
						differentStype(M); //处理不同的类型
					})

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	function differentStype(M) {
		var type = M.type;
		var oneImgArticleImgAnchorHead = M.information.id + "oneImgArticleImgAnchorHead";
		//console.log(oneImgArticleImgAnchorHead);
		if(type == 0) { //最头条
			//console.log(M);
		} else if(type == 1) { //专栏类目
			//console.log(M);
		} else if(type == 2) { //话题
			//console.log(M);
		} else if(type == 3) { //直播
			var liveWrap = "<a href=/liveNew?uid=" + M.information.liverInfo.uid + "&roomid=" + M.information.roomId + " >" +
				"<div class='liveWrap' uid=" + M.information.liverInfo.uid + ">" +
				"<div class='liveL fl'>" +
				"<img class='liveCover' src=" + M.information.coverUrl + '!220X164' + ">" +
				"<img class='liveSystem' src='images/indexlive.png' />" +
				"</div>" +
				"<div class='videoR fl'>" +
				"<div class='videoRPosition'>" +
				"<p class='videoTitle'>" + M.information.topic + "</p>" +
				"<p class='videoRBottom'>" +
				"<img class='videoImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">" +
				"<span class='videoImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
				"<span class='videoImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
				"</p>" +
				"</div>" +
				"</div>" +
				"</div>" +
				"</a>";
			$(".getLabelFlowBox").append(liveWrap);
			$(".liveCover").one("error", function(e) {
				$(this).attr("src", "images/vedioCoverUrl.jpg")
			});
		} else if(type == 4) { //回看
			//console.log(M);
			var liveLookWrap = "<a href=/liveLookBack?id=" + M.information.id + "&roomid=" + M.information.roomId + "&uid=" + M.information.liverInfo.uid + ">" +
				"<div class='liveLookWrap' id=" + M.information.id + ">" +
				"<div class='liveL fl'>" +
				"<img class='liveCover' src=" + M.information.coverUrl + '!220X164' + ">" +
				"<img class='liveLookSystem' src='images/indexplay.png' />" +
				"<img class='videoSystem' src='images/indexvideo.png' />" +
				"</div>" +
				"<div class='videoR fl'>" +
				"<div class='videoRPosition'>" +
				"<p class='videoTitle'>" + M.information.topic + "</p>" +
				"<p class='videoRBottom'>" +
				"<img class='videoImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">" +
				"<span class='videoImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
				"<span class='videoImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
				"</p>" +
				"</div>" +
				"</div>" +
				"</div>" +
				"</a>";
			$(".getLabelFlowBox").append(liveLookWrap);
			$(".liveCover").one("error", function(e) {
				$(this).attr("src", "images/vedioCoverUrl.jpg")
			});

		} else if(type == 5) { //视频
			var videoWrap = "<a href=/video?id=" + M.information.id + ">" +
				"<div class='videoWrap' videoId=" + M.information.id + ">" +
				"<div class='liveL fl'>" +
				"<img class='liveCover' src=" + M.information.coverUrl + '!220X164' + ">" +
				"<img class='videoSystem' src='images/indexvideo.png' />" +
				"<span class='videoTime'>" + durationFun(M.information.duration) + "</span>" +
				"</div>" +
				"<div class='videoR fl'>" +
				"<div class='videoRPosition'>" +
				"<p class='videoTitle'>" + M.information.topic + "</p>" +
				"<p class='videoRBottom'>" +
				"<img class='videoImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">" +
				"<span class='videoImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
				"<span class='videoImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
				"</p>" +
				"</div>" +
				"</div>" +
				"</div>" +
				"</a>";
			$(".getLabelFlowBox").append(videoWrap);

		} else if(type == 6) { //音频
			//			console.log(M);
			var indexAudioBox =
				"<a href=/audio?id=" + M.information.id + ">" +
				"<div class='ImgArticleWrap'>" +
				"<p class='ImgArticleImgTitle'>" + M.information.topic + "</p>" +
				"<div class='indexAudioBox'>" +
				"<div class='indexAudioBoxL fl'>" +
				"<img src=" + M.information.liverInfo.headImgUrl + ">" +
				"<img src='../images/indexvideo.png'/>" +
				"</div>" +
				"<p class='fl'>" + M.information.topic + "</p>" +
				"<p class='fl audioTime'>" + durationFun(M.information.duration) + "</p>" +
				'</div>' +
				"<p>" +
				"<img class='ImgArticleImgAnchorHead fl' src=" + M.information.liverInfo.headImgUrl + ">" +
				"<span class='ImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
				"<span class='mgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
				"</p>" +
				"</div>" +
				"</a>";
			$(".getLabelFlowBox").append(indexAudioBox);

		} else if(type == 7) { //文章
			//console.log(M);
			if(M.coverUrl) {
				var content = htmlEncode(M.information.content);
				var oneImgArticleWrap = "<a href=/article?id=" + M.information.id + ">" +
					"<div class='oneImgArticleWrap' id=" + M.information.id + ">" +
					"<div class='oneImgArticleL fl'>" +
					"<img class='fl oneImgArticleImg' src=" + M.coverUrl + ">" +
					"</div>" +
					"<div class='oneImgArticleImgR'>" +
					"<p class='oneImgArticleImgTitle'>" + M.information.title + "</p>" +
					"<p class='oneImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
					"<p>" +
					"<img class='ImgArticleImgAnchorHead fl' id=" + oneImgArticleImgAnchorHead + " src=" + M.information.liverInfo.headImgUrl + ">" +
					"<span class='ImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
					"<span class='mgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
					"</p>" +
					"</div>" +
					"</div>" +
					"</a>";
				$(".getLabelFlowBox").append(oneImgArticleWrap);

				//文章无图，显示内容一行半
				$(".oneImgArticleImgInner").each(function() {
					var shortReviewText = $(this).text().substring(0, 60) + "...";
					if($(this).text().length > 60) {
						$(this).text(shortReviewText);
					}
				});
				$("#" + oneImgArticleImgAnchorHead).one("error", function(e) {
					$(this).attr("src", "images/anchorHead.png");
				});
			} else if(M.userCoverUrl) {
				var content = htmlEncode(M.information.content);
				var oneImgArticleWrap = "<a href=/article?id=" + M.information.id + ">" +
					"<div class='oneImgArticleWrap' id=" + M.information.id + ">" +
					"<div class='oneImgArticleL fl'>" +
					"<img class='fl oneImgArticleImg' src=" + M.userCoverUrl + ">" +
					"</div>" +
					"<div class='oneImgArticleImgR'>" +
					"<p class='oneImgArticleImgTitle'>" + M.information.title + "</p>" +
					"<p class='oneImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
					"<p>" +
					"<img class='ImgArticleImgAnchorHead fl' id=" + oneImgArticleImgAnchorHead + " src=" + M.information.liverInfo.headImgUrl + ">" +
					"<span class='ImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
					"<span class='mgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
					"</p>" +
					"</div>" +
					"</div>" +
					"</a>";
				$(".getLabelFlowBox").append(oneImgArticleWrap);

				//文章无图，显示内容一行半
				$(".oneImgArticleImgInner").each(function() {
					var shortReviewText = $(this).text().substring(0, 60) + "...";
					if($(this).text().length > 60) {
						$(this).text(shortReviewText);
					}
				});
				$("#" + oneImgArticleImgAnchorHead).one("error", function(e) {
					$(this).attr("src", "images/anchorHead.png");
				});
			} else {
				var content = htmlEncode(M.information.content);
				var imgReg = /<img.*?(?:>|\/>)/gi;
				//匹配src属性
				var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
				var imgArr = content.match(imgReg);
				if(imgArr == null) {
					var ImgArticleWrap = "<a href=/article?id=" + M.information.id + ">" +
						"<div class='ImgArticleWrap'>" +
						"<p class='ImgArticleImgTitle'>" + M.information.title + "</p>" +
						"<p class='ImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
						"<p>" +
						"<img class='ImgArticleImgAnchorHead fl' id=" + oneImgArticleImgAnchorHead + " src=" + M.information.liverInfo.headImgUrl + ">" +
						"<span class='ImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
						"<span class='mgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
						"</p>" +
						"</div>" +
						"</a>";
					$(".getLabelFlowBox").append(ImgArticleWrap);
					//文章无图，显示内容一行半
					$(".ImgArticleImgInner").each(function() {
						var shortReviewText = $(this).text().substring(0, 80) + "...";
						if($(this).text().length > 80) {
							$(this).text(shortReviewText);
						}
					});
					$("#" + oneImgArticleImgAnchorHead).one("error", function(e) {
						$(this).attr("src", "images/anchorHead.png");
					});
				} else {
					src = imgArr[0].match(srcReg);
					if(src[1]) {
						var content = htmlEncode(M.information.content);
						var oneImgArticleWrap = "<a href=/article?id=" + M.information.id + ">" +
							"<div class='oneImgArticleWrap' id=" + M.information.id + ">" +
							"<div class='oneImgArticleL fl'>" +
							"<img class='fl oneImgArticleImg' src=" + src[1] + ">" +
							"</div>" +
							"<div class='oneImgArticleImgR'>" +
							"<p class='oneImgArticleImgTitle'>" + M.information.title + "</p>" +
							"<p class='oneImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
							"<p>" +
							"<img class='ImgArticleImgAnchorHead fl' id=" + oneImgArticleImgAnchorHead + " src=" + M.information.liverInfo.headImgUrl + ">" +
							"<span class='ImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
							"<span class='mgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
							"</p>" +
							"</div>" +
							"</div>" +
							"</a>";
						$(".getLabelFlowBox").append(oneImgArticleWrap);

						//文章无图，显示内容一行半
						$(".oneImgArticleImgInner").each(function() {
							var shortReviewText = $(this).text().substring(0, 60) + "...";
							if($(this).text().length > 60) {
								$(this).text(shortReviewText);
							}
						});
						$("#" + oneImgArticleImgAnchorHead).one("error", function(e) {
							$(this).attr("src", "images/anchorHead.png");
						});
					}
				}
			}
		} else if(type == 10) { //大图文章
			var content = htmlEncode(M.information.content);
			var oneImgArticleWrap = "<a href=/article?id=" + M.information.id + ">" +
				"<div class='oneImgArticleWrap' id=" + M.information.id + ">" +
				"<div class='oneImgArticleL fl'>" +
				"<img class='fl oneImgArticleImg' src=" + M.information.coverUrl + '!220X164' + ">" +
				"</div>" +
				"<div class='oneImgArticleImgR'>" +
				"<p class='oneImgArticleImgTitle'>" + M.information.title + "</p>" +
				"<p class='oneImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
				"<p>" +
				"<img class='ImgArticleImgAnchorHead fl' id=" + oneImgArticleImgAnchorHead + " src=" + M.information.liverInfo.headImgUrl + ">" +
				"<span class='ImgArticleImgAnchorNickName fl'>" + M.information.liverInfo.nickName + "</span>" +
				"<span class='mgArticleImgTime fl'>" + format(new Date(M.information.createTime)) + "</span>" +
				"</p>" +
				"</div>" +
				"</div>" +
				"</a>";
			$(".getLabelFlowBox").append(oneImgArticleWrap);

			//文章无图，显示内容一行半
			$(".oneImgArticleImgInner").each(function() {
				var shortReviewText = $(this).text().substring(0, 60) + "...";
				if($(this).text().length > 60) {
					$(this).text(shortReviewText);
				}
			});
			$("#" + oneImgArticleImgAnchorHead).one("error", function(e) {
				$(this).attr("src", "images/anchorHead.png");
			});
		} else if(type == 11) { //,11-话题回答
		} else if(type == 12) { //,12-专题
			//console.log(M);
			var subjectBottomId = M.information.subject.id + "subjectBottomId";
			var subjectHrefId = M.information.subject.id + "subjectHrefId";
			var subjectBoxId = M.information.subject.id + "subjectBoxId";
			var indexThematicBox =
				'<div class="indexThematicBox" id=' + subjectBoxId + '>' +
				'<div class="indexThematicBoxT">' +
				'<span>专题</span>' +
				'<span>' + M.information.subject.name + '</span>' +
				'<span class="fr" id=' + subjectHrefId + ' objectId=' + M.information.subject.id + '>更多>></span>' +
				'</div>' +
				'<div class="indexThematicBoxC" id=' + subjectBottomId + '>' +

				'</div>' +
				"</div>";
			$(".getLabelFlowBox").append(indexThematicBox);
			//专题详情
			$("#" + subjectHrefId).click(function() {
				var dissertationId = $(this).attr("objectId");
				window.location.href = "/dissertation?id=" + dissertationId;
			})

			var subjectLen = M.information.content.length;
			if(subjectLen == 0) {
				$("#" + subjectBoxId).stop().hide();
			} else {
				$(M.information.content).each(function(q, S) { //内容类型（0-短评 1-文章 2-视频 3-音频 4-回放 5-直播 6-banner 7-PDF）
					//console.log(S);
					var id = S.object.id;
					var imgCoverid = S.object.id + "img";
					if(S.objectType == 2) { //视频
						var contentBotton =
							"<a href=/video?id=" + S.object.id + ">" +
							'<li class="indexThematicBoxCInfo fl">' +
							'<div class="indexThematicBoxCInfoT">' +
							'<img id=' + imgCoverid + ' src="' + S.object.coverUrl + '"/>' +
							'<div class="indexThematicBoxCInfoTCover"></div>' +
							'</div>' +
							'<p>' + S.object.topic + '</p>' +
							'</li>' +
							'</a>';
						$("#" + subjectBottomId).append(contentBotton);
					} else if(S.objectType == 1) { //文章
						// console.log(S);
						if(S.object.coverUrl) {
							var contentBotton =
								"<a href=/article?id=" + S.object.id + ">" +
								'<li class="indexThematicBoxCInfo fl">' +
								'<div class="indexThematicBoxCInfoT">' +
								'<img id=' + imgCoverid + ' src="' + S.object.coverUrl + '"/>' +
								'<div class="indexThematicBoxCInfoTCover"></div>' +
								'</div>' +
								'<p>' + S.object.title + '</p>' +
								'</li>' +
								'</a>';
							$("#" + subjectBottomId).append(contentBotton);
						} else if(S.object.userCoverUrl) {
							var contentBotton =
								"<a href=/article?id=" + S.object.id + ">" +
								'<li class="indexThematicBoxCInfo fl">' +
								'<div class="indexThematicBoxCInfoT">' +
								'<img id=' + imgCoverid + ' src="' + S.object.userCoverUrl + '"/>' +
								'<div class="indexThematicBoxCInfoTCover"></div>' +
								'</div>' +
								'<p>' + S.object.title + '</p>' +
								'</li>' +
								'</a>';
							$("#" + subjectBottomId).append(contentBotton);
						} else {
							var contentBotton =
								"<a href=/article?id=" + S.object.id + ">" +
								'<li class="indexThematicBoxCInfo fl">' +
								'<div class="indexThematicBoxCInfoT">' +
								'<img id=' + imgCoverid + ' src="../images/vedioCoverUrl.jpg"/>' +
								'<div class="indexThematicBoxCInfoTCover"></div>' +
								'</div>' +
								'<p>' + S.object.title + '</p>' +
								'</li>' +
								'</a>';
							$("#" + subjectBottomId).append(contentBotton);
						}

					} else if(S.objectType == 3) { //音频
						var contentBotton =
							"<a href=/audio?id=" + S.object.id + ">" +
							'<li class="indexThematicBoxCInfo fl">' +
							'<div class="indexThematicBoxCInfoT">' +
							'<img id=' + imgCoverid + ' src="' + S.object.coverUrl + '"/>' +
							'<div class="indexThematicBoxCInfoTCover"></div>' +
							'</div>' +
							'<p>' + S.object.topic + '</p>' +
							'</li>' +
							'</a>';
						$("#" + subjectBottomId).append(contentBotton);
					}
					$("#" + imgCoverid).one("error", function(e) {
						$(this).attr("src", "images/vedioCoverUrl.jpg");
					});
				})
			}
		} else if(type == 13) { //,13-直播间
			//console.log(M);
			var liveCarouselBoxOlnyid = "liveCarouselBoxOlnyid" + M.information.roomId;
			var onlyLiveRoomId = "onlyLiveRoomId" + M.information.roomId;
			var liveBoxOnlyId = "liveBoxOnlyId111" + M.information.roomId;
			var liveCarouselBox =
				'<div class="liveCarouselBox liveCarouselBoxOlny" id=' + onlyLiveRoomId + ' roomid=' + M.information.roomId + ' uid=' + M.information.liverInfo.uid + ' >' +
				'<p class="anchorRecommendTop anchorRecommendTopOnly">' + M.information.description + '<span class="fr">' + M.information.subscribers.count + '人参与</span></p>' +
				'<div class="liveCarouselInfo liveCarouselInfoOnly">' +
				'<img class="fl" src="' + M.information.liverInfo.headImgUrl + '" />' +
				'<div class="liveCarouselInfoR fl">' +
				'<p><span>' + M.information.liverInfo.nickName + '</span><span>' + format(new Date(M.information.createTime)) + '</span></p>' +
				'<div id=' + liveBoxOnlyId + ' class="liveBoxOnly">' +
				'<div class="JQ-content-box">' +
				'<div class="liveCarouselInfoBox JQ-slide-content liveCarouselInfoBoxOnly" id=' + liveCarouselBoxOlnyid + '>' +

				'</div>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'</div>';
			$(".getLabelFlowBox").append(liveCarouselBox);
			$(M.information.newest).each(function(Q, E) {
				var newestBox =
					"<p>" + E.content + "</p>";
				$("#" + liveCarouselBoxOlnyid).append(newestBox);
			});
			$(document).on("click", "#" + onlyLiveRoomId, function(e) {
				var roomid = $(this).attr("roomid");
				var uid = $(this).attr("uid");
				window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
			})
			//正在直播的轮播
			var showCount = 1, // 画面显示的条数
				totalCount = $(".liveCarouselInfoBoxOnly p").length, // 轮播总条数
				index = 0, // 轮播总条数下标
				autoTimer, // 全局变量目的实现左右点击同步
				clickEndFlag = true, // 设置每张走完才能再点击
				intervalTime = 3000; // 间隔时间

			// 克隆画面显示的条数总数放到最后(实现无缝滚动)
			//console.log('hkdsahfkl', totalCount);
			for(var i = 1; i <= showCount; i++) {
				$("#" + liveCarouselBoxOlnyid + " p:eq(" + (i - 1) + ")").clone(true).appendTo($("#" + liveCarouselBoxOlnyid));
			}

			var liHeight = $("#" + liveCarouselBoxOlnyid + " p").height(); //一个li的高度
			var totalHeight = ($("#" + liveCarouselBoxOlnyid + " p").length * $("#" + liveCarouselBoxOlnyid + " p").eq(0).height()) - (showCount * liHeight); //获取li的总高度再减去画面显示的条数的高度
			$("#" + liveCarouselBoxOlnyid).height(totalHeight); //给ul赋值高度

			//	滚动方法
			function upOffset2() {
				$("#" + liveCarouselBoxOlnyid).stop().animate({
					top: -index * liHeight
				}, 400, function() {
					clickEndFlag = true; //图片走完才会true
					if(index == $("#" + liveCarouselBoxOlnyid + " p").length - 1) {
						$("#" + liveCarouselBoxOlnyid).css({ top: 0 });
						index = 0;
					}
				})
			}

			function next2() {
				index++;
				if(index > totalCount) { //判断index为最后一个Li时index为0
					$("#" + liveCarouselBoxOlnyid).css({ top: 0 });
					index = 1;
				}
				upOffset2();
			}
			// 自动轮播
			autoTimer = setInterval(next2, intervalTime);
			$("#" + liveCarouselBoxOlnyid + " p").hover(function() {
				clearInterval(autoTimer);
			}, function() {
				autoTimer = setInterval(next2, intervalTime);
			})

			//		}else if(type == 14) { //,14-活动
			//		console.log(M);
			//		var indexType14Id=M.information.bannerId+"indexType14Id";
			//		var informationStartTime=M.information.bannerId+"informationStartTime";
			//		var informationEndTime=M.information.bannerId+"informationEndTime";
			//		var indexAdBoxAD=
			//		'<div class="indexAdBox" id='+indexType14Id+'  type='+M.information.bannerType+' objectId='+M.information.id+' uid='+M.information.uid+'  roomId='+M.information.roomId+'>'+
			//   	    '<img class="fl" src="'+M.information.imgUrl+'"/>'+
			//   	    '<div class="indexAdBoxR fl">'+
			//   	    	'<p>'+M.information.remarks+'</p>'+
			//   	    	'<p><span>进行中</span><span id='+informationEndTime+'>活动时间：'+formatTrader(new Date(M.information.start))+'-'+formatTrader(new Date(M.information.end))+'</span><span>'+M.information.parNumber+'人参与</span></p>'+
			//   	   ' </div>'+
			//    '</div>';
			//		$(".getLabelFlowBox").append(indexAdBoxAD);
			//		$("#"+indexType14Id).click(function(){
			//			var bannerType=$(this).attr("type");//	横幅类型（1文章，2短评，3视频，4直播，5静态网页，6主播个人页,7不跳转，8操盘手个人页，9个人实盘页，10话题，11专栏详情页，12=直播间，13=音频,14=回放，15=文字链，16=专题）
			//			var uid=$(this).attr("uid");
			//			var roomId=$(this).attr("roomId");
			//			var objectId=$(this).attr("objectId");
			//			if(bannerType == 1) { //文章
			//				window.location.href="/article?id=" + objectId; //文章
			//			}else if(bannerType == 2) { //短评
			//				window.location.href="/shortView?id=" + objectId; //短评
			//			}else if(bannerType == 3) { //视频
			//				window.location.href="/video?id=" + objectId; //视频
			//			}else if(bannerType == 4) { //直播
			//				window.location.href="liveNew?roomid="+roomId+"&uid="+uid; 
			//			}else if(bannerType == 5) { //5静态网页
			//				window.open(objectId); //静态网页
			//			}else if(bannerType == 6||bannerType == 8) { //6主播个人页
			//				window.location.href="/userProfile?uid=" + uid;
			//			}else if(bannerType == 9) { 
			//				window.location.href="/userProfile?uid=" + uid+"&tab=4"; 
			//			}else if(bannerType == 11) { //11专栏详情
			//				window.location.href="/columnDetail?id=" + objectId; //专栏详情
			//			}else if(bannerType == 12) { //z直播
			//				window.location.href="liveNew?roomid="+roomId+"&uid="+uid; 
			//			}else if(bannerType == 13){
			//				window.location.href="/audio?id=" + objectId;
			//			}else if(bannerType == 14){//回看
			//				window.location.href="liveLookBack?id="+objectId+"&roomid="+roomId+"&uid="+uid;
			//			}else if(bannerType == 16){//专题
			//				window.location.href="/dissertation?id=" + objectId;
			//			}
			//		})

		} else if(type == 16) { //,16-实盘
			//console.log(M);
		} else if(type == 15) { //,15-直播间轮播
			//console.log(M);
			var liveCarouselBoxid = "liveCarouselBoxid" + M.information.roomId;
			var liveCarouselBoxonlyLiveRoomId = "liveCarouse" + M.information.roomId;
			var liveCarouselBoxliveBoxOnlyId = "liveCarouselBoxliveBoxOnlyId" + M.information.roomId;
			var liveCarouselBoxliveCarouselBoxThree =
				'<div class="liveCarouselBox" id=' + liveCarouselBoxid + '>' +
				'<p class="anchorRecommendTop">正在直播</p>' +
				'<div id=' + liveCarouselBoxonlyLiveRoomId + ' class="liveBox">' +
				'<div class="JQ-content-box">' +
				'<div class="liveCarouselInfoBox JQ-slide-content liveCarousel" id=' + liveCarouselBoxliveBoxOnlyId + '>' +

				'</div>' +
				'</div>' +
				'</div>' +
				"</div>";
			$(".getLabelFlowBox").append(liveCarouselBoxliveCarouselBoxThree);
			$(M.information).each(function(Q, D) {
				var type = D.type; //直播间类型，0=主直播间（免费），1=VIP直播间
				var liveRoomHrefId = D.liverInfo.uid + "liveRoomHrefId";
				if(D.latest.content) {
					var liveContent = D.latest.content;
					if(liveContent.indexOf("igstn") > 0) {
						var anchorAnwserBrforeIm = liveContent.split("igstn")[0];
						var anchorAnwserAfterIm = liveContent.split("igstn")[1];
						var liveCarouselInfo =
							'<div class="liveCarouselInfo" id=' + liveRoomHrefId + ' uid=' + D.liverInfo.uid + ' roomId=' + D.roomId + ' type=' + D.liverInfo.type + '>' +
							'<img class="fl headImgUrl" src="' + D.liverInfo.headImgUrl + '!60X60"/>' +
							'<div class="liveCarouselInfoR fl">' +
							'<p><span>' + D.liverInfo.nickName + '</span><span>' + format(new Date(D.latest.time)) + '</span></p>' +
							'<p>' + anchorAnwserBrforeIm + '回复' + anchorAnwserAfterIm + '</p>' +
							'</div>' +
							'</div>';
						$("#" + liveCarouselBoxliveBoxOnlyId).append(liveCarouselInfo);
					} else if(liveContent.indexOf("igugl") > 0) {
						//console.log(D);
						var hrefBrforeIm = liveContent.split("igugl")[0];
						var hrefAfterIm = liveContent.split("igugl")[1];
						var liveCarouselInfo =
							'<div class="liveCarouselInfo" id=' + liveRoomHrefId + ' uid=' + D.liverInfo.uid + ' roomId=' + D.roomId + ' type=' + D.liverInfo.type + '>' +
							'<img class="fl headImgUrl" src="' + D.liverInfo.headImgUrl + '!60X60"/>' +
							'<div class="liveCarouselInfoR fl">' +
							'<p><span>' + D.liverInfo.nickName + '</span><span>' + format(new Date(D.latest.time)) + '</span></p>' +
							'<p>' + hrefBrforeIm + '链接网址：' + hrefAfterIm + '</p>' +
							'</div>' +
							'</div>';
						$("#" + liveCarouselBoxliveBoxOnlyId).append(liveCarouselInfo);

					} else {
						var liveCarouselInfo =
							'<div class="liveCarouselInfo" id=' + liveRoomHrefId + ' uid=' + D.liverInfo.uid + ' roomId=' + D.roomId + ' type=' + D.liverInfo.type + '>' +
							'<img class="fl headImgUrl" src="' + D.liverInfo.headImgUrl + '!60X60"/>' +
							'<div class="liveCarouselInfoR fl">' +
							'<p><span>' + D.liverInfo.nickName + '</span><span>' + format(new Date(D.latest.time)) + '</span></p>' +
							'<p>' + D.latest.content + '</p>' +
							'</div>' +
							'</div>';
						$("#" + liveCarouselBoxliveBoxOnlyId).append(liveCarouselInfo);
					}

				}
				$(".headImgUrl").one("error", function(e) {
					$(this).attr("src", "images/anchorHead.png");
				});
				if(type == 0) {
					$(document).on("click", "#" + liveRoomHrefId, function(e) {
						var uid = $(this).attr("uid");
						var roomid = $(this).attr("roomId");
						window.location.href = "/liveNew?uid=" + uid + "&roomid=" + roomid;
					});
				} else if(type == 1) {
					$(document).on("click", "#" + liveRoomHrefId, function(e) {
						var uid = $(this).attr("uid");
						var roomid = $(this).attr("roomId");
						window.location.href = "/vipLive?uid=" + uid + "&roomid=" + roomid;
					});
				}
			});
			//轮播
			//正在直播的轮播
			var showCount = 3, // 画面显示的条数
				totalCount = $(".liveCarousel .liveCarouselInfo").length, // 轮播总条数
				index = 0, // 轮播总条数下标
				autoTimer, // 全局变量目的实现左右点击同步
				clickEndFlag = true, // 设置每张走完才能再点击
				intervalTime = 3000; // 间隔时间

			// 克隆画面显示的条数总数放到最后(实现无缝滚动)
			//console.log('hkdsahfkl', totalCount);
			for(var i = 1; i <= showCount; i++) {
				$(".liveCarousel .liveCarouselInfo:eq(" + (i - 1) + ")").clone(true).appendTo($(".liveCarousel"));
			}

			var liHeight = $(".liveCarousel .liveCarouselInfo").height(); //一个li的高度
			var totalHeight = ($(".liveCarousel .liveCarouselInfo").length * $(".liveCarousel .liveCarouselInfo").eq(0).height()) - (showCount * liHeight); //获取li的总高度再减去画面显示的条数的高度
			$(".liveCarousel").height(totalHeight); //给ul赋值高度

			//	滚动方法
			function upOffset1() {
				$(".liveCarousel").stop().animate({
					top: -index * liHeight
				}, 400, function() {
					clickEndFlag = true; //图片走完才会true
					if(index == $(".liveCarousel .liveCarouselInfo").length - 1) {
						$(".liveCarousel").css({ top: 0 });
						index = 0;
					}
				})
			}

			function next1() {
				index++;
				if(index > totalCount) { //判断index为最后一个Li时index为0
					$(".liveCarousel").css({ top: 0 });
					index = 1;
				}
				upOffset1();
			}
			// 自动轮播
			autoTimer = setInterval(next1, intervalTime);
			$(".liveCarousel .liveCarouselInfo").hover(function() {
				clearInterval(autoTimer);
			}, function() {
				autoTimer = setInterval(next1, intervalTime);
			})

		}

	}
	/*回到顶部*/
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
	//跳转到下载页
	$(".downLoadAppPcBtn").click(function() {
		window.location.href = "/downLoadAppPc";
	});

	$(".stockPcHref").click(function() {
		window.location.href = "/stockPc";
	});

	$(".rulesBtnBanner").click(function() {
		window.location.href = "/rulesPc";
	});

	//页面跳转
	function browserRedirect() {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		var bIsMidp = sUserAgent.match(/midp/i) == "midp";
		var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		var bIsAndroid = sUserAgent.match(/android/i) == "android";
		var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
		if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
			window.location.href = "https://www.fntv8.com/m/v5.0/match"
			//  window.location.href = "http://192.168.8.13:8445/m/v5.0/invite"
		}
	}
	browserRedirect();

})