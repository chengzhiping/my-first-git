$(document).ready(function() {
	var pid=GetQueryString("pid");
	if(pid){
		loginFun(pid);
	}else{
		loginFun("");
	}
	//console.log(pid);
	//tab切换
	tabFun(".rankBtn", "active", ".tabContentInviteBox");

	tabFun(".gameBtnRule", "active", ".tabContent1");

	$(".downLoadAppPcBtn").click(function() {
		window.location.href = "/downLoadAppPc";
	});
	//点击朕要参加-登录成功——是否报名——已报名——我的成绩——下载
	//点击朕要参加-登录成功——是否报名——未报名——报名页——已报名
	loginFun(pid);
	//判断是否登录
	function loginFun(pid) {
		$.ajax({
			type: "get",
			url: "/userInfos",
			success: function(res) {
				//console.log(res);
				if(res.code == -2) { //未登录
					$(".noLoginBoxSame").click(function() {
						$("#loginAlert").stop().show();
						$("#loginAlert").load("/login");
					});
					$(".a_rewardActivity1").stop().hide();
					$(".invite_numActivity1").stop().hide();
//					$(".noLoginBox").stop().show();
				} else if(res.code == 0) { //登录成功
					var userUid = res.data.userInfo.uid;
					var userToken=res.data.token;
					getJoinerInfo(userUid, userUid,pid);//判断是否已经报名
					getInviteInfoService(userUid);//邀请人和发出的红包
				}
			}
		})
	}
	//邀请相关
	function getInviteInfoService(uid) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"uid": uid,
			},
			url: "/common-service/api/v1/user/getInviteInfoService",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					$(".a_number").html(res.data.inviteMoney);
					$(".a_people").html(res.data.inviteNum);
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	
	
	//判断是否报名
	function getJoinerInfo(objectId, uid,pid) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"objectId": objectId,
				"uid": uid,
			},
			url: "/common-service/api/v1/joiner/getJoinerInfo",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					if(res.code == 0) {
						var JoinInfo = JSON.stringify(res.data.JoinInfo);
						if(JoinInfo == "" || JoinInfo == undefined || JoinInfo == null || JoinInfo == '{}') { //游客视角
							$(".signUpBtn").click(function() {
								//console.log("未报名");
								window.location.href = "/applyPc?pid="+pid;
							})
						} else { //账户视角
							$(".signUpBtn").html("我的成绩");
							var loginUidHref=res.data.userInfo.uid;
							//console.log(loginUidHref);
							if(pid!=loginUidHref){
								window.location.href="/invitePc?pid="+loginUidHref;
							}
							$(".signUpBtn").click(function() {
								window.location.href = "/downLoadAppPc";
							})
						}
					}

				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	//跑马灯
	getRedCarouselList();
	function getRedCarouselList() {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/common-service/api/v1/carousel/getRedCarouselList",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					$(".totalCountHaveRedPacket").html(res.data.totalCount+"人已成功领取");
					var totalAmount=addPreZero(Math.round(res.data.totalAmount/100))+"";//后台返回单位分
				//	console.log(totalAmount);
			        var arrayObj = new Array();
			        for(var i in totalAmount){
			            arrayObj.push(totalAmount[i]);
			        }
			     //   console.log(arrayObj);
					for(var j=0;j<arrayObj.length;j++){
						var getMoneyIntroNum=
						'<span>'+arrayObj[j]+'</span>';
						$(".getMoneyIntro i").append(getMoneyIntroNum);
					}
					var carouselArray = JSON.parse(JSON.stringify(res.data.carouselArray));
					var carouselArrayLen = carouselArray.length;	
					for(var k = 0; k < carouselArrayLen; k++) {
						var noticeList =
						'<li>' + carouselArray[k] + '</li>';
						$(".inviteCarouselBox").append(noticeList);
					}
					//轮播
					//正在直播的轮播
					var showCount = 2, // 画面显示的条数
						totalCount = $(".inviteCarouselBox li").length, // 轮播总条数
						index = 0, // 轮播总条数下标
						autoTimer, // 全局变量目的实现左右点击同步
						clickEndFlag = true, // 设置每张走完才能再点击
						intervalTime = 1500; // 间隔时间
					for(var i = 1; i <= totalCount; i++) {
						$(".inviteCarouselBox li:eq(" + (i - 1) + ")").clone(true).appendTo($(".inviteCarouselBox"));
					}
					var liHeight = $(".inviteCarouselBox li").height(); //一个li的高度
					var totalHeight = ($(".inviteCarouselBox li").length * $(".inviteCarouselBox li").eq(0).height()) - (showCount * liHeight); //获取li的总高度再减去画面显示的条数的高度
					$(".inviteCarouselBox").height(totalHeight); //给ul赋值高度
					//	滚动方法
					function upOffset2() {
						$(".inviteCarouselBox").stop().animate({
							top: -index * liHeight
						},1500, function() {
							clickEndFlag = true; //图片走完才会true
							if(index == $(".inviteCarouselBox li").length - 1) {
								$(".inviteCarouselBox").css({ top: 0 });
								index = 0;
							}
						})
					}

					function next2() {
						index++;
						if(index > totalCount) { //判断index为最后一个Li时index为0
							$(".inviteCarouselBox").css({ top: 0 });
							index = 1;
						}
						upOffset2();
					}
					// 自动轮播
					autoTimer = setInterval(next2, intervalTime);
					$(".inviteCarouselBox li").hover(function() {
						clearInterval(autoTimer);
					}, function() {
						autoTimer = setInterval(next2, intervalTime);
					})
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	//高校榜——人气榜
	getTeamPopularityRank(1, 3);

	function getTeamPopularityRank(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/common-service/api/v1/school/getTeamPopularityRank",
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
					//console.log(res);
					if(res.data.rank.length==0&&pageIndex==1){
						$(".schoolRankBoxNull").stop().show();		
						$(".schoolRankBox").stop().hide();				
					}else{
						$(res.data.rank).each(function(b, H) {
							var imgId = H.id + "schoolRankMoods" + b;
							var schoolRankMoodsList =
								'<li>'+
									'<p class="rankInner">'+
										'<img id=' + imgId + ' src="../images/NetCup/one.png" alt="" />'+
										'<span class="schoolName">' + H.sname + '</span>'+
										'<span class="schoolNum">' + H.memberCount + '</span>'+
									'</p>'+
									'<p class="joinSchool downLoadAppPcBtn fr">加入战队</p>'+
								'</li>';
							$(".schoolRankBoxMore").before(schoolRankMoodsList);
							$(".downLoadAppPcBtn").click(function() {
								window.location.href = "/downLoadAppPc";
							});
							if(b == 1) {
								$("#" + H.id + "schoolRankMoods" + b).attr("src", "../images/NetCup/two.png");
							} else if(b == 2) {
								//console.log(b);
								$("#" + H.id + "schoolRankMoods" + b).attr("src", "../images/NetCup/three.png");
							}
						 })
					}
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}

	//个人榜——人气榜
	getPopularityRank(1, 3);

	function getPopularityRank(pageIndex, pageSize) {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			data: {
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/common-service/api/v1/joiner/getPopularityRank",
			success: function(res) {
				// console.log(res);
				if(res.code == 0) {
				    //console.log(res);
				    if(res.data.rank.length==0&&pageIndex==1){
						$(".personRankBoxNull").stop().show();		
						$(".personRankBox").stop().hide();				
					}else{
						$(res.data.rank).each(function(b, F) {
							var imgId = F.id + "personOrderList" + b;
							var personRankMoodsList =
							    '<li>'+
									'<p class="rankInner">'+
										'<img id=' + imgId + ' src="../images/NetCup/one.png" alt="" />'+
										'<span class="schoolName schoolNameTab2">' + F.name + '</span>'+
										'<span class="schoolNameTab3">' + F.teamName + '</span>'+
									'</p>'+
								"</li>";
							$(".personRankBoxMore").before(personRankMoodsList);
							$(".downLoadAppPcBtn").click(function() {
								window.location.href = "/downLoadAppPc";
							});
							if(b == 1) {
								$("#" + F.id + "personOrderList" + b).attr("src", "../images/NetCup/two.png");
							} else if(b == 2) {
								//console.log(b);
								$("#" + F.id + "personOrderList" + b).attr("src", "../images/NetCup/three.png");
							}
						})
					}

				}else if(res.code==-9998){
					$(".personRankBoxNull").stop().show();		
					$(".personRankBox").stop().hide();	
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	$("#recordContentAll").click(function(){
		$(".rewardList").html("");
		beginFun();
		
	});
   
    
    /*获得活动*/
   beginFun();
    function beginFun() {
		$.ajax({
			type: "get",
			async: true,
			dataType: "json",
			url: "/luckydraw-service/api/v1/lottery/begin",
			success: function(res) {
				if(res.code == 0) {
					//console.log(res);
					var dataLen=res.data.length;
					if(dataLen>0){
						var activityId=res.data[0].id;
					   // console.log(activityId);
					    recordFun(activityId, "","",2,"",1,1,10);
					}else{
						$(".noLoginBox").stop().hide();
                     	$(".nogiftBox").stop().show();
                     	$(".rewardList").stop().hide();
					}
					
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	var recordFunIndex=1;
	function recordFun(activityId, token,sign,status,uid,prizeType,pageIndex,pageSize) {
		$.ajax({
			type: "post",
			async: true,
			dataType: "json",
			data: {
				"activityId": activityId,
				"token": token,
				"sign": sign,
				"status": status,
				"uid": uid,
				"prizeType": prizeType,
				"pageIndex": pageIndex,
				"pageSize": pageSize,
			},
			url: "/luckydraw-service/api/v1/lottery/record",
			success: function(res) {
				//console.log(res);
				if(res.code == 0) {
				//console.log(res);
					$(".rewardList").scroll(function(){
						var scrollTop=$(".rewardList").scrollTop();
					    if(scrollTop>=1060*recordFunIndex){
					    	// console.log(scrollTop);
							if(res.data.records.length==10){
						 	   recordFunIndex++;
						 	   recordFun(activityId, token,sign,status,uid,prizeType,recordFunIndex,pageSize);
						    }
					    }
					})
					
                     if(pageIndex==1&&res.data.records==""){
                     	$(".noLoginBox").stop().hide();
                     	$(".nogiftBox").stop().show();
                     	$(".rewardList").stop().hide();
                     }else{
                     	$(".rewardList").stop().show();
                     	$(".noLoginBox").stop().hide();
                     	$(".sameRewardListNull").stop().hide();
                     	$(res.data.records).each(function(s,M){
					 	  var rewardListInfo=
					 	  '<li>'+
								'<img class="rewardImg" src="'+M.prizeCoverUrl+'" alt="">'+
								'<span class="rewardName">'+M.userInfo.nickName+'抽中了'+M.prizeName+'</span>'+
							'</li>';
							$(".rewardList").append(rewardListInfo);
					    })
                     }
					 
				}
			},
			error: function(XMLHttpRequest, textStatus, errorThrown) {
				console.log(XMLHttpRequest.status);
				console.log(XMLHttpRequest.readyState);
				console.log(textStatus);
			},
		});
	}
	
	/*回到顶部*/
	$(window).scroll(function() {
		var t = $(this).scrollTop();
		if(t > 200) {
			$(".goTop").stop().fadeIn()
		} else {
			$(".goTop").stop().fadeOut()
		}
	});
	$(".goTop").click(function() {
		$("body,html").animate({
			scrollTop: 0
		}, 800)
	});
	
	//跳转到手机页
	//页面跳转
	function browserRedirect(pid) {
		var sUserAgent = navigator.userAgent.toLowerCase();
		var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
		var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
		var bIsMidp = sUserAgent.match(/midp/i) == "midp";
		var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
		var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
		var bIsAndroid = sUserAgent.match(/android/i) == "android";
		var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
		var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
		if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
			window.location.href = "https://www.fntv8.com/m/v5.0/invite?pid="+pid;
		}
	}
	browserRedirect(pid);

})