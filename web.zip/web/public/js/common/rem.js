
    function getQueryString2(name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        var r = window.location.search.substr(1).match(reg);
        if (r != null) return unescape(r[2]); return null;
    };
    var urlHref = window.location.href;
    var redirectUrl;
    var from = getQueryString2('from');
    if( urlHref.indexOf(from) >=0 ){
        if(urlHref.indexOf('&from=') >= 0){
            redirectUrl = urlHref.split('&from=')[0];
        }else if(urlHref.indexOf('?from=') >= 0){
            redirectUrl = urlHref.split('?from=')[0];
        };
        window.location.replace(redirectUrl);
    };
    var linkedme = getQueryString2('linkedme');
    if( urlHref.indexOf(linkedme) >=0){
        if(urlHref.indexOf('&linkedme=') >= 0){
            redirectUrl = urlHref.split('&linkedme=')[0];
        }
        window.location.replace(redirectUrl);
    };
    //百度统计
	var _hmt = _hmt || [];
	(function() {
	  var hm = document.createElement("script");
	  hm.src = "https://hm.baidu.com/hm.js?0ca11a5ea69dd128d53eb2065f209f80";
	  var s = document.getElementsByTagName("script")[0];
	  s.parentNode.insertBefore(hm, s);
	})();


	! function(win, lib) {		
		function refreshRem() {			
			var width = docEl.getBoundingClientRect().width;
			width / dpr > 1370 && (width = 1370 * dpr);
			var rem = width / 13.7;
			docEl.style.fontSize = rem + "px", flexible.rem = win.rem = rem
		}
		var tid, doc = win.document,
			docEl = doc.documentElement,
			metaEl = doc.querySelector('meta[name="viewport"]'),
			flexibleEl = doc.querySelector('meta[name="flexible"]'),
			dpr = 0,
			scale = 0,
			flexible = lib.flexible || (lib.flexible = {});
		if(metaEl) {
			//console.warn("将根据已有的meta标签来设置缩放比例");
			var match = metaEl.getAttribute("content").match(/initial\-scale=([\d\.]+)/);
			match && (scale = parseFloat(match[1]), dpr = parseInt(1 / scale))
		} else {
			if(flexibleEl) {
				var content = flexibleEl.getAttribute("content");
				if(content) {
					var initialDpr = content.match(/initial\-dpr=([\d\.]+)/),
						maximumDor = content.match(/maximum\-dpr=([\d\.]+)/);
					initialDpr && (dpr = parseFloat(initialDpr[1]), scale = parseFloat((1 / dpr).toFixed(2))), maximumDor && (dpr = parseFloat(maximumDor[1]), scale = parseFloat((1 / dpr).toFixed(2)))
				}
			}
		}
		if(!dpr && !scale) {
			
			var userAgent = win.navigator.userAgent,
				isAndroid = (!!userAgent.match(/android/gi), !!userAgent.match(/iphone/gi)),
				isIphone = isAndroid && !!userAgent.match(/OS 9_3/),
				devicePixelRatio = win.devicePixelRatio;
			dpr = isAndroid && !isIphone ? devicePixelRatio >= 3 && (!dpr || dpr >= 3) ? 3 : devicePixelRatio >= 2 && (!dpr || dpr >= 2) ? 2 : 1 : 1, scale = 1 / dpr
		}
		if(docEl.setAttribute("data-dpr", dpr), !metaEl) {
			if(metaEl = doc.createElement("meta"), metaEl.setAttribute("name", "viewport"), metaEl.setAttribute("content", "initial-scale=" + scale + ", maximum-scale=" + scale + ", minimum-scale=" + scale + ", user-scalable=no"), docEl.firstElementChild) {
				docEl.firstElementChild.appendChild(metaEl)
			} else {
				var wrap = doc.createElement("div");
				wrap.appendChild(metaEl), doc.write(wrap.innerHTML)
			}
		}
		win.addEventListener("resize", function() {
			clearTimeout(tid), tid = setTimeout(refreshRem, 300)
		}, !1), 
		win.addEventListener("pageshow", function(e) {
			e.persisted && (clearTimeout(tid), tid = setTimeout(refreshRem, 300))
		}, !1), "complete" === doc.readyState ? doc.body.style.fontSize = 12 * dpr + "px" : doc.addEventListener("DOMContentLoaded", function() {
			
			doc.body.style.fontSize = 12 * dpr + "px"
		}, !1), refreshRem(), flexible.dpr = win.dpr = dpr, flexible.refreshRem = refreshRem, flexible.rem2px = function(d) {
			var val = parseFloat(d) * this.rem;
			return "string" == typeof d && d.match(/rem$/) && (val += "px"), val
		}, flexible.px2rem = function(d) {
			var val = parseFloat(d) / this.rem;
			return "string" == typeof d && d.match(/px$/) && (val += "rem"), val
		}
	
	}(window, (window.lib || (window.lib = {})));
