$(document).ready(function () {
    var videoId = GetQueryString("id");
    var userId;
    var videoUserUid;
    var usertoken;
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");
    // 获取关注数
    function focusNumber(uid) {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v1/user/getFansCount.do",
            data: {
                "uid": uid,
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    $(".fansCount").html(res.data);
                }
            }
        })
    }
    // 检查用户是否登录
    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function (res) {
            // console.log(res);
            if (res.code == -2) { //未登录
                getVideo1();
                getCommentList1(1);//未登录评论列表
                //评论点击加载更多
                $(".moreComment").on("click",function () {
                    pageIndex1++;
                    getCommentList1(pageIndex1);
                })
                $(".focus").on("click",function(){//关注
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
                $(".publish").on("click",function(){//发布评论
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
                $("#articleZan").on("click",function(){//视频点赞
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
                $("#articleCollect").on("click",function(){//视频收藏
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
                $(".getFollowBtn").on("click", function () {//关注
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                })
            }else if(res.code==0){//已登录
                //console.log(res);
                userId = res.data.userInfo.uid;
                usertoken = res.data.token;
                getVideo2();
                getCommentList2(1);
                //评论点击加载更多
                $(".moreComment").on("click",function () {
                    pageIndex2++;
                    getCommentList2(pageIndex2);
                })
                $(".weChatErrorEnter").click(function(){
                    payFun(userId, usertoken);
                })
            }
        }
    })
    //充值弹框
    $(".money_listinfo").click(function() {
        $(this).addClass("click_effect").siblings().removeClass("click_effect")
    });
    /*关闭框*/
    $(".alertClose").click(function() {
        $("#n_money").stop().hide();
        $("#exceptWrap").stop().hide();
        clearInterval(intervalTime)
    });
    $(".weChatClose").click(function() {
        $(".weChatCodeWrap").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatSuccessClose").click(function() {
        $(".weChatPaySuccess").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatOweWrapClose").click(function() {
        $(".weChatOweWrap").css("display", "none");
        $("#exceptWrap").stop().hide();
    });
    $(".wechat_pay").click(function() {
        $(".wechatI").show();
        $(".alipayI").hide()
    });
    $(".alipay").click(function() {
        $(".wechatI").hide();
        $(".alipayI").show()
    });
    //跳转专栏详情
    $(".columnImg").click(function () {
        var kid = $(this).attr("kid");
        window.location.href = "/columnDetail?id="+kid;
    })
    $(".authorTop img").click(function(){
        var uid = $(this).attr("uid");
        window.location.href = "userProfile?uid="+uid;
    })
    // 获取视频详情(未登录)
    function getVideo1(){
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v1/multiple/getVideoDetailsById.do",
            data: {
                "id": videoId,
            },
            success: function (res) {
                console.log(res);
                if (res.code == 0) {
                    videoUserUid = res.data.liverInfo.uid;
                    var coverUrl=res.data.coverUrl;
                    var headImgUrl=res.data.liverInfo.headImgUrl;
                    var nickName=res.data.liverInfo.nickName;
                    var signature=res.data.liverInfo.signature;
                    var uid=res.data.liverInfo.uid;
                    var watchCount=res.data.watchCount;
                    var topic=res.data.topic;
                    var createTime=res.data.createTime;
                    var playUrl=res.data.playUrl;
                    playUrl=playUrl.replace('http','https');
                    var praiseCount=res.data.praiseCount;//点赞次数
                    var openness = res.data.openness;
                    var roleType=res.data.liverInfo.roleType;//主播角色类型{0=普通用户，1=主播，2=主播且操盘手}
                    if(roleType==0 ||　roleType==1){
                        $("#shipan").stop().hide();
                    }
                    $("title").html(topic+"_股票入门视频-疯牛直播");
                    $("#keywordsId").attr("content",nickName+"，股市故事，股市心理学，中国股市历史，财经内参，疯牛直播，投资理财入门，炒股教程");
                    var resume = res.data.liverInfo.resume;
                    if(resume == "" || resume == undefined||resume == null){
                        $(".authorDetail").html("暂无简介...");
                    }else{
                        $(".authorDetail").html(resume);
                    }
                    // 专栏
                    var columnId = res.data.columnId;
                    if(columnId == ""){//不属于专栏
                        $(".column").stop().hide();
                    }else{//属于专栏(专栏详情接口)
                        getColumnDetail(columnId);
                    }
                    //专题
                    var subjectsLength = res.data.subjects.length;
                    // console.log(subjectsLength);
                    if(subjectsLength == 0){//不属于专题
                        $(".topic").stop().hide();
                    }else{//属于专题
                        if(subjectsLength >3){//取前三条
                            subjectsLength = 3;
                        }
                        for(var i=0;i<subjectsLength;i++){
                        	var dissertationId="dissertationId"+res.data.subjects[i].id;
                            var topicListInner = "<li id="+dissertationId+" objectId="+res.data.subjects[i].id+">"+
                                "<img src='"+res.data.subjects[i].coverUrl+"' alt='' />"+
                                "<p class='topicName'>"+res.data.subjects[i].name+"</p>"+
                                "</li>";
                            $(".topic ul").append(topicListInner);
                            $("#"+dissertationId).click(function(){
                            	var id=$(this).attr("objectId");
                            	window.location.href="/dissertation?id="+id;
                            })
                        }
                    }
                    //获取关注人数
                    focusNumber(uid);
                    // 分享
                    var url = window.location.href;
                    var description="下载疯牛直播APP，观看"+nickName+"的更多视频！";
                    shareFun(url, topic, description, coverUrl);
                    if(praiseCount!=0){
                        $(".shareLeft .num").html(praiseCount);
                    }
                    if(openness == 0){//未加密
                        $(".myVideo").attr("poster",coverUrl);
                        // console.log(playUrl);
                        if(playUrl.indexOf("m3u8") > 0 )
                        {
                            hlsfun(playUrl);
                        }else{
                            $(".myVideo").attr("src",playUrl);
                        }
                        $(".articleLeft .articleTitle").html(topic);
                        $(".articleLeft .introduce .people").html("主播："+nickName);
                        $(".articleLeft .introduce .watch").html(watchCount+"人已看");
                        $(".articleLeft .introduce .time").html(format(new Date(createTime)));
                        if(headImgUrl!=""){
                            $(".anchor .headImg").attr("src",headImgUrl);
                            $(".anchor .headImg").attr("uid",uid);
                            $(".authorTop img").attr("src", headImgUrl);
                            $(".authorTop img").attr("uid", uid);
                        }
                        $(".dumpLink li").attr("uid",uid);
                        $(".articleRight .anchor .name").html(nickName);
                        $(".authorTop .authorName").html(nickName);
                        if(signature!=""){
                            $(".articleRight .anchor .introduce").html(signature);
                            $(".authorTop .authorIntr").html(signature);
                        }else{
                            $(".articleRight .anchor .introduce").html("这个主播很懒，什么都没有留下。");
                        }
                    }
                }
                if(res.code == -7){//不能为空
                    $("#vedio_masked").stop().show();
                    $(".sure_btn").on("click", function() {

                        var authCode = $("#pwd").val();
                        //console.log(authCode);
                        $.ajax({
                            type: "GET", //请求方式
                            async: true, //是否异步
                            dataType: "json",
                            url:"/api/v1/multiple/getVideoDetailsById2.do",
                            data: {
                                "id": videoId,
                                "authCode": authCode,
                            },
                            success: function(res) {
                                //console.log(res);
                                if(res.code == -111) {
                                    $(".error_ts").html("密码错误，请重新输入！")
                                };
                                if(res.code == -7) {
                                    $(".error_ts").html("密码不能为空，请重新输入！")
                                }
                                if(res.code == 0) {
                                    var coverUrl=res.data.coverUrl;
                                    var headImgUrl=res.data.liverInfo.headImgUrl;
                                    var nickName=res.data.liverInfo.nickName;
                                    var signature=res.data.liverInfo.signature;
                                    var uid=res.data.liverInfo.uid;
                                    var watchCount=res.data.watchCount;
                                    var topic=res.data.topic;
                                    var createTime=res.data.createTime;
                                    var playUrl=res.data.playUrl;
                                    playUrl=playUrl.replace('http','https');
                                    var praiseCount=res.data.praiseCount;//点赞次数
                                    var roleType=res.data.liverInfo.roleType;//主播角色类型{0=普通用户，1=主播，2=主播且操盘手}
                                    if(roleType==0 ||　roleType==1){
                                        $("#shipan").stop().hide();
                                    }
                                    var resume = res.data.liverInfo.resume;
                                    if(resume == "" || resume == undefined){
                                        $(".authorDetail").html("暂无简介...");
                                    }else{
                                        $(".authorDetail").html(resume);
                                    }
                                    //获取关注人数
                                    focusNumber(uid);
                                    $("title").html(topic+"_股票入门视频-疯牛直播");
                                    $("#vedio_masked").stop().hide();
                                    $(".myVideo").attr("poster",coverUrl);
                                    //  $(".myVideo").attr("src",playUrl);
                                    if(playUrl.indexOf("m3u8") > 0 )
                                    {
                                        hlsfun(playUrl);
                                    }else{
                                        $(".myVideo").attr("src",playUrl);
                                    }
                                    $(".articleLeft .articleTitle").html(topic);
                                    $(".articleLeft .introduce .people").html("主播："+nickName);
                                    $(".articleLeft .introduce .watch").html(watchCount+"人已看");
                                    $(".articleLeft .introduce .time").html(format(new Date(createTime)));
                                    if(headImgUrl!=""){
                                        $(".anchor .headImg").attr("src",headImgUrl);
                                        $(".anchor .headImg").attr("uid",uid);
                                        $(".authorTop img").attr("src", headImgUrl);
                                        $(".authorTop img").attr("uid", uid);
                                    }
                                    $(".dumpLink li").attr("uid",uid);
                                    $(".articleRight .anchor .name").html(nickName);
                                    $(".authorTop .authorName").html(nickName);
                                    if(signature!=""){
                                        $(".articleRight .anchor .introduce").html(signature);
                                        $(".authorTop .authorIntr").html(signature);
                                    }else{
                                        $(".articleRight .anchor .introduce").html("这个主播很懒，什么都没有留下。");
                                    }
                                }

                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus);
                            },
                        })
                    })
                }
                if(res.code == -902){//未订阅
                    //获取专栏详情
                    $.ajax({
                        type: "get",
                        async: true,
                        dataType: "json",
                        url: "/api/v2/column/getColumnByObjectId.do",
                        data: {
                            "objectId": videoId,
                            "type": 3//1-回放 2-视频 3-文章 4-直播
                        },
                        success: function (res) {
                            console.log(res);
                            if (res.code == 0) {
                                $(".howmany").html(res.data.subscribePay);
                                $("#moneyLogo").html(res.data.subscribePay+"牛币");
                                if(res.data.subscribeCycle){
                                    $(".howlong").html(res.data.subscribeCycle+"天");
                                    $(".payMoneyBox .days").html(res.data.subscribeCycle+"天");
                                }else{
                                    $(".howlong").html("全期");
                                    $(".payMoneyBox .days").html("全期");
                                }
                                $(".payMoneyInner .topic").html(res.data.name);
                                $("payMoneyBox .name").html(res.data.name);
                                $(".seeColumnIntro").attr("kid",res.data.id);
                                $(".gotoPay").click(function () {
                                    $("#loginAlert").stop().show();
                                    $("#loginAlert").load("/login");
                                })
                                $(".seeColumnIntro").click(function () {
                                    var columnId = $(this).attr("kid");
                                    window.location.href = "/columnDetail?id="+columnId+"&tab="+2;
                                })
                            }
                        }
                    })
                    $(".payMoney").stop().show();
                }
            }
        })
    }
    // 获取专栏详情
    function getColumnDetail(columnId) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v2/column/getColumnDetail1.do",
            data: {
                "columnId": columnId
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    var subscribeType = res.data.subscribeType;
                    if(subscribeType == 0){//免费
                        $(".charge").stop().hide();
                    }else{//收费
                        $(".charge").stop().show();
                    }
                    var coverUrl = res.data.coverUrl;
                    $(".columnImg").attr("src",coverUrl);
                    $(".columnImg").attr("kid",res.data.id);
                    var name = res.data.name;
                    $(".columnWrapRTitle").html(name);
                    $(".columnTitle").html(res.data.introduction);
                    $(".updateColumn").html(res.data.description);
                }
            }
        })
    }
    //第三方分享
    function shareFun(url, title, description, pic) {
        mobShare.config({
            debug: true, // 开启调试，将在浏览器的控制台输出调试信息
            appkey: '1d102ac0241c0', // appkey
            params: {
                url: url, // 分享链接
                title: title, // 分享标题
                description: description, // 分享内容
                pic: pic, // 分享图片，使用逗号,隔开
                reason: '', //自定义评论内容，只应用与QQ,QZone与朋友网
            },
            callback: function(plat, params) {
                // console.log("分享成功了");
            }

        });

    }
    //电脑跳转手机
    function browserRedirect() {
        var sUserAgent = navigator.userAgent.toLowerCase();
        var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
        var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
        var bIsMidp = sUserAgent.match(/midp/i) == "midp";
        var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
        var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
        var bIsAndroid = sUserAgent.match(/android/i) == "android";
        var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
        var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
        if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
            window.location.href = "https://www.fntv8.com/m/v5.0/video?id=" + videoId + "";
        }
    }
    browserRedirect();
    // 获取视频详情(已登录)
    function getVideo2(){
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v1/multiple/getVideoDetailsById4.do",
            data: {
                "id": videoId,
                "userId":userId,
                "token":usertoken,
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    videoUserUid = res.data.liverInfo.uid;
                    var coverUrl=res.data.coverUrl;
                    var headImgUrl=res.data.liverInfo.headImgUrl;
                    var nickName=res.data.liverInfo.nickName;
                    var signature=res.data.liverInfo.signature;
                    var uid=res.data.liverInfo.uid;
                    var watchCount=res.data.watchCount;
                    var topic=res.data.topic;
                    var createTime=res.data.createTime;
                    var playUrl=res.data.playUrl;
                    playUrl=playUrl.replace('http','https');
                    var isAgree=res.data.isAgree;
                    var isCollection=res.data.isCollection;
                    var praiseCount=res.data.praiseCount;//点赞次数
                    var openness = res.data.openness;
                    var roleType=res.data.liverInfo.roleType;//主播角色类型{0=普通用户，1=主播，2=主播且操盘手}
                    if(roleType==0 ||　roleType==1){
                        $("#shipan").stop().hide();
                    }
                    $("title").html(topic+"_股票入门视频-疯牛直播");
                    var resume = res.data.liverInfo.resume;
                    if(resume == "" || resume == undefined){
                        $(".authorDetail").html("暂无简介...");
                    }else{
                        $(".authorDetail").html(resume);
                    }
                    // 专栏
                    var columnId = res.data.columnId;
                    if(columnId == ""){//不属于专栏
                        $(".column").stop().hide();
                    }else{//属于专栏(专栏详情接口)
                        getColumnDetail(columnId);
                    }
                    //专题
                    var subjectsLength = res.data.subjects.length;
                    // console.log(subjectsLength);
                    if(subjectsLength == 0){//不属于专题
                        $(".topic").stop().hide();
                    }else{//属于专题
                        if(subjectsLength >3){//取前三条
                            subjectsLength = 3;
                        }
                        for(var i=0;i<subjectsLength;i++){
                        	var dissertationId="dissertationId"+res.data.subjects[i].id;
                            var topicListInner = "<li id="+dissertationId+" objectId="+res.data.subjects[i].id+">"+
                                "<img src='"+res.data.subjects[i].coverUrl+"' alt='' />"+
                                "<p class='topicName'>"+res.data.subjects[i].name+"</p>"+
                                "</li>";
                            $(".topic ul").append(topicListInner);
                            $("#"+dissertationId).click(function(){
                            	var id=$(this).attr("objectId");
                            	window.location.href="/dissertation?id="+id;
                            })
                        }
                    }
                    //检查是否关注
                    $.ajax({
                        type: "POST",
                        async: true,
                        dataType: "json",
                        url: "/api/v1/user/checkFollowing.do",
                        data: {
                            "receptorId": uid,
                            "uid": userId,
                            "token": usertoken,
                        },
                        success: function (res) {
                            if (res.code == 0) {
                                // console.log(res);
                                var isFocus = res.data;
                                if (isFocus == 1) {//已关注
                                    $(".focus").html("已关注");
                                    $(".focus").css("background","#C6C6C6");
                                    $(".getFollowBtn").html("已关注");
                                    $(".getFollowBtn").css("background", "#C6C6C6");
                                }
                            }
                        }
                    })
                    var url = window.location.href;
                    var description="下载疯牛直播APP，观看"+nickName+"的更多视频！";
                    shareFun(url, topic, description, coverUrl);
                    if(openness == 0){//未加密
                        $(".myVideo").attr("poster",coverUrl);
                        if(playUrl.indexOf("m3u8") > 0 )
                        {
                            hlsfun(playUrl);
                        }else{
                            $(".myVideo").attr("src",playUrl);
                        }
                        $(".articleLeft .articleTitle").html(topic);
                        $(".articleLeft .introduce .people").html("主播："+nickName);
                        $(".articleLeft .introduce .watch").html(watchCount+"人已看");
                        $(".articleLeft .introduce .time").html(format(new Date(createTime)));
                        if(headImgUrl!=""){
                            $(".anchor .headImg").attr("src",headImgUrl);
                            $(".anchor .headImg").attr("uid",uid);
                            $(".authorTop img").attr("src", headImgUrl);
                            $(".authorTop img").attr("uid", uid);
                        }
                        $(".dumpLink li").attr("uid",uid);
                        $(".articleRight .anchor .name").html(nickName);
                        $(".authorTop .authorName").html(nickName);
                        if(signature!=""){
                            $(".articleRight .anchor .introduce").html(signature);
                            $(".authorTop .authorIntr").html(signature);
                        }else{
                            $(".articleRight .anchor .introduce").html("这个主播很懒，什么都没有留下。");
                        }
                    }
                    if(praiseCount!=0){
                        $(".shareLeft .num").html(praiseCount);
                    }
                    if(isAgree==true){//已点赞
                        $(".shareLeft .zanImg").attr("src","../images/rewardP.png");
                        $(".shareLeft .num").css("color","#fe4502");
                    }
                    checkZan(videoId);
                    if(isCollection==true){//已收藏
                        $("#articleCollect").attr("src","../images/collectingP.png");
                        $("#collect").html("已收藏");
                        $("#collect").css("color","#fe4502");
                    }
                    //获取关注人数
                    focusNumber(uid);
                    checkCollect(videoId);
                    //检查关注
                    checkFocus(uid,".focus");
                    checkFocus(uid,".getFollowBtn");
                }
                if(res.code == -7){//不能为空
                    $("#vedio_masked").stop().show();
                    $(".sure_btn").on("click", function() {
                        var authCode = $("#pwd").val();
                        // console.log(authCode);
                        $.ajax({
                            type: "GET", //请求方式
                            async: true, //是否异步
                            dataType: "json",
                            url:"/api/v1/multiple/getVideoDetailsById3.do",
                            data: {
                                "id": videoId,
                                "userId":userId,
                                "token":usertoken,
                                "authCode": authCode,
                            },
                            success: function(res) {
                                // console.log(res);
                                if(res.code == -111) {
                                    $(".error_ts").html("密码错误，请重新输入！")
                                };
                                if(res.code == -7) {
                                    $(".error_ts").html("密码不能为空，请重新输入！")
                                }
                                if(res.code == 0) {
                                    var coverUrl=res.data.coverUrl;
                                    var headImgUrl=res.data.liverInfo.headImgUrl;
                                    var nickName=res.data.liverInfo.nickName;
                                    var signature=res.data.liverInfo.signature;
                                    var uid=res.data.liverInfo.uid;
                                    var watchCount=res.data.watchCount;
                                    var topic=res.data.topic;
                                    var createTime=res.data.createTime;
                                    var playUrl=res.data.playUrl;
                                    playUrl=playUrl.replace('http','https');
                                    var isAgree=res.data.isAgree;
                                    var isCollection=res.data.isCollection;
                                    var praiseCount=res.data.praiseCount;//点赞次数
                                    var roleType=res.data.liverInfo.roleType;//主播角色类型{0=普通用户，1=主播，2=主播且操盘手}
                                    if(roleType==0 ||　roleType==1){
                                        $("#shipan").stop().hide();
                                    }
                                    var resume = res.data.liverInfo.resume;
                                    if(resume == "" || resume == undefined){
                                        $(".authorDetail").html("暂无简介...");
                                    }else{
                                        $(".authorDetail").html(resume);
                                    }
                                    if(praiseCount!=0){
                                        $(".shareLeft .num").html(praiseCount);
                                    }
                                    if(isAgree==true){//已点赞
                                        $(".shareLeft .zanImg").attr("src","../images/rewardP.png");
                                        $(".shareLeft .num").css("color","#fe4502");
                                    }
                                    checkZan(videoId);
                                    if(isCollection==true){//已收藏
                                        $("#articleCollect").attr("src","../images/collectingP.png");
                                        $("#collect").html("已收藏");
                                        $("#collect").css("color","#fe4502");
                                    }
                                    checkCollect(videoId);
                                    //获取关注人数
                                    focusNumber(uid);
                                    //检查是否关注
                                    $.ajax({
                                        type: "POST",
                                        async: true,
                                        dataType: "json",
                                        url: "/api/v1/user/checkFollowing.do",
                                        data: {
                                            "receptorId": uid,
                                            "uid": userId,
                                            "token": usertoken,
                                        },
                                        success: function (res) {
                                            if (res.code == 0) {
                                                // console.log(res);
                                                var isFocus = res.data;
                                                if (isFocus == 1) {//已关注
                                                    $(".focus").html("已关注");
                                                    $(".focus").css("background","#C6C6C6");
                                                    $(".getFollowBtn").html("已关注");
                                                    $(".getFollowBtn").css("background", "#C6C6C6");
                                                }
                                            }
                                        }
                                    })
                                    //检查关注
                                    checkFocus(uid,".focus");
                                    checkFocus(uid,".getFollowBtn");
                                    $("#vedio_masked").stop().hide();
                                    $(".myVideo").attr("poster",coverUrl);
                                    // $(".myVideo").attr("src",playUrl);
                                    if(playUrl.indexOf("m3u8") > 0 )
                                    {
                                        hlsfun(playUrl);
                                    }else{
                                        $(".myVideo").attr("src",playUrl);
                                    }
                                    $("title").html(topic+"_股票入门视频-疯牛直播");
                                    $(".articleLeft .articleTitle").html(topic);
                                    $(".articleLeft .introduce .people").html("主播："+nickName);
                                    $(".articleLeft .introduce .watch").html(watchCount+"人已看");
                                    $(".articleLeft .introduce .time").html(format(new Date(createTime)));
                                    if(headImgUrl!=""){
                                        $(".anchor .headImg").attr("src",headImgUrl);
                                        $(".anchor .headImg").attr("uid",uid);
                                        $(".authorTop img").attr("src", headImgUrl);
                                        $(".authorTop img").attr("uid", uid);
                                    }
                                    $(".dumpLink li").attr("uid",uid);
                                    $(".articleRight .anchor .name").html(nickName);
                                    $(".authorTop .authorName").html(nickName);
                                    if(signature!=""){
                                        $(".articleRight .anchor .introduce").html(signature);
                                        $(".authorTop .authorIntr").html(signature);
                                    }else{
                                        $(".articleRight .anchor .introduce").html("这个主播很懒，什么都没有留下。");
                                    }
                                }

                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus);
                            },
                        })
                    })
                }

            }
        })
    }
    // 检查是否关注
    function checkFocus(uid,focusBttn) {
        $(focusBttn).on("click",function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v1/user/checkFollowing.do",
                data: {
                    "receptorId": uid,
                    "uid": userId,
                    "token": usertoken,
                },
                success: function (res) {
                    if (res.code == 0) {
                        // console.log(res);
                        var isFocus = res.data;
                        if (isFocus == 1) {//已关注
                            $(focusBttn).html("已关注");
                            $(focusBttn).css("background", "#C6C6C6");
                            //取消关注
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/user/deleteFollow.do",
                                data: {
                                    "receptorId": uid,
                                    "uid": userId,
                                    "token": usertoken,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        // console.log(res);
                                        var num = Number($(".fansCount").html());
                                        $(".fansCount").html(num - 1);
                                        $(focusBttn).html("＋ 关注");
                                        $(focusBttn).css("background", "#FE4502");
                                    }
                                }
                            })
                        } else {
                            //关注
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/user/following.do",
                                data: {
                                    "receptorId": uid,
                                    "uid": userId,
                                    "token": usertoken,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        // console.log(res);
                                        var num = Number($(".fansCount").html());
                                        $(".fansCount").html(num + 1);
                                        $(focusBttn).html("已关注");
                                        $(focusBttn).css("background", "#C6C6C6");
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }

    //获取最近打赏信息
    getRewardMsg();
    function getRewardMsg() {
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v2/journal/selectLatelyByTarget.do",
            data: {
                "target": videoId,
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    var rewardNumber = res.data.count;
                    if(rewardNumber == 0){//无人打赏
                        $(".rewordNumber").stop().hide();
                        $(".rewordHead").stop().hide();
                    }else{
                        $(".rewordNumber").stop().show();
                        $(".rewordHead").stop().show();
                        $(".rewordNumber").html(rewardNumber+"人已打赏");
                        var imgLength = res.data.imgUrl.length;
                        // console.log(imgLength);
                        if(rewardNumber == imgLength){
                            for(var i = 0;i<imgLength;i++){
                                if(res.data.imgUrl[i]==""){
                                    res.data.imgUrl[i] = "../images/anchorHeadAnchor.png";
                                }
                                var imgListInner = "<img src='"+res.data.imgUrl[i]+"' alt='' />";
                                $(".rewordHead").append(imgListInner);
                            }
                        }
                    }
                }
            }
        })
    }

    //检查视频是否收藏
    function checkCollect(videoId) {
        //判断是否收藏
        $("#articleCollect").on("click",function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v2/agree/selectAgreeCount.do",
                data: {
                    "objectId": videoId,
                    "uid": userId,
                    "agreeType": 2,
                },
                success: function (res) {
                    if (res.code == 0) {
                        // console.log(res);
                        var isAgree = res.data.isAgree;
                        if (isAgree == true) {//已收藏
                            //取消收藏
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/deleteAgree.do",
                                data: {
                                    "objectId": videoId,
                                    "uid": userId,
                                    "token": usertoken,
                                    "agreeType": 2,
                                },
                                success: function (res) {
                                    // console.log(res);
                                    if (res.code == 0) {
                                        $("#articleCollect").attr("src","../images/collecting.png");
                                        $("#collect").html("收藏");
                                        $("#collect").css("color","#a9a9a9");
                                    }
                                }
                            })
                        } else {//未收藏
                            //收藏接口
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/insertAgree.do",
                                data: {
                                    "objectId": videoId,
                                    "uid": userId,
                                    "token": usertoken,
                                    "type":2,
                                    "agreeType": 2,
                                },
                                success: function (res) {
                                    // console.log(res);
                                    if (res.code == 0) {
                                        $("#articleCollect").attr("src","../images/collectingP.png");
                                        $("#collect").html("已收藏");
                                        $("#collect").css("color","#fe4502");
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }
    // 检查评论点赞
    function checkZan2(id,agreeCount) {
        //判断是否点赞
        $("#"+id).on("click",function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v2/agree/selectAgreeCount.do",
                data: {
                    "objectId": id,
                    "uid": userId,
                    "agreeType":1,
                },
                success: function (res) {
                    if (res.code == 0) {
                        // console.log(res);
                        var isAgree=res.data.isAgree;
                        // var agreeCount=res.data.agreeCount;
                        if(isAgree==true){//已点赞
                            //取消点赞
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/deleteAgree.do",
                                data: {
                                    "objectId": id,
                                    "uid": userId,
                                    "token": usertoken,
                                    "agreeType":1,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        // console.log(res);
                                        $("#"+id).attr("src","../images/rewardIcon.png");
                                        $("#"+id).next().css("color","#a9a9a9");
                                        var praiseCount1 = $("#"+id).next().html();
                                        var praiseCount2 = Number(praiseCount1) - 1;
                                        $("#"+id).next().html(praiseCount2);
                                    }
                                }
                            })
                        }else{
                            //点赞接口
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/insertAgree.do",
                                data: {
                                    "objectId": id,
                                    "uid": userId,
                                    "token": usertoken,
                                    "type":4,
                                    "agreeType":1,
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        // console.log(res);
                                        $("#"+id).attr("src","../images/rewardP.png");
                                        var praiseCount1 = $("#"+id).next().html();
                                        var praiseCount2 = Number(praiseCount1) + 1;
                                        $("#"+id).next().html(praiseCount2);
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }

    //检查视频是否点赞
    function checkZan(videoId) {
        //判断是否点赞
        $("#articleZan").on("click",function () {
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v2/agree/selectAgreeCount.do",
                data: {
                    "objectId": videoId,
                    "uid": userId,
                    "agreeType": 1,
                },
                success: function (res) {
                    if (res.code == 0) {
                        console.log(res);
                        var isAgree = res.data.isAgree;
                        // var agreeCount=res.data.agreeCount;
                        if (isAgree == true) {//已点赞
                            //取消点赞
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/deleteAgree.do",
                                data: {
                                    "objectId": videoId,
                                    "uid": userId,
                                    "token": usertoken,
                                    "agreeType": 1,
                                },
                                success: function (res) {
                                    console.log(res);
                                    if (res.code == 0) {
                                        $(".shareLeft .zanImg").attr("src", "../images/rewardIcon.png");
                                        $(".shareLeft .num").css("color", "#A9A9A9");
                                        var praiseCount1 = $(".shareLeft .num").html();
                                        var praiseCount2 = Number(praiseCount1) - 1;
                                        $(".shareLeft .num").html(praiseCount2);
                                    }
                                }
                            })
                        } else {//未点赞
                            //点赞接口
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v2/agree/insertAgree.do",
                                data: {
                                    "objectId": videoId,
                                    "uid": userId,
                                    "token": usertoken,
                                    "type": 2,
                                    "agreeType": 1,
                                },
                                success: function (res) {
                                    console.log(res);
                                    if (res.code == 0) {
                                        $(".shareLeft .zanImg").attr("src", "../images/rewardP.png");
                                        $(".shareLeft .num").css("color", "#fe4502");
                                        var praiseCount1 = $(".shareLeft .num").html();
                                        var praiseCount2 = Number(praiseCount1) + 1;
                                        $(".shareLeft .num").html(praiseCount2);
                                    }
                                }
                            })
                        }
                    }
                }
            })
        })
    }

    //发表评论
    $(".publish").on("click",function(){
        var comment=$("textarea").val();
        if(comment==""){
            // alert("评论内容不能为空！");
            $(".noContent").fadeIn(100).delay(4000).fadeOut(100);
            return false;
        }
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v2/comment/insert.do",
            data: {
                "uid":userId ,
                "token":usertoken,
                "comment":comment,
                "objectId":videoId,
            },
            success: function (res) {
                if (res.code == 0) {
                    $('.comment ul li').remove();
                    getCommentList2(pageIndex2);
                    $(".articleLeft .comment textarea").val("");
                }
            }
        })
    })

    var pageIndex1=1;
    var pageIndex2=1;
    //获取评论接口（未登录）
    function getCommentList1(pageIndex1) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v3/comment/getCommentByObjId1.do",
            data: {
                "objectId": videoId,
                "pageIndex": pageIndex1,
                "pageSize": 10
            },
            success: function (res) {
                console.log(res);
                if (res.code == 0) {
                    if(res.data.length<10 && pageIndex1==1){
                        $(".moreComment").stop().hide();
                    }
                    if(res.data.length<10 && pageIndex1!=1){
                        $(".moreComment").stop().hide();
                        $(".noMoreComment").html("没有更多了");
                    }
                    $(res.data).each(function (i, k) {
                        var headImg = k.commentatorInfo.headImgUrl;
                        var nickName = k.commentatorInfo.nickName;
                        var replayNickName = "回复"+nickName+"...";
                        var comment = k.comment;
                        var time = k.time;
                        var id = k.id;
                        var commentId = "comment"+k.id;
                        var isAgree = k.isAgree;
                        var agreeCount = k.agreeCount;
                        var uid=k.commentatorInfo.uid;
                        var commentType = k.commentType;
                        if(commentType == 1){//1=一级评论；
                            var commentListInner = "<li>" +
                                "<div class='commentLeft'>" +
                                "<img uid="+uid+" src='" + headImg + "' alt=''>" +
                                "</div>" +
                                "<div class='commentRight'>" +
                                "<p class='name'>" + nickName + "<span class='time'>" + format(new Date(time)) + "</span></p>" +
                                "<p class='content'>" + comment + "</p>" +
                                "<div class='zan'>" +
                                "<img class='zanImg1' src='./images/answer.png' alt='' />"+
                                "<span class='playback'>回复</span>"+
                                "<img class='zanImg' id=" + id + " src='./images/rewardIcon.png' alt='' />" +
                                "<span class='zanNum'>" + agreeCount + "</span></div>" +
                                "<div class='applyabox'>"+
                                "<textarea placeholder="+replayNickName+"></textarea>"+
                                "<span class='sendApply' id="+commentId+" commentatorId="+k.commentatorId+">发送</span>"+
                                "<span class='cancalApply'>取消</span>"+
                                "</div></div></li>";
                            $(".comment ul").append(commentListInner);
                        }else if(commentType == 2){//2=二级评论
                            var parentName = k.parentCommentatorInfo.nickName;
                            var commentListInner = "<li>" +
                                "<div class='commentLeft'>" +
                                "<img uid="+uid+" src='" + headImg + "' alt=''>" +
                                "</div>" +
                                "<div class='commentRight'>" +
                                "<p class='name'>" + k.commentatorInfo.nickName + " <span style='color: #A9A9A9'>回复了 </span>"+k.parentCommentatorInfo.nickName+" <span class='time'>" + format(new Date(time)) + "</span></p>" +
                                "<p class='content'>" + comment + "</p>" +
                                "<div class='zan'>" +
                                "<img class='zanImg1' src='./images/answer.png' alt='' />"+
                                "<span class='playback'>回复</span>"+
                                "<img class='zanImg' id=" + id + " src='./images/rewardIcon.png' alt='' />" +
                                "<span class='zanNum'>" + agreeCount + "</span></div>" +
                                "<div class='applyabox'>"+
                                "<textarea placeholder="+replayNickName+"></textarea>"+
                                "<span class='sendApply'>发送</span>"+
                                "<span class='cancalApply'>取消</span>"+
                                "</div></div></li>";
                            $(".comment ul").append(commentListInner);
                        }
                    })
                    $(".commentLeft img").one("error", function(e) {
                        $(this).attr("src", "images/anchorHead.png");
                    })
                    $(".zan .zanImg").on("click",function(){//评论点赞
                        $("#loginAlert").stop().show();
                        $("#loginAlert").load("/login");
                    })
                    $(".commentLeft img").click(function () {
                        var uid=$(this).attr("uid");
                        window.location.href ="userProfile?uid="+uid;
                    })
                    $(".zanImg1").click(function () {
                        $("#loginAlert").stop().show();
                        $("#loginAlert").load("/login");
                    })
                }
            }
        })
    }
    //获取评论接口（已登录）
    function getCommentList2(pageIndex2) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v3/comment/getCommentByObjId2.do",
            data: {
                "objectId": videoId,
                "pageIndex": pageIndex2,
                "uid": userId,
                "pageSize": 10
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    if(res.data.length<10 && pageIndex2==1){
                        $(".moreComment").stop().hide();
                    }
                    if(res.data.length<10 && pageIndex2!=1){
                        $(".moreComment").stop().hide();
                        $(".noMoreComment").html("没有更多了");
                    }
                    $(res.data).each(function (i, k) {
                        var headImg = k.commentatorInfo.headImgUrl;
                        var nickName = k.commentatorInfo.nickName;
                        var replayNickName = "回复"+nickName+"...";
                        var comment = k.comment;
                        var time = k.time;
                        var id = k.id;
                        var isAgree = k.isAgree;
                        var agreeCount = k.agreeCount;
                        var uid=k.commentatorInfo.uid;
                        var commentType = k.commentType;
                        if(commentType == 1){//1=一级评论；
                            var commentListInner = "<li>" +
                                "<div class='commentLeft'>" +
                                "<img uid="+uid+" src='" + headImg + "' alt=''>" +
                                "</div>" +
                                "<div class='commentRight'>" +
                                "<p class='name'>" + nickName + "<span class='time'>" + format(new Date(time)) + "</span></p>" +
                                "<p class='content'>" + comment + "</p>" +
                                "<div class='zan'>" +
                                "<img class='zanImg1' src='./images/answer.png' alt='' />"+
                                "<span class='playback'>回复</span>"+
                                "<img class='zanImg' isAgree="+isAgree+"  id=" + id + "  src='./images/rewardIcon.png' alt=''/>" +
                                "<span class='zanNum'>" + agreeCount + "</span></div>" +
                                "<div class='applyabox'>"+
                                "<textarea placeholder="+replayNickName+"></textarea>"+
                                "<span class='sendApply' kid="+k.id+" commentatorId="+k.commentatorInfo.uid+">发送</span>"+
                                "<span class='cancalApply'>取消</span>"+
                                "</div></div></li>";
                            $(".comment ul").append(commentListInner);
                        }else if(commentType == 2){//二级评论
                            var commentListInner = "<li>" +
                                "<div class='commentLeft'>" +
                                "<img uid="+uid+" src='" + headImg + "' alt=''>" +
                                "</div>" +
                                "<div class='commentRight'>" +
                                "<p class='name'>" + k.commentatorInfo.nickName + " <span style='color: #A9A9A9'>回复了 </span>"+k.parentCommentatorInfo.nickName+" <span class='time'>" + format(new Date(time)) + "</span></p>" +
                                "<p class='content'>" + comment + "</p>" +
                                "<div class='zan'>" +
                                "<img class='zanImg1' src='./images/answer.png' alt='' />"+
                                "<span class='playback'>回复</span>"+
                                "<img class='zanImg' isAgree="+isAgree+"  id=" + id + "  src='./images/rewardIcon.png' alt=''/>" +
                                "<span class='zanNum'>" + agreeCount + "</span></div>" +
                                "<div class='applyabox'>"+
                                "<textarea placeholder="+replayNickName+"></textarea>"+
                                "<span class='sendApply' kid="+k.id+" commentatorId="+k.commentatorInfo.uid+">发送</span>"+
                                "<span class='cancalApply'>取消</span>"+
                                "</div></div></li>";
                            $(".comment ul").append(commentListInner);
                        }
                    })
                    $(".commentLeft img").one("error", function(e) {
                        $(this).attr("src", "images/anchorHead.png");
                    })
                    $(".commentLeft img").click(function () {
                        var uid=$(this).attr("uid");
                        window.location.href ="userProfile?uid="+uid;
                    })
                    $(".zan .zanImg").each(function () {
                        isAgree=$(this).attr("isAgree");
                        var id=$(this).attr("id");
                        var agreeCount=res.data.agreeCount;
                        var agreeCount=parseInt($(this).next().attr("agreeCount"));
                        // console.log(agreeCount);
                        if(isAgree=="true") {//已点赞
                            $(this).attr("src", "../images/rewardP.png");
                            $(this).next().css("color", "#fe4502");
                        }
                        checkZan2(id,agreeCount);
                    })
                    $(".zanImg1").click(function () {
                        $(this).parent().next(".applyabox").stop().show();
                    })
                    $(".cancalApply").click(function () {
                        $(this).parent(".applyabox").stop().hide();
                    })
                    $(".sendApply").click(function () {
                        var replayComment = $(this).prev("textarea").val();
                        var commentatorId = $(this).attr("commentatorId");
                        var authorId = commentatorId;
                        var parentId = $(this).attr("kid");
                        // 回复评论接口
                        $.ajax({
                            type: "post",
                            async: true,
                            dataType: "json",
                            url: "/api/v3/comment/insert.do",
                            data: {
                                "uid": userId,
                                "token": usertoken,
                                "comment": replayComment,
                                "objectId": videoId,
                                "parentId": parentId,
                                "type": 3,
                                "commentType": 2,
                                "authorId": commentatorId
                            },
                            success: function (res) {
                                if (res.code == 0) {
                                    // console.log(res);
                                    $('.comment ul li').remove();
                                    getCommentList2(pageIndex2);
                                    $(".applyabox textarea").val("");
                                }
                            }
                        })
                    })
                }
            }
        })
    }

    function complexDump(obj) {
        $(obj).on("click",function () {
            var type=$(this).attr("type");
            var id=$(this).attr("objectId");
            var uid=$(this).attr("uid")
            if(type==1){//文章
                window.location.href ="/article?id="+id;
            }else if(type==2){//短评

            }else if(type==3){//视频或回放
                window.location.href ="/video?id="+id;
            }else if(type==4){//直播
                window.location.href ="/live?uid="+uid;
            }else if(type==5){//静态页面
                window.location.href =id;
            }else if(type==6){//个人主播页
                window.location.href ="/userProfile?uid="+uid;
            }else if(type==7){//不跳转

            }else if(type==8){//操盘手个人页

            }else if(type==9){//个人实盘页
                window.location.href ="/userProfile?uid="+uid;
            }else if(type==10){//话题
                window.location.href ="/topicDetails?id="+id;
            }else if(type==11){//专栏详情页
                window.location.href ="/columnDetail?id="+id;
            }
        })
    }

    // 头像跳转
    $(".anchor .headImg").click(function () {
        var uid=$(this).attr("uid");
        window.location.href ="/userProfile?uid="+uid;
    })
    $(".dumpLink li").click(function () {
        var uid=$(this).attr("uid");
        var tab=$(this).attr("tab");
        window.location.href ="/userProfile?uid="+uid+"&tab="+tab;
    })

    var gift = [
        {niubi:1,text:'厉害了我的主播！',img:'images/giftzan.png'},
        {niubi:10,text:'来两颗金豆压压惊！',img:'images/giftjindou.png'},
        {niubi:188,text:'这是一个神奇的宝箱！',img:'images/giftbaoxiang.png'},
        {niubi:999,text:'让你的每只股都涨停！',img:'images/giftzhangtingban.png'},
        {niubi:1888,text:'让你财源滚滚来！',img:'images/giftcaishenye.png'},
        {niubi:8888,text:'让你牛气冲天，一牛再牛！',img:'images/giftjinniu.png'}
    ];

    $(".giftImg img").each(function(i){
        $(this).mouseover(function () {
            $(".giftImgHover").fadeIn(10);
            $(".giftValue").text(gift[i].niubi);
            $(".giftText").text(gift[i].text);
            $(".hoverImg").attr('src',gift[i].img);
            var aa = 192+75*i;
            $(".giftImgHover").css("left",aa+"px");
        });
        $(this).mouseleave(function () {
            $(".giftImgHover").fadeOut(10);
        });
    });

    function award(uid,uidIn,target,coinType,monetary,awardToken,channel,token) {
        $.ajax({
            type: "post",
            url: "/api/v1/account/award.do",
            data:{
                uid:uid,
                uidIn:uidIn,
                target:target,
                coinType:coinType,
                monetary:monetary,
                awardToken:awardToken,
                channel:channel,
                token:token
            },
            success: function (res) {
                console.log(res);
                if(res.code == 0){
                    $('.praiseSuccess').fadeIn(200);
                    setTimeout(function () {
                        $('.praiseSuccess').fadeOut(200);
                    },2000);
                    $(".reward .rewordPeople").stop().show();
                    $(".rewordHead img").remove();
                    getRewardMsg();
                }else if(res.code == -706){
                    $("#exceptWrap").stop().show();
                    $(".weChatOweWrap").stop().show();
                    $(".weChatErrorEnter").click(function() {
                        $(".weChatOweWrap").stop().hide();
                        $("#n_money").stop().show()
                    })
                }else if(res.code == -9998){
                    layer.msg('打赏失败！');
                }
            }
        })
    }

    $("body,html").click(function () {
        $(".giftImg").fadeOut(200);
    });

    $(".rewordBtn").click(function () {
        $.ajax({
            type: "get",
            url: "/userInfos",
            success: function (res) {
                if(res.code == 0){
                    $(".giftImg").fadeIn(200);
                    var token = res.data.token;
                    var uid = res.data.userInfo.uid;
                    //查询用户账户
                    $.ajax({
                        type: "post",
                        url: "/api/v1/account/selectByWhere.do",
                        data:{
                            uid:uid,
                            coinType:'RECHARGE_COIN',
                            token:token
                        },
                        success: function (res) {
                            if (res.code == 0) {
                                // console.log(res);
                                $(".balanceVal").text(res.data[0].coinNumber);
                            }
                        }
                    });
                }else {
                    $("#loginAlert").stop().show();
                    $("#loginAlert").load("/login");
                }
            }
        })
    });
    //视频格式兼容
    function hlsfun(playUrl) {
        if(Hls.isSupported()) {
            var video = document.getElementById('myVideo');
            var hls = new Hls();
            hls.loadSource(playUrl);
            hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED,function() {
                video.play();
            });
        }
    }

    $(".giftImgInner").on("click",function () {
        var niubi=$(this).attr("niubi");
        var niubishu=Number(niubi);
        $.ajax({
            type: "post",
            url: "/api/v1/account/getToken.do",
            data:{uid:userId,token:usertoken},
            success: function (result) {
                if (result.code == 0) {
                    award(userId,videoUserUid,videoId,'RECHARGE_COIN',niubishu,result.data,'WEB',usertoken);
                }
            }
        });
    })

    //充值函数
    function payFun(userId, token) {
        /*充值接口*/
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v1/account/selectByWhere.do",
            data: {
                "uid": userId,
                "coinType": "RECHARGE_COIN",
                "token": token,
            },
            success: function(res) {
                //console.log(res);
                if(res.code == 0) {
                    // console.log(res.data[0].coinNumber);
                    $(".coinNiBi").html(res.data[0].coinNumber);
                    $("#balanceCoin").html(res.data[0].coinNumber + "牛币")
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus);
            }
        });
        //点击重置按钮
        $(".payMoneyBtn").click(function() {
            $("#exceptWrap").stop().show();
            $("#n_money").stop().show();
        })
        $(".qitaMoney").focus(function() {
            $(this).removeAttr("placeholder");
            $(".moneyAlert").stop().show()
        });
        $(".qitaMoney").blur(function() {
            $(this).attr("placeholder", "其他金额");
            $(".moneyAlert").stop().hide()
        });
        $(".payBtn").click(function() {
            var totalFee = "";
            if($(".qitaMoney").val() != "") {
                totalFee = parseInt($(".qitaMoney").val());
                //console.log(totalFee)
            } else {
                totalFee = parseInt($(".money_list").find(".click_effect").children().text())
            }
            $(".weChatPayNum").html(totalFee);
            $.ajax({
                type: "POST",
                async: true,
                dataType: "json",
                url: "/api/v1/order/wxUnifiedOrder.do",
                data: {
                    "uid": userId,
                    "totalFee": totalFee,
                    "tradeType": "NATIVE",
                    "token": token,
                },
                success: function(res) {
                    if(res.code == 0) {
                        $("#n_money").fadeOut(1);
                        $(".weChatCodeWrap").fadeIn(1);
                        var codeUrl = res.data.codeUrl;
                        var outTradeNo = res.data.outTradeNo;
                        //console.log(outTradeNo);
                        jQuery("#weChatPayCode").qrcode({
                            render: "canvas",
                            foreground: "#000",
                            background: "#FFF",
                            width: 180,
                            height: 180,
                            text: codeUrl,
                            correctLevel: 2
                        });
                        intervalTime = setInterval(function() {
                            $.ajax({
                                type: "POST",
                                async: true,
                                dataType: "json",
                                url: "/api/v1/order/wxFrontNotify.do",
                                data: {
                                    "uid": userId,
                                    "outTradeNo": outTradeNo,
                                    "token": token,
                                },
                                success: function(res) {
                                    //	console.log(res);
                                    if(res.code == 0) {
                                        $(".weChatCodeWrap").stop().hide();
                                        $(".weChatPaySuccess").stop().show()
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus)
                                }
                            })
                        }, 3000)
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    console.log(XMLHttpRequest.status);
                    console.log(XMLHttpRequest.readyState);
                    console.log(textStatus);
                }
            })
        })

    }

    /*固定条*/
    var IndexpageIndex =1;
    $(".fixed_nav .reload").click(function() {
        $("body,html").animate({
            scrollTop: 1200
        }, 800)
        IndexpageIndex++;
        insertHot(IndexpageIndex, 10, "top");
        $(".insertTopWrap").stop().show(0).delay(4000).hide(0);
        $("#hotTopLoading").show().delay(1000).hide(0);
        $(".insertTop").delay(1000).slideDown(0).delay(3000).slideUp(0);

    })
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn()
        } else {
            $(".goTop").stop().fadeOut()
        }
    });
    $(".goTop").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 800)
    });

    //视频播放器
    var video = $("#myVideo").get(0);
    //播放进度
    video.ontimeupdate = function(){
        var currTime = this.currentTime,    //当前播放时间
            duration = this.duration,       // 视频总时长
            bufferedEnd=this.buffered.end(0);//缓冲进度
        $(".progress .loaded").css("width",(bufferedEnd / 100) * 834 +"px");
        //百分比
        var pre = currTime / duration;
        //显示进度条
        $(".progress .line").css("width",pre * 834 +"px");
        $(".progress_btn").css("left",pre * 834 +"px");
    };
    //跳跃播放
    $(".progress").click(function (e) {
        video.currentTime=(event.offsetX / this.offsetWidth) * video.duration;
    });
    //播放时间显示
    var i = setInterval(function() {
        if(video.readyState > 0) {
            var hours = parseInt(video.duration / (60*60));
            var minutes = parseInt((video.duration - hours*3600)/60);
            var seconds = parseInt(video.duration - minutes*60 - hours*3600 );
            // console.log(hours);
            // console.log(video.duration);
            if (hours < 10) {
                hours = "0" + hours;
            }
            if (minutes < 10) {
                minutes = "0" + minutes;
            }
            if (seconds < 10) {
                seconds = "0" + seconds;
            }
            $(".videoTime .totalTime").html(hours + ":" + minutes + ":" + seconds);

            clearInterval(i);
            $("#myVideo").on(
                "timeupdate",
                function (event) {
                    onTrackedVideoFrame(this.currentTime);
                });
            function onTrackedVideoFrame(currentTime){
                /*var minutes = parseInt(currentTime / 60, 10);
                 var hours = parseInt(minutes / 60);
                 var seconds = parseInt(currentTime % 60);*/
                var hours = parseInt(currentTime / (60*60));
                var minutes = parseInt((currentTime - hours*3600)/60);
                var seconds = parseInt(currentTime - minutes*60 - hours*3600 );
                if (hours < 10) {
                    hours = "0" + hours;
                }
                if (minutes < 10) {
                    minutes = "0" + minutes;
                }
                if (seconds < 10) {
                    seconds = "0" + seconds;
                }
                $(".videoTime .playTime").html(hours + ":" + minutes + ":" + seconds);
            }
        }
    }, 200);

    video.paused = true;
    $(".playicon").hover(function() {
        $(this).attr("src", "images/playicon-P.png")
    }, function() {
        $(this).attr("src", "images/playicon.png")
    });
    $(".playicon").on("click", function() {
        if(video.paused) {
            video.play();
            $(".playicon").attr("src", "images/playicon-p.png")
        } else {
            video.pause();
            $(".playicon").css("display", "none");
            $(".stopicon-P").css("display", "block");
        }
        return false
    });
    $(".stopicon-P").hover(function() {
        $(this).attr("src", "images/stopicon-p.png")
    }, function() {
        $(this).attr("src", "images/stopicon.png")
    });
    $(".stopicon-P").on("click", function() {
        if(video.paused) {
            video.play();
            $(".playicon").css("display", "block");
            $(".stopicon-P").css("display", "none")
        } else {
            video.pause()
        }
        return false
    });
    $(".refreshicon").click(function() {
        video.load();
    });
    $(".refreshicon").hover(function() {
        $(this).attr("src", "images/refreshicon-P.png")
    }, function() {
        $(this).attr("src", "images/refreshicon.png")
    });
    $(".volumeicon").click(function() {
        video.volume = 0;
        $("#range").val(0);
        $(".volumeicon").css("display", "none");
        $(".volumeicon1").css("display", "block");
        $(".range_before").width(0);
        $(".range_center").css({
            "left": "-5px"
        })
        return false
    });
    $(".volumeicon1").click(function() {
        video.volume = 0.5;
        $("#range").val(50);
        $(".volumeicon1").css("display", "none");
        $(".volumeicon").css("display", "block");
        $(".range_before").width(50);
        $(".range_center").css({
            "left": "45px"
        })
        return false
    });
    //声音播放器
    $("#soundBox").mousedown(function(e) {
        var oX = e.pageX - $("#soundBox").offset().left - $(".range_center").width() / 2;
        //判断，不让.drag出.left
        if(oX < 0) {
            oX = 0;
        } else if(oX > $("#soundBox").width() - $(".range_center").width()) {
            oX = $("#soundBox").width() - $(".range_center").width();
        }
        video.volume = oX / 100;
        $(".range_center").css({
            "left": oX + "px",
        });
        $(".range_before").css({
            "width": oX + 10 + "px",
        })

    })
    $(document).bind("mouseup", function() {
        $(this).unbind("mousemove");
    });
    //拖动中间部分改变声音大小

    $(".full_screenicon").hover(function() {
        $(this).attr("src", "images/full-screenicon-P.png")
    }, function() {
        $(this).attr("src", "images/full-screenicon.png")
    });

    function launchFullscreen(element) {
        if(element.requestFullscreen) {
            element.requestFullscreen()
        } else {
            if(element.mozRequestFullScreen) {
                element.mozRequestFullScreen()
            } else {
                if(element.webkitRequestFullscreen) {
                    element.webkitRequestFullscreen()
                } else {
                    if(element.msRequestFullscreen) {
                        element.msRequestFullscreen()
                    }
                }
            }
        }
    }
    $(".full_screenicon").on("click", function() {
        launchFullscreen(document.getElementById("myVideo"))
    });
    $("#myVideo").on("timeupdate", function(event) {
        onTrackedVideoFrame(this.currentTime, this.duration)
    });

    function onTrackedVideoFrame(currentTime, duration) {
        $("#current_minute").text(parseInt(currentTime / 60));
        $("#current_second").text(parseInt(currentTime % 60));
        $("#total_minute").text(parseInt(duration / 60));
        $("#total_second").text(parseInt(duration % 60))
    };
    
    //固定条
    $(window).scroll(function() {
		var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop()+140);
		if($(document).height() <= totalheight) {
			$(".share").css({
				"bottom":"355px"
			})
		}else{
			$(".share").css({
				"bottom":"0"
			})
		}
	});
})