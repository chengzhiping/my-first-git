window.onload = function(){
	var vm = new Vue({
		el:"#wrap",
		data:{			
			options: [{
	            value: '1',
	          	label: '黄金糕'
	        }, {
	          	value: '2',
	          	label: '双皮奶'
	        }, {
	          	value: '3',
	          	label: '蚵仔煎'
	        }, {
	          	value: '4',
	          	label: '龙须面'
	        }, {
	          	value: '5',
	          	label: '北京烤鸭'
	        }],
	        value1: '',
	        value2: '',
	        value3: '',
	        value4: ''
		},
		mounted:function(){	
			this.event()
		},
		methods:{				
			change:function(a){
				console.log(a)
			},
			event:function(){
				$(".el-input input").focus(function(){
					$(this).css('border','1px solid #dcdfe6')
				})
			}
		}
	})
}
