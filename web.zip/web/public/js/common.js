function format(datetime) {
	var y, m, d, h, min, s;
	y = datetime.getFullYear();
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;
	h = datetime.getHours();
	h = h < 10 ? "0" + h : h;
	min = datetime.getMinutes();
	min = min < 10 ? "0" + min : min;
	s = datetime.getSeconds();
	s = s < 10 ? "0" + s : s;
	return y + "-" + m + "-" + d + " " + h + ":" + min
}

function formatTrader(datetime) {
	var y, m, d;
	y = datetime.getFullYear();
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;

	return y + "." + m + "." + d;
}
//时间戳
function formats(datetime) {
	var y, m, d;
	y = datetime.getFullYear();
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;

	return y + "." + m + "." + d;
};

function formatsLogo(datetime) {
	var y, m, d;
	y = datetime.getFullYear();
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;

	return y + "," + m + "," + d;
};

function formatTraderNum(datetime) {
	var y, m, d;
	y = datetime.getFullYear();
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;

	return y + "" + m + "" + d;
}

function formatMDay(datetime) {
	var m, d;
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;
	return m + "/" + d
}

function formatTwo(datetime) {
	var y, m, d, h, min, s;
	y = datetime.getFullYear();
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;
	return y + "-" + m + "-" + d
}

function formatMS(datetime) {
	// var h , min , s;
	// h = datetime.getHours();
	// h = h < 10 ? "0" + h : h;
	min = datetime.getMinutes();
	min = min < 10 ? "0" + min : min;
	s = datetime.getSeconds();
	s = s < 10 ? "0" + s : s;
	return min + ":" + s;
}

function formatMS1(datetime) {
	var h, min, s;
	h = Math.floor(datetime / 60 / 60);
	h = h < 10 ? "0" + h : h;
	min = Math.floor(datetime / 60);
	min = min < 10 ? "0" + min : min;
	s = datetime % 60;
	s = s < 10 ? "0" + s : s;
	return h + ":" + min + ":" + s;
}

function formatMDay(datetime) {
	var m, d;
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;
	return m + "/" + d
}

function GetQueryString(name) {
	var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
	var r = window.location.search.substr(1).match(reg);
	if(r != null) {
		return unescape(r[2])
	}
	return null
}

function htmlEncode(str) {
	var s = "";
	if(str.length == 0) {
		return ""
	}
	var re1 = new RegExp("&lt;", "g");
	var re2 = new RegExp("&gt;", "g");
	var re3 = new RegExp("&nbsp;", "g");
	var re4 = new RegExp("&quot;", "g");
	s = str.replace(re1, "<");
	s = s.replace(re2, ">");
	s = s.replace(re3, " ");
	s = s.replace(re4, '"');
	return s
}

function sum(list) {
	return eval(list.join("+"))
}
//更新版本的兼容写法
var eventutil = {
	addHandler: function(element, type, handler) {
		if(element.addEventListener) {
			element.addEventListener(type, handler, false)
		} else {
			if(element.attachEvent) {
				element.attachEvent("on" + type, handler)
			} else {
				element["on" + type] = handler
			}
		}
	},
	removeHandler: function(element, type, handler) {
		if(element.removeEventListeners) {
			element.removeEventListener(type, handler, false)
		} else {
			if(element.detachEvent) {
				element.detachEvent("on" + type, handler)
			} else {
				element["on" + type] = null
			}
		}
	}
};
var cookie = {
	//增加cookie
	/*		var d = new Date();
			d.setDate(d.getDate()+2)
			var add = addcookie("name","李",d)
			console.log(add);*/
	addCookie: function(name, value, expires, path) {
		var cookieText = encodeURIComponent(name) + "=" + encodeURIComponent(value);
		if(expires && expires instanceof Date) {
			cookieText += '; expires=' + expires;
		}
		if(path) {
			cookieText += ';path' + path;
		}
		document.cookie = cookieText;
		return decodeURIComponent(document.cookie);
	},
	//获得cookie
	/*var get = getcookie('name3');
        console.log(get);*/
	getCookie: function(name) {
		var str = document.cookie;
		var arr1 = str.split('; '); //将获得的字符串cookie按"; "分割为数组
		for(var i = 0; i < arr1.length; i++) {
			var arr2 = arr1[i].split('=');
			if(name == arr2[0]) {
				return arr2[1]
			}
		}
		return ""; //如果没有则返回空。
	},
	//删除cookie
	//console.log(removecookie('name2'))
	removeCookie: function(name) {
		var d = new Date("2010-01-01");
		document.cookie = encodeURIComponent(name) + '= ;expires=' + d;
		return decodeURIComponent(document.cookie);
	}
}
//数字超过一万保留二位小数
function numTrans(str) {
    var num=Number(str)||'';
    if(num>=0&&num<10000){
    	return num;
    }else if(num>=10000){
    	return (num/10000).toFixed(2)+"万";
    }else if(num<0&&num>-10000){
       return num;
    }else if(num<=-10000){
    	return '-'+(Math.abs(num)/10000).toFixed(2)+'万';
    }else{
    	return '';
    }
    

}
//文章接口进行转义
function htmlEncode(str) {
	var s = "";
	if(str.length == 0) return "";

	var re1 = new RegExp("&lt;", "g"); //定义正则表达式,第一个参数是要替换掉的内容，第二个参数"g"表示替换全部（global）。
	var re2 = new RegExp("&gt;", "g");
	var re3 = new RegExp("&nbsp;", "g");
	var re4 = new RegExp("&quot;", "g");
	s = str.replace(re1, "<"); //第一个参数是正则表达式,第二个参数是替换后的目标。
	s = s.replace(re2, ">");
	s = s.replace(re3, " ");
	s = s.replace(re4, "\"");
	return s;
};
function removeHTMLTag(str) {
	str = str.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/g,'');//定义script的正则表达式
	str = str.replace(/<style(([\s\S])*?)<\/style>/g,'');//定义style的正则表达式
	str = str.replace(/<\/?[^>]*>/g, ''); //去除HTML tag
	str = str.replace(/[ | ]*\n/g, '\n'); //去除行尾空白
	//str = str.replace(/\n[\s| | ]*\r/g,'\n'); //去除多余空行
	str = str.replace(/ /ig, ''); //去掉
	return str;
};

function removeHTMLTag2(str) {
	str = str.replace(/<\/?[^>]*>/g, ''); //去除HTML tag
	str = str.replace(/[ | ]*\n/g, '\n'); //去除行尾空白
	str = str.replace(/\n[\s| | ]*\r/g, '\n'); //去除多余空行
	str = str.replace(/ /ig, ''); //去掉
	return str;
}

//视频时长
function durationFun(time) {
	var h, min, s
	min = Math.floor(time / 60) % 60;
	h = Math.floor(time / 3600)
	s = time - min * 60 - h * 60 * 60;
	h = h < 10 ? "0" + h : h;
	min = min < 10 ? "0" + min : min;
	s = s < 10 ? "0" + s : s;
	if(h > 0) {
		return h + ":" + min + ":" + s;
	} else {
		return min + ":" + s;
	}

}
//browse_button按钮id，container：按钮的父辈容器id，imgUrlObj：上传成功后存图片地址的img名
//descriptionImgUrlVip(uid,token,"descriptionImgUrlBtn","liveRoomIntroductionInfoVip",".descriptionImgUrlVip")//上传VIP特权的图片
function descriptionImgUrlVip(uid, token, browse_button, container, imgUrlObj) {
	//var updownimgHref="http://picture.91qiniu.com/";//内网
	var updownimgHref = "https://picture.fengniutv.com/";
	$.ajax({
		type: "get", //请求方式
		async: true, //是否异步
		dataType: "json",
		url: "/api/v1/picture/batchUpload/token.do",
		data: {
			"uid": uid,
			"token": token,
		},
		success: function(res) {
			if(res.code == 0) {
				//console.log(res);
				var videoEditImgtoken = res.data.uploadToken;
				//七牛上传图片
				var uploaderNam = "uploaderNam" + browse_button;
				uploaderNam = Qiniu.uploader({
					runtimes: 'html5,flash,html4', //上传模式,依次退化
					browse_button: browse_button, //上传选择的点选按钮，**必需**
					uptoken_url: updownimgHref, //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
					uptoken: videoEditImgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
					uptoken_func: function(file) {},
					unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
					save_key: false, // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
					domain: updownimgHref, //bucket域名，下载资源时用到，**必需**
					get_new_uptoken: true, //设置上传文件的时候是否每次都重新获取新的token
					container: container, //上传区域DOM ID，默认是browser_button的父元素，
					max_file_size: '100mb', //最大文件体积限制
					flash_swf_url: 'js/Moxie.swf', //引入flash,相对路径
					max_retries: 3, //上传失败最大重试次数
					dragdrop: true, //开启可拖曳上传
					drop_element: container, //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
					chunk_size: '4mb', //分块上传时，每片的体积
					auto_start: true, //选择文件后自动上传，若关闭需要自己绑定事件触发上传
					init: {
						'FilesAdded': function(up, files) {
							plupload.each(files, function(file) {
								// 文件添加进队列后,处理相关的事情
							});
						},
						'BeforeUpload': function(up, file) {
							//console.log(file);
							// 每个文件上传前,处理相关的事情
						},
						'UploadProgress': function(up, file) {
							// 每个文件上传时,处理相关的事情
						},
						'FileUploaded': function(up, file, info) {
							// console.log(info);
							var imgInfoVideoEditinfo = JSON.parse(info);
							coverUrl = updownimgHref + imgInfoVideoEditinfo.key;
							console.log(coverUrl);
							$(imgUrlObj).attr("src", coverUrl);
						},
						'Error': function(up, err, errTip) {
							console.log(up);
							console.log(err);
							console.log(errTip);
							//上传出错时,处理相关的事情
						},
						'UploadComplete': function() {
							//队列文件处理完毕后,处理相关的事情
						}
					}

				});
			}
		},
	});
}

//改变头像
function descriptionImgUrlVipImg(uid, token, browse_button, container, imgUrlObj) {
	// var updownimgHref = "http://picture.91qiniu.com/"; //内网
	 var updownimgHref="https://picture.fengniutv.com/";
	$.ajax({
		type: "get", //请求方式
		async: true, //是否异步
		dataType: "json",
		url: "/api/v1/user/head/upload/token.do",
		data: {
			"uid": uid,
			"token": token,
		},
		success: function(res) {
			if(res.code == 0) {
			var videoEditImgtoken = res.data.uploadToken;
			var imgkey = res.data.id;
			//七牛上传图片
			var uploaderNam = "uploaderNam" + browse_button;
			uploader = Qiniu.uploader({
            runtimes: 'html5,flash,html4',    //上传模式,依次退化
            browse_button: browse_button,       //上传选择的点选按钮，**必需**
            uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
            uptoken: videoEditImgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
            uptoken_func: function (file) {

            },
            unique_names: false, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
            save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
            domain: updownimgHref,//bucket域名，下载资源时用到，**必需**
            get_new_uptoken: false,  //设置上传文件的时候是否每次都重新获取新的token
            container: container,           //上传区域DOM ID，默认是browser_button的父元素，
            max_file_size: '100mb',           //最大文件体积限制
            flash_swf_url: 'js/Moxie.swf',  //引入flash,相对路径
            max_retries: 3,                   //上传失败最大重试次数
            dragdrop: true,                   //开启可拖曳上传
            drop_element:container,   //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
            chunk_size: '4mb',                //分块上传时，每片的体积
            auto_start: true,                //选择文件后自动上传，若关闭需要自己绑定事件触发上传

            init: {
                'FilesAdded': function (up, files) {
                    plupload.each(files, function (file) {
                        // 文件添加进队列后,处理相关的事情
                    });
                },
                'BeforeUpload': function (up, file) {
                    //console.log(file);
                    // 每个文件上传前,处理相关的事情
                },
                'UploadProgress': function (up, file) {
                    // 每个文件上传时,处理相关的事情
                },
                'FileUploaded': function (up, file, info) {
                    var imgInfo = JSON.parse(info);
                    var headimgUrl11=imgInfo.data;
                   // console.log(headimgUrl11);
					$(imgUrlObj).attr("src", headimgUrl11);
				      if(imgInfo.code == 0) { //上传成功
				      	console.log("上传成功");
				      }
                },
                'Error': function (up, err, errTip) {
                    console.log(errTip);
                    //上传出错时,处理相关的事情
                },
                'UploadComplete': function () {
                    //队列文件处理完毕后,处理相关的事情

                },
                'Key': function (up, file) {
                    // 若想在前端对每个文件的key进行个性化处理，可以配置该函数
                    // 该配置必须要在 unique_names: false , save_key: false 时才生效

                    var key = imgkey;
                    // do something with key here
                    return key;
                }
            },
        });
			}
		},
	});
}

function formatV5Time(datetime) {
	var y, m, d, h, min, s;
	y = datetime.getFullYear();
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;
	h = datetime.getHours();
	h = h < 10 ? "0" + h : h;
	min = datetime.getMinutes();
	min = min < 10 ? "0" + min : min;
	s = datetime.getSeconds();
	s = s < 10 ? "0" + s : s;

	return y + "-" + m + "-" + d;
};

function formatV5TimeMin(datetime) {
	var y, m, d, h, min, s;
	y = datetime.getFullYear();
	m = datetime.getMonth() + 1;
	m = m < 10 ? "0" + m : m;
	d = datetime.getDate();
	d = d < 10 ? "0" + d : d;
	h = datetime.getHours();
	h = h < 10 ? "0" + h : h;
	min = datetime.getMinutes();
	min = min < 10 ? "0" + min : min;
	s = datetime.getSeconds();
	s = s < 10 ? "0" + s : s;

	return h + ":" + min;
};
//obj点击对象，objActive点击后active的名字，objBox相对的div
function tabFun(obj, objActive, objBox) {
	$(obj).click(function() {
		$(objBox).eq($(this).index()).css("display", "block").siblings(objBox).css("display", "none");
		$(this).addClass(objActive).siblings(obj).removeClass(objActive);
	});
}

function tabSmallFun(obj, objActive) {
	$(obj).click(function() {
		$(this).addClass(objActive).siblings(obj).removeClass(objActive);
	});
}
//数字长度固定，不足前面加0
function addPreZero(num){
 return ('00000'+num).slice(-6);
}

/*交易动态付费——保留两位小数点*/
function fixedNum(str){
	if(Number(str)){
		return Number(str).toFixed(2);
	}else{
		return str;
	}
}
