$(document).ready(function () {
    var uid = GetQueryString("uid");
    var roomid = GetQueryString("roomid");
    var userId;
    var userToken;
    var userNickName;
    var userNickHeadurl;
    var target;
    var chatRoomId;
    var D;
    var media=[];
    var imgCount=0;
    var selSess = null;
    var groupId;
    var kindStatus;//区分主播视角和用户视角（主播视角--0，用户视角--1）
    var isLivingStatus;//判断是否正在直播（正在直播--1，未开始直播--0）
    var MemberNum;
    var lastliveMsgId;
    var lastChatMsgId;
    var selToID;
    var userSig;
    // var onKickedEventCall = null;
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");
    // tab切换
    $('.liveTab .liveTabUl li').click(function () {
        var index = $(this).index();
        $(this).addClass("tabhover").siblings('li').removeClass("tabhover");
        $('.tabcontent').eq(index).show(200).siblings('.tabcontent').hide();
    });
    $(".shareBtn").hover(function(){
        $(".share_inner").stop().show();
    },function(){
        $(".share_inner").stop().hide();
    });
    $(".codeBtn").hover(function(){
        $(".erweima").stop().show();
    },function(){
        $(".erweima").stop().hide();
    });
    // 显示二维码弹框
    $(".downApp").hover(function(){
        $(".erweima1").stop().show();
    },function(){
        $(".erweima1").stop().hide();
    });
    //关闭框
    $(".alertClose").click(function() {
        $("#n_money").stop().hide();
        $("#exceptWrap").stop().hide();
        clearInterval(intervalTime)
    });
    $(".weChatClose").click(function() {
        $(".weChatCodeWrap").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatSuccessClose").click(function() {
        $(".weChatPaySuccess").stop().hide();
        $("#exceptWrap").stop().hide();
        $(".qitaMoney").val("");
        $("#weChatPayCode").html("");
        clearInterval(intervalTime)
    });
    $(".weChatOweWrapClose").click(function() {
        $(".weChatOweWrap").css("display", "none");
        $("#exceptWrap").stop().hide();
    });
    //充值弹框
    $(".money_listinfo").click(function() {
        $(this).addClass("click_effect").siblings().removeClass("click_effect")
    });
    //获取直播间基本信息
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v3/live/getLiveRoomInfo.do",
        data: {
            "roomId": roomid
        },
        success: function (res) {
            if (res.code == 0) {
                // console.log(res);
                var topic = res.data.topic;
                var nickName = res.data.liverInfo.nickName;
                var partakes = res.data.partakes;//观看人数
                chatRoomId = res.data.chatRoomId;
                // console.log("chatRoomId="+chatRoomId);
                groupId = chatRoomId;
                $(".achor .achorNickName .firstname").html(res.data.roomName);
                if(res.data.liverInfo.headImgUrl == "" || res.data.liverInfo.headImgUrl == undefined){
                }else{
                    $(".anchorSameNickImg").attr("src",res.data.liverInfo.headImgUrl);
                }
                $(".achorBg").attr("src",res.data.liverInfo.headImgUrl);
                $(".achor .achorIntroduce").html("主题：" + res.data.topic);
                $(".achor .achorFocus .joinNum").html(res.data.partakes);
                $(".achor .achorFocus .buyNum").html(res.data.subscribers.count);
                $(".liveContentAnchor1 .fansCount").html(res.data.subscribers.count);
                if(res.data.announcements.length > 0){
                    var announcements = res.data.announcements[0].content;
                    $(".gonggao .gonggaoContent").html(announcements);
                    var publishTime = format(new Date(res.data.announcements[0].time));
                    $(".gonggao .noticeTime").html(publishTime);
                }else{
                    $(".gonggao").stop().hide();
                }
                //视频直播详情
                $(".liveContentAnchor1B .anchorName").html("主播："+nickName);
                var coverUrl = res.data.coverUrl;
                var defaultLiveCoverUrl = res.data.defaultLiveCoverUrl;
                $("#uploadInnerImg").attr("src",defaultLiveCoverUrl);
                //跳转到主播个人页
                $(".anchorSameNickImg").click(function(){
                	window.location.href="/userProfile?uid="+uid;
                })
            }
        }
    })
    function dingyue(){
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v2/subscribe/insert.do",
            data: {
                "uid": userId,
                "token": userToken,
                "type": 2,
                "objectId": roomid
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    // console.log(res);
                    var num = Number($(".fansCount").html());
                    $(".fansCount").html(num + 1);
                    $(".getFollowBtn").html("已订阅");
                    $(".getFollowBtn").css({
                        "background": "#C6C6C6"
                    })
                }
            }
        })
    }
    // 取消订阅
    function cancelDingyue() {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v3/subscribe/deleteSubscribe.do",
            data: {
                "uid": userId,
                "token": userToken,
                "type": 2,
                "objectId": roomid
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    $(".getFollowBtn").html("订阅");
                    $(".getFollowBtn").css({
                        "background": "#ff5038"
                    })
                    var num = Number($(".fansCount").html());
                    $(".fansCount").html(num - 1)
                }
            }
        })
    }
    getLiveRoomMsgByUid("" , roomid , 1 , uid , 10);//直播页面消息
    getLiveRoomMsgByUid("" , roomid , 2 , uid , 10);//交流页面消息交流页面消息
    //获取直播间视频直播地址
    $.ajax({
        type: "post",
        async: true,
        dataType: "json",
        url: "/api/v3/live/getLivePlayUrl.do",
        data: {
            "roomId": roomid
        },
        success: function (res) {
            if (res.code == 0) {//不加密
                console.log(res);
                $("#vedio_masked").stop().hide();
                var playUrl = res.data.hlsPlayUrl;
                // qiniuVideo('id_test_video1',playUrl,'');
                // $(".myVideo").attr("poster",res.data.coverUrl);
                getVideoDetails(res);
                $(".liveContentAnchor1T .liveTitle").html(res.data.liveTopic);
                $(".vcp-slider").stop().hide();
                $(".vcp-timelabel").stop().hide();
                videoPlay();
                $("#myVideo1").attr("src","");
            }else if(res.code == -7){//加密
                $("#vedio_masked").stop().show();
                //视频直播页信息
                $("#sure_btn").click(function () {
                    var authCode = $("#pwd").val();
                    // console.log(authCode);
                    $.ajax({
                        type: "post",
                        async: true,
                        dataType: "json",
                        url: "/api/v3/live/getLivePlayUrl1.do",
                        data: {
                            "roomId": roomid,
                            "authCode":authCode
                        },
                        success: function (res) {
                            if (res.code == 0) {
                                console.log(res);
                                $("#vedio_masked").stop().hide();
                                var playUrl = res.data.hlsPlayUrl;
                                var playImg = res.data.rtmpPlayUrl;
                                // qiniuVideo('id_test_video1',playUrl,playImg);
                                $("#myVideo").attr("poster",playImg);
                                getVideoDetails(res);
                                $(".vcp-slider").stop().hide();
                                $(".vcp-timelabel").stop().hide();
                                $(".liveContentAnchor1T .liveTitle").html(res.data.liveTopic);
                                videoPlay();
                            }else if(res.code == -111){
                                $(".error_ts").html("密码错误");
                                $(".error_ts").fadeIn(100).delay(4000).fadeOut(100);
                            }
                        }
                    })
                })
            }
        }
    })
    // 判断用户是否登录
    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function (res) {
            // console.log(res);
            if (res.code == -2) { //未登录（用户视角）
                kindStatus=1;
                //判断是否正在直播
                isLivingState1(roomid);
                $(".publish").stop().hide();//无发布
                $(".weChatScrollBottom").stop().show();
                alertLoginFun(".isLog"); //登录
                alertLoginFun(".sendGiftBtn"); //打赏
                alertLoginFun(".payMoneyBtn "); //充值
                alertLoginFun("#sendMsgBtn "); //发送
                alertLoginFun(".getFollowBtn "); //关注
                //访客模式（获得userSig）
                var data = new Date();
                var time = data.getTime() + "";
                var num = parseInt(1000000 * Math.random()) + ""; //时间戳加六位随机数
                userId = (time + num);
                $.ajax({
                    dataType: "json",
                    type: "POST", //请求方式
                    async: true, //是否异步
                    url: "/api/v1/im/createSig.do",
                    data: {
                        "uid": userId,
                    },
                    success: function(res) {
                        // console.log(res);
                        if(res.code == 0) {
                            userSig = res.data;
                            userNickHeadurl = 'https://picture.fengniutv.com/anchorHead.png'; //默认头像
                            // console.log(userSig);
                            //获取chatRoomId
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/live/getLiveRoomInfo.do",
                                data: {
                                    "roomId": roomid
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        chatRoomId = res.data.chatRoomId;
                                        // console.log("chatRoomId = "+chatRoomId);
                                        if(chatRoomId){
                                         chatRoom(chatRoomId, userSig, userId, "游客", userNickHeadurl, '');
                                         }
                                    }
                                }
                            })
                            
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        console.log(XMLHttpRequest.status);
                        console.log(XMLHttpRequest.readyState);
                        console.log(textStatus);
                    },
                });
            }else if(res.code == 0){//已登录
                // console.log(res);
                userId = res.data.userInfo.uid;
                userToken = res.data.token;
                userNickName = res.data.userInfo.nickName;
                if(res.data.userInfo.headImgUrl == "" || res.data.userInfo.headImgUrl == undefined){
                    userNickHeadurl = 'https://picture.fengniutv.com/anchorHead.png';
                }else{
                    userNickHeadurl = res.data.userInfo.headImgUrl;
                }
                // console.log(userNickHeadurl);
                $.ajax({
                    dataType: "json",
                    type: "POST", //请求方式
                    async: true, //是否异步
                    url: "/api/v1/im/createSig.do",
                    data: {
                        "uid": userId,
                    },
                    success: function(res) {
                        // console.log(res);
                        if(res.code == 0) {
                            userSig = res.data;
                            //获取chatRoomId
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/live/getLiveRoomInfo.do",
                                data: {
                                    "roomId": roomid
                                },
                                success: function (res) {
                                    if (res.code == 0) {
                                        chatRoomId = res.data.chatRoomId;
                                        console.log("chatRoomId = "+chatRoomId);
                                        if(chatRoomId){
                                            chatRoom(chatRoomId, userSig, userId, "游客", userNickHeadurl, '');
                                        }
                                    }
                                }
                            })
                            
                        }
                    },
                    error: function(XMLHttpRequest, textStatus, errorThrown) {
                        console.log(XMLHttpRequest.status);
                        console.log(XMLHttpRequest.readyState);
                        console.log(textStatus);
                    },
                });
                $(".login-inside").stop().hide();//去掉登录框
                addMoreImg(userId,userToken);
                payFun(userId, userToken);
                if(userId == uid){//主播视角
                    kindStatus = 0;
                    $(".guanli").stop().show();
                    //点击管理跳转
                    $(".guanli").click(function () {
                        window.location.href = "/userProfile?uid="+uid+"&tab=5&roomid="+roomid;
                    })
                    //判断是否正在直播
                    isLivingState2(roomid);
                    $(".weChatScrollBottom").stop().hide();//无发布评论
                    $(".publish").stop().show();//发布内容显示
                    $(".chat").css("height","900px");//聊天高度还原
                    //主播视角获取直播间视频直播地址
                    $.ajax({
                        type: "post",
                        async: true,
                        dataType: "json",
                        url: "/api/v3/live/getLivePlayUrl2.do",
                        data: {
                            "roomId": roomid,
                            "uid": userId,
                            "token": userToken
                        },
                        success: function (res) {
                            // console.log(res);
                            if(res.code == 0){
                                var playImg = res.data.rtmpPlayUrl;
                                // qiniuVideo2('id_test_video2',res.data.hlsPlayUrl,playImg);
                                $("#myVideo1").attr("poster",res.data.hlsPlayUrl,playImg);
                                getVideoDetails1(res);
                                $(".vcp-slider").stop().hide();
                                $(".vcp-timelabel").stop().hide();
                                $(".videoPlayDetail .videoPlayTitle").html(res.data.liveTopic);
                                videoPlay1();
                                $("#myVideo").attr("src","");
                            }
                        }
                    })
                    //发布链接
                    $("#publishAddLinkUrl").click(function () {
                        var publishType = 3;
                        var linkUrl = $("#linkUrl").val();
                        var linkUrlDescripe = $("#linkUrlDescripe").val();
                        if(linkUrl == ""){
                            $(".addLinkUrl .sendNull").fadeIn(100).delay(4000).fadeOut(100);
                            return false;
                        }
                        var msgtosend = linkUrlDescripe +" igugl "+ linkUrl;
                        sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid, msgtosend,publishType,'', '');
                    })
                    //发布无图图文
                    $(".publishEnter").click(function () {
                        var publishType = 1;
                        var msgtosend = $("#noImgContent").val();
                        if(msgtosend == ""){
                            $(".publish .sendNull").fadeIn(100).delay(4000).fadeOut(100);
                            return false;
                        }
                        // console.log(msgtosend);
                        sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid, msgtosend,publishType,'', '');
                    })
                    // 发布图文
                    $("#publishViewBtn").click(function () {
                        var publishType = 2;
                        var mediaLength = media.length;
                        // console.log(mediaLength);
                        if(mediaLength > 9 ){//图片超过九张
                            $(".publishImgBox .sendNull").fadeIn(100).delay(4000).fadeOut(100);
                            return false;
                        }
                        if(mediaLength == 0){
                            $(".publishImgBox .sendNull").html("请选择图片!");
                            $(".publishImgBox .sendNull").fadeIn(100).delay(4000).fadeOut(100);
                            return false;
                        }
                        var mediaStr = media.join(",")+",";
                        var msgtosend = $(".shortViewContent").val();
                        sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid, msgtosend,publishType,mediaStr, '');
                    })
                    // 上传封面图片
                    palybackImg(uid,userToken);
                    // 编辑回放
                    $("#saveEditPlayback").click(function () {
                        var playbackId = $(this).parent().parent().attr("kid");
                        // console.log(playbackId);
                        var coverUrl = $("#uploadInnerImg1").attr("src");
                        var topic = $("#playbackTopic").val();
                        // console.log(coverUrl);
                        // console.log(topic);
                        // 编辑直播接口
                        $.ajax({
                            type: "post",
                            async: true,
                            dataType: "json",
                            url: "/api/v2/live/edit1.do",
                            data: {
                                "uid": userId,
                                "token": userToken,
                                "id": playbackId,
                                "coverUrl": coverUrl,
                                "topic":topic
                            },
                            success: function(res) {
                                // console.log(res);
                                if(res.code == 0) {
                                    $(".editPlayback").stop().hide();
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus);
                            }
                        })
                     })
                    //回复用户消息
                    $(document).on("click",".sendApply",function () {
                        var answer = $(this).siblings(".applyInput").val();
                        var chatContent = $(this).attr("chatContent");
                        var chatName = $(this).attr("chatName");
                        var msgtosend = answer +" igstn "+chatName+":"+chatContent;
                        if(answer == ""){
                            $(this).next(".sendNull").fadeIn(100).delay(4000).fadeOut(100);
                            return false;
                        }
                        onSendMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid,msgtosend);
                    })
                    //删除图文信息
                    $(document).on("click",".deleteWenzi",function () {
                        var id = $(this).attr("id");
                        var deleteId = $(this).attr("kid");
                        // console.log(deleteId);
                        var kindofId = $(this).attr("kindofId");
                        // console.log(kindofId);
                        if(kindofId == 1){//回放
                            var playbackId = $(this).attr("playbackId");
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/liveRoomMsg/deleteMsg.do2",
                                data: {
                                    "uid": userId,
                                    "token": userToken,
                                    "id": deleteId,
                                    "objectId": playbackId
                                },
                                success: function(res) {
                                    // console.log(res);
                                    if(res.code == 0) {
                                        $("#kill"+deleteId).parent("#tuwenContent li").remove();
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus);
                                }
                            })
                        }else{//不是回放
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/liveRoomMsg/deleteMsg.do1",
                                data: {
                                    "uid": userId,
                                    "token": userToken,
                                    "id": deleteId
                                },
                                success: function(res) {
                                    // console.log(res);
                                    if(res.code == 0) {
                                        $("#kill"+deleteId).parent("#tuwenContent li").remove();
                                    }
                                },
                                error: function(XMLHttpRequest, textStatus, errorThrown) {
                                    console.log(XMLHttpRequest.status);
                                    console.log(XMLHttpRequest.readyState);
                                    console.log(textStatus);
                                }
                            })
                        }
                    })
                    //删除聊天里回复信息
                    $(document).on("click",".deleteChat",function () {
                        var deleteId = $(this).attr("kid");
                        var id = $(this).attr("id");
                        // console.log(deleteId);
                        $.ajax({
                            type: "post",
                            async: true,
                            dataType: "json",
                            url: "/api/v3/liveRoomMsg/deleteMsg.do1",
                            data: {
                                "uid": userId,
                                "token": userToken,
                                "id": deleteId
                            },
                            success: function(res) {
                                // console.log(res);
                                if(res.code == 0) {
                                    $("#kill"+deleteId).parent("#chatDetail li").remove();
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus);
                            }
                        })
                    })
                }else{//用户视角
                    kindStatus = 1;
                    $(".publish").stop().hide();//无发布
                    $(".weChatScrollBottom").stop().show();
                    //判断是否正在直播
                    isLivingState1(roomid);
                    // 用户评论
                    $("#sendMsgBtn").click(function () {
                        var msgtosend = $("#sendMsg").val();
                        if(msgtosend == ""){
                            $(".weChatScrollBottom .sendNull").fadeIn(100).delay(4000).fadeOut(100);
                            return false;
                        }
                        onSendMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid,msgtosend);
                    })
                    /*打赏*/
                    for(D = 1; D < 7; D++) {
                        sendGiftFun(D);
                    };
                    //充值
                    $(".payMoneyBtn").click(function() {
                        $("#exceptWrap").stop().show();
                        $("#n_money").stop().show();
                    })
                    //判断是不是已订阅
                    $.ajax({
                        type: "post",
                        async: true,
                        dataType: "json",
                        url: "/api/v3/live/getLiveRoomInfo.do1",
                        data: {
                            "roomId": roomid,
                            "uid": userId,
                            "token": userToken,
                        },
                        success: function (res) {
                            // console.log(res);
                            if (res.code == 0) {
                                var subscribed = res.data.subscribed;
                                if (subscribed == true) {//已订阅
                                    $(".getFollowBtn").html("已订阅");
                                    $(".getFollowBtn").css({
                                        "background": "#C6C6C6"
                                    })
                                }
                            }
                        }
                    })
                    //点击订阅按钮
                    $(".getFollowBtn").click(function () {
                        $.ajax({
                            type: "post",
                            async: true,
                            dataType: "json",
                            url: "/api/v3/live/getLiveRoomInfo.do1",
                            data: {
                                "roomId": roomid,
                                "uid": userId,
                                "token": userToken,
                            },
                            success: function (res) {
                                // console.log(res);
                                if (res.code == 0) {
                                    var subscribed = res.data.subscribed;
                                    if (subscribed == true) {//已订阅
                                        $(".getFollowBtn").html("已订阅");
                                        $(".getFollowBtn").css({
                                            "background": "#C6C6C6"
                                        })
                                        //取消订阅
                                        cancelDingyue();
                                    }else{
                                        dingyue();
                                    }
                                }
                            }
                        })
                    })
                }
            }
        }
    })
    //显示登录弹框
    function alertLoginFun(obj) {
        $(obj).click(function() {
            $("#loginAlert").stop().show();
            $("#loginAlert").load("/login");
        });
    }
    function showMsg(uid,token,liveRoomId,content,type,msgType){
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v3/liveRoomMsg/saveMsg.do",
            data: {
                "uid": uid,
                "token": token,
                "liveRoomId": liveRoomId,
                "content": content,
                "type": type,
                "msgType":msgType
            },
            success: function(res) {
                if(res.code == 0) {
                    // console.log(res);
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus);
            }
        })
    }
    $(".payBtn").click(function() {
        var totalFee = "";
        if($(".qitaMoney").val() != "") {
            totalFee = parseInt($(".qitaMoney").val());
            //console.log(totalFee)
        } else {
            totalFee = parseInt($(".money_list").find(".click_effect").children().text())
        }
        $(".weChatPayNum").html(totalFee);
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v1/order/wxUnifiedOrder.do",
            data: {
                "uid": userId,
                "totalFee": totalFee,
                "tradeType": "NATIVE",
                "token": userToken,
            },
            success: function(res) {
                // console.log(res);
                if(res.code == 0) {
                    $("#n_money").fadeOut(1);
                    $("#exceptWrap").fadeIn(1);
                    $(".weChatCodeWrap").fadeIn(1);
                    var codeUrl = res.data.codeUrl;
                    var outTradeNo = res.data.outTradeNo;
                    //console.log(outTradeNo);
                    jQuery("#weChatPayCode").qrcode({
                        render: "canvas",
                        foreground: "#000",
                        background: "#FFF",
                        width: 180,
                        height: 180,
                        text: codeUrl,
                        correctLevel: 2
                    });
                    intervalTime = setInterval(function() {
                        $.ajax({
                            type: "POST",
                            async: true,
                            dataType: "json",
                            url: "/api/v1/order/wxFrontNotify.do",
                            data: {
                                "uid": userId,
                                "outTradeNo": outTradeNo,
                                "token": userToken,
                            },
                            success: function(res) {
                                //	console.log(res);
                                if(res.code == 0) {
                                    $(".weChatCodeWrap").stop().hide();
                                    $(".weChatPaySuccess").stop().show();
                                    payFun(userId, usertoken);
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus)
                            }
                        })
                    }, 3000)
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus);
            }
        })
    })
    //发送礼品
    function sendGiftFun(D) {
        $("#sendGiftBtn" + D).click(function() {
            monetary = $("#giftPrice" + D).html();
            //console.log(monetary);
            $.ajax({
                dataType: "json",
                type: "POST",
                async: true,
                url: "/api/v1/account/getToken.do", //打赏认证Token
                data: {
                    "uid": userId,
                    "token": userToken,
                },
                success: function(res) {
                    if(res.code == 0) {
                        var awardToken = res.data;
                        $.ajax({
                            dataType: "json",
                            type: "POST",
                            async: true,
                            url: "/api/v1/account/award.do", //用户打赏接口
                            data: {
                                "uid": userId,
                                "uidIn": uid,
                                "target": roomid,
                                "coinType": "RECHARGE_COIN",
                                "monetary": monetary,
                                "awardToken": awardToken,
                                "channel": "WEB",
                                "token": userToken,
                            },
                            success: function(res) {
                                // console.log(res);
                                if(res.code == 0) {
                                    //获取chatRoomId
                                    $.ajax({
                                        type: "post",
                                        async: true,
                                        dataType: "json",
                                        url: "/api/v3/live/getLiveRoomInfo.do",
                                        data: {
                                            "roomId": roomid
                                        },
                                        success: function (res) {
                                            if (res.code == 0) {
                                                chatRoomId = res.data.chatRoomId;
                                                console.log("chatRoomId = "+chatRoomId);
                                                if(chatRoomId){
                                                    sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid,'','','',D);
                                                }
                                                payFun(userId, userToken);
                                            }
                                        }
                                    }) 
                                }
                                if(res.code == -706) { //余额不足
                                    $("#exceptWrap").stop().show();
                                    $(".weChatOweWrap").stop().show();
                                    $(".weChatErrorEnter").click(function() {
                                        $(".weChatOweWrap").stop().hide();
                                        $("#n_money").stop().show()
                                    })
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(XMLHttpRequest.status);
                                console.log(XMLHttpRequest.readyState);
                                console.log(textStatus)
                            },
                        })
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    console.log(XMLHttpRequest.status);
                    console.log(XMLHttpRequest.readyState);
                    console.log(textStatus)
                },
            })
        });
    }
    function payFun(userId, usertoken) {
        /*查询用户余额*/
        $.ajax({
            type: "POST",
            async: true,
            dataType: "json",
            url: "/api/v1/account/selectByWhere.do",
            data: {
                "uid": userId,
                "coinType": "RECHARGE_COIN",
                "token": usertoken,
            },
            success: function(res) {
                // console.log(res);
                if(res.code == 0) {
                    $(".coinNiBi").html(res.data[0].coinNumber);
                    $(".balanceCoin").html(res.data[0].coinNumber + "牛币");
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus);
            }
        });
    }
    function getLiveRoomMsgByUid(id, liveRoomId, msgType, uid, pageSize) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v3/liveRoomMsg/getLiveRoomMsgByUid.do",
            data: {
                "id": id,
                "liveRoomId": liveRoomId,
                "msgType": msgType,
                "uid": uid,
                "pageSize": pageSize
            },
            success: function(res) {
                // console.log(res);
                if(res.code == 0) {
                    if(msgType == 1) {
                        //直播tab里面显示(历史记录)
                        // console.log(res);
                        if(res.data.length == 0 && id == ""){
                            $("#noZhiboContent").stop().show();
                        }
                        getLiveMsg(res);
                        var liveMsgLength = res.data.length;
                        if(liveMsgLength != 0){
                            lastliveMsgId = res.data[liveMsgLength-1].id;
                        }
                        // console.log(lastliveMsgId);
                        $("#zhiboTab").mCustomScrollbar({
                            callbacks:{
                                onScrollStart:function(){},
                                onScroll:function(){},
                                onTotalScroll:function(){
                                    getLiveRoomMsgByUid(lastliveMsgId, liveRoomId, 1, uid, 10);
                                },
                                onTotalScrollBack:function(){},
                                onTotalScrollOffset:80,
                                whileScrolling:false,
                                whileScrollingInterval:0
                            },
                            scrollInertia:300
                        });
                    } else if(msgType == 2) {
                        //交流里面显示（历史记录）
                        // console.log(res);
                        if(id == "" && res.data.length == 0){
                            $("#noChatContent").stop().show();
                        }
                        getChatMsg(res);
                        var liveChatLength = res.data.length;
                        if(liveChatLength != 0){
                            lastChatMsgId = res.data[liveChatLength-1].id;
                        }
                        // console.log(lastChatMsgId);
                        $("#chat").mCustomScrollbar({
                            callbacks:{
                                onScrollStart:function(){},
                                onScroll:function(){},
                                onTotalScroll:function(){
                                    getLiveRoomMsgByUid(lastChatMsgId, liveRoomId, 2, uid, 10);
                                },
                                onTotalScrollBack:function(){},
                                onTotalScrollOffset:80,
                                whileScrolling:false,
                                whileScrollingInterval:0
                            },
                            scrollInertia:300
                        });
                    }
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus);
            },
        })
    }
    function getChatMsg(res) {
        $(res.data).each(function(i, k) {
            var sendTime = formatV5Time(new Date(k.sendTime)); //2017-09-29
            var sendTimeMin = formatV5TimeMin(new Date(k.sendTime)); //20:10
            var communicationInfo = JSON.parse(k.content).content+"";
            var headerIMG = k.userInfo.headImgUrl;
            if(!headerIMG) {
                headerIMG = '../images/anchorHead.png';
            }
            var killId = "kill"+k.id;
            var fromAccount = k.userInfo.uid;
            var imTime = k.sendTime;
            var cancelId = imTime+"cancel";
            var fromAccountNick = k.userInfo.nickName;
            var answerNick = "回复"+fromAccountNick+"...";
            var anchorAnwserBrforeIm = communicationInfo.split("igstn")[0];
            var anchorAnwserAfterIm = communicationInfo.split("igstn")[1];
            if(communicationInfo.indexOf("igstn") != -1){//带回复
                var chatListInner = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                    "<p class='chatName'>"+fromAccountNick+"</p>"+
                    "<p class='bozhu'>播主</p>"+
                    "<p class='chatTime'>"+sendTimeMin+"</p>"+
                    "<p class='answerContent'>"+anchorAnwserBrforeIm+"</p>"+
                    "<span class='chatContent'>"+anchorAnwserAfterIm+"</span><br />"+
                    "<p class='deleteChat' kid="+k.id+" id="+killId+">删除</p>"+
                    "</li>";
                $(".chatDetail").append(chatListInner);
            }else{
                if(fromAccount != uid) {//不是播主
                    var chatListInner = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                        "<p class='chatName'>"+fromAccountNick+"</p>"+
                        "<p class='chatTime'>"+sendTimeMin+"</p>"+
                        "<br /><span class='chatContent'>"+communicationInfo+"</span><br />"+
                        // "<p class='deleteChat' kid="+k.id+" id="+killId+">删除</p>"+
                        "<p class='answerChat'>回复</p>"+
                        "<div class='apply'><textarea class='applyInput' placeholder='"+answerNick+"' maxlength='140' ></textarea>"+
                        "<span class='cancalSend' id="+cancelId+">取消</span><span class='sendApply'  chatContent="+communicationInfo+" chatName="+fromAccountNick+">发送</span>"+
                        "<p class='sendNull'>不能回复空信息哦！</p></div></li>";
                    $(".chatDetail").append(chatListInner);
                }else{//播主
                    var chatListInner = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                        "<p class='chatName'>"+fromAccountNick+"</p>"+
                        "<p class='chatTime'>"+sendTimeMin+"</p>"+
                        "<br /><span class='chatContent'>"+communicationInfo+"</span><br />"+
                        "<p class='deleteChat' kid="+k.id+" id="+killId+">删除</p>"+
                        "<p class='answerChat'>回复</p>"+
                        "<div class='apply'><textarea class='applyInput' placeholder='"+answerNick+"' maxlength='140' ></textarea>"+
                        "<span class='cancalSend' id="+cancelId+">取消</span><span class='sendApply'  chatContent="+communicationInfo+" chatName="+fromAccountNick+">发送</span>"+
                        "<p class='sendNull'>不能回复空信息哦！</p></div></li>";
                    $(".chatDetail").append(chatListInner);
                }
            }
            $(".answerChat").click(function () {
                $(this).next(".apply").stop().show();
            })
            $("#"+cancelId).click(function () {
                // console.log("点击取消");
                $(this).parent(".apply").stop().hide();
            })
            if(kindStatus == 1){//用户视角
                $(".liveNewBody .chat .chatDetail li .deleteChat").stop().hide();//无删除聊天信息
                $(".liveNewBody .chat .chatDetail li .answerChat").stop().hide();//无回复聊天信息
            }else if(kindStatus == 0){//主播视角
                $(".liveNewBody .chat .chatDetail li .deleteChat").stop().show();
                $(".liveNewBody .chat .chatDetail li .answerChat").stop().show();
            }
        })
    }
    function getLiveMsg(res){
        $(res.data).each(function(i, k) {
            var content = JSON.parse(k.content);
            var type = content.type;
            // console.log(type);//0 短评 1回放 2 回复 3链接
            var sendTime = formatV5Time(new Date(k.sendTime)); //2017-09-29
            var sendTimeMin = formatV5TimeMin(new Date(k.sendTime)); //20:10
            var liveId = k.id; //图文每条信息的ID
            var killId = "kill"+k.id;
            var content1 = content.content;
            var media = content.media;
            if(type == 0){//短评
                if(media == ""){//无图
                    var shortDetailInner = "<li>"+
                        "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                        "<span class='timeDetail'>"+sendTime+"</span></p>"+
                        "<span class='publishTime'>"+sendTimeMin+"</span>"+
                        "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                        "<p class='wenziContent'>"+content1+"</p>"+
                        "</li>";
                    $("#tuwenContent").append(shortDetailInner);
                }else{//有图
                    var shortViewImg = (media.split(','));
                    var len = shortViewImg.length - 1;
                    if(len == 1){//1图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent'>"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }else if(len == 2){//2图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent'>"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[1]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[1] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }else if(len == 3){//三图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent'>"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[1]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[1] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[2]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[2] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }else if(len == 4){//4图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent' kid="+k.id+">"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[1]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[1] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[2]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[2] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[3]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[3] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }else if(len == 5){//5图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent'>"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[1]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[1] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[2]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[2] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[3]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[3] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[4]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[4] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }else if(len == 6){//6图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent'>"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[1]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[1] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[2]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[2] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[3]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[3] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[4]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[4] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[5]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[5] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }else if(len == 7){//7图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent'>"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[1]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[1] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[2]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[2] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[3]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[3] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[4]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[4] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[5]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[5] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[6]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[6] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }else if(len == 8){//8图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent'>"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[1]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[1] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[2]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[2] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[3]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[3] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[4]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[4] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[5]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[5] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[6]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[6] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[7]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[7] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }else if(len == 9){//9图
                        var shortDetailInner = "<li>"+
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                            "<span class='timeDetail'>"+sendTime+"</span></p>"+
                            "<span class='publishTime'>"+sendTimeMin+"</span>"+
                            "<span class='deleteWenzi' kid="+k.id+" kindofId='0' id="+killId+">删除</span>"+
                            "<p class='wenziContent'>"+content1+"</p>"+
                            "<ul class='shortImg'>"+
                            "<li><a href='"+shortViewImg[0]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[0] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[1]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[1] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[2]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[2] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[3]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[3] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[4]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[4] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[5]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[5] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[6]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[6] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[7]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[7] +"' alt='' /></a></li>"+
                            "<li><a href='"+shortViewImg[8]+"' data-lightbox="+liveId+"><img src='"+ shortViewImg[8] +"' alt='' /></a></li>"+
                            "</ul></li>";
                        $("#tuwenContent").append(shortDetailInner);
                    }
                }
            }else if(type == 1){//回放
                var playbackId = content.id;
                var playBackInner = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                                    "<span class='timeDetail'>"+sendTime+"</span></p>"+
                                    "<span class='publishTime'>"+sendTimeMin+"</span>"+
                                    "<span class='deleteWenzi' kid="+k.id+" playbackId="+playbackId+" kindofId='1' id="+killId+">删除</span>"+
                                    "<p class='editWenzi' kid="+playbackId+"  >编辑</p>"+
                                    "<p class='wenziContent'>"+content1+"</p>"+
                                    "<div  kid="+playbackId+" class='videoBox'>"+
                                    "<img class='videoBg' src='"+media+"' alt='' />"+
                                    "<p class='videoType'>回看</p>"+
                                    // "<p class='watchNum'>100人观看</p>"+
                                    "<img class='playBtn' src='images/indexvideo.png' alt='' /></div></li>";
                $("#tuwenContent").append(playBackInner);
                $(".videoBg").one("error", function(e) {
                    $(this).attr("src", "../images/vedioCoverUrl.jpg");
                });
                //编辑回放
                $(".editWenzi").click(function () {
                    $(".editPlayback").stop().show();
                    var playbackId = $(this).attr("kid");
                    $(".editPlayback").attr("kid",playbackId);
                })
                $("#cancalEditPlayback").click(function () {
                    $(".editPlayback").stop().hide();
                })
            }else if(type == 2){//回复
                var anchorAnwser = content.content;
                var anchorAnwserBrfore = anchorAnwser.split("igstn")[0];
                var anchorAnwserAfter = anchorAnwser.split("igstn")[1];
                var answerInner = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                                "<span class='timeDetail'>"+sendTime+"</span></p>"+
                                "<span class='publishTime'>"+sendTimeMin+"</span>"+
                                "<span class='deleteWenzi' kid="+k.id+" kindofId='2' id="+killId+">删除</span>"+
                                "<p class='wenziContent'>"+anchorAnwserBrfore+"</p>"+
                                "<span class=' answerWenzi'>"+anchorAnwserAfter+"</span></li>";
                $("#tuwenContent").append(answerInner);
            }else if(type == 3){//链接
                var anchorhref = content.content;
                var anchorhrefBrfore = anchorhref.split("igugl")[0];
                var anchorhrefAfter = anchorhref.split("igugl")[1];
                var linkUrl = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />"+
                                "<span class='timeDetail'>"+sendTime+"</span></p>"+
                                "<span class='publishTime'>"+sendTimeMin+"</span>"+
                                "<span class='deleteWenzi' kid="+k.id+" kindofId='3' id="+killId+">删除</span>"+
                                "<a href=" + anchorhrefAfter +"><p class='wenziContent'>"+ anchorhrefBrfore + "<span style='color: #5286BE'>" + anchorhrefAfter +"</span></p></a></li>";
                $("#tuwenContent").append(linkUrl);
            }
            if(kindStatus == 1){//用户视角
                $(".tabcontent .zhiboContent li .deleteWenzi").stop().hide();//无删除图文信息
                $(".tabcontent .zhiboContent li .editWenzi").stop().hide();//无编辑视频回放
            }else if(kindStatus == 0){//主播视角
                $(".tabcontent .zhiboContent li .deleteWenzi").stop().show();
                $(".tabcontent .zhiboContent li .editWenzi").stop().show();
            }
        })
        //遍历时间，相同的去掉
        var timeTitleLen = $(".timeDetail").length;
        var timeTitle = document.getElementsByClassName("dayTime");
        var timeTitleInnerLast = timeTitle[timeTitleLen - 1].innerHTML;
        for(var q = 0; q < timeTitleLen; q++) {
            var timeTitleInner = timeTitle[q].innerHTML;
            if(timeTitle[q + 1] != undefined && timeTitle[q + 1] != null && timeTitle[q + 1] != "") {
                var timeTitleInnerNext = timeTitle[q + 1].innerHTML;
                if(timeTitleInnerNext == timeTitleInner) {
                    timeTitle[q + 1].style.display = "none";
                }
            }
        }
    }
    //点击回放跳转
    $(document).on("click","#tuwenContent li .videoBox",function () {
        var id = $(this).attr("kid");
        window.location.href = "/liveLookBack?id="+id+"&roomid="+roomid+"&uid="+uid;
    })
    // 点击动态跳转
    $("#dongtaiTab").click(function () {
        window.location.href = "/userProfile?uid="+uid+"&tab=2";
    })
    // 点击vip跳转
    $("#vipTab").click(function () {
        window.location.href = "/userProfile?uid="+uid+"&tab=6";
    })
    //七牛云上传多张短评图片
    function addMoreImg(uid,token){
        $.ajax({
            type: "get", //请求方式
            async: true, //是否异步
            dataType: "json",
            url: "/api/v1/picture/batchUpload/shortViewToken.do",
            data:{
                "uid":uid,
                "token":token,
            },
            success:function(res){
                // console.log(res);
                if(res.code==0)
                {
                    var sortimgtoken = res.data.uploadToken;
                    //七牛上传图片
                    var uploader6 = Qiniu.uploader({
                        runtimes: 'html5,flash,html4',    //上传模式,依次退化
                        browse_button: 'addMoreImage',       //上传选择的点选按钮，**必需**
                        uptoken_url: '', //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                        uptoken : sortimgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                        uptoken_func: function(file) {

                        },
                        unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                        save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                        domain: 'upload.qbox.me',//bucket域名，下载资源时用到，**必需**
                        get_new_uptoken: true,  //设置上传文件的时候是否每次都重新获取新的token
                        container: 'shortViewImgBox',           //上传区域DOM ID，默认是browser_button的父元素，
                        max_file_size: '100mb',           //最大文件体积限制
                        flash_swf_url: 'js/Moxie.swf',  //引入flash,相对路径
                        max_retries: 3,                   //上传失败最大重试次数
                        dragdrop: true,                   //开启可拖曳上传
                        drop_element: 'shortViewImgBox',   //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                        chunk_size: '4mb',                //分块上传时，每片的体积
                        auto_start: true,                 //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                        init: {
                            'FilesAdded': function(up, files) {
                                // plupload.each(files, function(file) {
                                //    // 文件添加进队列后,处理相关的事情
                                // });
                            },
                            'BeforeUpload': function(up, file) {
                                //console.log(file);
                                // 每个文件上传前,处理相关的事情
                            },
                            'UploadProgress': function(up, file) {
                                // 每个文件上传时,处理相关的事情
                            },
                            'FileUploaded': function(up, file, info) {
                                var sortimgInfo=JSON.parse(info);
                                //console.log(info);
                                var sortimgUrl="https://picture.fengniutv.com/"+sortimgInfo.key;//外网
                                // var sortimgUrl="http://picture.91qiniu.com/"+sortimgInfo.key;//内网
                                var addMoreImageInner="<p class='floatImg' id='floatImg"+imgCount+"'><img src='"+sortimgUrl+"' /><img src='images/shortView5.png' class='perCloseBtn'/></p>"
                                $(".upload_out").before(addMoreImageInner);
                                media.push(sortimgUrl);
                                imgCount++;
                                //console.log(imgCount);
                                //console.log(media);

                                //鼠标进入图片关闭按钮时变红色
                                $(".perCloseBtn").hover(function(){
                                    $(this).attr("src","images/shortView5P.png");
                                },function(){
                                    $(this).attr("src","images/shortView5.png");
                                });
                            },
                            'Error': function(up, err, errTip) {
                                // console.log(errTip);
                                //上传出错时,处理相关的事情
                            },
                            'UploadComplete': function() {
                                //队列文件处理完毕后,处理相关的事情
                                //删除media对应的图片URL
                                $(".perCloseBtn").on("click",function(){
                                    var thisUrl=$(this).prev().attr("src");
                                    // console.log(thisUrl);
                                    media.splice($.inArray(thisUrl,media),1);
                                    // console.log(media);
                                    $(this).parent().remove();
                                })
                            }
                        }
                    });
                }
            },
            error: function(XMLHttpRequest, textStatus, errorThrown) {
                console.log(XMLHttpRequest.status);
                console.log(XMLHttpRequest.readyState);
                console.log(textStatus);
            },
        });
    }
    //编辑回放封面图片上传
    function palybackImg(uid,token) {
        // var updownimgHref = "http://picture.91qiniu.com/";//内网
        var updownimgHref="https://picture.fengniutv.com/";
        $.ajax({
            type: "get", //请求方式
            async: true, //是否异步
            dataType: "json",
            url: "/api/v1/picture/batchUpload/token.do",
            data: {
                "uid": uid,
                "token": token,
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    var videoEditImgtoken = res.data.uploadToken;
                    //七牛上传图片
                    var uploader = Qiniu.uploader({
                        runtimes: 'html5,flash,html4',    //上传模式,依次退化
                        browse_button: 'add2Img',       //上传选择的点选按钮，**必需**
                        uptoken_url: updownimgHref, //Ajax请求upToken的Url，**强烈建议设置**（服务端提供）
                        uptoken: videoEditImgtoken, //若未指定uptoken_url,则必须指定 uptoken ,uptoken由其他程序生成
                        uptoken_func: function (file) {

                        },
                        unique_names: true, // 默认 false，key为文件名。若开启该选项，SDK为自动生成上传成功后的key（文件名）。
                        save_key: false,   // 默认 false。若在服务端生成uptoken的上传策略中指定了 `sava_key`，则开启，SDK会忽略对key的处理
                        domain: updownimgHref,//bucket域名，下载资源时用到，**必需**
                        get_new_uptoken: true,  //设置上传文件的时候是否每次都重新获取新的token
                        container: 'uploadInnerImg1',           //上传区域DOM ID，默认是browser_button的父元素，
                        max_file_size: '100mb',           //最大文件体积限制
                        flash_swf_url: 'js/Moxie.swf',  //引入flash,相对路径
                        max_retries: 3,                   //上传失败最大重试次数
                        dragdrop: true,                   //开启可拖曳上传
                        drop_element: 'uploadInnerImg1',   //拖曳上传区域元素的ID，拖曳文件或文件夹后可触发上传
                        chunk_size: '4mb',                //分块上传时，每片的体积
                        auto_start: true,                //选择文件后自动上传，若关闭需要自己绑定事件触发上传
                        init: {
                            'FilesAdded': function (up, files) {
                                plupload.each(files, function (file) {
                                    // 文件添加进队列后,处理相关的事情
                                });
                            },
                            'BeforeUpload': function (up, file) {
                                //console.log(file);
                                // 每个文件上传前,处理相关的事情
                            },
                            'UploadProgress': function (up, file) {
                                // 每个文件上传时,处理相关的事情
                            },
                            'FileUploaded': function (up, file, info) {
                                // console.log(info);
                                var imgInfoVideoEditinfo = JSON.parse(info);
                                coverUrl = updownimgHref + imgInfoVideoEditinfo.key;
                                $("#uploadInnerImg1").attr("src",coverUrl);
                                $(".addTips").html("修改封面");
                                $(".addTips").css("color", "#ffffff");
                            },
                            'Error': function (up, err, errTip) {
                                // console.log(up);
                                // console.log(err);
                                // console.log(errTip);
                                //上传出错时,处理相关的事情
                            },
                            'UploadComplete': function () {
                                //队列文件处理完毕后,处理相关的事情
                            }
                        }
                    });
                }
            },
        });
    }
    function isLivingState1(roomid) {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v3/live/getLiveRoomInfo.do",
            data: {
                "roomId": roomid
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    // console.log(res);
                    var status = res.data.status;
                    // console.log(status);
                    if(status == 1){//视频直播中
                        // 10秒判断一次是不是在直播中
                        setInterval(function () {
                                $.ajax({
                                    type: "post",
                                    async: true,
                                    dataType: "json",
                                    url: "/api/v3/live/getLiveRoomInfo.do",
                                    data: {
                                        "roomId": roomid
                                    },
                                    success: function (res) {
                                        // console.log(res);
                                        if (res.code == 0) {
                                            var status = res.data.status;
                                            if(status == 1){//视频直播中
                                            }else{//非直播中
                                                $("#liveEndWrap").stop().show();
                                                $("#liveEndWrap .liveEndSure").click(function () {
                                                    location.reload();
                                                })
                                            }
                                        }
                                    }
                                })
                            },5000);
                        isLivingStatus = 1;
                        $("body").css("background","#ffffff");
                        $(".achor").stop().hide();
                        $(".shareBtn").stop().hide();
                        $(".livingBox").stop().show();
                        $(".activity").stop().show();
                        $(".liveTab .liveTabUl").css("width","836px");
                        $(".liveNewBody .chatCenter").css({
                            "top":"-12px",
                            "height":"600px"
                        });
                        $(".liveNewBody .chatCenter .chatTitle").css({
                            "background":"#e7e7e7",
                            "margin-bottom":"0"
                        })
                        $(".liveNewBody .chat").css("height","540px");
                    }else{//未在视频直播
                        isLivingStatus = 0;
                        $(".achor").stop().show();
                        $(".shareBtn").stop().show();
                        $(".livingBox").stop().hide();
                        $(".activity").stop().hide();
                        $(".weChatScrollBottom").css("bottom","32px");
                    }
                }
            }
        })
    }
    function isLivingState2(roomid) {
        $.ajax({
            type: "post",
            async: true,
            dataType: "json",
            url: "/api/v3/live/getLiveRoomInfo.do",
            data: {
                "roomId": roomid
            },
            success: function (res) {
                if (res.code == 0) {
                    // console.log(res);
                    var status = res.data.status;
                    // console.log(status);
                    if(status == 1){//视频直播中
                        // 10秒判断一次是不是在直播中
                        setInterval(function () {
                            $.ajax({
                                type: "post",
                                async: true,
                                dataType: "json",
                                url: "/api/v3/live/getLiveRoomInfo.do",
                                data: {
                                    "roomId": roomid
                                },
                                success: function (res) {
                                    // console.log(res);
                                    if (res.code == 0) {
                                        var status = res.data.status;
                                        if(status == 1){//视频直播中
                                        }else{//非直播中
                                            $("#liveEndWrap").stop().show();
                                            $("#liveEndWrap .liveEndSure").click(function () {
                                                location.reload();
                                            })
                                        }
                                    }
                                }
                            })
                        },5000);
                        isLivingStatus = 1;
                        $(".careWords").html("串流码已生效，正在直播中");
                        $(".living").html("直播中");
                        $(".living").click(function () {//跳转至视频直播页面
                            $(".videoPlay").stop().show();
                            $("html,body").animate({scrollTop:0},200);
                        })
                    }else{//未在视频直播
                        isLivingStatus = 0;
                        $(".careWords").html("串流码已生效，直播未开始");
                        $(".living").stop().hide();
                    }
                }
            }
        })
    }
    //官方活动
    $.ajax({
        type: "get",
        async: true,
        dataType: "json",
        data: {
            "type": 6,
        },
        url: "/api/v2/discovery/getDiscoveryByType.do",
        success: function(res) {
            //console.log(res);
            if(res.code == 0) {
                $(res.data).each(function(m, Q) {
                    if(Q.discoveryObject.bannerType == 5) {
                        var officialImg = "<img src=" + Q.discoveryObject.imgUrl + " id=" + Q.objectId + ">";
                        $(".officialEventWrap").append(officialImg);
                        $(".officialEventWrap img").one("error", function(e) {
                            $(this).attr("src", "images/vedioCoverUrl.jpg")
                        });
                    }
                });
                $(document).on("click", ".officialEventWrap img", function(e) {
                    var id = $(this).attr("id");
                    window.open(id);
                })

            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            console.log(XMLHttpRequest.status);
            console.log(XMLHttpRequest.readyState);
            console.log(textStatus);
        },
    });
    //电脑跳转手机
    function browserRedirect() {
        var sUserAgent = navigator.userAgent.toLowerCase();
        var bIsIpad = sUserAgent.match(/ipad/i) == "ipad";
        var bIsIphoneOs = sUserAgent.match(/iphone os/i) == "iphone os";
        var bIsMidp = sUserAgent.match(/midp/i) == "midp";
        var bIsUc7 = sUserAgent.match(/rv:1.2.3.4/i) == "rv:1.2.3.4";
        var bIsUc = sUserAgent.match(/ucweb/i) == "ucweb";
        var bIsAndroid = sUserAgent.match(/android/i) == "android";
        var bIsCE = sUserAgent.match(/windows ce/i) == "windows ce";
        var bIsWM = sUserAgent.match(/windows mobile/i) == "windows mobile";
        if(bIsIphoneOs || bIsMidp || bIsUc7 || bIsUc || bIsAndroid || bIsCE || bIsWM) {
            window.location.href = "https://www.fntv8.com/m/v5.0/live?uid="+uid+"&roomid="+roomid;
        }
    }
    browserRedirect();

    /*IM*/
    function chatRoom(chatRoomId, userSig, userId, userNickName, userNickHeadurl, roomid) {
        //帐号模式，0-表示独立模式，1-表示托管模式，开发者根据自己的模式，改成相应的值。
        var accountMode = 0;
        var sdkAppID = 1400018939; //开发者改成自己的业务id
        var accountType = 8454; //开发者改成自己的业务帐号类型
        var avChatRoomId = chatRoomId; //直播间的id
        sdkLogin(userSig, userId, userNickName, userNickHeadurl); //登录函数
    }
    function sdkLogin(userSig, userId, userNickName, userNickHeadurl) {
        var isAccessFormalEnv = true; //是否访问正式环境

        if(webim.Tool.getQueryString("isAccessFormalEnv") == "false") {
            isAccessFormalEnv = false; //访问测试环境
        }

        var isLogOn = true; //是否在浏览器控制台打印sdk日志

        //其他对象，选填
        var options = {
            'isAccessFormalEnv': isAccessFormalEnv, //是否访问正式环境，默认访问正式，选填
            'isLogOn': isLogOn //是否开启控制台打印日志,默认开启，选填
        };

        var curPlayAudio = null; //当前正在播放的audio对象

        var openEmotionFlag = false; //是否打开过表情

        if(/debug/gi.test(location.hash)) {
            document.write('<script src="http://sdklog.isd.com/js/vconsole.min.js"></scr' + 'ipt>');
        }
        //当前用户身份
        var loginInfo = {
            'sdkAppID': 1400018939, //用户所属应用id,必填
            'appIDAt3rd': 1400018939, //用户所属应用id，必填
            'accountType': 8454, //用户所属应用帐号类型，必填
            'identifier': userId, //当前用户ID，需要开发者填写
            'identifierNick': userNickName, //当前用户昵称，选填
            'userSig': userSig, //当前用户身份凭证，需要开发者填写
            'headurl': userNickHeadurl //当前用户默认头像，选填
        };
       

        var onConnNotify = function(resp) {
            switch(resp.ErrorCode) {
                case webim.CONNECTION_STATUS.ON:
                    //webim.Log.warn('连接状态正常...');
                    console.log("连接正常");
                    break;
                case webim.CONNECTION_STATUS.OFF:
                    webim.Log.warn('连接已断开，无法收到新消息，请检查下你的网络是否正常');
                    break;
                default:
                    webim.Log.error('未知连接状态,status=' + resp.ErrorCode);
                    break;
            }
        };


        //监听事件
        var listeners = {
            "onConnNotify": onConnNotify, //选填
            "jsonpCallback": jsonpCallback, //IE9(含)以下浏览器用到的jsonp回调函数,移动端可不填，pc端必填
            //"onBigGroupMsgNotify": onBigGroupMsgNotify, //监听新消息(大群)事件，必填
            "onMsgNotify": onMsgNotify, //监听新消息(私聊(包括普通消息和全员推送消息)，普通群(非直播聊天室)消息)事件，必填
            "onGroupSystemNotifys": onGroupSystemNotifys, //监听（多终端同步）群系统消息事件，必填
            "onGroupInfoChangeNotify": onGroupInfoChangeNotify, //监听群资料变化事件，选填
           "onKickedEventCall" : onKickedEventCall//被其他登录实例踢下线
        };
        //监听（多终端同步）群系统消息方法，方法都定义在demo_group_notice.js文件中
        //注意每个数字代表的含义，比如，
        //1表示监听申请加群消息，2表示监听申请加群被同意消息，3表示监听申请加群被拒绝消息等
        var onGroupSystemNotifys = {
            // "1": onApplyJoinGroupRequestNotify, //申请加群请求（只有管理员会收到）
            // "2": onApplyJoinGroupAcceptNotify, //申请加群被同意（只有申请人能够收到）
            // "3": onApplyJoinGroupRefuseNotify, //申请加群被拒绝（只有申请人能够收到）
            // "4": onKickedGroupNotify, //被管理员踢出群(只有被踢者接收到)
            "5": onDestoryGroupNotify, //群被解散(全员接收)
            // "6": onCreateGroupNotify, //创建群(创建者接收)
            // "7": onInvitedJoinGroupNotify, //邀请加群(被邀请者接收)
            //  "8": onQuitGroupNotify, //主动退群(主动退出者接收)
            // "9": onSetedGroupAdminNotify, //设置管理员(被设置者接收)
            //"10": onCanceledGroupAdminNotify, //取消管理员(被取消者接收)
            "11": onRevokeGroupNotify, //群已被回收(全员接收)
            "255": onCustomGroupNotify //用户自定义通知(默认全员接收)
        };
        //web sdk 登录
        webim.login(loginInfo, listeners, options,
            function(identifierNick) {
                //identifierNick为登录用户昵称(没有设置时，为帐号)，无登录态时为空
                webim.Log.info('webim登录成功');
                applyJoinGroup(chatRoomId); //加入加入聊天室
                getGroupInfo(chatRoomId);//读取群详细资料
                if(MemberNum == undefined){
                    getGroupInfo(chatRoomId);
                }
            },
            function(err) {
                console.log(err);

                console.log("登录失败");
            }
        ); //
    }
    //IE9(含)以下浏览器用到的jsonp回调函数
    function jsonpCallback(rspData) {
        //设置jsonp返回的
        webim.setJsonpLastRspData(rspData);
    }
//监听新消息(私聊(包括普通消息、全员推送消息)，普通群(非直播聊天室)消息)事件
//newMsgList 为新消息数组，结构为[Msg]
    function onMsgNotify(newMsgList) {
    	// console.log(newMsgList);
        var sess, newMsg;
        //获取所有聊天会话
        var sessMap = webim.MsgStore.sessMap();

        for(var j in newMsgList) { //遍历新消息

            newMsg = newMsgList[j];
            //console.warn(newMsg);
            if(newMsg.getSession().id() == selToID) { //为当前聊天对象的消息
                selSess = newMsg.getSession();
                //在聊天窗体中新增一条消息
                //console.warn(newMsg);
                addMsg(newMsg);
            }
        }
        //消息已读上报，以及设置会话自动已读标记
        webim.setAutoRead(selSess, true, true);
    }
    //监听 群资料变化 群提示消息
    function onGroupInfoChangeNotify(groupInfo) {
    	// console.log(groupInfo);
        webim.Log.warn("执行 群资料变化 回调： " + JSON.stringify(groupInfo));
        groupId = groupInfo.GroupId;
        var newFaceUrl = groupInfo.GroupFaceUrl; //新群组图标, 为空，则表示没有变化
        var newName = groupInfo.GroupName; //新群名称, 为空，则表示没有变化
        var newOwner = groupInfo.OwnerAccount; //新的群主id, 为空，则表示没有变化
        var newNotification = groupInfo.GroupNotification; //新的群公告, 为空，则表示没有变化
        var newIntroduction = groupInfo.GroupIntroduction; //新的群简介, 为空，则表示没有变化
        if(newName) {
            //更新群组列表的群名称
            //To do
            webim.Log.warn("群id=" + groupId + "的新名称为：" + newName);
        }
    }
    function onKickedEventCall() {//被其他登录实例踢下线
        // console.log("haaaaaaaaaaa");
        //弹出登录框
        $(".loginAgain").stop().show();
        $(".loginAgain .cacelLogin").click(function () {
            $(".loginAgain").stop().hide();
            // window.location.reload();
        })
        $(".loginAgain .enterLogin").click(function () {
            $(".loginAgain").stop().hide();
            $("#loginAlert").stop().show();
            $("#loginAlert").load("/login");
        })
    }
//监听 解散群 系统消息
    function onDestoryGroupNotify(notify) {
    	// console.log(notify);
        webim.Log.warn("执行 解散群 回调：" + JSON.stringify(notify));
        var reportTypeCh = "[群被解散]";
        var content = "群主" + notify.Operator_Account + "已解散该群";
        showGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId, notify.GroupName, content, notify.MsgTime);
    }
//监听 群被回收 系统消息
    function onRevokeGroupNotify(notify) {
        webim.Log.warn("执行 群被回收 回调：" + JSON.stringify(notify));
        var reportTypeCh = "[群被回收]";
        var content = "该群已被回收";
        showGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId, notify.GroupName, content, notify.MsgTime);
    }
//监听 用户自定义 群系统消息
    function onCustomGroupNotify(notify) {
    	// console.log(notify);
        // console.log("执行 用户自定义系统消息 回调： %s", JSON.stringify(notify));
        var reportTypeCh = "[用户自定义系统消息]";
        var content = "收到了自己自定义的系统消息";
        addGroupSystemMsg(notify.ReportType, reportTypeCh, notify.GroupId,
            notify.GroupName, content, notify.MsgTime);
    }
    //进入大群
    function applyJoinGroup(groupId) {
        var options = {
            'GroupId': groupId,
            "ReqMsgNumber": 10
        };
        webim.applyJoinGroup(
            options,
            function(resp) {
                //JoinedSuccess:加入成功; WaitAdminApproval:等待管理员审批
                // webim.Log.info('进群成功');
                selToID = groupId;
                if(resp.JoinedStatus && resp.JoinedStatus == 'JoinedSuccess') {
                    // webim.Log.info('进群成功');
                    selToID = groupId;
                } else {

                }
            },
            function(err) {
                selToID = groupId;

            }
        );
    }
    function getGroupInfo(groupId) {
        var getGroupOptions = {
            'GroupIdList': [
                groupId
            ],
            'GroupBaseInfoFilter': [
                'Type',
                'Name',
                'Introduction',
                'Notification',
                'FaceUrl',
                'CreateTime',
                'Owner_Account',
                'LastInfoTime',
                'LastMsgTime',
                'NextMsgSeq',
                'MemberNum',
                'MaxMemberNum',
                'ApplyJoinOption'
            ],
            'MemberInfoFilter': [
                'Account',
                'Role',
                'JoinTime',
                'LastSendMsgTime',
                'ShutUpUntil'
            ]
        };
        webim.getGroupInfo(
            getGroupOptions,
            function (resp) {
               // console.log(resp);
                MemberNum = resp.GroupInfo[0].MemberNum;
                if(MemberNum == undefined || MemberNum == ""){
                    applyJoinGroup(groupId);
                    getGroupInfo(groupId);
                }else{
                    $(".liveContentAnchor1B .watchNum").html(MemberNum + "人正在看");
                    $(".videoPlayDetail .videoPlayWatch").html(MemberNum + "人观看");
                }
                // console.log(MemberNum);
            },
            function (err) {
                console.log(err);
            }
        );
    }
    //聊天页面增加一条消息
    function addMsg(msg) {
       // console.log(msg);
        var isSelfSend, fromAccount, fromAccountNick, sessType, subType;
        fromAccount = msg.getFromAccount();
        if(!fromAccount) {
            fromAccount = '';
        }
        fromAccountNick = msg.getFromAccountNick();
        if(!fromAccountNick) {
            fromAccountNick = fromAccount;
        };
        var imTime = msg.getTime();
        isSelfSend = msg.getIsSend(); //消息是否为自己发的-:true：表示是我发出消息,false：表示是发给我的消息
        var sendTime = formatV5Time(new Date(msg.getTime() * 1000)); //2017-09-29
        var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000)); //20:10
        var getTime = sendTime + " " + sendTimeMin;
        // var getTime = unixTimestamp.getMonth() +"-"+ unixTimestamp.getDay()+" "+unixTimestamp.getHours() +":"+ unixTimestamp.getMinutes();
        var communicationInfo;
        var headerIMG = msg.getHeadurl();
        //console.log(headerIMG);
        if(!headerIMG) {
            headerIMG = 'images/anchorHead.png';
        }
        //解析消息
        //获取会话类型，目前只支持群聊
        //webim.SESSION_TYPE.GROUP-群聊，
        //webim.SESSION_TYPE.C2C-私聊，
        sessType = msg.getSession().type();
        //获取消息子类型
        //会话类型为群聊时，子类型为：webim.GROUP_MSG_SUB_TYPE
        //会话类型为私聊时，子类型为：webim.C2C_MSG_SUB_TYPE
        subType = msg.getSubType();
        switch(subType) {
            case webim.GROUP_MSG_SUB_TYPE.COMMON: //群普通消息
                communicationInfo = convertMsgtoHtml(msg);
                break;
            case webim.GROUP_MSG_SUB_TYPE.REDPACKET: //群红包消息
                communicationInner = "[群红包消息]" + convertMsgtoHtml(msg);
                break;
            case webim.GROUP_MSG_SUB_TYPE.LOVEMSG: //群点赞消息
                //业务自己可以增加逻辑，比如展示点赞动画效果
                communicationInner = "[群点赞消息]" + convertMsgtoHtml(msg);
                //展示点赞动画
                //showLoveMsgAnimation();
                break;
            case webim.GROUP_MSG_SUB_TYPE.TIP: //群提示消息
                communicationInner = "[群提示消息]" + convertMsgtoHtml(msg);
                break;
        }
    }
    //解析一条消息
    function convertMsgtoHtml(msg) {
       console.log(msg);
        $("#noChatContent").stop().hide();
        $("#noZhiboContent").stop().hide();
        var html = "",
            elems, elem, type, content, headurl;
        elems = msg.getElems(); //获取消息包含的元素数组
        headurl = msg.headurl;
       
        for(var i in elems) {
            elem = elems[i];
            type = elem.getType(); //获取元素类型
             console.log(type)
            content = elem.getContent(); //获取元素对象
            switch(type) {
                case webim.MSG_ELEMENT_TYPE.TEXT:
                    html += convertTextMsgToHtml(content, msg);
                    break;
                case webim.MSG_ELEMENT_TYPE.FACE:
                    html += convertFaceMsgToHtml(content);
                    break;
                case webim.MSG_ELEMENT_TYPE.IMAGE:
                    html += convertImageMsgToHtml(content);
                    break;
                case webim.MSG_ELEMENT_TYPE.SOUND:
                    html += convertSoundMsgToHtml(content);
                    break;
                case webim.MSG_ELEMENT_TYPE.FILE:
                    html += convertFileMsgToHtml(content);
                    break;
                case webim.MSG_ELEMENT_TYPE.LOCATION: //暂不支持地理位置
                    //html += convertLocationMsgToHtml(content);
                    break;
                case webim.MSG_ELEMENT_TYPE.CUSTOM: //自定义消息
                    html += convertCustomMsgToHtml(content, msg);
                    break;
                case webim.MSG_ELEMENT_TYPE.GROUP_TIP:
                    // html += convertGroupTipMsgToHtml(content);
                    break;
                default:
                    webim.Log.error('未知消息元素类型: elemType=' + type);
                    break;
            }
        }
        return html;
    }
//解析文本消息元素(普通消息)
    function convertTextMsgToHtml(content, msg) {
        // console.log(content);
        console.log(msg);
        var isSelfSend, fromAccount, fromAccountNick, sessType, subType;
        fromAccount = msg.getFromAccount();
        if(!fromAccount) {
            fromAccount = '';
        }
        fromAccountNick = msg.getFromAccountNick();
        if(!fromAccountNick) {
            fromAccountNick = fromAccount;
        };
        var imTime = msg.getTime();
        isSelfSend = msg.getIsSend(); //消息是否为自己发的-:true：表示是我发出消息,false：表示是发给我的消息
        var sendTime = formatV5Time(new Date(msg.getTime() * 1000)); //2017-09-29
        var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000)); //20:10
        var getTime = sendTime + " " + sendTimeMin;
        var uniqueId = msg.uniqueId;
        // console.log(uniqueId);
        var communicationInfo;
        var headerIMG = userNickHeadurl;
        var userNickName2 = msg.fromAccountNick;
        var headerIMG1 = msg.headurl;
        if(headerIMG1 == "" || headerIMG1 ==undefined){
            headerIMG = "https://picture.fengniutv.com/anchorHead.png";
        }else{
            headerIMG = msg.headurl;
        }
        var userNickName1 = userNickName;
        // console.log(headerIMG);
        console.log(headerIMG1);
        console.log(userNickName2)
        var answerNick = "回复"+ fromAccountNick +"...";
        var communicationInfo = content.getText();
        console.log(communicationInfo);
        if(communicationInfo.indexOf("igstn") != -1) {//主播带有回复
            var anchorAnwserBrforeIm = communicationInfo.split("igstn")[0];
            var anchorAnwserAfterIm = communicationInfo.split("igstn")[1];
            var chatListInner = "<li><img class='chatImg' src='"+headerIMG1+"' alt='' />"+
                "<p class='chatName'>"+userNickName2+"</p>"+
                "<p class='bozhu'>播主</p>"+
                "<p class='chatTime'>"+sendTimeMin+"</p>"+
                "<p class='answerContent'>"+anchorAnwserBrforeIm+"</p>"+
                "<span class='chatContent'>"+anchorAnwserAfterIm+"</span><br />"+
                "</li>";
            $(".chatDetail").prepend(chatListInner);
        } else {//用户评论
            console.log(fromAccount);//123475
            console.log("uid="+uid);//123481
            var chatListInner = "<li><img class='chatImg' src='"+headerIMG1+"' alt='' />"+
                "<p class='chatName'>"+userNickName2+"</p>"+
                "<p class='chatTime'>"+sendTimeMin+"</p>"+
                "<br /><span class='chatContent'>"+communicationInfo+"</span><br />"+
                "</li>";
            $(".chatDetail").prepend(chatListInner);
        }
    }
//解析表情消息元素
    function convertFaceMsgToHtml(content) {
        var index = content.getIndex();
        var data = content.getData();
        var url = null;
        var emotion = webim.Emotions[index];
        if(emotion && emotion[1]) {
            url = emotion[1];
        }
        if(url) {
            return "<img src='" + url + "'/>";
        } else {
            return data;
        }
    }
//解析图片消息元素
    function convertImageMsgToHtml(content) {
        var smallImage = content.getImage(webim.IMAGE_TYPE.SMALL); //小图
        var bigImage = content.getImage(webim.IMAGE_TYPE.LARGE); //大图
        var oriImage = content.getImage(webim.IMAGE_TYPE.ORIGIN); //原图
        if(!bigImage) {
            bigImage = smallImage;
        }
        if(!oriImage) {
            oriImage = smallImage;
        }
        return "<img src='" + smallImage.getUrl() + "#" + bigImage.getUrl() + "#" + oriImage.getUrl() + "' style='CURSOR: hand' id='" + content.getImageId() + "' bigImgUrl='" + bigImage.getUrl() + "' onclick='imageClick(this)' />";
    }
//解析语音消息元素
    function convertSoundMsgToHtml(content) {
        var second = content.getSecond(); //获取语音时长
        var downUrl = content.getDownUrl();
        if(webim.BROWSER_INFO.type == 'ie' && parseInt(webim.BROWSER_INFO.ver) <= 8) {
            return '[这是一条语音消息]demo暂不支持ie8(含)以下浏览器播放语音,语音URL:' + downUrl;
        }
        return '<audio src="' + downUrl + '" controls="controls" onplay="onChangePlayAudio(this)" preload="none"></audio>';
    }
//解析文件消息元素
    function convertFileMsgToHtml(content) {
        var fileSize = Math.round(content.getSize() / 1024);
        return '<a href="' + content.getDownUrl() + '" title="点击下载文件" ><i class="glyphicon glyphicon-file">&nbsp;' + content.getName() + '(' + fileSize + 'KB)</i></a>';
    }
//解析位置消息元素
    function convertLocationMsgToHtml(content) {
        return '经度=' + content.getLongitude() + ',纬度=' + content.getLatitude() + ',描述=' + content.getDesc();
    }
//解析自定义消息元素
    function convertCustomMsgToHtml(content,msg) {
	console.log(content);
	// console.log(msg);
        var sendTime = formatV5Time(new Date(msg.getTime() * 1000)); //2017-09-29
        var sendTimeMin = formatV5TimeMin(new Date(msg.getTime() * 1000)); //20:10
        var getTime = sendTime + " " + sendTimeMin;
        var headerIMG = msg.getHeadurl();
        var fromAccountNick = msg.fromAccountNick;
        if(!headerIMG) {
            headerIMG = 'images/anchorHead.png';
        }
        var desc = content.getDesc();
        if(desc == "LIVE_CLOSE") { //组名"LIVE_CLOSE",直播结束
            // console.log("直播结束");
            $("#liveEndWrap").stop().show();
            var liveTopic = $(".liveTitle").html();
            // console.log(liveTopic);
            $(".alertTopic").html('主题' + liveTopic);
        }
        // var fromAccountNick = msg.fromAccountNick;
        // var fromAccountNick = userNickName;
        //解析图文消息
        if(desc == "pic_live") {
            var uniqueId = msg.uniqueId;
            var contentImgInfo = JSON.parse(content.data);
            console.log(contentImgInfo);
            var content1 = contentImgInfo.content;
            var media = contentImgInfo.media;
            var contentImgType = contentImgInfo.type;//判断消息类型（0 短评 1回放 2 回复 3链接）
            if (contentImgType == 0) {//短评
                if (media == "") {//无图
                    var shortDetailInner = "<li>" +
                        "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                        "<span class='timeDetail'>" + sendTime + "</span></p>" +
                        "<span class='publishTime'>" + sendTimeMin + "</span>" +
                        "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                        "<p class='wenziContent'>" + content1 + "</p>" +
                        "</li>";
                    $("#tuwenContent").prepend(shortDetailInner);
                } else {//有图
                    var shortViewImg = (media.split(','));
                    var len = shortViewImg.length - 1;
                    if (len == 1) {//1图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    } else if (len == 2) {//2图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    } else if (len == 3) {//三图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    } else if (len == 4) {//4图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    } else if (len == 5) {//5图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    } else if (len == 6) {//6图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    } else if (len == 7) {//7图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    } else if (len == 8) {//8图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[7] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[7] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    } else if (len == 9) {//9图
                        var shortDetailInner = "<li>" +
                            "<p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                            "<span class='timeDetail'>" + sendTime + "</span></p>" +
                            "<span class='publishTime'>" + sendTimeMin + "</span>" +
                            "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='0'>删除</span>" +
                            "<p class='wenziContent'>" + content1 + "</p>" +
                            "<ul class='shortImg'>" +
                            "<li><a href='" + shortViewImg[0] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[0] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[1] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[1] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[2] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[2] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[3] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[3] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[4] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[4] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[5] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[5] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[6] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[6] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[7] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[7] + "' alt='' /></a></li>" +
                            "<li><a href='" + shortViewImg[8] + "' data-lightbox=" + uniqueId + "><img src='" + shortViewImg[8] + "' alt='' /></a></li>" +
                            "</ul></li>";
                        $("#tuwenContent").prepend(shortDetailInner);
                    }
                }
            } else if (contentImgType == 1) {//回放
                var playbackId = contentImgInfo.id;
                var playBackInner = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                    "<span class='timeDetail'>" + sendTime + "</span></p>" +
                    "<span class='publishTime'>" + sendTimeMin + "</span>" +
                    "<span class='deleteWenzi' kid=" + uniqueId + " playbackId=" + playbackId + " kindofId='1'>删除</span>" +
                    "<p class='editWenzi' kid=" + playbackId + "  >编辑</p>" +
                    "<p class='wenziContent'>" + content1 + "</p>" +
                    "<div  kid=" + playbackId + " class='videoBox'>" +
                    "<img class='videoBg' src='" + media + "' alt='' />" +
                    "<p class='videoType'>回看</p>" +
                    // "<p class='watchNum'>100人观看</p>"+
                    "<img class='playBtn' src='images/indexvideo.png' alt='' /></div></li>";
                $("#tuwenContent").prepend(playBackInner);
                $(".videoBg").one("error", function (e) {
                    $(this).attr("src", "../images/vedioCoverUrl.jpg");
                });
                //编辑回放
                $(".editWenzi").click(function () {
                    $(".editPlayback").stop().show();
                    var playbackId = $(this).attr("kid");
                    $(".editPlayback").attr("kid", playbackId);
                })
                $("#cancalEditPlayback").click(function () {
                    $(".editPlayback").stop().hide();
                })
            } else if (contentImgType == 2) {//回复
                var anchorAnwser = contentImgInfo.content;
                var anchorAnwserBrfore = anchorAnwser.split("igstn")[0];
                var anchorAnwserAfter = anchorAnwser.split("igstn")[1];
                var answerInner = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                    "<span class='timeDetail'>" + sendTime + "</span></p>" +
                    "<span class='publishTime'>" + sendTimeMin + "</span>" +
                    "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='2'>删除</span>" +
                    "<p class='wenziContent'>" + anchorAnwserBrfore + "</p>" +
                    "<span class=' answerWenzi'>" + anchorAnwserAfter + "</span></li>";
                $("#tuwenContent").prepend(answerInner);
            } else if (contentImgType == 3) {//链接
                var anchorhref = contentImgInfo.content;
                var anchorhrefBrfore = anchorhref.split("igugl")[0];
                var anchorhrefAfter = anchorhref.split("igugl")[1];
                var linkUrl = "<li><p class='dayTime'><img class='dayTimeImg' src='images/calendar.png' alt='' />" +
                    "<span class='timeDetail'>" + sendTime + "</span></p>" +
                    "<span class='publishTime'>" + sendTimeMin + "</span>" +
                    "<span class='deleteWenzi' kid=" + uniqueId + " kindofId='3'>删除</span>" +
                    "<a href='" + anchorhrefAfter + "'><p class='wenziContent'>" + anchorhrefBrfore + "  <span style='color: #5286BE'>" + anchorhrefAfter + "</span></p></a></li>";
                $("#tuwenContent").prepend(linkUrl);
            }
            if (kindStatus == 1) {//用户视角
                $(".tabcontent .zhiboContent li .deleteWenzi").stop().hide();//无删除图文信息
                $(".tabcontent .zhiboContent li .editWenzi").stop().hide();//无编辑视频回放
            } else if (kindStatus == 0) {//主播视角
                $(".tabcontent .zhiboContent li .deleteWenzi").stop().show();
                $(".tabcontent .zhiboContent li .editWenzi").stop().show();
            }
            //遍历时间，相同的去掉
            var timeTitleLen = $(".timeDetail").length;
            var timeTitle = document.getElementsByClassName("dayTime");
            var timeTitleInnerLast = timeTitle[timeTitleLen - 1].innerHTML;
            for (var q = 0; q < timeTitleLen; q++) {
                var timeTitleInner = timeTitle[q].innerHTML;
                if (timeTitle[q + 1] != undefined && timeTitle[q + 1] != null && timeTitle[q + 1] != "") {
                    var timeTitleInnerNext = timeTitle[q + 1].innerHTML;
                    if (timeTitleInnerNext == timeTitleInner) {
                        timeTitle[q + 1].style.display = "none";
                    }
                }
            }
        }
        /*礼物*/
        if(desc == "givemoney2_zhubo") { //组名为givemoney2_zhubo为打赏
            var data = content.getData(); //打赏的牛币数（1牛币=赞，10牛币=金豆；188牛币=宝箱；999牛币=涨停板；1888牛币=财神爷；8888金币=金牛）
            var ext = content.getExt();
            switch(data) {
                case "1": //赞
                    var giftSendAlert =
                        "<li><img class='presentBg' src='images/changeSlow.png' alt='' />"+
                        "<div class='absoluteBox'>"+
                        "<p class='presentNick'>"+fromAccountNick+"</p>"+
                        "<p class='send'>送出</p>"+
                        "<img class='gift' src='images/zan11.png' alt='' />"+
                        "<img class='cheng' src='images/cheng.png' alt=''/>"+
                        "<img class='giftnumber' src='images/one.png' alt='' />"+
                        "</div></li>";
                    var giftAnimation = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                        "<p class='chatName'>"+fromAccountNick+"</p>"+
                        "<p class='chatTime'>"+sendTimeMin+"</p>"+
                        "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “赞” </span></p>"+
                        "<img class='whatGift' src='images/zan11.png' alt='' /></li>";
                    $(".presentJump").prepend(giftSendAlert);
                    $(".chatDetail").prepend(giftAnimation);
                    $('.chatDetail').scrollTop(0);
                    /*打赏图像5秒消失*/
                    $(".presentJump li").delay(5000).hide(0);
                    break;
                case "10": //金豆
                    var giftSendAlert =
                        "<li><img class='presentBg' src='images/changeSlow.png' alt='' />"+
                        "<div class='absoluteBox'>"+
                        "<p class='presentNick'>"+fromAccountNick+"</p>"+
                        "<p class='send'>送出</p>"+
                        "<img class='gift' src='images/giftjindou.png' alt='' />"+
                        "<img class='cheng' src='images/cheng.png' alt=''/>"+
                        "<img class='giftnumber' src='images/one.png' alt='' />"+
                        "</div></li>";
                    var giftAnimation = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                        "<p class='chatName'>"+fromAccountNick+"</p>"+
                        "<p class='chatTime'>"+sendTimeMin+"</p>"+
                        "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “金豆” </span></p>"+
                        "<img class='whatGift' src='images/giftjindou.png' alt='' /></li>";
                    $(".presentJump").prepend(giftSendAlert);
                    $(".chatDetail").prepend(giftAnimation);
                    $('.chatDetail').scrollTop(0);
                    /*打赏图像5秒消失*/
                    $(".presentJump li").delay(5000).hide(0);
                    break;
                case "188": //宝箱
                    var giftSendAlert =
                        "<li><img class='presentBg' src='images/changeSlow.png' alt='' />"+
                        "<div class='absoluteBox'>"+
                        "<p class='presentNick'>"+fromAccountNick+"</p>"+
                        "<p class='send'>送出</p>"+
                        "<img class='gift' src='images/giftbaoxiang.png' alt='' />"+
                        "<img class='cheng' src='images/cheng.png' alt=''/>"+
                        "<img class='giftnumber' src='images/one.png' alt='' />"+
                        "</div></li>";
                    var giftAnimation = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                        "<p class='chatName'>"+fromAccountNick+"</p>"+
                        "<p class='chatTime'>"+sendTimeMin+"</p>"+
                        "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “宝箱” </span></p>"+
                        "<img class='whatGift' src='images/giftbaoxiang.png' alt='' /></li>";
                    $(".presentJump").prepend(giftSendAlert);
                    $(".chatDetail").prepend(giftAnimation);
                    $('.chatDetail').scrollTop(0);
                    /*打赏图像5秒消失*/
                    $(".presentJump li").delay(5000).hide(0);
                    break;
                case "999": //涨停板
                    var giftSendAlert =
                        "<li><img class='presentBg' src='images/changeSlow.png' alt='' />"+
                        "<div class='absoluteBox'>"+
                        "<p class='presentNick'>"+fromAccountNick+"</p>"+
                        "<p class='send'>送出</p>"+
                        "<img class='gift' src='images/giftzhangtingban.png' alt='' />"+
                        "<img class='cheng' src='images/cheng.png' alt=''/>"+
                        "<img class='giftnumber' src='images/one.png' alt='' />"+
                        "</div></li>";
                    var giftAnimation = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                        "<p class='chatName'>"+fromAccountNick+"</p>"+
                        "<p class='chatTime'>"+sendTimeMin+"</p>"+
                        "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “涨停板” </span></p>"+
                        "<img class='whatGift' src='images/giftzhangtingban.png' alt='' /></li>";
                    $(".presentJump").prepend(giftSendAlert);
                    $(".chatDetail").prepend(giftAnimation);
                    $('.chatDetail').scrollTop(0);
                    /*打赏图像5秒消失*/
                    $(".presentJump li").delay(5000).hide(0);
                    break;
                case "1888": //财神爷
                    var giftSendAlert =
                        "<li><img class='presentBg' src='images/changeSlow.png' alt='' />"+
                        "<div class='absoluteBox'>"+
                        "<p class='presentNick'>"+fromAccountNick+"</p>"+
                        "<p class='send'>送出</p>"+
                        "<img class='gift' src='images/giftcaishenye.png' alt='' />"+
                        "<img class='cheng' src='images/cheng.png' alt=''/>"+
                        "<img class='giftnumber' src='images/one.png' alt='' />"+
                        "</div></li>";
                    var giftAnimation = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                        "<p class='chatName'>"+fromAccountNick+"</p>"+
                        "<p class='chatTime'>"+sendTimeMin+"</p>"+
                        "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “财神爷” </span></p>"+
                        "<img class='whatGift' src='images/giftcaishenye.png' alt='' /></li>";
                    $(".presentJump").prepend(giftSendAlert);
                    $(".chatDetail").prepend(giftAnimation);
                    $('.chatDetail').scrollTop(0);
                    /*打赏图像5秒消失*/
                    $(".presentJump li").delay(5000).hide(0);
                    break;
                case "8888"://金牛
                    var giftSendAlert =
                        "<li><img class='presentBg' src='images/changeSlow.png' alt='' />"+
                        "<div class='absoluteBox'>"+
                        "<p class='presentNick'>"+fromAccountNick+"</p>"+
                        "<p class='send'>送出</p>"+
                        "<img class='gift' src='images/giftjinniu.png' alt='' />"+
                        "<img class='cheng' src='images/cheng.png' alt=''/>"+
                        "<img class='giftnumber' src='images/one.png' alt='' />"+
                        "</div></li>";
                    var giftAnimation = "<li><img class='chatImg' src='"+headerIMG+"' alt='' />"+
                        "<p class='chatName'>"+fromAccountNick+"</p>"+
                        "<p class='chatTime'>"+sendTimeMin+"</p>"+
                        "<p class='giftContent'>赠送了主播一个<span class='chatPresent'> “金牛” </span></p>"+
                        "<img class='whatGift' src='images/giftjinniu.png' alt='' /></li>";
                    $(".presentJump").prepend(giftSendAlert);
                    $(".chatDetail").prepend(giftAnimation);
                    $('.chatDetail').scrollTop(0);
                    /*打赏图像5秒消失*/
                    $(".presentJump li").delay(5000).hide(0);
                    break;
                default:
            }
            $("#mCSB_2_container").css("top","0");
            $("html,body").animate({scrollTop:0},200);
        }
        return giftSendAlert;
    }
//显示一条群组系统消息
    function addGroupSystemMsg(ReportType, reportTypeCh, GroupId, GroupName, content, timestamp) {
        var sysMsgStr = "收到一条群系统消息: type=" + timestamp + ", typeCh=" + reportTypeCh + ",群ID=" + GroupId + ", 群名称=" + GroupName + ", 内容=" + content + ", 时间=" + webim.Tool.formatTimeStamp(msg_time);
        webim.Log.warn(sysMsgStr);
        // console.log(sysMsgStr);
    }
    /*发送消息(普通消息：用户发言以及主播回复)*/
    function onSendMsg(userId, userNickName, userSig, userNickHeadurl, usertoken, roomid,msgtosend) {
        //当前用户身份
        console.log(userNickHeadurl);
        var loginInfo = {
            'sdkAppID': 1400018939, //用户所属应用id,必填
            'appIDAt3rd': 1400018939, //用户所属应用id，必填
            'accountType': 8454, //用户所属应用帐号类型，必填
            'identifier': userId, //当前用户ID，需要开发者填写
            'identifierNick': userNickName, //当前用户昵称，选填
            'userSig': userSig, //当前用户身份凭证，需要开发者填写
            'headurl': userNickHeadurl //当前用户默认头像，选填
        };
        var selSessHeadUrl = ''; //默认群组
        if(!selToID) {
            //layer.msg("你还没有选中好友或者群组，暂不能聊天");
            // console.log("你还没有选中好友或者群组，暂不能聊天");
            $("#sendMsg").val('');
            return;
        }
        var communicationData
        var data = new Date();
        var time = data.getTime() + "";
        /*判断用户类型*/
        if(userId != uid){//用户发送聊天
            var content = {
                "content":msgtosend,
                "itemType":2,
                "media":"",
                "sendName":userNickName,
                "type":"2"
            }
            var content1 = JSON.stringify(content);
        }else{//主播发送回复(现在只发在交流中，怎么发在图文直播中)
            var content = {
                "content":msgtosend,//"哈哈igstn用户亲哦额：2555"
                "itemType":2,
                "media":"",
                "sendName":userNickName,
                "type":"2"
            };
            var content1 = JSON.stringify(content);
        }
        var msgLen = webim.Tool.getStrBytes(msgtosend);
        if(msgtosend.length < 1) {
            // layer.msg("发送的消息不能为空!");
            // console.log("发送的消息不能为空!");
            $("#sendMsg").val('');
            $("#sendMsg").attr("placeholder", "来说两句吧！");
            return;
        }
        var maxLen, errInfo;
        var selType = webim.SESSION_TYPE.GROUP;
        if(selType == webim.SESSION_TYPE.C2C) {
            maxLen = webim.MSG_MAX_LENGTH.C2C;
            errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
        } else {
            maxLen = webim.MSG_MAX_LENGTH.GROUP;
            errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
        }
        if(msgLen > maxLen) {
            // layer.msg(errInfo);
            // console.log(errInfo);
            return;
        }
        if(!selSess) {
            var selSess = new webim.Session(selType, selToID, selToID, selSessHeadUrl, Math.round(new Date().getTime() / 1000));
        }
        var isSend = true; //是否为自己发送
        var seq = -1; //消息序列，-1表示sdk自动生成，用于去重
        var random = Math.round(Math.random() * 4294967296); //消息随机数，用于去重
        var msgTime = Math.round(new Date().getTime() / 1000); //消息时间戳
        var subType; //消息子类型
        if(selType == webim.SESSION_TYPE.C2C) {
            subType = webim.C2C_MSG_SUB_TYPE.COMMON;
        } else {
            //webim.GROUP_MSG_SUB_TYPE.COMMON-普通消息,
            //webim.GROUP_MSG_SUB_TYPE.LOVEMSG-点赞消息，优先级最低
            //webim.GROUP_MSG_SUB_TYPE.TIP-提示消息(不支持发送，用于区分群消息子类型)，
            //webim.GROUP_MSG_SUB_TYPE.REDPACKET-红包消息，优先级最高
            subType = webim.GROUP_MSG_SUB_TYPE.COMMON;
        }
        var msg = new webim.Msg(selSess, isSend, seq, random, msgTime, loginInfo.identifier, subType, loginInfo.identifierNick);

        var text_obj, face_obj, tmsg, emotionIndex, emotion, restMsgIndex;
        //解析文本和表情
        var expr = /\[[^[\]]{1,3}\]/mg;
        var emotions = msgtosend.match(expr);
        if(!emotions || emotions.length < 1) {
            text_obj = new webim.Msg.Elem.Text(msgtosend);
            msg.addText(text_obj);
        } else {
            for(var i = 0; i < emotions.length; i++) {
                tmsg = msgtosend.substring(0, msgtosend.indexOf(emotions[i]));
                if(tmsg) {
                    text_obj = new webim.Msg.Elem.Text(tmsg);
                    msg.addText(text_obj);
                }
                emotionIndex = webim.EmotionDataIndexs[emotions[i]];
                emotion = webim.Emotions[emotionIndex];

                if(emotion) {
                    face_obj = new webim.Msg.Elem.Face(emotionIndex, emotions[i]);
                    msg.addFace(face_obj);
                } else {
                    text_obj = new webim.Msg.Elem.Text(emotions[i]);
                    msg.addText(text_obj);
                }
                restMsgIndex = msgtosend.indexOf(emotions[i]) + emotions[i].length;
                msgtosend = msgtosend.substring(restMsgIndex);
            }
            if(msgtosend) {
                text_obj = new webim.Msg.Elem.Text(msgtosend);
                msg.addText(text_obj);
            }
        }
        webim.sendMsg(msg, function(resp) {
            $("#sendMsg").val("");
            $(".apply").stop().hide();
            $(".applyInput").val("");
            // console.log("uid="+uid);
            // console.log("userId="+userId);
            if(uid != userId){//用户聊天保存
                showMsg(userId,userToken,roomid,content1,1,2);
            }else{
                //保存在图文里
                showMsg(uid,userToken,roomid,content1,1,1);
                //保存在聊天里
                showMsg(uid,userToken,roomid,content1,1,2);
            }
            $("html,body").animate({scrollTop:0},200);
            $("#mCSB_2_container").css("top","0");
            $("#noChatContent").stop().hide();
        }, function(err) {
            // layer.msg(err.ErrorInfo);
            // console.log(err.ErrorInfo);
        });
    }
//发送自定义消息（主播发言，发送图文、链接）
    function sendCustomMsg(userId, userNickName, userSig, userNickHeadurl, userToken, roomid,msgtosend,publishType,mediaStr,giftBox) {
        //当前用户身份
        var loginInfo = {
            'sdkAppID': 1400018939, //用户所属应用id,必填
            'appIDAt3rd': 1400018939, //用户所属应用id，必填
            'accountType': 8454, //用户所属应用帐号类型，必填
            'identifier': userId, //当前用户ID，需要开发者填写
            'identifierNick': userNickName, //当前用户昵称，选填
            'userSig': userSig, //当前用户身份凭证，需要开发者填写
            'headurl': userNickHeadurl //当前用户默认头像，选填
        };
        if(!selToID) {
            // layer.msg("您还没有好友或群组，暂不能聊天");
            // console.log("您还没有好友或群组，暂不能聊天");
            return;
        }
        if(!giftBox){
            if(publishType == 1){//主播发言（无图消息）
                var sendInfo = {
                    "content":msgtosend,
                    "itemType":0,
                    "media":"",
                    "sendName":userNickName,
                    "type":"0"
                };
            }else if(publishType == 2){//主播发带图短评
                var sendInfo = {
                    "content":msgtosend,
                    "itemType":0,
                    "media":mediaStr,
                    "sendName":userNickName,
                    "type":"0"
                };
            }else if(publishType == 3){//主播发链接
                var sendInfo = {
                    "content":msgtosend,
                    "itemType":3,
                    "media":"",
                    "sendName":userNickName,
                    "type":"3"
                }
            }else if(publishType == 4){//主播发回放

            }
            var data = JSON.stringify(sendInfo);
            var desc = "pic_live";
            var ext = userNickName;
            var msgLen = webim.Tool.getStrBytes(data);

            if(data.length < 1) {
                // layer.msg("发送的消息不能为空!");
                // console.log("发送的消息不能为空!");
                return;
            }
            var maxLen, errInfo;
            var selType = webim.SESSION_TYPE.GROUP;
            if(selType == webim.SESSION_TYPE.C2C) {
                maxLen = webim.MSG_MAX_LENGTH.C2C;
                errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
            } else {
                maxLen = webim.MSG_MAX_LENGTH.GROUP;
                errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
            }
            if(msgLen > maxLen) {
                // layer.msg(errInfo);
                // console.log(errInfo);
                return;
            }
            if(!selSess) {
                selSess = new webim.Session(selType, selToID, selToID, userNickHeadurl, Math.round(new Date().getTime() / 1000));
            }
            var msg = new webim.Msg(selSess, true, -1, -1, -1, loginInfo.identifier, 0, loginInfo.identifierNick);
            var custom_obj = new webim.Msg.Elem.Custom(data, desc, ext);
            msg.addCustom(custom_obj);
            //调用发送消息接口
            webim.sendMsg(msg, function(resp) {
                if(publishType == 1){
                    $("#noImgContent").val("");
                }else if(publishType == 2){
                    $(".shortViewContent").val("");
                    $(".publishImgBox").stop().hide();
                }else if(publishType == 3){
                    $("#linkUrl").val("");
                    $("#linkUrlDescripe").val("");
                    $(".addLinkUrl").stop().hide();
                }
                $("html,body").animate({scrollTop:0},200);
                $("#mCSB_1_container").css("top","0");
                $("#noZhiboContent").stop().hide();
                //保存消息
                showMsg(userId,userToken,roomid,data,1,1);
                if(selType == webim.SESSION_TYPE.C2C) { //私聊时，在聊天窗口手动添加一条发的消息，群聊时，长轮询接口会返回自己发的消息

                }
            }, function(err) {
                // layer.msg(err.ErrorInfo);
            });
        }else{//发送打赏
            var data = $("#giftPrice" +giftBox).html();
            // console.log(data);
            var desc = "givemoney2_zhubo";
            var ext = userNickName;
            var msgLen = webim.Tool.getStrBytes(data);
            if (data.length < 1) {
                //alert("发送的消息不能为空!");
                return;
            }
            var maxLen, errInfo;
            var selType = webim.SESSION_TYPE.GROUP;
            if (selType == webim.SESSION_TYPE.C2C) {
                maxLen = webim.MSG_MAX_LENGTH.C2C;
                errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
            } else {
                maxLen = webim.MSG_MAX_LENGTH.GROUP;
                errInfo = "消息长度超出限制(最多" + Math.round(maxLen / 3) + "汉字)";
            }
            if (msgLen > maxLen) {
                //alert(errInfo);
                return;
            }
            if (!selSess) {
                selSess = new webim.Session(selType, selToID, selToID, userNickHeadurl, Math.round(new Date().getTime() / 1000));
            }
            var msg = new webim.Msg(selSess, true,-1,-1,-1,loginInfo.identifier,0,loginInfo.identifierNick);
            var custom_obj = new webim.Msg.Elem.Custom(data, desc, ext);
            msg.addCustom(custom_obj);
            //调用发送消息接口
            webim.sendMsg(msg, function (resp) {
                // console.log(msg);
            }, function (err) {
                //console.log(err.ErrorInfo);
            });
        }
    };
    // videoPlay();
    // videoPlay1();
    function videoPlay() {
        //视频播放器
        var video = $("#myVideo").get(0);
        //播放进度
        video.ontimeupdate = function(){
            var currTime = this.currentTime,    //当前播放时间
                duration = this.duration,       // 视频总时长
                bufferedEnd=this.buffered.end(0);//缓冲进度
            $(".progress .loaded").css("width",(bufferedEnd / 100) * 834 +"px");
            //百分比
            var pre = currTime / duration;
            //显示进度条
            $(".progress .line").css("width",pre * 834 +"px");
            $(".progress_btn").css("left",pre * 834 +"px");
        };
        //跳跃播放
        $(".progress").click(function (e) {
            video.currentTime=(event.offsetX / this.offsetWidth) * video.duration;
        });
        //播放时间显示
        var i = setInterval(function() {
            if(video.readyState > 0) {
                var hours = parseInt(video.duration / (60*60));
                var minutes = parseInt((video.duration - hours*3600)/60);
                var seconds = parseInt(video.duration - minutes*60 - hours*3600 );
                // console.log(hours);
                // console.log(video.duration);
                if (hours < 10) {
                    hours = "0" + hours;
                }
                if (minutes < 10) {
                    minutes = "0" + minutes;
                }
                if (seconds < 10) {
                    seconds = "0" + seconds;
                }
                $(".videoTime .totalTime").html(hours + ":" + minutes + ":" + seconds);

                clearInterval(i);
                $("#myVideo").on(
                    "timeupdate",
                    function (event) {
                        onTrackedVideoFrame(this.currentTime);
                    });
                function onTrackedVideoFrame(currentTime){
                    /*var minutes = parseInt(currentTime / 60, 10);
                     var hours = parseInt(minutes / 60);
                     var seconds = parseInt(currentTime % 60);*/
                    var hours = parseInt(currentTime / (60*60));
                    var minutes = parseInt((currentTime - hours*3600)/60);
                    var seconds = parseInt(currentTime - minutes*60 - hours*3600 );
                    if (hours < 10) {
                        hours = "0" + hours;
                    }
                    if (minutes < 10) {
                        minutes = "0" + minutes;
                    }
                    if (seconds < 10) {
                        seconds = "0" + seconds;
                    }
                    $(".videoTime .playTime").html(hours + ":" + minutes + ":" + seconds);
                }
            }
        }, 200);

        video.paused = true;
        $(".playicon").hover(function() {
            $(this).attr("src", "images/playicon-P.png")
        }, function() {
            $(this).attr("src", "images/playicon.png")
        });
        $(".playicon").on("click", function() {
            if(video.paused) {
                video.play();
                $(".playicon").attr("src", "images/playicon-p.png")
            } else {
                video.pause();
                $(".playicon").css("display", "none");
                $(".stopicon-P").css("display", "block");
            }
            return false
        });
        $(".stopicon-P").hover(function() {
            $(this).attr("src", "images/stopicon-p.png")
        }, function() {
            $(this).attr("src", "images/stopicon.png")
        });
        $(".stopicon-P").on("click", function() {
            if(video.paused) {
                video.play();
                $(".playicon").css("display", "block");
                $(".stopicon-P").css("display", "none")
            } else {
                video.pause()
            }
            return false
        });
        $(".refreshicon").click(function() {
            video.load();
        });
        $(".refreshicon").hover(function() {
            $(this).attr("src", "images/refreshicon-P.png")
        }, function() {
            $(this).attr("src", "images/refreshicon.png")
        });
        $(".volumeicon").click(function() {
            video.volume = 0;
            $("#range").val(0);
            $(".volumeicon").css("display", "none");
            $(".volumeicon1").css("display", "block");
            $(".range_before").width(0);
            $(".range_center").css({
                "left": "-5px"
            })
            return false
        });
        $(".volumeicon1").click(function() {
            video.volume = 0.5;
            $("#range").val(50);
            $(".volumeicon1").css("display", "none");
            $(".volumeicon").css("display", "block");
            $(".range_before").width(50);
            $(".range_center").css({
                "left": "45px"
            })
            return false
        });
        //声音播放器
        $("#soundBox").mousedown(function(e) {
            var oX = e.pageX - $("#soundBox").offset().left - $(".range_center").width() / 2;
            //判断，不让.drag出.left
            if(oX < 0) {
                oX = 0;
            } else if(oX > $("#soundBox").width() - $(".range_center").width()) {
                oX = $("#soundBox").width() - $(".range_center").width();
            }
            video.volume = oX / 100;
            $(".range_center").css({
                "left": oX + "px",
            });
            $(".range_before").css({
                "width": oX + 10 + "px",
            })

        })
        $(document).bind("mouseup", function() {
            $(this).unbind("mousemove");
        });
        //拖动中间部分改变声音大小

        $("#full_screenicon").hover(function() {
            $(this).attr("src", "images/full-screenicon-P.png")
        }, function() {
            $(this).attr("src", "images/full-screenicon.png")
        });

        function launchFullscreen(element) {
            if(element.requestFullscreen) {
                element.requestFullscreen()
            } else {
                if(element.mozRequestFullScreen) {
                    element.mozRequestFullScreen()
                } else {
                    if(element.webkitRequestFullscreen) {
                        element.webkitRequestFullscreen()
                    } else {
                        if(element.msRequestFullscreen) {
                            element.msRequestFullscreen()
                        }
                    }
                }
            }
        }
        $("#full_screenicon").on("click", function() {
            launchFullscreen(document.getElementById("myVideo"))
        });
        $("#myVideo").on("timeupdate", function(event) {
            onTrackedVideoFrame(this.currentTime, this.duration)
        });

        function onTrackedVideoFrame(currentTime, duration) {
            $("#current_minute").text(parseInt(currentTime / 60));
            $("#current_second").text(parseInt(currentTime % 60));
            $("#total_minute").text(parseInt(duration / 60));
            $("#total_second").text(parseInt(duration % 60))
        };
    }
    function videoPlay1() {
        //视频播放器
        var video = $("#myVideo1").get(0);
        //播放进度
        video.ontimeupdate = function(){
            var currTime = this.currentTime,    //当前播放时间
                duration = this.duration,       // 视频总时长
                bufferedEnd=this.buffered.end(0);//缓冲进度
            $(".progress .loaded").css("width",(bufferedEnd / 100) * 834 +"px");
            //百分比
            var pre = currTime / duration;
            //显示进度条
            $(".progress .line").css("width",pre * 834 +"px");
            $(".progress_btn").css("left",pre * 834 +"px");
        };
        //跳跃播放
        $(".progress").click(function (e) {
            video.currentTime=(event.offsetX / this.offsetWidth) * video.duration;
        });
        //播放时间显示
        var i = setInterval(function() {
            if(video.readyState > 0) {
                var hours = parseInt(video.duration / (60*60));
                var minutes = parseInt((video.duration - hours*3600)/60);
                var seconds = parseInt(video.duration - minutes*60 - hours*3600 );
                // console.log(hours);
                // console.log(video.duration);
                if (hours < 10) {
                    hours = "0" + hours;
                }
                if (minutes < 10) {
                    minutes = "0" + minutes;
                }
                if (seconds < 10) {
                    seconds = "0" + seconds;
                }
                $(".videoTime .totalTime").html(hours + ":" + minutes + ":" + seconds);

                clearInterval(i);
                $("#myVideo1").on(
                    "timeupdate",
                    function (event) {
                        onTrackedVideoFrame(this.currentTime);
                    });
                function onTrackedVideoFrame(currentTime){
                    var hours = parseInt(currentTime / (60*60));
                    var minutes = parseInt((currentTime - hours*3600)/60);
                    var seconds = parseInt(currentTime - minutes*60 - hours*3600);
                    if (hours < 10) {
                        hours = "0" + hours;
                    }
                    if (minutes < 10) {
                        minutes = "0" + minutes;
                    }
                    if (seconds < 10) {
                        seconds = "0" + seconds;
                    }
                    $(".videoTime .playTime").html(hours + ":" + minutes + ":" + seconds);
                }
            }
        }, 200);

        video.paused = true;
        $(".playicon").hover(function() {
            $(this).attr("src", "images/playicon-P.png")
        }, function() {
            $(this).attr("src", "images/playicon.png")
        });
        $(".playicon").on("click", function() {
            if(video.paused) {
                video.play();
                $(".playicon").attr("src", "images/playicon-p.png")
            } else {
                video.pause();
                $(".playicon").css("display", "none");
                $(".stopicon-P").css("display", "block");
            }
            return false
        });
        $(".stopicon-P").hover(function() {
            $(this).attr("src", "images/stopicon-p.png")
        }, function() {
            $(this).attr("src", "images/stopicon.png")
        });
        $(".stopicon-P").on("click", function() {
            if(video.paused) {
                video.play();
                $(".playicon").css("display", "block");
                $(".stopicon-P").css("display", "none")
            } else {
                video.pause()
            }
            return false
        });
        $(".refreshicon").click(function() {
            video.load();
        });
        $(".refreshicon").hover(function() {
            $(this).attr("src", "images/refreshicon-P.png")
        }, function() {
            $(this).attr("src", "images/refreshicon.png")
        });
        $(".volumeicon").click(function() {
            video.volume = 0;
            $("#range1").val(0);
            $(".volumeicon").css("display", "none");
            $(".volumeicon1").css("display", "block");
            $(".range_before").width(0);
            $(".range_center").css({
                "left": "-5px"
            })
            return false
        });
        $(".volumeicon1").click(function() {
            video.volume = 0.5;
            $("#range1").val(50);
            $(".volumeicon1").css("display", "none");
            $(".volumeicon").css("display", "block");
            $(".range_before").width(50);
            $(".range_center").css({
                "left": "45px"
            })
            return false
        });
        //声音播放器
        $("#soundBox1").mousedown(function(e) {
            var oX = e.pageX - $("#soundBox1").offset().left - $(".range_center").width() / 2;
            //判断，不让.drag出.left
            if(oX < 0) {
                oX = 0;
            } else if(oX > $("#soundBox1").width() - $(".range_center").width()) {
                oX = $("#soundBox1").width() - $(".range_center").width();
            }
            video.volume = oX / 100;
            $(".range_center").css({
                "left": oX + "px",
            });
            $(".range_before").css({
                "width": oX + 10 + "px",
            })

        })
        $(document).bind("mouseup", function() {
            $(this).unbind("mousemove");
        });
        //拖动中间部分改变声音大小

        $("#full_screenicon1").hover(function() {
            $(this).attr("src", "images/full-screenicon-P.png")
        }, function() {
            $(this).attr("src", "images/full-screenicon.png")
        });

        function launchFullscreen(element) {
            if(element.requestFullscreen) {
                element.requestFullscreen()
            } else {
                if(element.mozRequestFullScreen) {
                    element.mozRequestFullScreen()
                } else {
                    if(element.webkitRequestFullscreen) {
                        element.webkitRequestFullscreen()
                    } else {
                        if(element.msRequestFullscreen) {
                            element.msRequestFullscreen()
                        }
                    }
                }
            }
        }
        $("#full_screenicon1").on("click", function() {
            launchFullscreen(document.getElementById("myVideo1"))
        });
        $("#myVideo1").on("timeupdate", function(event) {
            onTrackedVideoFrame(this.currentTime, this.duration)
        });

        function onTrackedVideoFrame(currentTime, duration) {
            $("#current_minute").text(parseInt(currentTime / 60));
            $("#current_second").text(parseInt(currentTime % 60));
            $("#total_minute").text(parseInt(duration / 60));
            $("#total_second").text(parseInt(duration % 60))
        };
    }

    //加密或者不加密获得视频详情后
    function getVideoDetails(res) {
        console.log(res);
        var playUrl = res.data.hlsPlayUrl;
         playUrl = playUrl.replace('http', 'https'); //外网视频https
        if(Hls.isSupported()) {
            var video = document.getElementById('myVideo');
            var hls = new Hls();
            hls.loadSource(playUrl);
            hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED, function() {
                video.play();
            });
        }
    };
    function getVideoDetails1(res) {
        console.log(res);
        var playUrl = res.data.hlsPlayUrl;
         playUrl = playUrl.replace('http', 'https'); //外网视频https
        if(Hls.isSupported()) {
            var video = document.getElementById('myVideo1');
            var hls = new Hls();
            hls.loadSource(playUrl);
            hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED, function() {
                video.play();
            });
        }
    };
})