var servicesModule = angular.module("appServices",[]);
servicesModule.service("apiFun",['$rootScope','$http','$q',function ($rootScope,$http,$q) {
    var serviceFun = {

        //获取用户信息    ------检查是否登录
        getUserInfoFun: function() {
            var config={
                url:'/userInfos',
                method:"get",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        //根据类型获取banner
        selectByTypeFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v1/banner/selectByType.do',
                method:"POST",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        // 获取话题详情
        selectDiscussFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/discuss/selectDiscuss.do',
                method:"POST",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        // 获取话题详情2
        selectDiscussFun2: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/discuss/selectDiscuss2.do',
                method:"POST",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        // web热点推荐
        homePageViewFun: function(index,size) {
            var config={
                url:'/api/v2/homePage/view.do?pageIndex='+index+'&pageSize='+size,
                method:"get",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        //获取话题回答列表，回答评论列表
        getTopicCommentListFun3: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/comment/getTopicCommentList3.do',
                method:"POST",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        //根据回答ID查询话题和回答详情
        selectByCommentIdFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/discuss/selectByCommentId.do',
                method:"POST",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        //点赞/取消点赞评论
        likeCommentFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/comment/likeComment.do',
                method:"POST",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        //点赞/收藏接口
        insertAgreeFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/agree/insertAgree.do',
                method:"POST",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },
        //取消点赞/收藏接口
        deleteAgreeFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/agree/deleteAgree.do',
                method:"POST",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //web获取等我来答
        selectAnswerDiscussFun: function() {
            var config={
                url:'/api/v2/discuss/selectAnswerDiscuss.do',
                method:"post",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //发表评论
        commentInsertFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/comment/insert.do',
                method:"post",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //web分类信息
        kindFun: function(type,size) {
            var config={
                url:'/api/v2/homePage/kind2.do?type='+type+'&size='+size,
                method:"get",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取点赞/收藏数，是否点赞/收藏
        selectAgreeCountFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/agree/selectAgreeCount.do',
                method:"post",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取赛事动态
        selectTraderReportFun: function() {
            var config={
                url:'/api/v1/banner/selectTraderReport.do',
                method:"post",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取操盘手话题
        selectTraderDiscussFun: function() {
            var config={
                url:'/api/v2/discuss/selectTraderDiscuss.do',
                method:"post",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取实盘PK接口
        getPkFun: function(pageSize,pageIndex,uid) {
            var config={
                url:'/api/v1/fo/getPk.do?pageSize='+pageSize+'&pageIndex='+pageIndex+'&uid='+uid,
                method:"get",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取最新成交记录
        getTransferRecordsFun: function(size,index) {
            var config={
                url:'/api/v2/fo/getTransferRecords.do?pageSize='+size+'&pageIndex='+index,
                method:"get",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取收益信息接口
        getProfitInfoByUidFun: function(uid) {
                var config={
                    url:'/api/v1/fo/getProfitInfoByUid.do?uid='+uid,
                    method:"get",
                    headers: {"Content-type":"application/x-www-form-urlencoded"}
                };
                var deferred = $q.defer();
                $http(config).
                success(function(data, status, headers, config) {
                    deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
                }).
                error(function(data, status, headers, config) {
                    console.log(status);
                    deferred.reject(data);   // 声明执行失败，即服务器返回错误
                });
                return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
            },

        //获取收益排名接口
        getProfitRankingFun: function(period,pageSize,pageIndex) {
            var config={
                url:'/api/v1/fo/getProfitRanking.do?period='+period+'&pageSize='+pageSize+'&pageIndex='+pageIndex,
                method:"get",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //根据类型获取发现内容
        getDiscoveryByType2Fun: function(type,pageSize,pageIndex) {
            var config={
                url:'/api/v2/discovery/getDiscoveryByType2.do?type='+type+'&pageSize='+pageSize+'&pageIndex='+pageIndex,
                method:"get",
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取话题列表
        selectAllDiscussFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/discuss/selectAllDiscuss.do',
                method:"post",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取话题回答列表，回答评论列表
        topicCommentList4Fun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/comment/getTopicCommentList4.do',
                method:"post",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //新增话题
        insertDiscussFun: function(param) {
            var fromData = param;
            var config={
                url:'/api/v2/discuss/insertDiscuss.do',
                method:"post",
                data:$.param(fromData),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },

        //获取排行榜接口
        profitRankByTypeFun: function(param) {
            var config={
                url:'/api/v3/fo/getProfitRankByType.do',
                method:"post",
                data:$.param(param),
                headers: {"Content-type":"application/x-www-form-urlencoded"}
            };
            var deferred = $q.defer();
            $http(config).
            success(function(data, status, headers, config) {
                deferred.resolve(data);  // 声明执行成功，即http请求数据成功，可以返回数据了
            }).
            error(function(data, status, headers, config) {
                console.log(status);
                deferred.reject(data);   // 声明执行失败，即服务器返回错误
            });
            return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
        },


};
    return serviceFun;
}]);

servicesModule.directive('onFinishRender', function ($timeout) {
    return {
        restrict: 'A',
        link: function (scope, element, attr) {
            if (scope.$last === true) {
                console.log("1111");
                $timeout(function () {
                    scope.$emit('repeatFinish');
                });
            }
        }
    }
});
servicesModule.filter('cut', function () {
    return function (val, wordwise, max, tail) {
        function removeHTMLTag2(str) {
            // str = str.replace(/<\/?[^>]*>/g,''); //去除HTML tag
            str = str.replace(/[ | ]*\n/g,'\n'); //去除行尾空白
            str = str.replace(/\n[\s| | ]*\r/g,'\n'); //去除多余空行
            str=str.replace(/ /ig,'');//去掉
            return str;
        };
        var value = removeHTMLTag2(val);
        if (!value) return '';
        max = parseInt(max, 10);
        if (!max) return value;
        if (value.length <= max) return value;
        value = value.substr(0, max);
        if (wordwise) {
            var lastspace = value.lastIndexOf(' ');
            if (lastspace != -1) {
                value = value.substr(0, lastspace);
            }
        }
        return value + (tail || '...');
    };
});
servicesModule.filter('dataStr', function () {
    return function (val) {
        var str = val.toString();
        return str.substr(4,2)+'/'+str.substr(6,2);
    };
});
