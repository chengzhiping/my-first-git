$(document).ready(function () {
    var dissertationId = GetQueryString("id");
    var dissertationIndex = 1;
    //加载头部
    $("#header").load("/header");
    //加载底部
    $("#footer").load("/footer");

    // 检查用户是否登录
    $.ajax({
        type: "get",
        url: "/userInfos",
        success: function (res) {
            // console.log(res);
            if (res.code == -2) { //未登录

            } else if (res.code == 0) {//已登录
                //console.log(res);
                userId = res.data.userInfo.uid;
                usertoken = res.data.token;
            }
        }
    })
    //点击滚动到对应模块
    $('.moduleTittle').on('click','li',function(e){
        var target = e.target;
        var id = $(target).data("to");
        $('html,body').animate({scrollTop:$('#'+id).offset().top}, 800);
    });
    
    // 获取专题详情
    $.ajax({
        type: "get",
        async: true,
        dataType: "json",
        url: "/api/v2/subject/getSubjectDetail.do",
        data: {
            "subjectId": dissertationId
        },
        success: function (res) {
            // console.log(res);
            if(res.code == 0){
                $(".topInnerDetail .topTittle").html(res.data.name);
                $(".topInnerDetail .topIntroduce").html(res.data.introduction);
                $(".top .topBgImg").attr("src",res.data.coverUrl);
            }
        }
    })

    //获取专题内容列表
    getDissertionList(dissertationIndex);
    function getDissertionList(dissertationIndex) {
        $.ajax({
            type: "get",
            async: true,
            dataType: "json",
            url: "/api/v3/subject/getSubjectContentList.do",
            data: {
                "subjectId": dissertationId,
                "pageIndex": dissertationIndex,
                "pageSize": 20
            },
            success: function (res) {
                // console.log(res);
                if (res.code == 0) {
                    $(res.data).each(function (i, k){
                        var moduleName = k.moduleName;
                        // console.log(moduleName);
                        var moduleType = k.moduleType;
                        // console.log(moduleType);
                        if(moduleType == 3){//3-标题内容模块，4-资讯内容模块，5-PDF模块，6-问答模块，7-广告图片模块
                            // console.log(i);
                            var datago = "go"+moduleName;
                            var moduleTittleInner = "<li data-to="+datago+">"+moduleName+"</li>";
                            $(".moduleTittle").append(moduleTittleInner);
                            var id = "tittleContent"+i;
                            var tittleContentId = "tittleContent"+i;
                            var tittleContentList = "<div class='tittleContent' id="+datago+">"+
                                "<p class='moduleTittle1'>"+
                                "<img src='images/indexcfx.png' alt='' />"+
                                "<span>"+moduleName+"</span>"+
                                "</p>"+
                                "<ul class='tittleContentInner' id="+id+">"+
                                "</ul></div>";
                            $(".bottom").append(tittleContentList);
                            var moduleLength = k.moduleContent.length;
                            // console.log(moduleLength);
                            for(var j = 0 ;j< moduleLength ; j++){
                                var objectType = k.moduleContent[j].objectType;//0-短评 1-文章 2-视频 3-音频 4-回放 5-直播 6-banner 7-PDF
                                if(objectType == 1) {//文章
                                    var articleInner = "<a href=/article?id="+ k.moduleContent[j].object.id + "><li><p class='contentTittle'>"+
                                        "<img src='images/articleImg.png' alt='' />"+
                                        "<span>"+k.moduleContent[j].object.title+"</span>"+
                                        "</p><p class='contentMsg'>"+
                                        "<img src='images/anchorHeadAnchor.png' alt='' />"+
                                        "<span class='nickName'>"+k.moduleContent[j].object.liverInfo.nickName+"</span>"+
                                        "<span class='publishTime'>"+format(new Date(k.moduleContent[j].object.createTime))+"</span></p></li></a>";
                                    $("#tittleContent"+i).append(articleInner);
                                }else if(objectType == 2){//2-视频
                                    var videoInner = "<a href=/video?id=" + k.moduleContent[j].object.id + "><li><p class='contentTittle'>"+
                                        "<img src='images/videoImg.png' alt='' />"+
                                        "<span>"+k.moduleContent[j].object.topic+"</span>"+
                                        "</p><p class='contentMsg'>"+
                                        "<img src='images/anchorHeadAnchor.png' alt='' />"+
                                        "<span class='nickName'>"+k.moduleContent[j].object.liverInfo.nickName+"</span>"+
                                        "<span class='publishTime'>"+format(new Date(k.moduleContent[j].object.createTime))+"</span>"+
                                        "</p></li></a>";
                                    $("#tittleContent"+i).append(videoInner);
                                }else if(objectType == 3){//3-音频
                                    var audioInner = "<a href=/audio?id=" + k.moduleContent[j].object.id + "><li><p class='contentTittle'>"+
                                        "<img src='images/voiceImg.png' alt='' />"+
                                        "<span>"+k.moduleContent[j].object.topic+"</span>"+
                                        "</p><p class='contentMsg'>"+
                                        "<img src='images/anchorHeadAnchor.png' alt='' />"+
                                        "<span class='nickName'>"+k.moduleContent[j].object.liverInfo.nickName+"</span>"+
                                        "<span class='publishTime'>"+format(new Date(k.moduleContent[j].object.createTime))+"</span>"+
                                        "</p></li></a>";
                                    $("#tittleContent"+i).append(audioInner);
                                }else if(objectType == 4){//4-回放
                                    var playbackInner = "<a href=/liveLookBack?id=" + k.moduleContent[j].object.id + "&roomid=" + k.moduleContent[j].object.roomId + "&uid=" + k.moduleContent[j].object.liverInfo.uid + "><li><p class='contentTittle'>"+
                                        "<img src='images/videoImg.png' alt='' />"+
                                        "<span>"+k.moduleContent[j].object.topic+"</span>"+
                                        "</p><p class='contentMsg'>"+
                                        "<img src='images/anchorHeadAnchor.png' alt='' />"+
                                        "<span class='nickName'>"+k.moduleContent[j].object.liverInfo.nickName+"</span>"+
                                        "<span class='publishTime'>"+format(new Date(k.moduleContent[j].object.createTime))+"</span>"+
                                        "</p></li></a>";
                                    $("#tittleContent"+i).append(playbackInner);
                                }else if(objectType == 5){//5-直播
                                    var liveInner = "<a href=/liveNew?uid=" +  k.moduleContent[j].object.liverInfo.uid + "&roomid=" +  k.moduleContent[j].object.roomId + " ><li><p class='contentTittle'>"+
                                        "<img src='images/liveImg.png' alt='' />"+
                                        "<span>"+k.moduleContent[j].object.topic+"</span>"+
                                        "</p><p class='contentMsg'>"+
                                        "<img src='images/anchorHeadAnchor.png' alt='' />"+
                                        "<span class='nickName'>"+k.moduleContent[j].object.liverInfo.nickName+"</span>"+
                                        "<span class='publishTime'>"+format(new Date(k.moduleContent[j].object.createTime))+"</span>"+
                                        "</p></li></a>";
                                    $("#tittleContent"+i).append(liveInner);
                                }
                            }
                        }else if(moduleType == 4){//4-资讯内容模块
                            // console.log(i);
                            var datago = "go"+moduleName;
                            var moduleTittleInner = "<li data-to="+datago+">"+moduleName+"</li>";
                            $(".moduleTittle").append(moduleTittleInner);
                            var id = "msgInner"+i;
                            var msgInnerList = "<div class='msg' id="+datago+">"+
                                "<p class='moduleTittle1'>"+
                                "<img src='images/indexcfx.png' alt='' />"+
                                "<span>"+moduleName+"</span>"+
                                "</p>"+
                                "<div class='msgInner' id="+id+">"+
                                "</div></div>";
                            $(".bottom").append(msgInnerList);
                            var moduleLength = k.moduleContent.length;
                            // console.log(moduleLength);
                            for(var j = 0 ;j< moduleLength ; j++){
                                var objectType = k.moduleContent[j].objectType;
                                // console.log(objectType);//0-短评 1-文章 2-视频 3-音频 4-回放 5-直播 6-banner 7-PDF
                                if(objectType == 1){//文章
                                    var coverUrl = k.moduleContent[j].object.coverUrl;
                                    if(coverUrl == "" || coverUrl == undefined){//无封面文章
                                        var content = htmlEncode(k.moduleContent[j].object.content);
                                        var imgReg = /<img.*?(?:>|\/>)/gi;
                                        //匹配src属性
                                        var srcReg = /src=[\'\"]?([^\'\"]*)[\'\"]?/i;
                                        var imgArr = content.match(imgReg);
                                        if(imgArr == null){//无图文章
                                            var ImgArticleWrap = "<a href=/article?id="+ k.moduleContent[j].object.id + ">" +
                                                "<div class='ImgArticleWrap'>" +
                                                "<p class='ImgArticleImgTitle'>" + k.moduleContent[j].object.title + "</p>" +
                                                "<p class='ImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
                                                "<p>" +
                                                "<img class='ImgArticleImgAnchorHead fl' src="+ k.moduleContent[j].object.liverInfo.headImgUrl + ">" +
                                                "<span class='ImgArticleImgAnchorNickName fl'>"  + k.moduleContent[j].object.liverInfo.nickName + "</span>" +
                                                "<span class='mgArticleImgTime fl'>" + format(new Date(k.moduleContent[j].object.createTime)) + "</span>" +
                                                "</p></div></a>";
                                            $("#msgInner"+i).append(ImgArticleWrap);
                                            //文章无图，显示内容一行半
                                            $(".ImgArticleImgInner").each(function() {
                                                var shortReviewText = $(this).text().substring(0, 80) + "...";
                                                if($(this).text().length > 80) {
                                                    $(this).text(shortReviewText);
                                                }
                                            });
                                            $(".ImgArticleImgAnchorHead").one("error", function(e) {
                                                $(this).attr("src", "images/anchorHead.png");
                                            });
                                        }else{//有图无封面文章
                                            var src = imgArr[0].match(srcReg);
                                            if(src[1]){
                                                var content = htmlEncode( k.moduleContent[j].object.content);
                                                var oneImgArticleWrap = "<a href=/article?id=" + k.moduleContent[j].object.id + ">" +
                                                    "<div class='oneImgArticleWrap' id=" + k.moduleContent[j].object.id + ">" +
                                                    "<div class='oneImgArticleL fl'>" +
                                                    "<img class='fl oneImgArticleImg' src=" + src[1] +  ">" +
                                                    "</div>" +
                                                    "<div class='oneImgArticleImgR'>" +
                                                    "<p class='oneImgArticleImgTitle'>" + k.moduleContent[j].object.title + "</p>" +
                                                    "<p class='oneImgArticleImgInner'>" + removeHTMLTag(content) + "</p>" +
                                                    "<p>" +
                                                    "<img class='oneImgArticleImgAnchorHead fl' src=" + k.moduleContent[j].object.liverInfo.headImgUrl + ">" +
                                                    "<span class='oneImgArticleImgAnchorNickName fl'>" + k.moduleContent[j].object.liverInfo.nickName + "</span>"
                                                "<span class='oneImgArticleImgTime fl'>" + format(new Date(k.moduleContent[j].object.createTime)) + "</span>" +
                                                "</p></div></div></a>";
                                                $("#msgInner"+i).append(oneImgArticleWrap);
                                                //文章无图，显示内容一行半
                                                $(".oneImgArticleImgInner").each(function() {
                                                    var shortReviewText = $(this).text().substring(0, 60) + "...";
                                                    if($(this).text().length > 60) {
                                                        $(this).text(shortReviewText);
                                                    }
                                                });
                                                $(".oneImgArticleImgAnchorHead").one("error", function(e) {
                                                    $(this).attr("src", "images/anchorHead.png");
                                                });
                                            }
                                        }
                                    }else{//带封面图
                                        var oneImgArticleWrap = "<a href=/article?id=" + k.moduleContent[j].object.id + ">" +
                                            "<div class='oneImgArticleWrap' id=" + k.moduleContent[j].object.id + ">" +
                                            "<div class='oneImgArticleL fl'>" +
                                            "<img class='fl oneImgArticleImg' src=" + k.moduleContent[j].object.coverUrl +  ">" +
                                            "</div>" +
                                            "<div class='oneImgArticleImgR'>" +
                                            "<p class='oneImgArticleImgTitle'>" + k.moduleContent[j].object.title + "</p>" +
                                            "<p class='oneImgArticleImgInner'>" + removeHTMLTag(htmlEncode(k.moduleContent[j].object.content)) + "</p>" +
                                            "<p>" +
                                            "<img class='oneImgArticleImgAnchorHead fl' src=" + k.moduleContent[j].object.liverInfo.headImgUrl + ">" +
                                            "<span class='oneImgArticleImgAnchorNickName fl'>" + k.moduleContent[j].object.liverInfo.nickName + "</span>"
                                        "<span class='oneImgArticleImgTime fl'>" + format(new Date(k.moduleContent[j].object.publishTime)) + "</span>" +
                                        "</p></div></div></a>";
                                        $("#msgInner"+i).append(oneImgArticleWrap);
                                        //文章无图，显示内容一行半
                                        $(".oneImgArticleImgInner").each(function() {
                                            var shortReviewText = $(this).text().substring(0, 60) + "...";
                                            if($(this).text().length > 60) {
                                                $(this).text(shortReviewText);
                                            }
                                        });
                                        $(".oneImgArticleImgAnchorHead").one("error", function(e) {
                                            $(this).attr("src", "images/anchorHead.png");
                                        });
                                    }
                                }else if(objectType == 2){//视频
                                    var videoWrap = "<a href=/video?id=" + k.moduleContent[j].object.id + ">" +
                                        "<div class='videoWrap' videoId=" + k.moduleContent[j].object.id + ">" +
                                        "<div class='liveL fl'>" +
                                        "<img class='liveCover' src=" + k.moduleContent[j].object.coverUrl + '!220X164' + ">" +
                                        "<img class='videoSystem' src='images/indexvideo.png' />" +
                                        "<span class='videoTime'>" + durationFun(k.moduleContent[j].object.duration) + "</span>" +
                                        "</div>" +
                                        "<div class='videoR fl'>" +
                                        "<div class='videoRPosition'>" +
                                        "<p class='videoTitle'>" + k.moduleContent[j].object.topic + "</p>" +
                                        "<p class='videoRBottom'>" +
                                        "<img class='videoImgAnchorHead fl' src=" + k.moduleContent[j].object.liverInfo.headImgUrl + ">" +
                                        "<span class='videoImgAnchorNickName fl'>" + k.moduleContent[j].object.liverInfo.nickName + "</span>" +
                                        "<span class='videoImgTime fl'>" + format(new Date(k.moduleContent[j].object.createTime)) + "</span>" +
                                        "</p></div></div></div></a>";
                                    $("#msgInner"+i).append(videoWrap);
                                }else if(objectType == 3){//音频
                                    var indexAudioBox= "<a href=/audio?id=" + k.moduleContent[j].object.id + "><div class='ImgArticleWrap'>"+
                                        "<p class='ImgArticleImgTitle'>"+k.moduleContent[j].object.topic+"</p>"+
                                        "<div class='indexAudioBox'>"+
                                        "<div class='indexAudioBoxL fl'>"+
                                        "<img src="+ k.moduleContent[j].object.liverInfo.headImgUrl +">"+
                                        "<img src='../images/indexvideo.png'/>"+
                                        "</div>"+
                                        "<p class='fl'>"+k.moduleContent[j].object.topic+"</p>"+
                                        "<p class='fl audioTime'>" + durationFun(k.moduleContent[j].object.duration) + "</p>"+
                                        '</div>'+
                                        "<p>"+
                                        "<img class='ImgArticleImgAnchorHead fl' src=" + k.moduleContent[j].object.liverInfo.headImgUrl + ">"+
                                        "<span class='ImgArticleImgAnchorNickName fl'>" + k.moduleContent[j].object.liverInfo.nickName + "</span>"+
                                        "<span class='mgArticleImgTime fl'>" + format(new Date(k.moduleContent[j].object.createTime)) + "</span>"+
                                        "</p>"+
                                        "</div></a>";
                                    $("#msgInner"+i).append(indexAudioBox);
                                }else if(objectType == 4){//回放
                                    var liveLookWrap = "<a href=/liveLookBack?id=" + k.moduleContent[j].object.id + "&roomid=" + k.moduleContent[j].object.roomId + "&uid=" + k.moduleContent[j].object.liverInfo.uid + ">" +
                                        "<div class='liveLookWrap' id=" + k.moduleContent[j].object.id + ">" +
                                        "<div class='liveL fl'>" +
                                        "<img class='liveCover' src=" + k.moduleContent[j].object.coverUrl + '!220X164' + ">" +
                                        "<img class='liveLookSystem' src='images/indexplay.png' />" +
                                        "<img class='videoSystem' src='images/indexvideo.png' />" +
                                        "</div>" +
                                        "<div class='videoR fl'>" +
                                        "<div class='videoRPosition'>" +
                                        "<p class='videoTitle'>" + k.moduleContent[j].object.topic + "</p>" +
                                        "<p class='videoRBottom'>" +
                                        "<img class='videoImgAnchorHead fl' src=" + k.moduleContent[j].object.liverInfo.headImgUrl + ">" +
                                        "<span class='videoImgAnchorNickName fl'>" + k.moduleContent[j].object.liverInfo.nickName + "</span>" +
                                        "<span class='videoImgTime fl'>" + format(new Date(k.moduleContent[j].object.createTime)) + "</span>" +
                                        "</p></div></div></div></a>";
                                    $("#msgInner"+i).append(liveLookWrap);
                                    $(".liveCover").one("error", function(e) {
                                        $(this).attr("src", "images/vedioCoverUrl.jpg")
                                    });
                                }else if(objectType == 5){//直播
                                    var liveWrap = "<a href=/liveNew?uid=" +  k.moduleContent[j].object.liverInfo.uid + "&roomid=" +  k.moduleContent[j].object.roomId + " >" +
                                        "<div class='liveWrap' uid=" +  k.moduleContent[j].object.liverInfo.uid + ">" +
                                        "<div class='liveL fl'>" +
                                        "<img class='liveCover' src=" +  k.moduleContent[j].object.coverUrl + '!220X164' + ">" +
                                        "<img class='liveSystem' src='images/indexlive.png' />" +
                                        "</div>" +
                                        "<div class='videoR fl'>" +
                                        "<div class='videoRPosition'>" +
                                        "<p class='videoTitle'>" +  k.moduleContent[j].object.topic + "</p>" +
                                        "<p class='videoRBottom'>" +
                                        "<img class='videoImgAnchorHead fl' src=" +  k.moduleContent[j].object.liverInfo.headImgUrl + ">" +
                                        "<span class='videoImgAnchorNickName fl'>" +  k.moduleContent[j].object.liverInfo.nickName + "</span>" +
                                        "<span class='videoImgTime fl'>" + format(new Date( k.moduleContent[j].object.createTime)) + "</span>" +
                                        "</p></div></div></div></a>";
                                    $("#msgInner"+i).append(liveWrap);
                                    $(".liveCover").one("error", function(e) {
                                        $(this).attr("src", "images/vedioCoverUrl.jpg")
                                    });
                                }
                            }
                        }else if(moduleType == 5){//5-PDF模块
                            var datago = "go"+moduleName;
                            var moduleTittleInner = "<li data-to="+datago+">"+moduleName+"</li>";
                            $(".moduleTittle").append(moduleTittleInner);
                            var PDFList = "<div class='PDF' id="+datago+">"+
                                "<p class='moduleTittle1'>"+
                                "<img src='images/indexcfx.png' alt='' />"+
                                "<span>"+moduleName+"</span>"+
                                "</p>"+
                                "<ul class='PDFInner'>"+
                                "</ul></div>";
                            $(".bottom").append(PDFList);
                            var pdfLength = k.moduleContent.length;
                            for(var j = 0 ; j < pdfLength ; j++){
                                var PDFInnerList = "<li kid="+k.moduleContent[j].object.id+"><p class='contentTittle'>"+
                                    "<img src='images/PDFImg.png' alt='' />"+
                                    "<span>"+k.moduleContent[j].object.topic+"</span>"+
                                    "</p></li>";
                                $(".PDFInner").append(PDFInnerList);
                            }
                            $(".PDFInner li").click(function () {
                                var downLoadId = $(this).attr("kid");
                                console.log(downLoadId);
                                $.ajax({
                                    type: "get",
                                    async: true,
                                    dataType: "json",
                                    data: {
                                        "id": downLoadId
                                    },
                                    url: "/api/v3/document/download/url.do",
                                    success: function (res) {
                                        console.log(res);
                                        if (res.code == 0) {
                                            window.location.href = res.data;
                                        }
                                    }
                                })
                            })
                        }else if(moduleType ==7){//7-广告图片模块
                            var datago = "go"+moduleName;
                            var moduleTittleInner = "<li data-to="+datago+">"+moduleName+"</li>";
                            $(".moduleTittle").append(moduleTittleInner);
                            var adsListInner = "<div class='ads' id="+datago+">"+
                                "<p class='moduleTittle1'>"+
                                "<img src='images/indexcfx.png' alt='' />"+
                                "<span>"+moduleName+"</span>"+
                                "</p>"+
                                "<ul class='adsInner'>"+
                                "</ul>"+
                                "</div>";
                            $(".bottom").append(adsListInner);
                            var adsLength = k.moduleContent.length;
                            for(var j = 0 ; j < adsLength ; j++){
                                var adsInnerList = "<li><p class='adsIntroduce'></p>"+
                                    "<img class='adsImg' src='images/indexphoto1.jpg' alt='' /></li>";
                                $(".adsInner").append(PDFInnerList);
                            }
                        }
                    })
                }
            }
        })
    }
    // 滚动到底部加载更多
    $(window).scroll(function() {
        var totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop());
        if($(document).height() <= totalheight) {
            dissertationIndex++;
            getDissertionList(dissertationIndex);
        }
    });
    /*固定条*/
    var IndexpageIndex =1;
    $(".fixed_nav .reload").click(function() {
        $("body,html").animate({
            scrollTop: 1200
        }, 800)
        IndexpageIndex++;
        insertHot(IndexpageIndex, 10, "top");
        $(".insertTopWrap").stop().show(0).delay(4000).hide(0);
        $("#hotTopLoading").show().delay(1000).hide(0);
        $(".insertTop").delay(1000).slideDown(0).delay(3000).slideUp(0);

    })
    $(window).scroll(function() {
        var t = $(this).scrollTop();
        if(t > 200) {
            $(".goTop").stop().fadeIn()
        } else {
            $(".goTop").stop().fadeOut()
        }
    });
    $(".goTop").click(function() {
        $("body,html").animate({
            scrollTop: 0
        }, 800)
    });
})