var htmlCtrl = require('./htmlCtrl');
module.exports = function(app) {
	app.get('/', htmlCtrl.loginFromWeb, htmlCtrl.index); //首页
 
	app.get('/megagame', htmlCtrl.loginFromWeb, htmlCtrl.megagame); //大赛
	app.get('/test', htmlCtrl.loginFromWeb, htmlCtrl.test); //大赛
 
	app.get('/investment', htmlCtrl.loginFromWeb, htmlCtrl.investment); //投资观点
	app.get('/investmentMore', htmlCtrl.loginFromWeb, htmlCtrl.investmentMore); //投资观点查看更多
 
	app.get('/sideBarRight', htmlCtrl.loginFromWeb, htmlCtrl.sideBarRight); //右侧公共组件
 
};