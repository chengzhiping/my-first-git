var ctrl = require('./apiCtrl');
module.exports = function(app) {
    // 远程图片上传七牛
    app.post('/uploadimgSrc', ctrl.uploadimgSrc);
    app.get('/api/v1/picture/batchUpload/token.do', ctrl.batchUploadtoken);
    app.post('/uploadHtml', ctrl.uploadHtml);
    // QQ
    app.get('/qqOauth', ctrl.qqOauth);
    app.get('/qqUserInfo', ctrl.qqUserInfo);
    // 微博
    app.get('/wbOauth', ctrl.wbOauth);
    app.get('/wbUserInfo', ctrl.wbUserInfo);
	// 微信
	app.get('/wxOauth', ctrl.wxOauth);
	app.get('/wxUserInfo', ctrl.wxUserInfo);

   	app.get('/api/logout', ctrl.logoutFntv);
    app.get('/refreshGraphCode', ctrl.refreshGraphCode); //刷新图形验证码
    app.post('/checkGraphCode', ctrl.checkGraphCode); //校验图形验证码
    app.get('/userInfos', ctrl.userInfos);
    app.post('/api/v1/user/getIsRegister.do', ctrl.getIsRegister); //检测手机号是否注册
    app.post('/api/v1/user/login.do', ctrl.login); //站内注册用户登录接口
	app.get('/api/v1/user/getUserInfo.do', ctrl.getUserInfo); //获取用户详情接口
	app.post('/api/v1/user/selectFans.do', ctrl.selectFans); //获取粉丝接口
	app.post('/api/v1/user/following.do', ctrl.following); //关注用户接口
	app.post('/api/v1/user/getFansCount.do', ctrl.getFansCount); //根据主播ID获取其粉丝数量
	app.post('/api/v1/user/getReceptorCount.do', ctrl.getReceptorCount); //获取关注人数
    app.post('/api/v1/user/register/sendSms.do', ctrl.sendSms);//发送验证码接口，已包含token接口
    app.post('/api/v1/user/register.do', ctrl.register);/*注册*/
    app.post('/api/v2/user/sendSms.do', ctrl.v2sendSms);/*获取验证码接口   （sign前端不用传,已在node处理）*/
    app.post('/api/v2/user/login.do', ctrl.v2login);/*验证码登录接口*/
	// zxx接口
	app.post('/api/v2/comment/getComment1.do', ctrl.getAnswerDetail1); //获取回答详情
	app.post('/api/v2/comment/getComment2.do', ctrl.getAnswerDetail2); //获取回答详情
	app.post('/api/v1/journal/selectByTarget.do', ctrl.getRewardPeople); //查询最近打赏前三名
	app.get('/api/v2/homePage/watch.do', ctrl.allPeopleSee); //大家都在看信息流
	app.get('/api/v2/comment/getCommentList.do', ctrl.getComment); //获取评论列表
	app.post('/api/v1/article/getArticle1.do', ctrl.getArticle1); //获取文章详情
	app.post('/api/v1/article/getArticle2.do', ctrl.getArticle2); //获取文章详情
	app.get('/api/v1/fo/getProfitInfoByUid.do', ctrl.getProfitInfo); //获取收益信息
	app.get('/api/v1/fo/getTransferRecordsByUid.do', ctrl.getTransferRecords); //获取调仓记录
	app.get('/api/v1/fo/getPositionsByUid.do', ctrl.getPositions); //获取持仓数据
	app.post('/api/v2/dynamic/getLiverDynamicListByAuthor.do', ctrl.getLiverDynamicList); //获取最新动态
	app.get('/api/v2/column/getColumnDetail.do', ctrl.getColumnDetail); //获取专栏详情
	app.get('/api/v2/column/getColumnDetail1.do', ctrl.getColumnDetail1); //获取专栏详情(未登录)
	app.get('/api/v2/column/getColumnContent.do', ctrl.getColumnContent); //获取专栏内容
	app.get('/api/v2/column/getColumnList.do', ctrl.getColumnList); //获取全部专栏列表
	app.post('/api/v2/banner/selectDiscussImg.do', ctrl.selectDiscussImg); //获取话题图片
	//话题详情
    app.post('/api/v2/discuss/selectDiscuss.do', ctrl.selectDiscuss); //获取话题详情
    app.post('/api/v2/discuss/selectDiscuss2.do', ctrl.selectDiscuss2); //获取话题详情
    app.post('/api/v2/comment/getTopicCommentList.do', ctrl.getTopicCommentList); //获取话题回答列表，回答评论列表    只带objectId参数
    app.post('/api/v2/comment/getTopicCommentList2.do', ctrl.getTopicCommentList2); //获取话题回答列表，回答评论列表    带objectId,pageSize,pageIndex参数
    app.post('/api/v2/comment/getTopicCommentList3.do', ctrl.getTopicCommentList3); //获取话题回答列表，回答评论列表    带objectId,pageSize,pageIndex,uid参数
    app.post('/api/v2/comment/getTopicCommentList4.do', ctrl.getTopicCommentList4); //获取话题回答列表，回答评论列表    带全部参数
    app.get('/api/v2/homePage/kind2.do', ctrl.homePagekind2); //web分类信息

	//直播间
	app.post('/api/v1/live/joinLive.do', ctrl.joinLive);
	app.post('/api/v1/live/joinLive2.do', ctrl.joinLive2);
	app.get('/api/v1/live/getAnnouncement.do', ctrl.getAnnouncement); //获得公告接口
	app.post('/api/v1/im/createSig.do', ctrl.createSig);
	//专栏列表
	app.get('/api/v2/column/getColumnByUid.do', ctrl.getColumnByUid);
	//直播列表
	app.get('/api/v2/live/getUserLives.do', ctrl.getUserLives);
	//操盘手排行榜
	app.get('/api/v1/fo/getProfitRanking.do', ctrl.getProfitRanking);

    // app.get('/text', ctrl.text1); //测试

	// 接口文档（续）

	// 横幅相关接口
    app.post('/api/v1/banner/selectBanner.do', ctrl.selectBanner); //获取横幅接口
    app.post('/api/v1/banner/joinBanner.do', ctrl.joinBanner); //获取横幅内容
    app.post('/api/v1/banner/selectInvitation.do', ctrl.selectInvitation); //获取邀请活动接口
    app.post('/api/v1/banner/selectByType.do', ctrl.selectByType); //根据类型获取banner
    app.post('/api/v1/banner/selectAdvertisement.do', ctrl.selectAdvertisement); //获取广告位链接

	// 聚合查询接口
    app.get('/api/v1/multiple/getVideosByCategoryId.do', ctrl.getVideosByCategoryId);//根据分类ID获取直播、直播回放、视频列表接口
    app.get('/api/v1/multiple/getVideosByIds.do', ctrl.getVideosByIds);//根据ID数组获取直播、直播回放、视频列表接口
    app.get('/api/v1/multiple/getVideoDetailsById.do', ctrl.getVideoDetailsById); //接口-不加密根据ID获取直播回放、视频详情接口
    app.get('/api/v1/multiple/getVideoDetailsById2.do', ctrl.getVideoDetailsById2); //接口-加密根据ID获取直播回放、视频详情接口(带authCode)
    app.get('/api/v1/multiple/getVideoDetailsById3.do', ctrl.getVideoDetailsById3); //接口-加密根据ID获取直播回放、视频详情接口(带authCode,uid,token)
    app.get('/api/v1/multiple/getVideoDetailsById4.do', ctrl.getVideoDetailsById4); //接口-加密根据ID获取直播回放、视频详情接口(带uid,token)
    app.get('/api/v1/recommend/getRecTags.do', ctrl.getRecTags); //获取推荐标签列表接口
    app.get('/api/v1/recommend/getContentsByTagId.do', ctrl.getContentsByTagId); //根据标签ID获取推荐内容接口
    app.get('/api/v1/multiple/getLiveListByUid.do', ctrl.getLiveListByUid); //根据标签ID获取推荐内容接口
    app.get('/api/v1/multiple/search.do', ctrl.search); //搜索接口

	// 用户相关接口
    app.post('/api/v1/user/logout.do', ctrl.logout); //注销登录接口
    app.post('/api/v1/user/deleteFollow.do', ctrl.deleteFollow); //取消关注用户接口
    app.post('/api/v1/user/selectReceptor.do', ctrl.selectReceptor); //获取关注人接口
    app.get('/api/v1/user/head/upload/token.do', ctrl.token); //上传头像token接口
    app.get('/api/v1/user/getSmsToken.do', ctrl.getSmsToken); //发送短信token接口
    app.post('/api/v1/user/checkFollowing.do', ctrl.checkFollowing); //检查是否已关注接口
    app.post('/api/v1/userAuth/binding.do', ctrl.binding); //绑定第三方账号接口
    app.post('/api/v1/userAuth/selectImgName.do', ctrl.selectImgName); //查询用户第三方头像昵称
    app.post('/api/v1/user/checkNickName.do', ctrl.checkNickName); //查询昵称是否存在
    app.post('/api/v1/user/updateUser.do', ctrl.updateUser); //修改用户基本资料
    app.post('/api/v1/user/bindingMobile.do', ctrl.bindingMobile); //用户绑定手机号
    app.post('/api/v1/user/resetPwd.do', ctrl.resetPwd); //用户重置密码接口
    app.post('/api/v1/anchor/auditAnchor.do', ctrl.auditAnchor); //主播申请接口
    app.post('/api/v1/anchor/selectAuditStatus.do', ctrl.selectAuditStatus); //查询申请主播状态
    app.post('/api/v1/anchor/selectAnchor.do', ctrl.selectAnchor); //查询主播认证信息
    app.post('/api/v1/user/saveInviteCode.do', ctrl.saveInviteCode); //保存邀请码接口
    app.get('/api/v1/user/getInviteCount.do', ctrl.getInviteCount); //获取邀请人数接口
    app.get('/api/v1/user/getInviteMembers.do', ctrl.getInviteMembers); //获取已邀请人员接口
    app.post('/api/v1/task/invite/statistics.do', ctrl.statistics); //获取邀请好友详情

	//直播相关接口
    app.post('/api/v1/live/createLive.do', ctrl.createLive); //创建直播接口
    app.get('/api/v1/live/getPushUrl.do', ctrl.getPushUrl); //获取推流地址接口
    app.post('/api/v1/live/terminateLive.do', ctrl.terminateLive); //终止直播接口
    app.post('/api/v1/live/saveLive.do', ctrl.saveLive); //保存直播回放接口
    app.post('/api/v1/live/saveChatRoomId.do', ctrl.saveChatRoomId); //保存聊天室ID接口
    app.get('/api/v1/live/getChatRoomId.do', ctrl.getChatRoomId); //获取聊天室ID接口
    app.post('-/api/v1/live/quitLive.do', ctrl.quitLive); //退出直播间接口
    app.post('/api/v1/live/saveAnnouncement.do', ctrl.saveAnnouncement); //保存直播间公告接口
    app.post('/api/v2/live/createLive.do', ctrl.createLive2); //创建直播接口
	// 视频相关接口
    app.get('/api/v1/video/upload/token.do', ctrl.videotoken); //上传视频token接口
    app.post('/api/v1/video/publish.do', ctrl.publish); //发布视频接口
    app.post('/api/v1/video/delete.do', ctrl.delete); //删除视频接口
    app.get('/api/v1/recommend/getContentsByCategoryId.do', ctrl.getContentsByCategoryId); //根据分类ID获取精选推荐视频接口

	// 虚拟货币模块接口
    app.post('/api/v1/order/wxUnifiedOrder.do', ctrl.wxUnifiedOrder); //微信统一下单接口
    app.post('/api/v1/order/wxFrontNotify.do', ctrl.wxFrontNotify); //微信订单查询
    app.post('/api/v1/account/award.do', ctrl.award); //用户打赏接口
    app.post('/api/v1/account/updateAdd.do', ctrl.updateAdd); //领取免费牛币接口
    app.post('/api/v1/account/selectCoin.do', ctrl.selectCoin); //用户指定币种查询
    app.post('/api/v1/account/selectByWhere.do', ctrl.selectByWhere); //查询用户账户
    app.post('/api/v1/cash/selectByUid.do', ctrl.selectByUid); //查询主播提现记录
    app.post('/api/v1/cash/insertOrder.do', ctrl.insertOrder); //主播提现申请接口
    app.post('/api/v1/account/getToken.do', ctrl.getToken); //获取打赏认证
    app.post('/api/v1/order/insertIosOrder.do', ctrl.insertIosOrder); //IOS生成订单接口
    app.post('/api/v1/order/verifyReceipt.do', ctrl.verifyReceipt); //IOS支付验证接口

	// 消息推送相关接口
    app.post('/api/v1/push/pushToFollow.do', ctrl.pushToFollow); //开播消息推送接口
    app.post('/api/v2/push/pushToFollow.do', ctrl.pushToFollow2); //开播消息推送接口v2

	// 评论相关接口
    app.post('/api/v1/comment/insert.do', ctrl.insert); //插入评论接口
    app.post('/api/v1/comment/getCommentList.do', ctrl.getCommentList); //获取评论接口
    app.post('/api/v1/comment/deleteComment.do', ctrl.deleteComment); //删除评论接口
    app.post('/api/v1/comment/countComment.do', ctrl.countComment); //查询评论数量接口
    app.post('/api/v2/discuss/selectAnswerDiscuss.do', ctrl.selectAnswerDiscuss); //web获取等我来答

	// 文章相关接口
    app.post('/api/v1/article/saveOrUpdate.do', ctrl.saveOrUpdate); //添加或修改文章接口
    app.post('/api/v2/article/saveOrUpdate.do', ctrl.saveOrUpdate2); //添加或修改文章接口v2
    app.post('/api/v2/article/deleteArticle.do', ctrl.deleteArticle); //删除文章接口
    app.post('/api/v1/article/getArticleByType.do', ctrl.getArticleByType); //获取文章列表接口
    app.post('/api/v1/articleType/getArticleType.do', ctrl.getArticleType); //获取文章类型接口
    app.post('/api/v1/article/getArticleByUid.do', ctrl.getArticleByUid); //获取用户文章接口

	// 通用接口
    app.get('/api/v1/category/getAllCategories.do', ctrl.getAllCategories); //直播、视频所有分类接口
    app.get('/api/v1/category/getRootCategories.do', ctrl.getRootCategories); //直播、视频根级分类接口
    app.get('/api/v1/category/getCategoriesByParentId.do', ctrl.getCategoriesByParentId); //直播、视频子级分类接口
    app.get('/api/v1/picture/upload/token.do', ctrl.imgtoken); //上传图片token接口
    app.post('/api/v1/share/shareByType.do', ctrl.shareByType); //更新分享次数

	// 动态相关接口
    app.post('/api/v1/dynamic/getDynamicListByAuthor.do', ctrl.getDynamicListByAuthor); //获取个人动态接口
    app.post('/api/v1/dynamic/getDynamicCount.do', ctrl.getDynamicCount); //获得个人动态条数
    app.post('/api/v1/dynamic/getTraderList.do', ctrl.getTraderList); //获取操盘手动态接口
    app.get('/api/v1/dynamic/getDynamicByType.do', ctrl.getDynamicByType); //根据类型获得动态
    app.get('/api/v2/dynamic/getDynamicByTypeLiveVideo.do', ctrl.getDynamicByTypeLiveVideo); //根据类型获得动态
    app.post('/api/v1/dynamic/getLivingLiver.do', ctrl.getLivingLiver); //获取正在直播的关注主播
    app.post('/api/v1/comment/getLivingLiverCount.do', ctrl.getLivingLiverCount); //获取正在直播的关注主播数量
    app.get('/api/v1/dynamic/getLiverDynamicListByAuthor.do', ctrl.getLiverDynamicListByAuthor); //游客获取主播动态
    app.get('/api/v1/dynamic/getCountByType.do', ctrl.getCountByType); //根据类型获取动态数量接口
    app.get('/api/v2/dynamic/selectCountByTypeLiveVideo.do', ctrl.selectCountByTypeLiveVideo); //根据类型获取动态数量接口
    app.get('/api/v2/column/getColumnInfoByUid.do', ctrl.getColumnInfoByUid); //获取主播专栏信息
    app.get('/api/v1/dynamic/deleteDynamicByType.do', ctrl.deleteDynamicByType); //删除动态接口

    // 实盘相关接口
    app.post('/api/v1/fo/authorize.do', ctrl.bindingauthorize); //绑定华鑫证券接口
    app.get('/api/v1/fo/getPk.do', ctrl.getPk); //获取实盘PK接口
    app.post('/api/v1//fo/topic/getTopicList.do', ctrl.getTopicList); //获取话题列表接口
    app.post('/api/v1/banner/selectTraderReport.do', ctrl.selectTraderReport); //获取赛事动态
    app.get('/api/v1/fo/checkAuthorization.do', ctrl.checkAuthorization); //检查是否绑定华鑫
    app.get('/api/v1/fo/getRegisterPageInfo.do', ctrl.getRegisterPageInfo); //获取华鑫注册页面信息接口
    app.post('/api/v3/fo/getProfitRankByType.do', ctrl.getProfitRankByType); //获取排行榜接口

    // 其他相关接口
    app.get('/api/v1/client/version/checkUpdate.do', ctrl.checkUpdate); //客户端检测更新接口

    // 行情相关接口
    app.get('/api/v1/quotation/getQuotation.do', ctrl.getQuotation); //获取行情接口
    app.get('/api/v1/quotation/getQuotationRose.do', ctrl.getQuotationRose); //获取涨幅榜接口
    app.get('/api/v1/quotation/getQuotationDrop.do', ctrl.getQuotationDrop); //获取跌幅榜接口
    app.get('/api/v1/quotation/getStockDetail.do', ctrl.getStockDetail); //获取个股详情接口
    app.get('/api/v1/quotation/getIndex.do', ctrl.getIndex1); //获取指数接口

    // 热门动态相关接口
    app.get('/api/v1/dynamicHot/selectDynamicHotPaging.do', ctrl.selectDynamicHotPaging); //获取热门动态接口

    // 主播中心相关接口
    app.post('/api/v1/multiple/edit.do', ctrl.edit); //编辑直播或视频接口

    // 接口文档2
    // 首页相关接口
    app.get('/api/v2/homePage/home.do', ctrl.home); //获取首页信息流
    app.get('/api/v2/homePage/kind.do', ctrl.kind);//web页根据type拉取热点信息
    app.get('/api/v2/homePage/view.do', ctrl.homePageView); //web页根据type拉取热点信息

    // 专栏相关接口
    app.post('/api/v2/column/save.do', ctrl.saveColumn); //新增/修改专栏
    app.post('/api/v2/column/delete.do', ctrl.deleteColumn); //删除专栏
    app.post('/api/v2/column/edit.do', ctrl.editColumn); //编辑专栏内容

    // 评论相关接口
    app.post('/api/v2/comment/likeComment.do', ctrl.likeComment); //点赞/取消点赞评论
    app.post('/api/v2/comment/setTop.do', ctrl.setTop); //置顶/取消置顶评论
    app.post('/api/v2/comment/insert.do', ctrl.insertComment); //发表评论

    // 话题相关接口
    app.post('/api/v2/discuss/selectAllDiscuss.do', ctrl.selectAllDiscuss); //获取话题列表
    app.post('/api/v2/discuss/selectMyDiscuss.do', ctrl.selectMyDiscuss); //获取我的话题列表
    app.post('/api/v2/discuss/insertDiscuss.do', ctrl.insertDiscuss); //新增话题
    app.post('/api/v2/discuss/deleteDiscuss.do', ctrl.deleteDiscuss); //删除话题接口
    app.post('/api/v2/discuss/updateDiscuss.do', ctrl.updateDiscuss); //修改话题接口
    app.post('/api/v2/discuss/appointBest.do', ctrl.appointBest); //指定最佳回答
    app.post('/api/v2/discuss/selectByCommentId.do', ctrl.selectByCommentId); //根据回答ID查询话题和回答详情
    app.post('/api/v2/discuss/selectMyAnswerDiscuss.do', ctrl.selectMyAnswerDiscuss); //获取我的回答
    app.post('/api/v2/discuss/selectTraderDiscuss.do', ctrl.selectTraderDiscuss); //获取操盘手话题

    // 点赞相关接口
    app.post('/api/v2/agree/insertAgree.do', ctrl.insertAgree); //点赞/收藏接口
    app.post('/api/v2/agree/deleteAgree.do', ctrl.deleteAgree); //取消点赞/收藏接口
    app.post('/api/v2/agree/selectAgreeCount.do', ctrl.selectAgreeCount); //获取点赞/收藏数，是否点赞/收藏
    app.post('/api/v2/agree/selectAgreeCount1.do', ctrl.selectAgreeCount1); //获取点赞/收藏数，是否点赞/收藏(未登录)
    app.post('/api/v2/agree/selectAgreeList.do', ctrl.selectAgreeList); //获取我的赞/我的收藏

    // 大V直播相关接口
    app.get('/api/v2/live/getLives.do', ctrl.getLives); //获取直播列表接口
    app.get('/api/v2/live/getRecLiverList.do', ctrl.getRecLiverList); //大V推荐接口

    // 发现相关接口
    app.get('/api/v2/discovery/getDiscovery.do', ctrl.getDiscovery); //获取“发现”内容

    // 财经视频相关接口
    app.post('/api/v2/video/publish.do', ctrl.publishVideo); //发布视频接口
    app.get('/api/v2/video/getRecColumnList.do', ctrl.getRecColumnList); //获取大牌栏目接口
    app.get('/api/v2/video/getVideosByColumnId.do', ctrl.getVideosByColumnId); //获取栏目视频接口
    app.get('/api/v2/video/getRecVideoList.do', ctrl.getRecVideoList); //获取推荐视频接口
    app.get('/api/v2/video/getUserVideos.do', ctrl.getUserVideos); //获取用户视频列表
    app.get('/api/v2/video/getRecVideoCategories.do', ctrl.getRecVideoCategories); //获取推荐视频分类
    app.get('/api/v2/video/getVideosByCategoryId2.do', ctrl.getVideosByCategoryId2); //获取推荐视频分类的内容
    
    // 用户相关接口
    app.post('/api/v2/anchor/auditAnchor.do', ctrl.auditAnchor2); //申请主播接口
    app.post('/api/v2/anchor/selectAnchor.do', ctrl.selectAnchor2); //申请主播接口
    app.post('/api/v2/user/anchorCenterData.do', ctrl.anchorCenterData); //查询主播中心数据
    // app.post('/api/v2/user/login.do', ctrl.loginverify); //验证码登录接口

    // 实盘相关接口
    app.get('/api/v2/fo/getTransferRecordsByUid.do', ctrl.getTransferRecordsByUid); //获取操盘手成交记录
    app.get('/api/v2/fo/getTransferRecordsByUidNum.do', ctrl.getTransferRecordsByUidNum); //获取操盘手总条数
    app.get('/api/v2/fo/getTransferRecords.do', ctrl.getTransferRecords2); //获取最新成交记录
    app.get('/api/v2/fo/getPositionsByUid.do', ctrl.getPositionsByUid); //获取操盘手持仓数据
    app.get('/api/v2/fo/getFirmOfferByUid.do', ctrl.getFirmOfferByUid); //获取简版个人实盘

    //官方活动
    app.get('/api/v2/discovery/getDiscoveryByType.do', ctrl.getDiscoveryByType); //发现里面的官方活动
    app.get('/api/v2/discovery/getDiscoveryByType2.do', ctrl.getDiscoveryByType2); //发现里面的官方活动(带全部参数)

    
    //发布短评的接口
     app.get('/api/v1/picture/batchUpload/shortViewToken.do', ctrl.shortViewToken); //发现里面的官方活动

    // 活动项目接口文档V1
    // 投票活动接口
    app.get('/api/v1/vote/objectsList.do', ctrl.objectsList); //获取投票对象列表
    app.post('/api/v1/vote/go.do', ctrl.govote); //投票接口
    app.post('/api/v1/vote/share.do', ctrl.sharevote); //分享接口

    // 邀请活动相关接口
    app.get('/api/v1/user/getInviteInfo.do', ctrl.getInviteInfo); //获取邀请信息接口

    // 谁与争分活动相关接口
    app.post('/api/v1/apply/go.do', ctrl.applygo); //申请接口
    app.get('/api/v1/apply/getApplyInfo.do', ctrl.getApplyInfo); //获取申请信息接口
    app.get('/api/v2/homePage/kind3.do', ctrl.kind3); //web分类信息（最头条）
    app.get('/api/v2/live/getLiveRoomList.do', ctrl.getLiveRoomList); //获取直播间列表接口
    app.get('/api/v2/column/hotUpdate.do', ctrl.hotUpdate); //获取热门更新专栏
    app.get('/api/v2/column/getNewContent.do', ctrl.getNewContent); //获取热门更新专栏(财经专栏)
    
    //百度主动推送
    app.get('http://data.zz.baidu.com/urls', ctrl.baiduFun); 
    //发布音视频接口
    app.post('/api/v3/video/publish.do', ctrl.publishV3);
    
    /*新版wap*/
    app.get('/api/v3/live/getUserLiveRoomList.do', ctrl.getUserLiveRoomList); //获取用户直播间
    app.post('/api/v3/live/updateRoomInfo.do', ctrl.updateRoomInfo);//更新直播间信息
    app.post('/api/v3/live/createVipRoom.do', ctrl.createVipRoom);//创建VIP直播间
    app.post('/api/v3/live/saveRoomAnnouncement.do', ctrl.saveRoomAnnouncement);//保存直播间公告
    app.get('/api/v3/live/getRoomAnnouncementList.do', ctrl.getRoomAnnouncementList); //获取直播间公告列表
    app.post('/api/v3/live/delRoomAnnouncement.do', ctrl.delRoomAnnouncement);//删除直播间公告接口
    app.post('/api/v3/live/getLiveRoomInfo.do', ctrl.getLiveRoomInfo);//获取直播间基本信息
    app.post('/api/v3/live/getLiveRoomInfo.do1', ctrl.getLiveRoomInfo1);//获取直播间基本信息(带uid,token判断是否已订阅)
    app.post('/api/v3/live/createLive.do', ctrl.createLive3);//开启视频直播(不加密)
    app.post('/api/v3/live/createLive2.do', ctrl.createLive4);//开启视频直播(加密)
    app.get('/api/v2/column/getColumnByObjectId.do', ctrl.getColumnByObjectId); //根据对象ID获取所属专栏详情
    app.get('/api/v3/live/getVideoLiveRoomList.do', ctrl.getVideoLiveRoomList); //视频直播列表
    app.get('/api/v3/liveRoomMsg/getLiveRoomMsgByUid.do', ctrl.getLiveRoomMsgByUid); //获取直播间视频直播地址
	app.post('/api/v3/column/getColumnByUid.do', ctrl.getColumnByUidV3);//获取我的专栏
	app.post('/api/v3/liveRoomMsg/saveMsg.do', ctrl.saveMsg);//记录直播消息接口
	app.post('/api/v2/live/edit1.do', ctrl.editLive1);//编辑直播接口（不加密）
	app.post('/api/v2/live/edit2.do', ctrl.editLive2);//编辑直播接口（加密）
    app.get('/api/v3/live/getHotLiveRoomList.do', ctrl.getHotLiveRoomList); //最新热门直播间列表
    app.get('/api/v3/discovery/getDiscovery2.do', ctrl.getDiscovery2); //发现内容二-直播推荐
    app.get('/api/v3/live/getSpecialLive.do', ctrl.getSpecialLive); //获取专场直播列表
    app.post('/api/v3/live/getLivePlayUrl.do', ctrl.getLivePlayUrl);//获取直播间视频直播地址（不加密）
    app.post('/api/v3/live/getLivePlayUrl1.do', ctrl.getLivePlayUrl1);//获取直播间视频直播地址（加密）
    app.post('/api/v3/live/getLivePlayUrl2.do', ctrl.getLivePlayUrl2);//获取直播间视频直播地址（主播视角）
    app.post('/api/v3/live/getLivePlayUrl3.do', ctrl.getLivePlayUrl3);//获取直播间视频直播地址(用户登录加密）
    app.get('/api/v3/dynamic/getLiverDynamicListByAuthor.do', ctrl.getLiverDynamicListByAuthor1); //粉丝获取主播动态
    app.post('/api/v3/liveRoomMsg/deleteMsg.do1', ctrl.deleteMsg);//删除图文直播消息
    app.post('/api/v3/liveRoomMsg/deleteMsg.do2', ctrl.deleteMsg2);//删除图文直播消息(回放)
    app.get('/api/v2/dynamicHot/selectDynamicHotPaging.do', ctrl.selectDynamicHotPagingV2); //获取热门动态接口
    app.post('/api/v3/dynamic/getDynamicList.do', ctrl.getDynamicListV3);//获取关注人动态接口
    app.get('/api/v3/tag/getTagList.do', ctrl.getTagList); //获取标签列表
    app.get('/api/v3/tag/getTagContent.do', ctrl.getTagContent); //根据标签获取牛人大咖
    app.get('/api/v2/user/selectReceptor.do', ctrl.selectReceptorV2); //获取关注人接口
    app.post('/api/v3/live/getVideoLivePlaybackInfo.do', ctrl.getVideoLivePlaybackInfo); //获取视频直播回放信息(游客进入)
    app.post('/api/v3/live/getVideoLivePlaybackInfo2.do', ctrl.getVideoLivePlaybackInfo2); //获取视频直播回放信息(游客进入,带密码)
    app.post('/api/v3/live/getVideoLivePlaybackInfo3.do', ctrl.getVideoLivePlaybackInfo3); //获取视频直播回放信息(主播进入)
    app.post('/api/v3/live/getVideoLivePlaybackInfo4.do', ctrl.getVideoLivePlaybackInfo4); //获取视频直播回放信息(游客进入、已订阅vip直播间，无密码)
    app.post('/api/v3/live/getVideoLivePlaybackInfo5.do', ctrl.getVideoLivePlaybackInfo5); //获取视频直播回放信息(游客进入、已订阅vip直播间，有密码)
    app.post('/api/v2/subscribe/insert.do', ctrl.insert1); //新增订阅/重新订阅
    app.post('/api/v3/subscribe/deleteSubscribe.do', ctrl.deleteSubscribe); //取消订阅
    app.get('/api/v3/live/getVideoLivePlaybackList.do', ctrl.getVideoLivePlaybackList); //获取视频直播回放列表
    app.get('/api/v3/discovery/getDiscovery3.do', ctrl.getDiscovery3); //获取第三部分发现内容，推荐专栏
    app.get('/api/v3/columnCategory/getList.do', ctrl.getList);//专题/专栏分类列表
    app.get('/api/v3/column/getColumnListByCategoryId.do', ctrl.getColumnListByCategoryId);//专栏列表
    app.get('/api/v3/discovery/getDiscovery1.do', ctrl.getDiscovery1);//专栏列表
    app.get('/api/v3/homePage/label/getLabelList.do', ctrl.getLabelList);//获取标签
    app.get('/api/v3/homePage/label/getLabelFlow.do', ctrl.getLabelFlow);//获取标签信息流
    app.get('/api/v2/homePage/homeV2.do', ctrl.homeV2); //获取首页信息流
    app.post('/api/v2/journal/selectLatelyByTarget.do', ctrl.selectLatelyByTarget); //获取最近打赏信息
    app.post('/api/v3/comment/insert.do', ctrl.insert2); //发表评论接口
    app.get('/api/v3/comment/getCommentByObjId1.do', ctrl.getCommentByObjId1); //获取评论列表接口(未登录)
    app.get('/api/v3/comment/getCommentByObjId2.do', ctrl.getCommentByObjId2); //获取评论列表接口(已登录)
    app.post('/api/v2/subscribe/selectSubscribe.do', ctrl.selectSubscribe); //查询是否订阅专栏
    app.get('/api/v3/column/getFreeLook.do', ctrl.getFreeLook); //获取免费试看
    app.get('/api/v3/column/getColumnContent.do', ctrl.getColumnContent); //获取专栏内容详情
    app.post('/api/v3/column/setFreeLook.do', ctrl.setFreeLook); //设置免费试看
    app.post('/api/v2/subscribe/insert.do', ctrl.insertColumn); //新增订阅/重新订阅
    app.post('/api/v3/order/wxUnifiedOrderBusLive.do', ctrl.wxUnifiedOrderBusLive);//商业直播微信统一下单
    app.post('/api/v3/order/wxFrontNotifyBusLive.do', ctrl.wxFrontNotifyBusLive); //微信订单查询(直播活动)
    app.get('/api/v3/subject/getSubjectContentList.do', ctrl.getSubjectContentList); //获取专题内容列表
    app.post('/api/v2/video/delete.do', ctrl.deleteV2); //删除视频接口
    app.get('/api/v3/document/download/url.do', ctrl.url); //获取文档下载地址
    app.get('/api/v2/subject/getSubjectDetail.do', ctrl.getSubjectDetail); //获取专题详情
   /*消息中心*/
    app.post('/api/v3/comment/getSendCommentByUid.do', ctrl.getSendCommentByUid); //获取发出的评论列表
    app.post('/api/v3/comment/getReceiveCommentByUid.do', ctrl.getReceiveCommentByUid); //获取收到的评论列表
    app.post('/api/v3/msgCenter/getMsgNum.do', ctrl.getMsgNum); //获取未读消息数量
    app.post('/api/v3/msgCenter/getLiveRoomMsgList.do', ctrl.getLiveRoomMsgList); //获取直播消息列表
    app.post('/api/v3/msgCenter/getLikeList.do', ctrl.getLikeList); //获取直播消息列表
    app.post('/api/v3/msgCenter/getPrivateLetter.do', ctrl.getPrivateLetter); //获取用户私信接口
    app.post('/api/v3/msgCenter/getOfficialLetterList.do', ctrl.getOfficialLetterList); //获取私信列表接口
    app.post('/api/v3/msgCenter/checkAndSaveOfficialLetter.do', ctrl.checkAndSaveOfficialLetter); //检查更新官方私信
    app.post('/api/v3/msgCenter/getUnreadCount.do', ctrl.getUnreadCount); //检查更新官方私信
    app.get('/api/v3/live/getContestRoom.do', ctrl.getContestRoom); //获取大赛直播接口
    app.get('/api/v3/homePage/eventDynamics.do', ctrl.eventDynamics); //赛事动态
    app.post('/api/v3/subscribe/selectMySubscribe.do', ctrl.selectMySubscribe); //获取我的订阅/我的已购
    app.get('/api/v1/user/userVerification/sendSms.do', ctrl.sendSmsV1); //获取重置密码，绑定手机号验证码接口
    app.get('/api/v3/dynamic/getLiverDynamicListByAuthorV3.do', ctrl.getLiverDynamicListByAuthorV3); //检查更新官方私信
    app.get('/api/v3/dynamic/getDynamicByTypeV3.do', ctrl.getDynamicByTypeV3); //根据类型获取动态列表

    app.post('/api/v2/article/saveOrUpdate.do', ctrl.saveOrUpdate1); //发布/修改文章接口
    
    /*网信杯*/
    app.get('/api/v3/column/getTzsColumn.do', ctrl.getTzsColumn); //股市学堂专栏内容
    app.get('/common-service/api/v1/carousel/getCarouselList', ctrl.getCarouselList); //获取赛事主页轮播消息
    app.get('/common-service/api/v1/school/getTeamPopularityRank', ctrl.getTeamPopularityRank); //获取战队人气排行榜接口
    app.get('/common-service/api/v1/joiner/getPopularityRank', ctrl.getPopularityRank); //获取战队人气排行榜接口
    app.post('/common-service/api/v1/video/getVideosByParams', ctrl.getVideosByParams); //聚合查询视频列表
    app.get('/common-service/api/v1/joiner/getJoinerInfo', ctrl.getJoinerInfo); //获取参赛用户基本信息接口
    app.get('/common-service/api/v1/carousel/getRedCarouselList', ctrl.getRedCarouselList); //获取拉新页红包轮播消息
    app.post('/luckydraw-service/api/v1/lottery/record', ctrl.record); //聚合查询视频列表
    app.get('/common-service/api/v1/entered/getProvinces', ctrl.getProvinces); //获取省份信息
    app.get('/common-service/api/v1/entered/getSchool', ctrl.getSchool); //获取院校信息
    app.post('/common-service/api/v1/entered/toEntered', ctrl.toEntered); //报名接口
    app.post('/common-service/api/v1/entered/getRedBag', ctrl.getRedBag); //报名接口
    app.get('/trade-service/api/v1/trade/getProfitRank', ctrl.getProfitRank); //获取省份信息
    app.get('/api/v4/fo/getTransferRecords.do', ctrl.getTransferRecordsV4); //获取操盘手成交记录
    app.get('/api/v4/fo/getPosition.do', ctrl.getPositionV4); //获取操盘手持仓接口
    app.get('/api/v3/subscribe/getSubscribeCharge.do', ctrl.getSubscribeCharge); //获取订阅收费详情
    app.get('/bindingThirdparty', ctrl.bindingThirdparty);//绑定第三方
    app.get('/luckydraw-service/api/v1/lottery/begin', ctrl.begin); //获取活动id
    app.get('/common-service/api/v1/user/getInviteInfoService', ctrl.getInviteInfoService); //邀请相关
    app.get('/trade-service/api/v1/trade/getTeamProfitRank', ctrl.getTeamProfitRank); //获取战队收益排行榜
    app.post('/api/v1/user/bindingMobileV4.do', ctrl.bindingMobileV4); //用户绑定手机号

    app.get('/api/v4/fo/getTraderProfitByType.do', ctrl.getTraderProfitByType); //获取个人收益信息
    
    
};


