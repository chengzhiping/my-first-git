var request = require('request');
var moment = require('moment');
var ctrlConfig = require('./ctrlConfig');
var fntv_api_address = ctrlConfig.fntv_api_address; //  https://www.fntv8.com/fntv
var fntv_domain = ctrlConfig.fntv_domain; //  https://www.fntv8.com

exports.loginFromWeb = function (req, res, next) {
    req.session.loginFrom = 'WEB官网';
    next();
};
exports.index = function (req, res, next){
    req.session.href = req.originalUrl;
    res.render('./index');
};
//投资观点
exports.investment = function (req, res, next){
    req.session.href = req.originalUrl;
    res.render('./investment');
};
//投资观点查看更多
exports.investmentMore = function (req, res, next){
    req.session.href = req.originalUrl;
    res.render('./investmentMore');
};
//右侧公共组件
exports.sideBarRight = function (req, res, next){
    req.session.href = req.originalUrl;
    res.render('./sideBarRight');
};

 
exports.megagame = function (req, res, next){
    req.session.href = req.originalUrl;
    res.render('./megagame');
};
exports.test = function (req, res, next){
    req.session.href = req.originalUrl;
    res.render('./test');
};
 
