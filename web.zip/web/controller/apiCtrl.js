var request = require('request');
var crypto = require('crypto'); //加密模块
var ctrlConfig = require('./ctrlConfig');
var fntv_api_address = ctrlConfig.fntv_api_address; //  https://www.fntv8.com/fntv
var fntv_domain = ctrlConfig.fntv_domain; //  https://www.fntv8.com
var fntv_api_address_tzs = ctrlConfig.fntv_api_address_tzs;
var fntv_domain_tzs = ctrlConfig.fntv_domain_tzs;
var captchapng = require('captchapng');
var qiniu = require('qiniu');
var qn = require('qn');
//外网
// var clientLogin3rd = 1;
// var qqAppID = '101391663'; //QQ
// var qqAppSecret = '13bb99af54d3f098dc6e0cb53dff9629'; //QQ
// var weiboAppID = '2203910803'; //微博
// var weiboAppSecret = 'c4a189bf112d8310119a4bba37607e4c'; //微博

//内网
var clientLogin3rd = 2;
var qqAppID = '101415828'; //QQ
var qqAppSecret = '5c0e214abf481377f4e102da05ec2623'; //QQ
var weiboAppID = '1557796394'; //微博
var weiboAppSecret = '11725bc5e48184f1f4d3a788f72e9360'; //微博

//微信外网
var wxAppID = 'wx3f8a0b15994e0615'; //外网
var wxAppSecret = 'ce8c635a143d1b71eb39d02d7c260cc2'; //外网

exports.batchUploadtoken = function(req, res, next) {
	var uid = req.query.uid;
	var token = req.query.token;
	request.get({
			url: fntv_api_address + '/api/v1/picture/batchUpload/token.do?uid=' + uid + '&token=' + token
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var result = JSON.parse(data);
				res.send(result);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.uploadimgSrc = function(req, res, next) {
	var imgsrc = req.body.imgSrc;
	console.log(imgsrc);

	function fetchImg(url, bucket, key) {
		qiniu.conf.ACCESS_KEY = "SUIYTvD296JDxT1DwmNezxar45oTXtJ7w4FKmo7S";
		qiniu.conf.SECRET_KEY = "_qExRnwKgyQ6v4nn_3qxTmKMlW0U12vCBOZfK0FJ";
		var client = new qiniu.rs.Client();
		var key = 'fntvImg' + new Date().getTime();
		client.fetch(url, bucket, key, function(err, ret) {
			if(err) {
				console.log("--------------------------------------");
				console.log(err);
			} else {
				console.log("==================================");
				console.log(ret);
				//res.send(ret);
			}
		});
	};
	fetchImg(imgsrc, 'picture-dev-storage', '');
};
exports.uploadHtml = function(req, res, next) {
	var imgsrc = req.body.html;
	//console.log(imgsrc);
	//图片转存
	/*资源管理相关的操作首先要构建BucketManager对象：*/
	var accessKey = 'SUIYTvD296JDxT1DwmNezxar45oTXtJ7w4FKmo7S';
	var secretKey = '_qExRnwKgyQ6v4nn_3qxTmKMlW0U12vCBOZfK0FJ';
	var mac = new qiniu.auth.digest.Mac(accessKey, secretKey);
	var config = new qiniu.conf.Config();
	//config.useHttpsDomain = true;
	config.zone = qiniu.zone.Zone_z0;
	var bucketManager = new qiniu.rs.BucketManager(mac, config);

	var resUrl = imgsrc;
	var bucket = "picture-storage";
	var key = 'fntvImg' + new Date().getTime();
	bucketManager.fetch(resUrl, bucket, key, function(err, respBody, respInfo) {
		if(err) {
			console.log(err);
			//throw err;
			res.send({
				code: -1,
				data: '',
				msg: '上传出错',
				time: new Date().getTime()
			});
		} else {
			if(respInfo.statusCode == 200) {
				res.send({
					code: 0,
					data: 'http://picture.fengniutv.com/' + respBody.key,
					msg: '上传成功',
					time: new Date().getTime()
				});

				//console.log("=================================");
				//console.log(respBody.key);
				//console.log(respBody.hash);
				//console.log(respBody.fsize);
				//console.log(respBody.mimeType);
			} else {
				res.send({
					code: -2,
					data: '',
					msg: '上传失败',
					time: new Date().getTime()
				});
				console.log(respInfo.statusCode);
				console.log(respBody);
			}
		}
	});
};
exports.logoutFntv = function(req, res, next) {
	req.session.user = {
		"code": -2,
		"data": "",
		"msg": "注销成功",
		"time": new Date().getTime()
	};
	res.send(req.session.user);
};
exports.refreshGraphCode = function(req, res, next) {
	var code = '0123456789';
	var length = 4;
	var randomcode = '';
	for(var i = 0; i < length; i++) {
		randomcode += code[parseInt(Math.random() * 1000) % code.length];
	};
	req.session.checkcode = randomcode;
	var p = new captchapng(56, 34, randomcode);
	p.color(213, 213, 213, 255); // First color: background (red, green, blue, alpha)
	p.color(255, 161, 98, 255); // Second color: paint (red, green, blue, alpha)
	// console.log(req.session.checkcode);
	var img = p.getBase64();
	/*
		var imgbase64 = new Buffer(img, 'base64');
		res.writeHead(200, {
			'Content-Type': 'image/png'
		});
	*/
	res.send({
		code: 0,
		data: img,
		msg: '验证码',
		time: new Date().getTime()
	});
};
exports.checkGraphCode = function(req, res, next) {
	var verifiCode = req.body.verifiCode;
	if(verifiCode == req.session.checkcode) {
		res.send({
			"code": 0,
			"data": "",
			"msg": "验证码正确",
			"time": new Date().getTime()
		})
	} else {
		res.send({
			"code": -1,
			"data": "",
			"msg": "验证码不正确",
			"time": new Date().getTime()
		})
	}
};

var qq_return_uri = fntv_domain + '/qqUserInfo';
exports.qqOauth = function(req, res, next) {
	res.redirect('https://graph.qq.com/oauth2.0/authorize?response_type=code&client_id=' + qqAppID + '&redirect_uri=' + qq_return_uri + '&state=state&scope=get_user_info');
};
exports.qqUserInfo = function(req, res, next) {
	var realIp = req.get("X-Real-IP") || req.get("X-Forwarded-For") || req.ip;  
	var code = req.query.code;
	request.get({
			url: 'https://graph.qq.com/oauth2.0/token?grant_type=authorization_code&client_id=' + qqAppID + '&client_secret=' + qqAppSecret + '&code=' + code + '&redirect_uri=' + qq_return_uri,
		},
		function(error, response, body) {
			if(response.statusCode == 200) {
				// 截取access_token
				String.prototype.getQuery = function(name) {
					var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
					var r = this.substr(this.indexOf("\?") + 1).match(reg);
					if(r != null) return unescape(r[2]);
					return null;
				};
				var str = body;
				var access_token = str.getQuery("access_token");
				req.session.access_token = access_token;
				request.get({
						url: 'https://graph.qq.com/oauth2.0/me?access_token=' + access_token,
					},
					function(errors, responses, result) {
						var resultStr = result;
						var openidStr = resultStr.substring(resultStr.indexOf("(") + 1, resultStr.indexOf(")"));
						var openid = JSON.parse(openidStr).openid;
					//	console.log("access_token");
					//	console.log(access_token);
					//	console.log("openid");
					//	console.log(openid);
						req.session.access_token = access_token;
						req.session.openid = JSON.parse(openidStr).openid;
						req.session.openidSource = 3; /*QQ  openID*/
						if(response.statusCode == 200) {
						//	console.log("req.session.user.data.userInfo.uid");
						//	console.log(req.session.user);
							if(req.session.user&&req.session.user.code==0) { //如果用户信息存在，则为绑定手机号码
								var loginUid = req.session.user.data.userInfo.uid;
								var loginToken = req.session.user.data.token;
								request.post({
										url: fntv_api_address + '/api/v1/userAuth/binding.do',
										form: {
											uid: loginUid,
											token: loginToken,
											type: 5,
											openId: openid,
											accessToken: access_token,
											client: clientLogin3rd
										}
									},
									function(errors, respon, data) {
										if(respon.statusCode == 200) {
											var resdata = JSON.parse(data);
										//	console.log("qqqqqqqqqqqqqqqqqqqqqq");
										//	console.log(resdata);
											if(resdata.code == 0) {
												req.session.bindingThirdparty = resdata;
												res.redirect(req.session.href);
											}else{
												req.session.bindingThirdparty = resdata;
									            res.redirect(req.session.href);
											}
										} else {
											console.log(respon.statusCode);
										}
									}
								);
							} else {
								request.post({
										url: fntv_api_address + '/api/v1/user/login3rdParty.do',
										form: {
											type: 5,
											openId: openid,
											accessToken: access_token,
											client: clientLogin3rd,
											loginSource: req.session.loginFrom,
											ip: realIp
										}
									},
									function(errors, respon, data) {
										if(respon.statusCode == 200) {
											var resdata = JSON.parse(data);
											if(resdata.code == 0) {
												req.session.user = resdata;
												res.redirect(req.session.href);
											} else {
												res.send(resdata.msg);
											}
										} else {
											console.log(respon.statusCode);
										}
									}
								);
							}

						} else {
							console.log(response.statusCode);
						}
					}
				)
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.wxOauth = function(req, res, next) {
	var return_uri = fntv_domain + '/wxUserInfo';
	var scope = 'snsapi_userinfo';
	res.redirect('https://open.weixin.qq.com/connect/qrconnect?appid=' + wxAppID + '&redirect_uri=' + return_uri + '&response_type=code&scope=snsapi_login');
};
exports.wxUserInfo = function(req, res, next) {
	var realIp = req.get("X-Real-IP") || req.get("X-Forwarded-For") || req.ip;  
	var code = req.query.code;
	request.get({
			url: 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' + wxAppID + '&secret=' + wxAppSecret + '&code=' + code + '&grant_type=authorization_code',
		},
		function(error, response, body) {
			if(response.statusCode == 200) {
				var data = JSON.parse(body);
				var access_token = data.access_token;
				var openid = data.openid;
				req.session.openid = data.openid;
				req.session.openidSource = 1; /*微信  openID*/
				req.session.access_token = access_token;
				if(req.session.user&&req.session.user.code==0){
				//	console.log(req.session.user.data);
					var loginUid = req.session.user.data.userInfo.uid;
					var loginToken = req.session.user.data.token;
					request.post({
							url: fntv_api_address + '/api/v1/userAuth/binding.do',
							form: {
								uid: loginUid,
								token: loginToken,
								type: 4,
								openId: openid,
								accessToken: access_token,
								client: clientLogin3rd
							}
						},
						function(errors, respon, data) {
							if(respon.statusCode == 200) {
								var resdata = JSON.parse(data);
							//	console.log("wxwxwxwxwxwxwxwxwxwxxwxw");
							//	console.log(resdata);
								if(resdata.code == 0) {
									req.session.bindingThirdparty = resdata;
									res.redirect(req.session.href);
								}else{
									req.session.bindingThirdparty = resdata;
						            res.redirect(req.session.href);
								}
							} else {
								console.log(respon.statusCode);
							}
						}
					);
				} else {
					request.post({
							url: fntv_api_address + '/api/v1/user/login3rdParty.do',
							form: {
								type:4,
								openId: openid,
								accessToken: access_token,
								client: clientLogin3rd,
								loginSource: req.session.loginFrom,
								ip: realIp
							}
						},
						function(errors, respon, data) {
							if(respon.statusCode == 200) {
								var resdata = JSON.parse(data);
								if(resdata.code == 0) {
									req.session.user = resdata;
									res.redirect(req.session.href);
								} else {
									res.redirect('/');
								}
							} else {
								console.log(respon.statusCode);
							}
						}
					);
				}

			} else {
				console.log(response.statusCode);
			}
		}
	);
};

var weibo_return_uri = fntv_domain + '/wbUserInfo';
exports.wbOauth = function(req, res, next) {
	res.redirect('https://api.weibo.com/oauth2/authorize?client_id=' + weiboAppID + '&redirect_uri=' + weibo_return_uri + '&display=default');
};
exports.wbUserInfo = function(req, res, next) {
	var realIp = req.get("X-Real-IP") || req.get("X-Forwarded-For") || req.ip;  
	var code = req.query.code;
	request.post({
			url: 'https://api.weibo.com/oauth2/access_token?client_id=' + weiboAppID + '&client_secret=' + weiboAppSecret + '&grant_type=authorization_code&code=' + code + '&redirect_uri=' + weibo_return_uri,
		},
		function(error, response, body) {
			if(response.statusCode == 200) {
				var data = JSON.parse(body);
			//	console.log("wbwbwbwbwbwbwbwbwbwbbwbwbwbwb");
			//	console.log(data);
				var access_token = data.access_token;
				req.session.access_token = access_token;
				req.session.openid = data.uid;
				req.session.openidSource = 2; /*微信  openID*/
				var uid = data.uid;
				var openid=data.uid;
				if(req.session.user&&req.session.user.code==0) {
					var loginUid = req.session.user.data.userInfo.uid;
					var loginToken = req.session.user.data.token;
					request.post({
							url: fntv_api_address + '/api/v1/userAuth/binding.do',
							form: {
								uid: loginUid,
								token: loginToken,
								type: 3,
								openId: openid,
								accessToken: access_token,
								client:clientLogin3rd
							}
						},
						function(errors, respon, data) {
							if(respon.statusCode == 200) {
								var resdata = JSON.parse(data);
								//console.log("wbwbwbwbwb");
							//	console.log(resdata);
								if(resdata.code == 0) {
									req.session.bindingThirdparty = resdata;
									res.redirect(req.session.href);
								}else{
									req.session.bindingThirdparty = resdata;
									res.redirect(req.session.href);
								}
							} else {
								console.log(respon.statusCode);
							}
						}
					);
				} else {
					request.post({
							url: fntv_api_address + '/api/v1/user/login3rdParty.do',
							form: {
								type: 3,
								openId: uid,
								accessToken: access_token,
								client: clientLogin3rd,
								loginSource: req.session.loginFrom,
								ip: realIp
							}
						},
						function(errors, respon, resjson) {
							if(respon.statusCode == 200) {
								var resdata = JSON.parse(resjson);
								if(resdata.code == 0) {
									req.session.user = resdata;
									res.redirect(req.session.href);
								} else {
									res.redirect('/');
								}
							} else {
								console.log(respon.statusCode);
							}
						}
					)
				}
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.userInfos = function(req, res, next) {
	// console.log(req.session.user);
	var userState = {
		"code": -2,
		"data": "",
		"msg": "未登录",
		"time": new Date().getTime()
	};
	if(req.session.user) {
		if(req.session.user.code == 0) {
			var uid = req.session.user.data.userInfo.uid;
			var token = req.session.user.data.token;
			request.get({
					url: fntv_api_address + '/api/v1/user/getUserInfo.do?uid=' + uid,
				},
				function(error, response, result) {
					if(response.statusCode == 200) {
						var userData = JSON.parse(result);
						if(userData.code == 0) {
							var openid;
							if(req.session.openid) {
								openid = req.session.openid
							} else {
								openid = ''
							};
							var openidSource;
							if(req.session.openidSource) {
								openidSource = req.session.openidSource
							} else {
								openidSource = 0
							};
							var access_token;
							if(req.session.access_token) {
								access_token = req.session.access_token
							} else {
								access_token = ''
							};
							var userResult = {
								"code": 0,
								"data": {
									token: token,
									userInfo: userData.data,
									openid: openid,
									openidSource: openidSource, /*0为非第三方登录，1为微信登录，2为微博登录，3为QQ登录*/
									access_token: access_token
								},
								"msg": "登录成功",
								"time": new Date().getTime()
							};
							req.session.user = userResult;
							//console.log("99999999999999999999999");
							res.send(req.session.user);
						} else {
							res.send(userData);
						}
					} else {
						console.log(response.statusCode);
						res.send(userState);
					}
				}
			);
		} else {
			res.send(userState);
		}
	} else {
		res.send(userState);
	}
};
//exports.userInfos = function (req, res, next) {
//  if (req.session.user) {
//      res.send(req.session.user);
//  } else {
//      res.send({
//          "code": -2,
//          "data": "",
//          "msg": "未登录",
//          "time": new Date()
//      });
//  }
//};
exports.bindingThirdparty = function(req, res, next) {
	if(req.session.bindingThirdparty&&req.session.bindingThirdparty.code==0) {
		res.send(req.session.bindingThirdparty);
	} else {
		res.send({
			"code": -2,
			"data": "",
			"msg": "绑定失败,请重新绑定",
			"time": new Date()
		});
	}
};
exports.getReceptorCount = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
	};
	request.post({
			url: fntv_api_address + '/api/v1/user/getReceptorCount.do',
			form: formData
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				//if(data.code == 0) {
				//					req.session.user = data;
				//};
				res.send(data);
			} else {
				console.log(response.statusCode);
			}

		}
	);
};
exports.sendSms = function(req, res, next) {
	var mobile = req.body.mobile;
	request.get({
			url: fntv_api_address + '/api/v1/user/getSmsToken.do?mobile=' + mobile + '&type=0',
		},
		function(error, response, smsTokendata) {
			if(response.statusCode == 200) {
				var result = JSON.parse(smsTokendata);
				if(result.code == 0) {
					var smsToken = result.data;
					request.post({
							url: fntv_api_address + '/api/v1/user/register/sendSms.do?mobile=' + mobile + '&token=' + smsToken + '&type=0',
						},
						function(errors, responses, data) {
							if(responses.statusCode == 200) {
								var result = JSON.parse(data);
								res.send(result);
							} else {
								console.log(responses.statusCode);
							}
						}
					);
				} else {
					res.send(result);
				}
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.register = function(req, res, next) {
	var realIp = req.get("X-Real-IP") || req.get("X-Forwarded-For") || req.ip;  
	var md5 = crypto.createHash('md5');
	md5.update(req.body.password);
	var passwordMd5 = md5.digest('hex');
	var formData = {
		mobile: req.body.mobile,
		password: passwordMd5,
		nickName: req.body.nickName,
		authCode: req.body.authCode,
		regSource: req.session.loginFrom,
		inviteCode: req.body.inviteCode,
		ip: realIp
	};
	request.post({
			url: fntv_api_address + '/api/v1/user/register.do',
			form: formData
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				if(data.code == 0) {
					req.session.user = data;
				};
				res.send(data);
			} else {
				console.log(response.statusCode);
			}

		}
	);
};
exports.v2sendSms = function(req, res, next) {
	var salt = '5llEbAwsYV5TGRYeXzTDCQ==';
	var signMd5 = req.body.mobile + salt;
	var md5 = crypto.createHash('md5'); //定义加密方式:md5不可逆,此处的md5可以换成任意hash加密的方法名称；
	md5.update(signMd5);
	var sign = md5.digest('hex'); //加密后的值
	request.post({
			url: fntv_api_address + '/api/v2/user/sendSms.do',
			form: {
				type: req.body.type,
				mobile: req.body.mobile,
				sign: sign
			}
		},
		function(error, response, result) {
			var data = JSON.parse(result);
			if(response.statusCode == 200) {
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		});
};
exports.v2login = function(req, res, next) {
	var realIp = req.get("X-Real-IP") || req.get("X-Forwarded-For") || req.ip;  
	request.post({
			url: fntv_api_address + '/api/v2/user/login.do',
			form: {
				mobile: req.body.mobile,
				authCode: req.body.authCode,
				inviteCode: req.body.inviteCode,
				loginSource: req.session.loginFrom,
				ip: realIp
			}
		},
		function(error, response, result) {
			var data = JSON.parse(result);
			if(response.statusCode == 200) {
				if(data.code == 0) {
					req.session.user = data;
					req.session.user.data.userInfo.mobile = req.body.mobile;
				};
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		});
};
exports.authorize = function(req, res, next) {
	if(req.session.user) {
		next();
	} else {
		res.send({
			"code": -2,
			"data": "",
			"msg": "未登录",
			"time": new Date().getTime()
		});
	}
};

exports.getIsRegister = function(req, res, next) {
	// console.log(req.body.mobile);
	var formData = {
		mobile: req.body.mobile
	};
	request.post({
			url: fntv_api_address + '/api/v1/user/getIsRegister.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var result = JSON.parse(data);
				res.send(result);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.login = function(req, res, next) {
	var realIp = req.get("X-Real-IP") || req.get("X-Forwarded-For") || req.ip;  
	var md5 = crypto.createHash('md5'); //定义加密方式:md5不可逆,此处的md5可以换成任意hash加密的方法名称；
	md5.update(req.body.password);
	var passwordMd5 = md5.digest('hex'); //加密后的值

	var formData = {
		mobile: req.body.mobile,
		password: passwordMd5,
		ip: realIp
	};
	request.post({
			url: fntv_api_address + '/api/v1/user/login.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				if(userData.code == 0) {
					req.session.user = userData;
				};
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getDynamicList = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
		token: req.body.token,
		pageIndex: req.body.pageIndex,
		pageSize: req.body.pageSize
	};
	request.post({
			url: fntv_api_address + '/api/v2/dynamic/getDynamicList.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getUserInfo = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/user/getUserInfo.do?uid=' + req.query.uid
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				// console.log("========================");
				console.log(response.statusCode);
			}
		}
	);
};
exports.getColumnDetail = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnDetail.do?columnId=' + req.query.columnId + '&uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getColumnDetail1 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnDetail.do?columnId=' + req.query.columnId,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getColumnContent = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnContent.do?columnId=' + req.query.columnId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getColumnList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnList.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getColumn = function(req, res, next) {
	var formData = {
		uid: req.query.uid,
	};
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnByUid.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLiveList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnByUid.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getProfitInfo = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/fo/getProfitInfoByUid.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectFans = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/selectFans.do',
			form: {
				uid: req.body.uid,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.following = function(req, res, next) {
	var formData = {
		receptorId: req.body.receptorId,
		uid: req.body.uid,
		token: req.body.token,
	};
	request.post({
			url: fntv_api_address + '/api/v1/user/following.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getFansCount = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/getFansCount.do?uid=' + req.body.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getAnswerDetail1 = function(req, res, next) {
	var formData = {
		id: req.body.id,
	};
	request.post({
			url: fntv_api_address + '/api/v2/comment/getComment.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getAnswerDetail2 = function(req, res, next) {
	var formData = {
		id: req.body.id,
		uid: req.body.uid,
	};
	request.post({
			url: fntv_api_address + '/api/v2/comment/getComment.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLiverDynamicList = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
		pageIndex: req.body.pageIndex,
		pageSize: req.body.pageSize,
	};
	request.post({
			url: fntv_api_address + '/api/v2/dynamic/getLiverDynamicListByAuthor.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRewardPeople = function(req, res, next) {
	var formData = {
		target: req.body.target,
	};
	request.post({
			url: fntv_api_address + '/api/v1/journal/selectByTarget.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectDiscussImg = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/banner/selectDiscussImg.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getArticle1 = function(req, res, next) {
	var formData = {
		id: req.body.id,
	};
	request.post({
			url: fntv_api_address + '/api/v2/article/getArticle.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getArticle2 = function(req, res, next) {
	var formData = {
		id: req.body.id,
		uid: req.body.uid,
	};
	request.post({
			url: fntv_api_address + '/api/v2/article/getArticle.do',
			formData: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getComment = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/comment/getCommentList.do?objectId=' + req.query.objectId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTransferRecords = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/fo/getTransferRecordsByUid.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTransferRecords2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/fo/getTransferRecords.do?pageSize=' + req.query.pageSize + '&pageIndex=' + req.query.pageIndex
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getPositions = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/fo/getPositionsByUid.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.allPeopleSee = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/homePage/watch.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
//zj-话题详情页
exports.selectDiscuss = function(req, res, next) {
	var formData = {
		id: req.body.id,
	};
	request.post({
			url: fntv_api_address + '/api/v2/discuss/selectDiscuss.do',
			formData: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectDiscuss2 = function(req, res, next) {
	var formData = {
		id: req.body.id,
		uid: req.body.uid
	};
	request.post({
			url: fntv_api_address + '/api/v2/discuss/selectDiscuss.do',
			form: formData
		},
		function(error, response, data) {
			// console.log("===============");
			// console.log(data);
			// console.log(formData);
			if(response.statusCode == 200) {
				var result = JSON.parse(data);
				res.send(result);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTopicCommentList = function(req, res, next) {
	var formData = {
		objectId: req.body.objectId
	};
	request.post({
			url: fntv_api_address + '/api/v2/comment/getTopicCommentList.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTopicCommentList2 = function(req, res, next) {
	var formData = {
		objectId: req.body.objectId,
		pageIndex: req.body.pageIndex,
		pageSize: req.body.pageSize
	};
	request.post({
			url: fntv_api_address + '/api/v2/comment/getTopicCommentList.do',
			form: formData
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTopicCommentList3 = function(req, res, next) {
	var formData = {
		objectId: req.body.objectId,
		pageIndex: req.body.pageIndex,
		pageSize: req.body.pageSize,
		uid: req.body.uid,
	};
	request.post({
			url: fntv_api_address + '/api/v2/comment/getTopicCommentList.do',
			form: formData
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTopicCommentList4 = function(req, res, next) {
	var formData = {
		objectId: req.body.objectId,
		seeType: req.body.seeType,
		sortType: req.body.sortType,
		creatorId: req.body.creatorId,
		uid: req.body.uid,
		pageIndex: req.body.pageIndex,
		pageSize: req.body.pageSize
	};
	request.post({
			url: fntv_api_address + '/api/v2/comment/getTopicCommentList.do',
			form: formData
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.homePagekind2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/homePage/kind.do?type=' + req.query.type + '&size=' + req.query.size
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

//直播间
exports.joinLive = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
	};
	request.post({
			url: fntv_api_address + '/api/v1/live/joinLive.do',
			formData: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.joinLive2 = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
		authCode: req.body.authCode,
	};
	request.post({
			url: fntv_api_address + '/api/v1/live/joinLive.do',
			formData: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getAnnouncement = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/live/getAnnouncement.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.createSig = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
	};
	request.post({
			url: fntv_api_address + '/api/v1/im/createSig.do',
			formData: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getColumnByUid = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnByUid.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getUserLives = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/live/getUserLives.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getProfitRanking = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/fo/getProfitRanking.do?period=' + req.query.period + '&pageSize=' + req.query.pageSize + '&pageIndex=' + req.query.pageIndex,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 横幅相关接口
exports.selectBanner = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/banner/selectBanner.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.joinBanner = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/banner/joinBanner.do',
			form: {
				id: req.body.id,
				bannerType: req.body.bannerType,
				uid: req.body.uid,
			}
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				res.send(result);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectInvitation = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/banner/selectInvitation.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectByType = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/banner/selectByType.do',
			form: {
				type: req.body.type,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectAdvertisement = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/banner/selectAdvertisement.do',
			form: {
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 聚合查询接口
exports.getVideosByCategoryId = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/live/getAnnouncement.do?categoryId=' + req.query.categoryId + "pageIndex=" + req.query.pageIndex + "pageSize=" + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideosByIds = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/multiple/getVideosByIds.do' + req.query.ids,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideoDetailsById = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/multiple/getVideoDetailsById.do?id=' + req.query.id,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideoDetailsById2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/multiple/getVideoDetailsById.do?id=' + req.query.id + '&authCode=' + req.query.authCode,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideoDetailsById3 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/multiple/getVideoDetailsById.do?id=' + req.query.id + '&authCode=' + req.query.authCode + '&userId=' + req.query.userId + '&token=' + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideoDetailsById4 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/multiple/getVideoDetailsById.do?id=' + req.query.id + '&userId=' + req.query.userId + '&token=' + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRecTags = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/recommend/getRecTags.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getContentsByTagId = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/recommend/getContentsByTagId.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&tagId=' + req.query.tagId,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLiveListByUid = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/multiple/getLiveListByUid.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.search = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/multiple/search.do?keyword=' + req.query.keyword + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&type=' + req.query.type,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 用户相关接口
exports.logout = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/logout.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				//				if(userData.code==0||userData.code==-2){
				//					req.session.user = {
				//						"code": -2,
				//						"data": "",
				//						"msg": "注销成功",
				//						"time": new Date().getTime()
				//					};
				//				}
				//				console.log(userData);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteFollow = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/deleteFollow.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				receptorId: req.body.receptorId,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectReceptor = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/selectReceptor.do',
			form: {
				uid: req.body.uid,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				console.log(userData);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.token = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/user/head/upload/token.do?uid=' + req.query.uid + '&token=' + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getSmsToken = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/user/getSmsToken.do?mobile=' + req.query.mobile + '&type=' + req.query.type,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.checkFollowing = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/checkFollowing.do',
			form: {
				receptorId: req.body.receptorId,
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.binding = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/userAuth/binding.do',
			form: {
				type: req.body.type,
				uid: req.body.uid,
				openId: req.body.openId,
				accessToken: req.body.accessToken,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectImgName = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/userAuth/selectImgName.do',
			form: {
				identityType: req.body.identityType,
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.checkNickName = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/checkNickName.do',
			form: {
				nickName: req.body.nickName,
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.updateUser = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/updateUser.do',
			form: {
				nickName: req.body.nickName,
				uid: req.body.uid,
				token: req.body.token,
				signature: req.body.signature,
				resume: req.body.resume,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.bindingMobile = function(req, res, next) {
	var md5 = crypto.createHash('md5');
	md5.update(req.body.password);
	var passwordMd5 = md5.digest('hex'); //加密后的值
	request.post({
			url: fntv_api_address + '/api/v1/user/bindingMobile.do',
			form: {
				mobile: req.body.mobile,
				uid: req.body.uid,
				token: req.body.token,
				password: passwordMd5,
				authCode: req.body.authCode
			}
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				req.session.user.data.userInfo.mobile = req.body.mobile;
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.resetPwd = function(req, res, next) {
	var md5 = crypto.createHash('md5');
	md5.update(req.body.password);
	var passwordMd5 = md5.digest('hex'); //加密后的值
	request.post({
			url: fntv_api_address + '/api/v1/user/resetPwd.do',
			form: {
				mobile: req.body.mobile,
				password: passwordMd5,
				authCode: req.body.authCode
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.auditAnchor = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/anchor/auditAnchor.do',
			form: {
				uid: req.body.uid,
				fullName: req.body.fullName,
				idNo: req.body.idNo,
				mobile: req.body.mobile,
				authCode: req.body.authCode,
				field: req.body.field,
				content: req.body.content,
				sketch: req.body.sketch,
				resume: req.body.resume,
				img: req.body.img,
				auditStatus: req.body.auditStatus,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.auditAnchor2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/anchor/auditAnchor.do',
			form: {
				uid: req.body.uid,
				fullName: req.body.fullName,
				idNo: req.body.idNo,
				mobile: req.body.mobile,
				authCode: req.body.authCode,
				field: req.body.field,
				content: req.body.content,
				sketch: req.body.sketch,
				resume: req.body.resume,
				img: req.body.img,
				auditStatus: req.body.auditStatus,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectAuditStatus = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/anchor/selectAuditStatus.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectAnchor = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/anchor/selectAnchor.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectAnchor2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/anchor/selectAnchor.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.saveInviteCode = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/user/saveInviteCode.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				inviteCode: req.body.inviteCode,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getInviteCount = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/user/getInviteCount.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getInviteMembers = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/user/getInviteMembers.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.statistics = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/task/invite/statistics.do',
			form: { uid: req.body.uid, token: req.body.token }
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

//直播相关接口
exports.createLive = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/live/createLive.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				topic: req.body.topic,
				categoryId: req.body.categoryId,
				coverUrl: req.body.coverUrl,
				device: req.body.device,
				openness: req.body.openness,
				authCode: req.body.authCode,
			}
		},
		function(error, response, data) {

			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getPushUrl = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/live/getPushUrl.do?uid=' + req.query.uid + "&token=" + req.query.token + "&streamKey=" + req.query.streamKey,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.terminateLive = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/live/terminateLive.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				streamKey: req.body.streamKey,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.saveLive = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/live/saveLive.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				streamKey: req.body.streamKey,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.saveChatRoomId = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/live/saveChatRoomId.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				chatRoomId: req.body.chatRoomId,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getChatRoomId = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/live/getChatRoomId.do?uid=' + req.query.uid + "&token=" + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.quitLive = function(req, res, next) {
	request.post({
			url: fntv_api_address + '-/api/v1/live/quitLive.do',
			form: {
				uid: req.body.uid,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.saveAnnouncement = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/live/saveAnnouncement.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				announcement: req.body.announcement,
				announcementImgUrl: req.body.announcementImgUrl,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

//视频相关接口
exports.videotoken = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/video/upload/token.do?uid=' + req.query.uid + '&duration=' + req.query.duration + '&token=' + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.publish = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/video/publish.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				categoryId: req.body.categoryId,
				coverUrl: req.body.coverUrl,
				topic: req.body.topic,
				device: req.body.device,
				openness: req.body.openness,
				authCode: req.body.authCode,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.delete = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/video/delete.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getContentsByCategoryId = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/recommend/getContentsByCategoryId.do',
			form: {
				categoryId: req.body.categoryId,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 虚拟货币模块接口
exports.wxUnifiedOrder = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/order/wxUnifiedOrder.do',
			form: {
				uid: req.body.uid,
				totalFee: req.body.totalFee,
				tradeType: req.body.tradeType,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.wxFrontNotify = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/order/wxFrontNotify.do',
			form: {
				uid: req.body.uid,
				outTradeNo: req.body.outTradeNo,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.award = function(req, res, next) {
	console.log("=======================");
	console.log(req.body.uid);
	console.log(req.body.uidIn);
	console.log(req.body.target);
	console.log(req.body.coinType);
	console.log(req.body.monetary);
	console.log(req.body.awardToken);
	console.log(req.body.channel);
	console.log(req.body.token);
	request.post({
			url: fntv_api_address + '/api/v1/account/award.do',
			form: {
				uid: req.body.uid,
				uidIn: req.body.uidIn,
				target: req.body.target,
				coinType: req.body.coinType,
				monetary: req.body.monetary,
				awardToken: req.body.awardToken,
				channel: req.body.channel,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.updateAdd = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/account/updateAdd.do',
			form: {
				uid: req.body.uid,
				coinType: req.body.coinType,
				monetary: req.body.monetary,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectCoin = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/account/selectCoin.do',
			form: {
				uid: req.body.uid,
				coinType: req.body.coinType,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectByWhere = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/account/selectByWhere.do',
			form: {
				uid: req.body.uid,
				coinType: req.body.coinType,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectByUid = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/cash/selectByUid.do',
			form: {
				uid: req.body.uid,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.insertOrder = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/cash/insertOrder.do',
			form: {
				uid: req.body.uid,
				coinNumber: req.body.coinNumber,
				money: req.body.money,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getToken = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/account/getToken.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.insertIosOrder = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/order/insertIosOrder.do',
			form: {
				uid: req.body.uid,
				productId: req.body.productId,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.verifyReceipt = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/order/verifyReceipt.do',
			form: {
				uid: req.body.uid,
				receipt: req.body.receipt,
				outTradeNo: req.body.outTradeNo,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 消息推送相关接口
exports.pushToFollow = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/push/pushToFollow.do',
			form: {
				tag: req.body.tag,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.pushToFollow2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/push/pushToFollow.do',
			form: {
				tag: req.body.tag,
				isDev: req.body.isDev,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 评论相关接口
exports.insert = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/comment/insert.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				comment: req.body.comment,
				objectId: req.body.objectId,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getCommentList = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/comment/getCommentList.do',
			form: {
				objectId: req.body.objectId,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteComment = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/comment/deleteComment.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				objectType: req.body.objectType,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.countComment = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/comment/countComment.do',
			form: {
				objectId: req.body.objectId,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectAnswerDiscuss = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/selectAnswerDiscuss.do'
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 文章相关接口
exports.saveOrUpdate = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/article/saveOrUpdate.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				type: req.body.type,
				content: req.body.content,
				title: req.body.title,
				media: req.body.media,
				id: req.body.id,
				userCoverUrl: req.body.userCoverUrl,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.saveOrUpdate2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/article/saveOrUpdate.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				type: req.body.type,
				content: req.body.content,
				title: req.body.title,
				media: req.body.media,
				id: req.body.id,
				lead: req.body.lead,
				columnId: req.body.columnId,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteArticle = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/article/deleteArticle.do',
			form: {
				id: req.body.id,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getArticleByType = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/article/getArticleByType.do',
			form: {
				type: req.body.type,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getArticleType = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/articleType/getArticleType.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getArticleByUid = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/article/getArticleByUid.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

//通用接口
exports.getAllCategories = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/category/getAllCategories.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRootCategories = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/category/getRootCategories.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getCategoriesByParentId = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/category/getCategoriesByParentId.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.imgtoken = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/picture/upload/token.do?uid=' + req.query.uid + '&token=' + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.shareByType = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/share/shareByType.do',
			form: {
				id: req.body.id,
				type: req.body.type,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 动态相关接口
exports.getDynamicListByAuthor = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/dynamic/getDynamicListByAuthor.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getDynamicCount = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/dynamic/getDynamicCount.do',
			form: {
				uid: req.body.uid,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTraderList = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/dynamic/getTraderList.do',
			form: {
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getDynamicByType = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/dynamic/getDynamicByType.do?objectType=' + req.query.objectType + '&uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getDynamicByTypeLiveVideo = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/dynamic/getDynamicByTypeLiveVideo.do?objectType=' + req.query.objectType + '&uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLivingLiver = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/dynamic/getLivingLiver.do?uid=' + req.query.uid + '&token=' + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLivingLiverCount = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/comment/getLivingLiverCount.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLiverDynamicListByAuthor = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/dynamic/getLiverDynamicListByAuthor.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getCountByType = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/dynamic/getCountByType.do?uid=' + req.query.uid + '&objectType=' + req.query.objectType,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.selectCountByTypeLiveVideo = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/dynamic/selectCountByTypeLiveVideo.do?uid=' + req.query.uid + '&objectType=' + req.query.objectType,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getColumnInfoByUid = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnInfoByUid.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteDynamicByType = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/dynamic/deleteDynamicByType.do?id=' + req.query.id,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 实盘相关接口

/*exports.text1 = function (req, res, next) {
    res.render('./text');
};*/
exports.bindingauthorize = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/fo/authorize.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				phoneNum: req.body.phoneNum,
				customerNum: req.body.customerNum,
				customerName: req.body.customerName,
				idNum: req.body.idNum,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getPk = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/fo/getPk.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTopicList = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1//fo/topic/getTopicList.do',
			form: {
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectTraderReport = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/banner/selectTraderReport.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.checkAuthorization = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/fo/checkAuthorization.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRegisterPageInfo = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/fo/getRegisterPageInfo.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getProfitRankByType = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/fo/getProfitRankByType.do',
			form: {
				type: req.body.type,
				date: req.body.date,
				season: req.body.season,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize
			}
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 其他相关接口
exports.checkUpdate = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/client/version/checkUpdate.do?type=' + req.query.type + '&currentVersionCode=' + req.query.currentVersionCode,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 行情相关接口
exports.getQuotation = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/quotation/getQuotation.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getQuotationRose = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/quotation/getQuotationRose.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getQuotationDrop = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/quotation/getQuotationDrop.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getStockDetail = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/quotation/getStockDetail.do?stockId=' + req.query.stockId,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getIndex1 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/quotation/getIndex.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 热门动态相关接口
exports.selectDynamicHotPaging = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/dynamicHot/selectDynamicHotPaging.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 主播中心相关接口
exports.edit = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/multiple/edit.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				coverUrl: req.body.coverUrl,
				topic: req.body.topic,
				categoryId: req.body.categoryId,
				openness: req.body.openness,
				authCode: req.body.authCode,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 接口文档2
// 首页相关接口
exports.home = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/homePage/home.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 专栏相关接口
exports.saveColumn = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/column/save.do',
			form: {
				id: req.body.id,
				token: req.body.token,
				uid: req.body.uid,
				name: req.body.name,
				coverUrl: req.body.coverUrl,
				introduction: req.body.introduction,
				subscribeType: req.body.subscribeType,
				subscribePay: req.body.subscribePay,
				subscribeCycle: req.body.subscribeCycle,
				subscribeSummary: req.body.subscribeSummary,
				summaryUrl: req.body.summaryUrl,
				subscribeNotice: req.body.subscribeNotice,
				userNotice: req.body.userNotice,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteColumn = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/column/delete.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.editColumn = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/column/edit.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				columnId: req.body.columnId,
				type: req.body.type,
				operation: req.body.operation,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 评论相关接口
exports.likeComment = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/comment/likeComment.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				isLike: req.body.isLike,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.setTop = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/comment/setTop.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				isTop: req.body.isTop,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.insertComment = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/comment/insert.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				comment: req.body.comment,
				objectId: req.body.objectId,
				parentId: req.body.parentId,
				type: req.body.type,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 话题相关接口
exports.selectAllDiscuss = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/selectAllDiscuss.do',
			form: {
				uid: req.body.uid,
				type: req.body.type,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectMyDiscuss = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/selectMyDiscuss.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.insertDiscuss = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/insertDiscuss.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				title: req.body.title,
				content: req.body.content,
				coinNumber: req.body.coinNumber,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteDiscuss = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/deleteDiscuss.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.updateDiscuss = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/updateDiscuss.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				title: req.body.title,
				content: req.body.content,
				coinNumber: req.body.coinNumber,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.appointBest = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/appointBest.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectByCommentId = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/selectByCommentId.do',
			form: {
				uid: req.body.uid,
				id: req.body.id,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectMyAnswerDiscuss = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/selectMyAnswerDiscuss.do',
			form: {
				uid: req.body.uid,
				id: req.body.id,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectTraderDiscuss = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/discuss/selectTraderDiscuss.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 点赞相关接口
exports.insertAgree = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/agree/insertAgree.do',
			form: {
				uid: req.body.uid,
				type: req.body.type,
				objectId: req.body.objectId,
				agreeType: req.body.agreeType,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				console.log("==========-----------------");
				console.log(req.body.uid);
				console.log(req.body.type);
				console.log(req.body.objectId);
				console.log(req.body.agreeType);
				console.log(req.body.token);
				console.log(userData);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteAgree = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/agree/deleteAgree.do',
			form: {
				uid: req.body.uid,
				objectId: req.body.objectId,
				agreeType: req.body.agreeType,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectAgreeCount = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/agree/selectAgreeCount.do',
			form: {
				uid: req.body.uid,
				objectId: req.body.objectId,
				agreeType: req.body.agreeType,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectAgreeCount1 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/agree/selectAgreeCount.do',
			form: {
				objectId: req.body.objectId,
				agreeType: req.body.agreeType,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectAgreeList = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/agree/selectAgreeList.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				agreeType: req.body.agreeType,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 大V直播相关接口
exports.getLives = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/live/getLives.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRecLiverList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/live/getRecLiverList.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 发现相关接口
exports.getDiscovery = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/discovery/getDiscovery.do?',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 财经视频相关接口
exports.publishVideo = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/video/publish.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				columnId: req.body.columnId,
				coverUrl: req.body.coverUrl,
				topic: req.body.topic,
				device: req.body.device,
				openness: req.body.openness,
				authCode: req.body.authCode,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRecColumnList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/video/getRecColumnList.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideosByColumnId = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/video/getVideosByColumnId.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&columnId=' + req.query.columnId,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRecVideoList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/video/getRecVideoList.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getUserVideos = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/video/getUserVideos.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRecVideoCategories = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/video/getRecVideoCategories.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 用户相关接口
exports.anchorCenterData = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/user/anchorCenterData.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
/*
exports.loginverify = function (req, res, next) {
    request.post(
        {
            url: fntv_api_address + '/api/v2/user/login.do',
            form: {
                mobile:req.body.mobile,
                authCode:req.body.authCode,
                inviteCode:req.body.inviteCode,
                loginSource:req.body.loginSource,
            }
        },
        function (error, response, data) {
            if (response.statusCode == 200) {
                var userData = JSON.parse(data);
                res.send(userData);
            } else {
                console.log(response.statusCode);
            }
        }
    );
};
*/

// 实盘相关接口
exports.getTransferRecordsByUid = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/fo/getTransferRecordsByUid.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTransferRecordsByUidNum = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/fo/getTransferRecordsByUid.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getPositionsByUid = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/fo/getPositionsByUid.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getFirmOfferByUid = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/fo/getFirmOfferByUid.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 活动项目接口文档V1
// 投票活动接口
exports.objectsList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/vote/objectsList.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.govote = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/vote/go.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				objectId: req.body.objectId,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.sharevote = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/vote/share.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 邀请活动相关接口
exports.getInviteInfo = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/user/getInviteInfo.do?inviteCode=' + req.query.inviteCode + '&startTime=' + req.query.startTime + '&endTime=' + req.query.endTime,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 谁与争分活动相关接口
exports.applygo = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v1/apply/go.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				declaration: req.body.declaration,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getApplyInfo = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/apply/getApplyInfo.do?uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.kind = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/homePage/kind.do?type=' + req.query.type,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getLiveRoomList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/live/getLiveRoomList.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.hotUpdate = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/hotUpdate.do'
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getNewContent = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getNewContent.do'
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.kind3 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/homePage/kind.do?type=' + req.query.type + '&pageSize=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getDiscoveryByType = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/discovery/getDiscoveryByType.do?type=' + req.query.type,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getDiscoveryByType2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/discovery/getDiscoveryByType.do?type=' + req.query.type + '&pageSize=' + req.query.pageSize + '&pageIndex=' + req.query.pageIndex
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.homePageView = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/homePage/view.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getVideosByCategoryId2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/video/getVideosByCategoryId.do?categoryId=' + req.query.categoryId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.shortViewToken = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/picture/batchUpload/token.do?uid=' + req.query.uid + '&token=' + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
/*百度站长主动推送*/
exports.baiduFun = function(req, res, next) {
	request.get({
			url: 'http://data.zz.baidu.com/urls?site=' + req.query.site + '&token=' + req.query.token,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.createLive2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/live/createLive.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				topic: req.body.topic,
				columnId: req.body.columnId,
				coverUrl: req.body.coverUrl,
				device: req.body.device,
				openness: req.body.openness,
				authCode: req.body.authCode,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.publishV3 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/video/publish.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				coverUrl: req.body.coverUrl,
				topic: req.body.topic,
				device: req.body.device,
				type: req.body.type,
				columnId: req.body.columnId,
				duration: req.body.duration
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getUserLiveRoomList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/live/getUserLiveRoomList.do?liverUid=' + req.query.liverUid + '&type=' + req.query.type + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.updateRoomInfo = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/updateRoomInfo.do',
			form: {
				token: req.body.token,
				uid: req.body.uid,
				roomId: req.body.roomId,
				name: req.body.name,
				topic: req.body.topic,
				description: req.body.description,
				descriptionImgUrl: req.body.descriptionImgUrl,
				coverUrl: req.body.coverUrl,
				subscribeType: req.body.subscribeType,
				subscribePay: req.body.subscribePay,
				subscribeCycle: req.body.subscribeCycle,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.createVipRoom = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/createVipRoom.do',
			form: {
				token: req.body.token,
				uid: req.body.uid,
				name: req.body.name,
				topic: req.body.topic,
				description: req.body.description,
				descriptionImgUrl: req.body.descriptionImgUrl,
				coverUrl: req.body.coverUrl,
				subscribeType: req.body.subscribeType,
				subscribePay: req.body.subscribePay,
				subscribeCycle: req.body.subscribeCycle,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.saveRoomAnnouncement = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/saveRoomAnnouncement.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				roomId: req.body.roomId,
				content: req.body.content,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getRoomAnnouncementList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/live/getRoomAnnouncementList.do?roomId=' + req.query.roomId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.delRoomAnnouncement = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/delRoomAnnouncement.do',
			form: {
				uid: req.body.uid,
				id: req.body.id,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getLiveRoomInfo = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/getLiveRoomInfo.do',
			form: {
				roomId: req.body.roomId
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLiveRoomInfo1 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/getLiveRoomInfo.do',
			form: {
				roomId: req.body.roomId,
				uid: req.body.uid,
				token: req.body.token
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.createLive3 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/createLive.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				topic: req.body.topic,
				roomId: req.body.roomId,
				coverUrl: req.body.coverUrl,
				device: req.body.device
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.createLive4 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/createLive.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				topic: req.body.topic,
				roomId: req.body.roomId,
				coverUrl: req.body.coverUrl,
				device: req.body.device,
				openness: req.body.openness,
				authCode: req.body.authCode
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				console.log("liveTopic");
				console.log(req.body.topic);
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getColumnByObjectId = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/column/getColumnByObjectId.do?objectId=' + req.query.objectId + '&type=' + req.query.type,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getVideoLiveRoomList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/live/getVideoLiveRoomList.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
//				var userData = JSON.parse(data).toJSONString();
				var userData1 = ctrlConfig.compileStr(data);
				res.send(userData1);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLiveRoomMsgByUid = function(req, res, next) {
	var url;
	if(req.query.id) {
		url = fntv_api_address + '/api/v3/liveRoomMsg/getLiveRoomMsgByUid.do?id=' + req.query.id + '&liveRoomId=' + req.query.liveRoomId + '&msgType=' + req.query.msgType + '&uid=' + req.query.uid + '&pageSize=' + req.query.pageSize;
	} else {
		url = fntv_api_address + '/api/v3/liveRoomMsg/getLiveRoomMsgByUid.do?liveRoomId=' + req.query.liveRoomId + '&msgType=' + req.query.msgType + '&uid=' + req.query.uid + '&pageSize=' + req.query.pageSize;
	};
	request.get({
			url: url,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.saveMsg = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/liveRoomMsg/saveMsg.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				liveRoomId: req.body.liveRoomId,
				content: req.body.content,
				type: req.body.type,
				msgType: req.body.msgType
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getColumnByUidV3 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/column/getColumnByUid.do',
			form: {
				uid: req.body.uid,
				type: req.body.type,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.editLive1 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/live/edit.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				coverUrl: req.body.coverUrl,
				topic: req.body.topic
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.editLive2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/live/edit.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
				coverUrl: req.body.coverUrl,
				topic: req.body.topic,
				openness: req.body.openness,
				authCode: req.body.authCode
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getHotLiveRoomList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/live/getHotLiveRoomList.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
//				var userData = JSON.parse(data);
//				res.send(userData);
         		var userData = ctrlConfig.compileStr(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getDiscovery2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/discovery/getDiscovery2.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getSpecialLive = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/live/getSpecialLive.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLivePlayUrl = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/getLivePlayUrl.do',
			form: {
				roomId: req.body.roomId
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLivePlayUrl1 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/getLivePlayUrl.do',
			form: {
				roomId: req.body.roomId,
				authCode: req.body.authCode
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLivePlayUrl2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/getLivePlayUrl.do',
			form: {
				roomId: req.body.roomId,
				uid: req.body.uid,
				token: req.body.token
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLivePlayUrl3 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/live/getLivePlayUrl.do',
			form: {
				roomId: req.body.roomId,
				authCode: req.body.authCode,
				uid: req.body.uid,
				token: req.body.token
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getLiverDynamicListByAuthor1 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/dynamic/getLiverDynamicListByAuthor.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteMsg = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/liveRoomMsg/deleteMsg.do',
			form: {
				uid: req.body.uid,
				id: req.body.id,
				token: req.body.token
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteMsg2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/liveRoomMsg/deleteMsg.do',
			form: {
				uid: req.body.uid,
				id: req.body.id,
				token: req.body.token,
				objectId: req.body.objectId
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

// 热门动态相关接口
exports.selectDynamicHotPagingV2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/dynamicHot/selectDynamicHotPaging.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getDynamicListV3 = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
		token: req.body.token,
		pageIndex: req.body.pageIndex,
		pageSize: req.body.pageSize
	};
	request.post({
			url: fntv_api_address + '/api/v3/dynamic/getDynamicList.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getTagList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/tag/getTagList.do?tagId=' + req.query.tagId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTagContent = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/tag/getTagContent.do?uid=' + req.query.uid + '&tagId=' + req.query.tagId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectReceptorV2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/user/selectReceptor.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getVideoLivePlaybackInfo = function(req, res, next) {
	var formData = {
		id: req.body.id
	};
	request.post({
			url: fntv_api_address + '/api/v3/live/getVideoLivePlaybackInfo.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getVideoLivePlaybackInfo2 = function(req, res, next) {
	var formData = {
		id: req.body.id,
		authCode: req.body.authCode,
	};
	request.post({
			url: fntv_api_address + '/api/v3/live/getVideoLivePlaybackInfo.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideoLivePlaybackInfo3 = function(req, res, next) {
	var formData = {
		id: req.body.id,
		uid: req.body.uid,
		token: req.body.token
	};
	request.post({
			url: fntv_api_address + '/api/v3/live/getVideoLivePlaybackInfo.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideoLivePlaybackInfo4 = function(req, res, next) {
	var formData = {
		id: req.body.id,
		uid: req.body.uid,
		token: req.body.token
	};
	request.post({
			url: fntv_api_address + '/api/v3/live/getVideoLivePlaybackInfo.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getVideoLivePlaybackInfo5 = function(req, res, next) {
	var formData = {
		id: req.body.id,
		uid: req.body.uid,
		token: req.body.token,
		authCode: req.body.authCode
	};
	request.post({
			url: fntv_api_address + '/api/v3/live/getVideoLivePlaybackInfo.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.insert1 = function(req, res, next) {
	var formData = {
		objectId: req.body.objectId,
		uid: req.body.uid,
		token: req.body.token,
		type: req.body.type
	};
	request.post({
			url: fntv_api_address + '/api/v2/subscribe/insert.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.deleteSubscribe = function(req, res, next) {
	var formData = {
		objectId: req.body.objectId,
		uid: req.body.uid,
		token: req.body.token,
		type: req.body.type
	};
	request.post({
			url: fntv_api_address + '/api/v3/subscribe/deleteSubscribe.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getVideoLivePlaybackList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/live/getVideoLivePlaybackList.do?roomId=' + req.query.roomId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getDiscovery3 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/ discovery/getDiscovery3.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/columnCategory/getList.do?type=' + req.query.type + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getColumnListByCategoryId = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/column/getColumnListByCategoryId.do?categoryId=' + req.query.categoryId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getDiscovery1 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/ discovery/getDiscovery1.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getLabelList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/homePage/label/getLabelList.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getLabelFlow = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/homePage/label/getLabelFlow.do?labelId=' + req.query.labelId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.homeV2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/homePage/home.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.selectLatelyByTarget = function(req, res, next) {
	var formData = {
		target: req.body.target
	};
	request.post({
			url: fntv_api_address + '/api/v2/journal/selectLatelyByTarget.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.insert2 = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
		token: req.body.token,
		comment: req.body.comment,
		objectId: req.body.objectId,
		parentId: req.body.parentId,
		type: req.body.type,
		commentType: req.body.commentType,
		authorId: req.body.authorId
	};
	request.post({
			url: fntv_api_address + '/api/v3/comment/insert.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getCommentByObjId1 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/comment/getCommentByObjId.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&objectId=' + req.query.objectId,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getCommentByObjId2 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/comment/getCommentByObjId.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&objectId=' + req.query.objectId + '&uid=' + req.query.uid,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.selectSubscribe = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
		objectId: req.body.objectId,
		type: req.body.type,
		token: req.body.token,
	};
	request.post({
			url: fntv_api_address + '/api/v2/subscribe/selectSubscribe.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getFreeLook = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/column/getFreeLook.do?columnId=' + req.query.columnId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getColumnContent = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/column/getColumnContent.do?columnId=' + req.query.columnId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.setFreeLook = function(req, res, next) {
	var formData = {
		id: req.body.id,
		type: req.body.type,
		columnId: req.body.columnId,
	};
	request.post({
			url: fntv_api_address + '/api/v3/column/setFreeLook.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.insertColumn = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
		objectId: req.body.objectId,
		type: req.body.type,
		token: req.body.token,
	};
	request.post({
			url: fntv_api_address + '/api/v2/subscribe/insert.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.wxUnifiedOrderBusLive = function(req, res, next) {
	var formData = {
		uid: req.body.uid,
		totalFee: req.body.totalFee,
		tradeType: req.body.tradeType,
		payType: req.body.payType,
		roomId: req.body.roomId,
		token: req.body.token,
	};
	request.post({
			url: fntv_api_address + '/api/v3/order/wxUnifiedOrderBusLive.do',
			form: formData
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var result = JSON.parse(data);
				res.send(result);
			} else {
				console.log(response.statusCode);
			}
		}
	)
};

exports.wxFrontNotifyBusLive = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/order/wxFrontNotifyBusLive.do',
			form: {
				uid: req.body.uid,
				outTradeNo: req.body.outTradeNo,
				tradeType: req.body.tradeType,
				roomId: req.body.roomId,
				token: req.body.token
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getSubjectContentList = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/subject/getSubjectContentList.do?subjectId=' + req.query.subjectId + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.deleteV2 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/video/delete.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				id: req.body.id,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.url = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/document/download/url.do?id=' + req.query.id,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getSubjectDetail = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v2/subject/getSubjectDetail.do?subjectId=' + req.query.subjectId,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getSendCommentByUid = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/comment/getSendCommentByUid.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getReceiveCommentByUid = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/comment/getReceiveCommentByUid.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getMsgNum = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/msgCenter/getMsgNum.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				type: req.body.type,
				lastTime: req.body.lastTime,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getLiveRoomMsgList = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/msgCenter/getLiveRoomMsgList.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getLikeList = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/msgCenter/getLikeList.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getPrivateLetter = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/msgCenter/getPrivateLetter.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				senderUid: req.body.senderUid,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getOfficialLetterList = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/msgCenter/getOfficialLetterList.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.checkAndSaveOfficialLetter = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/msgCenter/checkAndSaveOfficialLetter.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				lastTime: req.body.lastTime
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getUnreadCount = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/msgCenter/getUnreadCount.do',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				commentTime: req.body.commentTime,
				likeTime: req.body.likeTime,
				roomMsgTime: req.body.roomMsgTime,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getContestRoom = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/live/getContestRoom.do',
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.eventDynamics = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/homePage/eventDynamics.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.selectMySubscribe = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v3/subscribe/selectMySubscribe.do',
			form: {
				uid: req.body.uid,
				type: req.body.type,
				objectType: req.body.objectType,
				status: req.body.status,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
				token: req.body.token,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.sendSmsV1 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v1/user/userVerification/sendSms.do?type=' + req.query.type + '&mobile=' + req.query.mobile + '&smsToken=' + req.query.smsToken,
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
// 动态相关接口
exports.getLiverDynamicListByAuthorV3 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/dynamic/getLiverDynamicListByAuthor.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&userId=' + req.query.userId,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
// 动态相关接口
exports.getDynamicByTypeV3 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/dynamic/getDynamicByType.do?uid=' + req.query.uid + '&pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&userId=' + req.query.userId + '&dynamicType=' + req.query.dynamicType,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.saveOrUpdate1 = function(req, res, next) {
	request.post({
			url: fntv_api_address + '/api/v2/article/saveOrUpdate.do',
			form: {
				uid: req.body.uid,
				type: req.body.type,
				token: req.body.token,
				content: req.body.content,
				title: req.body.title,
				media: req.body.media,
				id: req.body.id,
				userCoverUrl: req.body.userCoverUrl,
				lead: req.body.lead,
				columnId: req.body.columnId
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

/*网信杯*/
exports.getTzsColumn = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/column/getTzsColumn.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getCarouselList = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/common-service/api/v1/carousel/getCarouselList',
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getPopularityRank = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/common-service/api/v1/joiner/getPopularityRank?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getTeamPopularityRank = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/common-service/api/v1/school/getTeamPopularityRank?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getVideosByParams = function(req, res, next) {
	request.post({
			url: fntv_api_address_tzs + '/common-service/api/v1/video/getVideosByParams',
			form: {
				uid: req.body.uid,
				userId: req.body.userId,
				isRec: req.body.isRec,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getJoinerInfo = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/common-service/api/v1/joiner/getJoinerInfo?objectId=' + req.query.objectId + '&uid=' + req.query.uid,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRedCarouselList = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/common-service/api/v1/carousel/getRedCarouselList',
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.record = function(req, res, next) {
	request.post({
			url: fntv_api_address_tzs + '/luckydraw-service/api/v1/lottery/record',
			form: {
				activityId: req.body.activityId,
				token: req.body.token,
				sign: req.body.sign,
				status: req.body.status,
				uid: req.body.uid,
				prizeType: req.body.prizeType,
				pageIndex: req.body.pageIndex,
				pageSize: req.body.pageSize,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getProvinces = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/common-service/api/v1/entered/getProvinces',
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getSchool = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/common-service/api/v1/entered/getSchool?pid=' + req.query.pid,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.toEntered = function(req, res, next) {
	request.post({
			url: fntv_api_address_tzs + '/common-service/api/v1/entered/toEntered',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				pid: req.body.pid,
				sid: req.body.sid,
				realName: req.body.realName,
				authCode: req.body.authCode,
				mobile: req.body.mobile,
				smsToken: req.body.smsToken,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getRedBag = function(req, res, next) {
	request.post({
			url: fntv_api_address_tzs + '/common-service/api/v1/entered/getRedBag',
			form: {
				uid: req.body.uid,
				token: req.body.token,
				sign: req.body.sign,
			}
		},
		function(error, response, data) {
			if(response.statusCode == 200) {
				var userData = JSON.parse(data);
				res.send(userData);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getProfitRank = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/trade-service/api/v1/trade/getProfitRank?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getPositionV4 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v4/fo/getPosition.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&traderId=' + req.query.traderId + '&uid=' + req.query.uid,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getTransferRecordsV4 = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v4/fo/getTransferRecords.do?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize + '&traderId=' + req.query.traderId + '&uid=' + req.query.uid,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getSubscribeCharge = function(req, res, next) {
	request.get({
			url: fntv_api_address + '/api/v3/subscribe/getSubscribeCharge.do?objectId=' + req.query.objectId + '&objectType=' + req.query.objectType,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.begin = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/luckydraw-service/api/v1/lottery/begin',
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.getInviteInfoService = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/common-service/api/v1/user/getInviteInfo?uid=' + req.query.uid,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};

exports.getTeamProfitRank = function(req, res, next) {
	request.get({
			url: fntv_api_address_tzs + '/trade-service/api/v1/trade/getTeamProfitRank?pageIndex=' + req.query.pageIndex + '&pageSize=' + req.query.pageSize,
		},
		function(error, response, result) {
			if(response.statusCode == 200) {
				var data = JSON.parse(result);
				res.send(data);
			} else {
				console.log(response.statusCode);
			}
		}
	);
};
exports.bindingMobileV4 = function (req, res, next) {
    var formData = {
        uid: req.body.uid,
        token: req.body.token,
        mobile: req.body.mobile,
        authCode: req.body.authCode
    };
    request.post(
        {
            url: fntv_api_address + '/api/v1/user/bindingMobileV4.do',
            form: formData
        },
        function (error, response, data) {
            console.log(formData);
            if (response.statusCode == 200) {
                var result = JSON.parse(data);
                res.send(result);
                if(result.code == 0) {
					req.session.user = result;
				};
            } else {
                console.log(response.statusCode);
            }
        }
    )
};

exports.getTraderProfitByType = function(req, res, next) {
    request.get({
            url: fntv_api_address + '/api/v4/fo/getTraderProfitByType.do?uid=' + req.query.uid + '&type=' + req.query.type + '&date=' + req.query.date + '&season=' + req.query.season,
        },
        function(error, response, result) {
            if(response.statusCode == 200) {
                var data = JSON.parse(result);
                res.send(data);
            } else {
                console.log(response.statusCode);
            }
        }
    );
};