//------------------记得改第三方登录的配置

 //疯牛直播主项目
exports.fntv_api_address = 'https://www.fntv8.com/fntv';
exports.fntv_domain = 'https://www.fntv8.com';

// exports.fntv_api_address = 'http://192.168.9.21:8080/fntv/';
// exports.fntv_domain = 'http://192.168.9.21:8080';

exports.fntv_api_address_tzs = ' https://www.fntv8.com/tzs';
exports.fntv_domain_tzs = 'https://www.fntv8.com';


exports.compileStr=function(code) { //对字符串进行加密
	console.log("codecodecode");
	console.log(code);
    var c = String.fromCharCode(code.charCodeAt(0) + code.length);
    for (var i = 1; i < code.length; i++) {
        c += String.fromCharCode(code.charCodeAt(i) + code.charCodeAt(i - 1));
    }
    return escape(c);
}
